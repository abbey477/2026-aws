package com.example.dbtester.repository.oracle;

import com.example.dbtester.entity.Product;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * JDBC CRUD for Oracle PRODUCT.
 * Primary keys come from PRODUCT_SEQ — we fetch NEXTVAL explicitly.
 */
@Repository
public class ProductRepository {

    private static final int BATCH_SIZE = 500;

    private static final String SQL_NEXT_ID = "SELECT PRODUCT_SEQ.NEXTVAL FROM DUAL";
    private static final String SQL_FIND_ALL = "SELECT id, sku, name, price, in_stock FROM PRODUCT";
    private static final String SQL_FIND_BY_ID = "SELECT id, sku, name, price, in_stock FROM PRODUCT WHERE id = ?";
    private static final String SQL_INSERT = "INSERT INTO PRODUCT (id, sku, name, price, in_stock) VALUES (?, ?, ?, ?, ?)";
    private static final String SQL_UPDATE = "UPDATE PRODUCT SET sku = ?, name = ?, price = ?, in_stock = ? WHERE id = ?";
    private static final String SQL_DELETE = "DELETE FROM PRODUCT WHERE id = ?";

    private final JdbcTemplate jdbc;
    private final ProductRowMapper rowMapper = new ProductRowMapper();

    public ProductRepository(@Qualifier("oracleJdbcTemplate") JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    // ---- Read ----

    public List<Product> findAll() {
        return jdbc.query(SQL_FIND_ALL, rowMapper);
    }

    public Optional<Product> findById(Long id) {
        return jdbc.query(SQL_FIND_BY_ID, rowMapper, id).stream().findFirst();
    }

    // ---- Write (single row) ----

    public Product insert(Product p) {
        Long id = jdbc.queryForObject(SQL_NEXT_ID, Long.class);
        jdbc.update(SQL_INSERT, id, p.sku(), p.name(), p.price(), p.inStock() ? 1 : 0);
        return findById(id).orElseThrow();
    }

    public int update(Long id, Product p) {
        return jdbc.update(SQL_UPDATE, p.sku(), p.name(), p.price(), p.inStock() ? 1 : 0, id);
    }

    public int delete(Long id) {
        return jdbc.update(SQL_DELETE, id);
    }

    // ---- Write (batch) ----
    // Each batch method chunks by BATCH_SIZE to keep memory bounded.

    public List<Long> insertAll(List<Product> products) {
        List<Long> ids = new ArrayList<>(products.size());
        List<Object[]> rows = new ArrayList<>(products.size());

        for (Product p : products) {
            Long id = jdbc.queryForObject(SQL_NEXT_ID, Long.class);
            ids.add(id);
            rows.add(new Object[]{id, p.sku(), p.name(), p.price(), p.inStock() ? 1 : 0});
        }

        batchInChunks(SQL_INSERT, rows);
        return ids;
    }

    public int updateAll(List<Product> products) {
        List<Object[]> rows = new ArrayList<>(products.size());
        for (Product p : products) {
            rows.add(new Object[]{p.sku(), p.name(), p.price(), p.inStock() ? 1 : 0, p.id()});
        }
        return batchInChunks(SQL_UPDATE, rows);
    }

    public int deleteAll(List<Long> ids) {
        List<Object[]> rows = new ArrayList<>(ids.size());
        for (Long id : ids) {
            rows.add(new Object[]{id});
        }
        return batchInChunks(SQL_DELETE, rows);
    }

    /** Run a batchUpdate in BATCH_SIZE chunks; return total rows affected. */
    private int batchInChunks(String sql, List<Object[]> rows) {
        int total = 0;
        for (int i = 0; i < rows.size(); i += BATCH_SIZE) {
            List<Object[]> chunk = rows.subList(i, Math.min(i + BATCH_SIZE, rows.size()));
            int[] counts = jdbc.batchUpdate(sql, chunk);
            for (int c : counts) {
                total += (c >= 0) ? c : 1;
            }
        }
        return total;
    }
}
