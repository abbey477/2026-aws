# CheckJobStatus Lambda

Unified status poller that checks the status of a running job regardless of runner type (ECS Fargate or Databricks). Called every 60 seconds by a Step Functions poll loop.

## Project structure

```
check-job-status/
├── src/
│   └── check_job_status/
│       ├── __init__.py
│       ├── handler.py              # Lambda entry point (thin router)
│       ├── ecs_status.py           # ECS Fargate status check logic
│       ├── databricks_status.py    # Databricks status check logic
│       └── log_to_dynamo.py        # Shared DynamoDB logger (INFO/WARN/ERROR)
├── test/
│   ├── __init__.py
│   ├── conftest.py                 # Shared pytest fixtures (auto-mock DynamoDB)
│   ├── helpers.py                  # Constants, event builders, mock factories
│   ├── test_ecs_status.py          # 7 tests for ECS status checks
│   ├── test_databricks_status.py   # 10 tests for Databricks status checks
│   └── test_handler.py            # 13 tests for handler routing/validation
├── Makefile
├── poetry.toml
├── pyproject.toml
└── README.md
```

## Prerequisites

- Python 3.9+
- [Poetry](https://python-poetry.org/docs/#installation)

## Setup

```bash
cd check-job-status
make install
```

Or without Make:

```bash
poetry install
```

## Running tests

Run all 30 tests:

```bash
make test
```

Run with verbose output:

```bash
make test-verbose
```

Run with coverage report:

```bash
make test-cov
```

### Without Poetry / Make

```bash
python -m venv .venv
source .venv/bin/activate
pip install pytest boto3 botocore
PYTHONPATH=src:. pytest test/ -v
```

### Run a specific test file

```bash
poetry run pytest test/test_ecs_status.py -v
poetry run pytest test/test_databricks_status.py -v
poetry run pytest test/test_handler.py -v
```

### Run a single test

```bash
poetry run pytest test/test_ecs_status.py::TestCheckEcsTaskStatus::test_stopped_all_success -v
```

## What the tests cover

**ECS tests** (`test_ecs_status.py` — 7 tests): task stopped with success, task stopped with error, task still running, task not found, AWS ClientError, multiple containers all success, multiple containers mixed exit codes.

**Databricks tests** (`test_databricks_status.py` — 10 tests): terminated with success, terminated with failed, still running, pending state, terminating state, unexpected lifecycle state, HTTP error, URL error, correct API URL construction, terminated with timeout.

**Handler tests** (`test_handler.py` — 13 tests): ECS path success/running/failed, missing task_arn, preserves event fields (ECS), DBR path success/running/failed, missing dbr_run_id, preserves event fields (DBR), unsupported/missing/empty runner_type.

## How it works

The `lambda_handler` in `handler.py` receives a Step Functions event, checks `trigger_result.runner_type`, and routes to:

- `ecs_status.check_ecs_task_status()` — calls `describe_tasks` via boto3
- `databricks_status.check_databricks_job_status()` — calls the Databricks REST API

Both return a dict with `job_status` (SUCCESS, RUNNING, or FAILED). The handler updates `trigger_result` and logs the outcome to DynamoDB via `log_to_dynamo` using the appropriate level:

- `write_log_info()` — normal events (STARTED, RUNNING, SUCCESS)
- `write_log_warn()` — unexpected but non-fatal situations
- `write_log_error()` — failures

## Notes

- All tests mock external dependencies (AWS, Databricks API, DynamoDB) — no credentials or network needed.
- `conftest.py` auto-mocks the DynamoDB log writer globally so no test hits a real table.
- `helpers.py` contains reusable event builders and mock factories shared across test files.
