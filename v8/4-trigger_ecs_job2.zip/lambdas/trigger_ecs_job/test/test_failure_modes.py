"""
Failure mode tests for trigger_ecs_task.

Coverage:
  - RunTask returns empty tasks list (placement failure)
  - Generic ClientError from RunTask
  - InvalidParameterException — the 8 KB overrides overrun
  - ClusterNotFoundException
  - AccessDeniedException
"""

from trigger_ecs_job.ecs_trigger import trigger_ecs_task
from conftest import make_event, mock_ecs_client_no_tasks, mock_ecs_client_with_error


class TestFailureModes:

    def test_no_tasks_returned_trigger_failed(self):
        """RunTask returns empty tasks list — should mark TRIGGER_FAILED."""
        mock_ecs = mock_ecs_client_no_tasks()
        event = make_event()
        job_config = event["job_config"]
        job_param = job_config["job_param"]

        result = trigger_ecs_task(mock_ecs, job_config, job_param, "run-001")

        assert result["trigger_status"] == "TRIGGER_FAILED"
        assert result["task_arn"] == ""
        assert "RESOURCE:MEMORY" in result["error"]

    def test_generic_client_error_trigger_failed(self):
        """Generic ClientError — should mark TRIGGER_FAILED with error message."""
        mock_ecs = mock_ecs_client_with_error(
            code="InternalServerError",
            message="Something went wrong.",
        )
        event = make_event()
        job_config = event["job_config"]
        job_param = job_config["job_param"]

        result = trigger_ecs_task(mock_ecs, job_config, job_param, "run-001")

        assert result["trigger_status"] == "TRIGGER_FAILED"
        assert result["task_arn"] == ""
        assert "InternalServerError" in result["error"]

    def test_invalid_parameter_exception_8kb_overrun(self):
        """The 8 KB overrides overrun scenario — InvalidParameterException."""
        mock_ecs = mock_ecs_client_with_error(
            code="InvalidParameterException",
            message="Container overrides length must be at most 8192",
        )
        event = make_event()
        job_config = event["job_config"]
        job_param = job_config["job_param"]

        result = trigger_ecs_task(mock_ecs, job_config, job_param, "run-001")

        assert result["trigger_status"] == "TRIGGER_FAILED"
        assert result["task_arn"] == ""
        assert "InvalidParameterException" in result["error"]
        assert "8192" in result["error"]

    def test_cluster_not_found_exception(self):
        """ClusterNotFoundException — should mark TRIGGER_FAILED."""
        mock_ecs = mock_ecs_client_with_error(
            code="ClusterNotFoundException",
            message="Cluster not found.",
        )
        event = make_event()
        job_config = event["job_config"]
        job_param = job_config["job_param"]

        result = trigger_ecs_task(mock_ecs, job_config, job_param, "run-001")

        assert result["trigger_status"] == "TRIGGER_FAILED"
        assert "ClusterNotFoundException" in result["error"]

    def test_access_denied_exception(self):
        """AccessDeniedException — should mark TRIGGER_FAILED."""
        mock_ecs = mock_ecs_client_with_error(
            code="AccessDeniedException",
            message="User is not authorized.",
        )
        event = make_event()
        job_config = event["job_config"]
        job_param = job_config["job_param"]

        result = trigger_ecs_task(mock_ecs, job_config, job_param, "run-001")

        assert result["trigger_status"] == "TRIGGER_FAILED"
        assert "AccessDeniedException" in result["error"]
