# DynamoDB Seed Data — Job Orchestration Platform (v2)

Test data for three DynamoDB tables: **`app-jobConfig`**, **`app-jobRun`**, **`app-jobLog`**.

## Contents

| File | Items | Target table |
|---|---|---|
| `app-jobConfig_part1_of_1.json` | 15 | `app-jobConfig` |
| `app-jobRun_part1_of_2.json` | 25 | `app-jobRun` |
| `app-jobRun_part2_of_2.json` | 25 | `app-jobRun` |
| `app-jobLog_part1_of_4.json` | 25 | `app-jobLog` |
| `app-jobLog_part2_of_4.json` | 25 | `app-jobLog` |
| `app-jobLog_part3_of_4.json` | 25 | `app-jobLog` |
| `app-jobLog_part4_of_4.json` | 25 | `app-jobLog` |
| `load_all.sh` | — | Bash runner (macOS / Linux / WSL) |
| `load_all.ps1` | — | PowerShell runner (Windows) |

**Totals:** 15 configs, 50 runs, 100 logs. Run status mix: 25 SUCCESS, 10 FAILED, 8 RUNNING, 7 WAITING.

## Prerequisites

1. AWS CLI installed and configured: `aws configure`
2. Tables must already exist with these keys:
   - `app-jobConfig`: PK `job_id` (S), SK `job_type` (S)
   - `app-jobRun`: PK `run_id` (S), SK `last_updated_time` (S)
   - `app-jobLog`: PK `run_id` (S), SK `time` (S)

## Usage

### macOS / Linux / WSL

```bash
chmod +x load_all.sh
./load_all.sh --dry-run   # preview
./load_all.sh             # load
```

### Windows PowerShell

```powershell
.\load_all.ps1 -DryRun
.\load_all.ps1
```

### Manual (no script)

```bash
for f in app-jobConfig_part*.json app-jobRun_part*.json app-jobLog_part*.json; do
  aws dynamodb batch-write-item --request-items file://$f
done
```

## Verify the load

```bash
aws dynamodb scan --table-name app-jobConfig --select COUNT
aws dynamodb scan --table-name app-jobRun    --select COUNT
aws dynamodb scan --table-name app-jobLog    --select COUNT
```

Expected: **15**, **50**, **100**.

## What's in the data

**15 configs** form three parallel three-stage pipelines (sourcing → silver_load → gold_load) for `client`, `country`, `currency`, and `product` subjects, plus three standalone jobs:
- `trade_ref` — ADHOC sourcing
- `dq_check` — scheduled validation
- `legacy_feed` — disabled (tests dispatcher skip behavior)

**50 runs** include:
- 5 complete end-to-end chains (15 runs) where sourcing → silver → gold, linked via `custom_attributes.parent_run_id`
- 10 FAILED runs with realistic errors (timeouts, IDA auth failures, OOM, merge conflicts, expiry overruns, DQ breaches)
- 8 RUNNING runs with fresh heartbeats and `expiry_time` set 5 minutes out (matches orchestrator behavior)
- 7 WAITING runs with `next_scheduled_run_time` in the near future (exercises the `statusCheck` GSI path)

**100 logs**: 2 per run, covering START/END for completed runs and START/HEARTBEAT or QUEUED/DISPATCH for in-flight ones.

## Notes

- `batch-write-item` caps at 25 items per call — that's why runs and logs are split across multiple files.
- `delete_at` (TTL) is set to a timestamp in Dec 2026; adjust if your TTL window matters.
- All data integrity is verified: every `jobRun.job_id` references a real `jobConfig`, every `jobLog.run_id` references a real `jobRun`, and all PK+SK pairs are unique per table.
- If `batch-write-item` returns `UnprocessedItems`, it's usually throttling — rerun the affected file.
