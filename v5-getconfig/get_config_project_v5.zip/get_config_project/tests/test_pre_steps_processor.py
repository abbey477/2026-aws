"""
Unit tests for PreStepsProcessor Lambda handler — v4.

Covers:
1. No pre_steps data scenarios (missing, None, empty, all-invalid).
2. Routing: known pre_step_types → correct handlers; unknown → unknown handler.
3. Output shape (v4): spread event + pre_steps_results dict per step type.
4. change_since_append DynamoDB query logic (success, no rows, ClientError).
"""

import copy
import pytest
import boto3
from moto import mock_aws
from unittest.mock import patch
from botocore.exceptions import ClientError

from lambdas.pre_steps_processor.handler import lambda_handler
from lambdas.pre_steps_processor.dynamodb_ops import (
    get_last_successful_run_start_time,
    pull_config_from_table,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_event(pre_steps=...) -> dict:
    """
    Build a minimal but realistic GetConfig-shaped event.

    pre_steps=... (Ellipsis) means "do not set pre_steps at all"
    pre_steps=None / [] / [...items...] are set as provided.
    """
    event = {
        "run_id": "run-001",
        "job_id": "client",
        "job_type": "sourcing",
        "status": "WAITING",
        "trigger_type": "SCHEDULER",
        "custom_attributes": {},
        "job_config": {
            "enabled": True,
            "job_runner": {"type": "ECS_Fargate", "name": "S2S3", "config": {}},
            "job_param": {},
            "next_jobs": [],
        },
    }
    if pre_steps is not ...:
        event["job_config"]["pre_steps"] = pre_steps
    return event


def _raise_access_denied(*args, **kwargs):
    """Helper: stub that raises a DynamoDB AccessDeniedException."""
    raise ClientError(
        {"Error": {"Code": "AccessDeniedException", "Message": "Denied"}},
        "Query",
    )


_HANDLER_PATH = "lambdas.pre_steps_processor.handler"


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def mocks():
    """
    Patch all four stub handlers (as seen from inside handler.py).
    Default return is {} so routing logic sees "no result to collect".
    """
    with patch(f"{_HANDLER_PATH}.handle_no_pre_steps", return_value={}) as no_data, \
         patch(f"{_HANDLER_PATH}.handle_change_since_append", return_value={}) as change_since, \
         patch(f"{_HANDLER_PATH}.handle_ddb_config_pull", return_value={}) as ddb_pull, \
         patch(f"{_HANDLER_PATH}.handle_unknown_pre_step", return_value={}) as unknown:
        yield {
            "no_data": no_data,
            "change_since": change_since,
            "ddb_pull": ddb_pull,
            "unknown": unknown,
        }


@pytest.fixture
def job_run_table():
    """
    Create a mocked job_run table WITH the GSI-2 jobIdQuery index, so the
    real change_since_append query can execute against moto.
    """
    with mock_aws():
        dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
        table = dynamodb.create_table(
            TableName="job_run",
            KeySchema=[{"AttributeName": "run_id", "KeyType": "HASH"}],
            AttributeDefinitions=[
                {"AttributeName": "run_id", "AttributeType": "S"},
                {"AttributeName": "job_id", "AttributeType": "S"},
                {"AttributeName": "start_time", "AttributeType": "S"},
            ],
            GlobalSecondaryIndexes=[
                {
                    "IndexName": "jobIdQuery",
                    "KeySchema": [
                        {"AttributeName": "job_id", "KeyType": "HASH"},
                        {"AttributeName": "start_time", "KeyType": "RANGE"},
                    ],
                    "Projection": {"ProjectionType": "ALL"},
                },
            ],
            BillingMode="PAY_PER_REQUEST",
        )
        yield table


@pytest.fixture
def config_tables():
    """
    Create mocked config tables (service_config, table_config) with
    the assumed two-part key: PK=job_id, SK=job_type.
    """
    with mock_aws():
        dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
        created = {}
        for name in ("service_config", "table_config"):
            t = dynamodb.create_table(
                TableName=name,
                KeySchema=[
                    {"AttributeName": "job_id", "KeyType": "HASH"},
                    {"AttributeName": "job_type", "KeyType": "RANGE"},
                ],
                AttributeDefinitions=[
                    {"AttributeName": "job_id", "AttributeType": "S"},
                    {"AttributeName": "job_type", "AttributeType": "S"},
                ],
                BillingMode="PAY_PER_REQUEST",
            )
            created[name] = t
        yield dynamodb, created


# ---------------------------------------------------------------------------
# No-data tests
# ---------------------------------------------------------------------------

class TestNoPreStepsData:
    """Every flavour of 'no data to iterate' should call handle_no_pre_steps."""

    def test_pre_steps_key_missing(self, mocks):
        lambda_handler(_make_event(), None)
        mocks["no_data"].assert_called_once()
        mocks["change_since"].assert_not_called()
        mocks["ddb_pull"].assert_not_called()
        mocks["unknown"].assert_not_called()

    def test_pre_steps_is_none(self, mocks):
        lambda_handler(_make_event(pre_steps=None), None)
        mocks["no_data"].assert_called_once()

    def test_pre_steps_is_empty_list(self, mocks):
        lambda_handler(_make_event(pre_steps=[]), None)
        mocks["no_data"].assert_called_once()

    def test_pre_steps_is_not_a_list(self, mocks):
        """String, dict, number etc. should be treated as no-data."""
        lambda_handler(_make_event(pre_steps="not-a-list"), None)
        mocks["no_data"].assert_called_once()

    def test_job_config_key_missing(self, mocks):
        """Even if job_config is missing entirely, we don't crash."""
        event = {"run_id": "run-001", "job_id": "client", "job_type": "sourcing"}
        lambda_handler(event, None)
        mocks["no_data"].assert_called_once()

    @pytest.mark.parametrize("invalid_step", [
        {},
        {"pre_step_type": None},
        {"pre_step_type": ""},
        {"pre_step_type": 123},
        {"other_field": "value"},
        "just-a-string",
        None,
    ])
    def test_items_without_valid_pre_step_type_treated_as_no_data(
        self, mocks, invalid_step,
    ):
        lambda_handler(_make_event(pre_steps=[invalid_step]), None)
        mocks["no_data"].assert_called_once()
        mocks["change_since"].assert_not_called()
        mocks["ddb_pull"].assert_not_called()
        mocks["unknown"].assert_not_called()


# ---------------------------------------------------------------------------
# Known routing
# ---------------------------------------------------------------------------

class TestKnownPreStepTypes:
    """Each known pre_step_type should route to its specific handler."""

    def test_change_since_append_calls_its_handler_with_event(self, mocks):
        step = {"pre_step_type": "change_since_append"}
        event = _make_event(pre_steps=[step])
        lambda_handler(event, None)

        # v4: change_since_append is now called with BOTH step and event
        mocks["change_since"].assert_called_once_with(step, event)
        mocks["ddb_pull"].assert_not_called()
        mocks["unknown"].assert_not_called()
        mocks["no_data"].assert_not_called()

    def test_ddb_config_pull_calls_its_handler(self, mocks):
        step = {
            "pre_step_type": "ddb_config_pull",
            "tables": ["service_config", "table_config"],
        }
        event = _make_event(pre_steps=[step])
        lambda_handler(event, None)

        # v5: ddb_config_pull is now called with BOTH step and event
        mocks["ddb_pull"].assert_called_once_with(step, event)
        mocks["change_since"].assert_not_called()
        mocks["unknown"].assert_not_called()
        mocks["no_data"].assert_not_called()

    def test_both_known_types_in_sequence(self, mocks):
        steps = [
            {"pre_step_type": "change_since_append"},
            {"pre_step_type": "ddb_config_pull", "tables": ["a", "b"]},
        ]
        event = _make_event(pre_steps=steps)
        lambda_handler(event, None)

        mocks["change_since"].assert_called_once_with(steps[0], event)
        mocks["ddb_pull"].assert_called_once_with(steps[1], event)
        mocks["unknown"].assert_not_called()
        mocks["no_data"].assert_not_called()

    def test_same_type_multiple_times(self, mocks):
        steps = [
            {"pre_step_type": "change_since_append"},
            {"pre_step_type": "change_since_append"},
        ]
        lambda_handler(_make_event(pre_steps=steps), None)
        assert mocks["change_since"].call_count == 2


# ---------------------------------------------------------------------------
# Unknown routing
# ---------------------------------------------------------------------------

class TestUnknownPreStepType:
    """Unknown types route to handle_unknown_pre_step, not a known handler."""

    def test_unknown_type_routes_to_unknown_handler(self, mocks):
        step = {"pre_step_type": "something_new"}
        lambda_handler(_make_event(pre_steps=[step]), None)

        mocks["unknown"].assert_called_once_with(step)
        mocks["change_since"].assert_not_called()
        mocks["ddb_pull"].assert_not_called()
        mocks["no_data"].assert_not_called()

    def test_mixed_known_and_unknown(self, mocks):
        steps = [
            {"pre_step_type": "change_since_append"},
            {"pre_step_type": "mystery_type"},
            {"pre_step_type": "ddb_config_pull", "tables": []},
        ]
        event = _make_event(pre_steps=steps)
        lambda_handler(event, None)

        mocks["change_since"].assert_called_once_with(steps[0], event)
        mocks["unknown"].assert_called_once_with(steps[1])
        mocks["ddb_pull"].assert_called_once_with(steps[2], event)
        mocks["no_data"].assert_not_called()

    def test_mixed_valid_and_invalid_items(self, mocks):
        """Invalid items skipped; valid ones still route correctly."""
        steps = [
            {"pre_step_type": "change_since_append"},
            {},
            {"pre_step_type": ""},
            "not-a-dict",
            {"pre_step_type": "ddb_config_pull"},
        ]
        event = _make_event(pre_steps=steps)
        lambda_handler(event, None)

        mocks["change_since"].assert_called_once_with(steps[0], event)
        mocks["ddb_pull"].assert_called_once_with(steps[4], event)
        mocks["unknown"].assert_not_called()
        mocks["no_data"].assert_not_called()


# ---------------------------------------------------------------------------
# v4 Output shape — spread event + pre_steps_results dict
# ---------------------------------------------------------------------------

class TestOutputShape:
    """Output is {**event, 'pre_steps_results': {...}}."""

    def test_output_includes_all_input_fields(self, mocks):
        event = _make_event(pre_steps=[{"pre_step_type": "change_since_append"}])
        snapshot = copy.deepcopy(event)

        result = lambda_handler(event, None)

        # All original event fields are preserved at the top level
        for key, value in snapshot.items():
            assert result[key] == value

    def test_output_has_pre_steps_results_key(self, mocks):
        result = lambda_handler(_make_event(pre_steps=[]), None)
        assert "pre_steps_results" in result
        assert isinstance(result["pre_steps_results"], dict)

    def test_empty_pre_steps_results_when_no_data(self, mocks):
        """No data path → pre_steps_results is empty dict."""
        result = lambda_handler(_make_event(), None)
        assert result["pre_steps_results"] == {}

    def test_handler_result_populates_pre_steps_results(self, mocks):
        """When a handler returns a non-empty dict, it shows up keyed by pre_step_type."""
        mocks["change_since"].return_value = {
            "last_successful_start_time": "2024-01-01T00:00:00Z",
            "placeholder": True,
        }

        result = lambda_handler(
            _make_event(pre_steps=[{"pre_step_type": "change_since_append"}]),
            None,
        )

        assert "change_since_append" in result["pre_steps_results"]
        assert result["pre_steps_results"]["change_since_append"] == {
            "last_successful_start_time": "2024-01-01T00:00:00Z",
            "placeholder": True,
        }

    def test_multiple_handlers_contribute_separate_keys(self, mocks):
        """
        v5: change_since_append still goes under pre_steps_results,
        but ddb_config_pull results now merge into job_param.
        """
        mocks["change_since"].return_value = {"a": 1}
        mocks["ddb_pull"].return_value = {"service_config": {"b": 2}}

        result = lambda_handler(
            _make_event(pre_steps=[
                {"pre_step_type": "change_since_append"},
                {"pre_step_type": "ddb_config_pull"},
            ]),
            None,
        )

        # change_since_append: under pre_steps_results
        assert result["pre_steps_results"] == {"change_since_append": {"a": 1}}

        # ddb_config_pull: merged into job_param
        assert result["job_config"]["job_param"]["service_config"] == {"b": 2}

        # ddb_config_pull should NOT appear under pre_steps_results
        assert "ddb_config_pull" not in result["pre_steps_results"]

    def test_empty_handler_result_not_added_to_output(self, mocks):
        """If a handler returns {}, its key shouldn't appear in results."""
        mocks["ddb_pull"].return_value = {}  # stub returns empty
        mocks["change_since"].return_value = {"something": "value"}

        result = lambda_handler(
            _make_event(pre_steps=[
                {"pre_step_type": "change_since_append"},
                {"pre_step_type": "ddb_config_pull"},
            ]),
            None,
        )

        assert "change_since_append" in result["pre_steps_results"]
        assert "ddb_config_pull" not in result["pre_steps_results"]
        # And nothing new should have been merged into job_param
        assert result["job_config"]["job_param"] == _make_event()["job_config"]["job_param"]


# ---------------------------------------------------------------------------
# get_last_successful_run_start_time — real query logic
# ---------------------------------------------------------------------------

class TestGetLastSuccessfulRunStartTime:
    """Direct tests for the GSI-2 query helper."""

    def test_returns_start_time_of_most_recent_success(self, job_run_table):
        """
        Seed three runs for job_id=client, job_type=sourcing:
        - old success
        - newer failed
        - newest success
        Query should return the NEWEST SUCCESS start_time.
        """
        job_run_table.put_item(Item={
            "run_id": "r1", "job_id": "client", "job_type": "sourcing",
            "status": "SUCCESS", "start_time": "2024-01-01T00:00:00Z",
        })
        job_run_table.put_item(Item={
            "run_id": "r2", "job_id": "client", "job_type": "sourcing",
            "status": "FAILED", "start_time": "2024-02-01T00:00:00Z",
        })
        job_run_table.put_item(Item={
            "run_id": "r3", "job_id": "client", "job_type": "sourcing",
            "status": "SUCCESS", "start_time": "2024-03-01T00:00:00Z",
        })

        result = get_last_successful_run_start_time(
            table=job_run_table, job_id="client", job_type="sourcing",
        )
        assert result == "2024-03-01T00:00:00Z"

    def test_ignores_other_job_types(self, job_run_table):
        """Runs with the same job_id but different job_type shouldn't match."""
        job_run_table.put_item(Item={
            "run_id": "r1", "job_id": "client", "job_type": "sourcing",
            "status": "SUCCESS", "start_time": "2024-01-01T00:00:00Z",
        })
        job_run_table.put_item(Item={
            "run_id": "r2", "job_id": "client", "job_type": "other_type",
            "status": "SUCCESS", "start_time": "2024-06-01T00:00:00Z",
        })

        result = get_last_successful_run_start_time(
            table=job_run_table, job_id="client", job_type="sourcing",
        )
        assert result == "2024-01-01T00:00:00Z"

    def test_ignores_non_success_statuses(self, job_run_table):
        """Only SUCCESS should be returned."""
        job_run_table.put_item(Item={
            "run_id": "r1", "job_id": "client", "job_type": "sourcing",
            "status": "FAILED", "start_time": "2024-05-01T00:00:00Z",
        })
        job_run_table.put_item(Item={
            "run_id": "r2", "job_id": "client", "job_type": "sourcing",
            "status": "RUNNING", "start_time": "2024-06-01T00:00:00Z",
        })

        result = get_last_successful_run_start_time(
            table=job_run_table, job_id="client", job_type="sourcing",
        )
        assert result is None

    def test_returns_none_when_no_rows(self, job_run_table):
        """Brand-new job with no runs at all — placeholder None returned."""
        result = get_last_successful_run_start_time(
            table=job_run_table, job_id="never-ran", job_type="sourcing",
        )
        assert result is None

    def test_client_error_propagates(self, monkeypatch, job_run_table):
        """ClientError from DynamoDB surfaces to caller, not swallowed."""
        monkeypatch.setattr(job_run_table, "query", _raise_access_denied)

        with pytest.raises(ClientError):
            get_last_successful_run_start_time(
                table=job_run_table, job_id="client", job_type="sourcing",
            )


# ---------------------------------------------------------------------------
# pull_config_from_table — real query logic
# ---------------------------------------------------------------------------

class TestPullConfigFromTable:
    """Direct tests for the ddb_config_pull helper."""

    def test_returns_row_when_found(self, config_tables):
        _, tables = config_tables
        service = tables["service_config"]
        service.put_item(Item={
            "job_id": "client", "job_type": "sourcing",
            "some_setting": "value_x", "other": 42,
        })

        result = pull_config_from_table(
            table=service, table_name="service_config",
            job_id="client", job_type="sourcing",
        )

        assert result is not None
        assert result["some_setting"] == "value_x"
        assert result["other"] == 42

    def test_returns_none_when_not_found(self, config_tables):
        _, tables = config_tables
        result = pull_config_from_table(
            table=tables["service_config"], table_name="service_config",
            job_id="unknown", job_type="sourcing",
        )
        assert result is None

    def test_client_error_propagates(self, monkeypatch, config_tables):
        _, tables = config_tables
        service = tables["service_config"]
        monkeypatch.setattr(service, "get_item", _raise_access_denied)

        with pytest.raises(ClientError):
            pull_config_from_table(
                table=service, table_name="service_config",
                job_id="client", job_type="sourcing",
            )


# ---------------------------------------------------------------------------
# End-to-end: ddb_config_pull results merged into job_param
# ---------------------------------------------------------------------------

class TestDdbConfigPullEndToEnd:
    """
    Full lambda_handler runs that exercise the real step handler +
    real DynamoDB (via moto). Confirms pulled rows end up in job_param.
    """

    def test_pulled_rows_merged_into_job_param(self, config_tables, monkeypatch):
        dynamodb, tables = config_tables

        # Seed service_config with a matching row; leave table_config empty.
        tables["service_config"].put_item(Item={
            "job_id": "client", "job_type": "sourcing",
            "feature_flag": True, "region": "us-east-1",
        })

        # Patch get_dynamodb_resource (seen from inside step_handlers) to use moto.
        monkeypatch.setattr(
            "lambdas.pre_steps_processor.step_handlers.get_dynamodb_resource",
            lambda: dynamodb,
        )

        event = _make_event(pre_steps=[{
            "pre_step_type": "ddb_config_pull",
            "tables": ["service_config", "table_config"],
        }])

        result = lambda_handler(event, None)

        job_param = result["job_config"]["job_param"]

        # service_config row came through
        assert job_param["service_config"] == {
            "job_id": "client", "job_type": "sourcing",
            "feature_flag": True, "region": "us-east-1",
        }
        # table_config has no matching row, so it shows up as None
        assert job_param["table_config"] is None

        # ddb_config_pull should NOT appear under pre_steps_results
        assert "ddb_config_pull" not in result["pre_steps_results"]

    def test_empty_tables_list_adds_nothing(self, config_tables, monkeypatch):
        dynamodb, _ = config_tables
        monkeypatch.setattr(
            "lambdas.pre_steps_processor.step_handlers.get_dynamodb_resource",
            lambda: dynamodb,
        )

        event = _make_event(pre_steps=[{
            "pre_step_type": "ddb_config_pull",
            "tables": [],
        }])

        result = lambda_handler(event, None)

        # job_param should be unchanged from the input
        assert result["job_config"]["job_param"] == _make_event()["job_config"]["job_param"]

    def test_missing_tables_key_adds_nothing(self, config_tables, monkeypatch):
        dynamodb, _ = config_tables
        monkeypatch.setattr(
            "lambdas.pre_steps_processor.step_handlers.get_dynamodb_resource",
            lambda: dynamodb,
        )

        event = _make_event(pre_steps=[{"pre_step_type": "ddb_config_pull"}])
        result = lambda_handler(event, None)

        assert result["job_config"]["job_param"] == _make_event()["job_config"]["job_param"]
