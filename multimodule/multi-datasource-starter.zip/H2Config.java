package com.myapp.config;

import com.myapp.config.ApplicationProperties.DatasourceEntry;
import com.myapp.config.ApplicationProperties.Hikari;
import com.zaxxer.hikari.HikariDataSource;
import javax.sql.DataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 * H2 datasource configuration — fully self-contained.
 *
 * <p>This class owns its own {@code switch} on {@code auth-type} and builds the
 * H2 {@link DataSource} directly. H2 is an in-memory/embedded database with no
 * Kerberos support, so the {@code KERBEROS} case fails fast rather than
 * silently falling back.
 *
 * <p>Beans are {@link Lazy} for consistency with the other datasources.
 */
@Configuration
public class H2Config {

    private static final Logger log = LoggerFactory.getLogger(H2Config.class);

    @Lazy
    @Bean(name = "h2DataSource", destroyMethod = "close")
    public DataSource h2DataSource(ApplicationProperties props) {
        DatasourceEntry entry = props.datasource().h2();

        HikariDataSource ds = new HikariDataSource();
        ds.setJdbcUrl(entry.url());
        ds.setDriverClassName(entry.driverClassName());
        applyHikari(ds, entry.hikari());

        switch (entry.authType()) {
            case BASIC -> {
                log.info("[h2] configuring BASIC auth (username/credential)");
                ds.setUsername(entry.username());
                ds.setPassword(entry.credential());
            }
            case KERBEROS -> throw new IllegalStateException(
                    "[h2] H2 does not support KERBEROS auth — "
                            + "set app.datasource.h2.auth-type=basic");
            default -> throw new IllegalStateException(
                    "[h2] unsupported auth-type: " + entry.authType());
        }
        return ds;
    }

    @Lazy
    @Bean("h2JdbcTemplate")
    public JdbcTemplate h2JdbcTemplate(@Qualifier("h2DataSource") DataSource h2DataSource) {
        return new JdbcTemplate(h2DataSource);
    }

    private static void applyHikari(HikariDataSource ds, Hikari hikari) {
        if (hikari == null) {
            return;
        }
        if (hikari.maximumPoolSize() != null) {
            ds.setMaximumPoolSize(hikari.maximumPoolSize());
        }
        if (hikari.minimumIdle() != null) {
            ds.setMinimumIdle(hikari.minimumIdle());
        }
        ds.setPoolName(hikari.poolName() != null ? hikari.poolName() : "h2-pool");
    }
}
