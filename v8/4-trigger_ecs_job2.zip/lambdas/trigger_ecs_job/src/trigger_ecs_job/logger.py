"""
Shared structured logger for TriggerEcsJob.

Every log line carries a step tag + key-value pairs so operators can
grep by step and extract structured fields from CloudWatch.

Usage:
    from trigger_ecs_job.logger import get_logger, log_info, log_error

    logger = get_logger(__name__)
    log_info(logger, "HANDLER_START", {"run_id": run_id})
    log_error(logger, "ECS_CLIENT_ERROR", {"error_code": code})
"""

import logging
from typing import Any


def get_logger(name: str) -> logging.Logger:
    """Return a logger configured at INFO level."""
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    return logger


def _format(step: str, details: dict[str, Any]) -> str:
    detail_str = ", ".join(f"{k}={v}" for k, v in details.items())
    return f"[TriggerEcsJob] [{step}] {detail_str}"


def log_info(logger: logging.Logger, step: str, details: dict[str, Any]) -> None:
    """Emit a structured INFO log line."""
    logger.info(_format(step, details))


def log_error(logger: logging.Logger, step: str, details: dict[str, Any]) -> None:
    """Emit a structured ERROR log line."""
    logger.error(_format(step, details))
