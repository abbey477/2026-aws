package com.example.dbtester.service;

import com.example.dbtester.config.AppProperties;
import com.example.dbtester.dto.ConnectionStatus;
import com.zaxxer.hikari.HikariDataSource;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Uses real H2 DataSources to exercise DatabaseHealthService without
 * needing Oracle or Sybase. The keys are still "oracle" and "sybase"
 * because the service looks them up by name.
 */
class DatabaseHealthServiceTest {

    private HikariDataSource oracle;
    private HikariDataSource sybase;
    private DatabaseHealthService service;

    @BeforeEach
    void setUp() {
        oracle = h2("healthOracle");
        sybase = h2("healthSybase");

        AppProperties props = new AppProperties(
                dbProps(List.of("SELECT 1")),
                dbProps(List.of("SELECT 1"))
        );

        service = new DatabaseHealthService(oracle, sybase, props);
    }

    @AfterEach
    void tearDown() {
        oracle.close();
        sybase.close();
    }

    @Test
    void checkAllReturnsUpForBothDatasources() {
        List<ConnectionStatus> results = service.checkAll();

        assertThat(results).hasSize(2);
        assertThat(results).extracting(ConnectionStatus::status).containsOnly("UP");
        assertThat(results).extracting(ConnectionStatus::datasource)
                .containsExactlyInAnyOrder("oracle", "sybase");
    }

    @Test
    void checkUnknownDataSourceReturnsUnknown() {
        ConnectionStatus status = service.check("nope");

        assertThat(status.status()).isEqualTo("UNKNOWN");
        assertThat(status.message()).contains("nope");
    }

    @Test
    void checkReturnsDownWhenPoolClosed() {
        oracle.close();

        ConnectionStatus status = service.check("oracle");

        assertThat(status.status()).isEqualTo("DOWN");
    }

    private static HikariDataSource h2(String name) {
        HikariDataSource ds = new HikariDataSource();
        ds.setJdbcUrl("jdbc:h2:mem:" + name + ";DB_CLOSE_DELAY=-1");
        ds.setDriverClassName("org.h2.Driver");
        ds.setUsername("sa");
        ds.setPassword("");
        ds.setMaximumPoolSize(2);
        return ds;
    }

    private static AppProperties.DbProps dbProps(List<String> validationQueries) {
        return new AppProperties.DbProps(
                null, null, null, null, null, Map.of(), validationQueries);
    }
}
