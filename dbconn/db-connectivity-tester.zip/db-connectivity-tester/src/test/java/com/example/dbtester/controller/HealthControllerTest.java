package com.example.dbtester.controller;

import com.example.dbtester.dto.ConnectionStatus;
import com.example.dbtester.service.DatabaseHealthService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(HealthController.class)
class HealthControllerTest {

    @Autowired MockMvc mvc;
    @MockBean DatabaseHealthService healthService;

    @Test
    void allReturnsList() throws Exception {
        when(healthService.checkAll()).thenReturn(List.of(
                new ConnectionStatus("oracle", "UP", 12L, "OK"),
                new ConnectionStatus("sybase", "UP", 34L, "OK")
        ));

        mvc.perform(get("/api/db/health/all"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2))
                .andExpect(jsonPath("$[0].datasource").value("oracle"))
                .andExpect(jsonPath("$[0].status").value("UP"));
    }

    @Test
    void singleReturnsStatus() throws Exception {
        when(healthService.check("oracle"))
                .thenReturn(new ConnectionStatus("oracle", "DOWN", 0L, "nope"));

        mvc.perform(get("/api/db/health/oracle"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("DOWN"))
                .andExpect(jsonPath("$.message").value("nope"));
    }
}
