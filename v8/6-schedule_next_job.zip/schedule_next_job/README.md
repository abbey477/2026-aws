# ScheduleNextJob Lambda

This Lambda is called automatically after a job finishes successfully.
It looks at the job's configuration, finds what jobs should run next,
and creates new job records in DynamoDB so the Scheduler can pick them up.

---

## Project structure

```
schedule_next_job/
├── src/
│   └── schedule_next_job/      ← all source code lives here
│       ├── __init__.py
│       ├── handler.py           ← Lambda entry point (start here)
│       ├── scheduler.py         ← logic for scheduling next jobs
│       ├── dynamodb_ops.py      ← all DynamoDB read/write calls
│       ├── logger.py            ← structured logging (INFO + ERROR)
│       ├── config.py            ← environment variables and defaults
│       └── log_to_dynamo.py     ← writes log entries to DynamoDB
├── test/
│   ├── __init__.py
│   ├── conftest.py              ← shared test setup and fixtures
│   ├── test_handler.py
│   ├── test_scheduler.py
│   ├── test_dynamodb_ops.py
│   ├── test_logger.py
│   └── test_log_to_dynamo.py
├── pytest.ini                   ← tells pytest where to find tests
├── requirements-dev.txt         ← list of packages needed to run tests
├── pyproject.toml               ← Poetry config (optional)
├── poetry.toml                  ← Poetry settings (optional)
├── Makefile                     ← shortcuts for common commands
└── .gitignore                   ← files Git should ignore
```

---

## Prerequisites

You only need **Python 3.11 or newer** installed.
Check your version by running:

```bash
python --version
# or on some systems:
python3 --version
```

If you don't have Python, download it from https://www.python.org/downloads/

---

## Option 1 — venv + pip (recommended if you are new to Python)

This is the simplest approach. It uses tools that come built into Python —
no extra software needed.

### What is a virtual environment?

A virtual environment (`.venv`) is an isolated folder where Python packages
are installed **just for this project**, so they don't affect anything else
on your computer. Think of it as a clean workspace.

### Step-by-step

**Step 1 — Open your terminal and go to the project folder**

```bash
cd schedule_next_job
```

**Step 2 — Create the virtual environment**

```bash
python -m venv .venv
```

This creates a `.venv` folder inside your project. You only do this once.

**Step 3 — Activate the virtual environment**

On Mac or Linux:
```bash
source .venv/bin/activate
```

On Windows:
```bash
.venv\Scripts\activate
```

You will see `(.venv)` appear at the start of your terminal prompt.
This means the virtual environment is active.

> ⚠️ You need to activate the virtual environment **every time** you open
> a new terminal window before running tests.

**Step 4 — Install the required packages**

```bash
pip install -r requirements-dev.txt
```

This installs `pytest`, `boto3`, and `moto` (the packages the tests need).
You only need to do this once after creating the virtual environment.

**Step 5 — Run the tests**

```bash
pytest
```

You should see output like this:

```
test/test_handler.py::TestScheduleNextJobLambda::test_schedule_with_next_jobs PASSED
test/test_handler.py::TestScheduleNextJobLambda::test_schedule_no_next_jobs   PASSED
...
33 passed in 20s
```

**All green means everything is working correctly.**

### Quick reference

| What you want to do          | Command                        |
|------------------------------|--------------------------------|
| Activate virtual environment | `source .venv/bin/activate`    |
| Install packages             | `pip install -r requirements-dev.txt` |
| Run all tests                | `pytest`                       |
| Run tests with more detail   | `pytest -v`                    |
| Run one specific test file   | `pytest test/test_handler.py`  |
| Deactivate virtual environment | `deactivate`                 |

### Using the Makefile shortcuts

If you have `make` installed, these shortcuts do the same thing:

```bash
make venv      # create the virtual environment
make install   # install packages
make test      # run tests
make test-v    # run tests with extra detail
make clean     # delete the virtual environment and caches
```

---

## Option 2 — Poetry (alternative)

Poetry is a more advanced tool that manages virtual environments and
dependencies automatically. Use this if you already have Poetry installed.

```bash
poetry install     # install everything
poetry run pytest  # run tests
```

Or with the Makefile:

```bash
make poetry-install
make poetry-test
```

> If Poetry is giving you errors, use Option 1 above instead —
> it works the same way.

---

## Environment variables

The Lambda reads these from its environment. Default values are used
when running tests locally.

| Variable         | Default    | Description                              |
|------------------|------------|------------------------------------------|
| `JOB_RUN_TABLE`  | `job_run`  | DynamoDB table name for job run records  |
| `JOB_CONFIG_TABLE` | `job_config` | DynamoDB table for job configuration |
| `LOGS_TABLE`     | `logs`     | DynamoDB table for log entries           |

---

## What each source file does

| File                | What it does |
|---------------------|--------------|
| `handler.py`        | The Lambda entry point — reads the event, calls the scheduler, returns the result |
| `scheduler.py`      | Loops through `next_jobs`, fetches each child config, creates job_run records |
| `dynamodb_ops.py`   | All DynamoDB calls (get item, put item, time helpers) |
| `logger.py`         | Structured logging — every log line includes a step name and key/value details |
| `config.py`         | Reads environment variables so nothing is hardcoded |
| `log_to_dynamo.py`  | Writes a log entry to the `logs` DynamoDB table — used at the end of every Lambda |

---

## Troubleshooting

**`command not found: python`**
Try `python3` instead of `python`.

**`(.venv)` does not appear after activating**
On Windows, you may need to allow scripts to run first:
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

**`ModuleNotFoundError` when running pytest**
Make sure your virtual environment is activated (`source .venv/bin/activate`)
and you have run `pip install -r requirements-dev.txt`.

**Tests fail with AWS credential errors**
The tests use `moto` which fakes AWS locally — no real credentials are needed.
If you see credential errors, make sure `moto` installed correctly:
```bash
pip show moto
```
