# Maven → JFrog Artifactory Guide

| Path | What it is |
|---|---|
| `docs/multi-project-maven-jfrog.md` | Main guide: one repo with many independent Maven projects, a shared parent POM, Git tags per release, deploying to JFrog |
| `docs/single-project-deploy-jar-to-jfrog.md` | Short guide: create one Maven project and deploy its JAR to JFrog |
| `sample-repo-acme-libs/` | Sample repo that follows the main guide (parent POM + `string-utils` + `date-utils`) |

## Start here

1. Read `docs/multi-project-maven-jfrog.md`.
2. Copy `sample-repo-acme-libs/` somewhere, then run `git init` inside it.
3. Set your JFrog URL in `sample-repo-acme-libs/pom.xml` (replace `YOURCOMPANY`).
4. Copy `sample-repo-acme-libs/settings.xml.example` to `~/.m2/settings.xml` and add your token.
5. Try a build: `cd sample-repo-acme-libs/string-utils && mvn clean package`.
