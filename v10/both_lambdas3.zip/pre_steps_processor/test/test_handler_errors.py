"""Error handling — FAILED log + re-raise."""
import pytest
from pre_steps_processor.handler import lambda_handler
from seed_data import make_event


class TestHandlerErrors:

    def test_step_handler_exception_writes_failed(self, monkeypatch, mock_write_log):
        monkeypatch.setattr(
            "pre_steps_processor.handler.handle_change_since_append",
            lambda step, event: (_ for _ in ()).throw(RuntimeError("Something broke")),
        )
        with pytest.raises(RuntimeError, match="Something broke"):
            lambda_handler(make_event(pre_steps=[{"pre_step_type": "change_since_append"}]), None)
        mock_write_log.assert_called_once_with(
            run_id="run-001", job_id="client", stage="PreStepsProcessor", status="FAILED",
        )

    def test_success_writes_success(self, mocks, mock_write_log):
        lambda_handler(make_event(pre_steps=[]), None)
        mock_write_log.assert_called_once_with(
            run_id="run-001", job_id="client", stage="PreStepsProcessor", status="SUCCESS",
        )
