import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Row mappers for {@link IRInstrumentFlag}, extracted from the migration class
 * for readability — IRInstrumentFlag has 39 columns and inlining two copies of
 * the mapping logic would dominate the migration file.
 *
 * <p>Two static methods are provided so the migration class can A/B them
 * on identical data:
 * <ul>
 *   <li>{@link #mapByIndex(ResultSet)} — positional reads, fastest, fragile
 *       to SELECT column reordering.</li>
 *   <li>{@link #mapByName(ResultSet)} — name-based reads, robust to column
 *       reordering, slight per-cell overhead.</li>
 * </ul>
 *
 * <p>Type-handling notes (consistent across all migrations):
 * <ul>
 *   <li>{@code Integer} fields use {@code (Integer) rs.getObject(...)} — null-safe;
 *       jconn4 doesn't support the two-arg {@code getObject(idx, Class)} overload.</li>
 *   <li>{@code Date} field uses {@code rs.getTimestamp(...)} assuming
 *       {@code java.util.Date}. If it's actually {@code java.sql.Date},
 *       swap to {@code rs.getDate}.</li>
 * </ul>
 */
public final class IRInstrumentFlagRowMapper {

    private IRInstrumentFlagRowMapper() {
        // utility class
    }

    /** Positional read — column index MUST match SELECT order. */
    public static IRInstrumentFlag mapByIndex(ResultSet rs) throws SQLException {
        IRInstrumentFlag row = new IRInstrumentFlag();
        row.setID_IMNT(           (Integer) rs.getObject(1));
        row.setID_ACCR(                     rs.getString(2));
        row.setID_CPN_CUSTOM(               rs.getString(3));
        row.setID_AMRT(                     rs.getString(4));
        row.setID_EMBD_OPTN(                rs.getString(5));
        row.setID_EXOTIC(                   rs.getString(6));
        row.setID_RISKY(                    rs.getString(7));
        row.setID_ACCR_RCVY(                rs.getString(8));
        row.setID_BRADY(                    rs.getString(9));
        row.setID_GOVT(                     rs.getString(10));
        row.setID_CPTL(                     rs.getString(11));
        row.setID_DEFAULT_JPMC(             rs.getString(12));
        row.setID_CRV_RCVY(                 rs.getString(13));
        row.setID_PRICE_PRIMARY(            rs.getString(14));
        row.setID_CI_LINKED(                rs.getString(15));
        row.setID_GUARANTOR(                rs.getString(16));
        row.setID_FIXED(                    rs.getString(17));
        row.setID_SECURED(                  rs.getString(18));
        row.setID_PERPETUAL(                rs.getString(19));
        row.setID_TYP_REPASTYP(             rs.getString(20));
        row.setID_LIQUIDITY(                rs.getString(21));
        row.setID_DISTRESS(                 rs.getString(22));
        row.setID_PIK(                      rs.getString(23));
        row.setID_TYP_QUOTE(                rs.getString(24));
        row.setID_INDEX_LINKED(             rs.getString(25));
        row.setID_BO_COMP(                  rs.getString(26));
        row.setID_RISK_SENS(                rs.getString(27));
        row.setID_TYP_CCYTYPE(              rs.getString(28));
        row.setID_TRD_MIN(                  rs.getString(29));
        row.setID_MAKE_WHOLE(               rs.getString(30));
        row.setID_TRUST_PRF(                rs.getString(31));
        row.setID_SINKABLE(                 rs.getString(32));
        row.setID_EXTENDIBLE(               rs.getString(33));
        row.setID_EXCHANGEABLE(             rs.getString(34));
        row.setMTG_PAY_DELAY(     (Integer) rs.getObject(35));
        row.setID_FVM(                      rs.getString(36));
        row.setDT_CHG_GRD(                  rs.getTimestamp(37));
        row.setID_DEL_GRD(                  rs.getString(38));
        row.setID_OWN_GRD(        (Integer) rs.getObject(39));
        return row;
    }

    /** Name-based read — robust to SELECT column reordering. */
    public static IRInstrumentFlag mapByName(ResultSet rs) throws SQLException {
        IRInstrumentFlag row = new IRInstrumentFlag();
        row.setID_IMNT(           (Integer) rs.getObject("ID_IMNT"));
        row.setID_ACCR(                     rs.getString("ID_ACCR"));
        row.setID_CPN_CUSTOM(               rs.getString("ID_CPN_CUSTOM"));
        row.setID_AMRT(                     rs.getString("ID_AMRT"));
        row.setID_EMBD_OPTN(                rs.getString("ID_EMBD_OPTN"));
        row.setID_EXOTIC(                   rs.getString("ID_EXOTIC"));
        row.setID_RISKY(                    rs.getString("ID_RISKY"));
        row.setID_ACCR_RCVY(                rs.getString("ID_ACCR_RCVY"));
        row.setID_BRADY(                    rs.getString("ID_BRADY"));
        row.setID_GOVT(                     rs.getString("ID_GOVT"));
        row.setID_CPTL(                     rs.getString("ID_CPTL"));
        row.setID_DEFAULT_JPMC(             rs.getString("ID_DEFAULT_JPMC"));
        row.setID_CRV_RCVY(                 rs.getString("ID_CRV_RCVY"));
        row.setID_PRICE_PRIMARY(            rs.getString("ID_PRICE_PRIMARY"));
        row.setID_CI_LINKED(                rs.getString("ID_CI_LINKED"));
        row.setID_GUARANTOR(                rs.getString("ID_GUARANTOR"));
        row.setID_FIXED(                    rs.getString("ID_FIXED"));
        row.setID_SECURED(                  rs.getString("ID_SECURED"));
        row.setID_PERPETUAL(                rs.getString("ID_PERPETUAL"));
        row.setID_TYP_REPASTYP(             rs.getString("ID_TYP_REPASTYP"));
        row.setID_LIQUIDITY(                rs.getString("ID_LIQUIDITY"));
        row.setID_DISTRESS(                 rs.getString("ID_DISTRESS"));
        row.setID_PIK(                      rs.getString("ID_PIK"));
        row.setID_TYP_QUOTE(                rs.getString("ID_TYP_QUOTE"));
        row.setID_INDEX_LINKED(             rs.getString("ID_INDEX_LINKED"));
        row.setID_BO_COMP(                  rs.getString("ID_BO_COMP"));
        row.setID_RISK_SENS(                rs.getString("ID_RISK_SENS"));
        row.setID_TYP_CCYTYPE(              rs.getString("ID_TYP_CCYTYPE"));
        row.setID_TRD_MIN(                  rs.getString("ID_TRD_MIN"));
        row.setID_MAKE_WHOLE(               rs.getString("ID_MAKE_WHOLE"));
        row.setID_TRUST_PRF(                rs.getString("ID_TRUST_PRF"));
        row.setID_SINKABLE(                 rs.getString("ID_SINKABLE"));
        row.setID_EXTENDIBLE(               rs.getString("ID_EXTENDIBLE"));
        row.setID_EXCHANGEABLE(             rs.getString("ID_EXCHANGEABLE"));
        row.setMTG_PAY_DELAY(     (Integer) rs.getObject("MTG_PAY_DELAY"));
        row.setID_FVM(                      rs.getString("ID_FVM"));
        row.setDT_CHG_GRD(                  rs.getTimestamp("DT_CHG_GRD"));
        row.setID_DEL_GRD(                  rs.getString("ID_DEL_GRD"));
        row.setID_OWN_GRD(        (Integer) rs.getObject("ID_OWN_GRD"));
        return row;
    }
}
