package com.example.dbtester.service;

import com.example.dbtester.config.AppProperties;
import com.example.dbtester.dto.ConnectionStatus;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.Statement;
import java.util.List;
import java.util.Map;

/**
 * Pings each configured DataSource and reports liveness + latency.
 *
 * <p>Uses plain JDBC rather than going through JdbcTemplate because we want
 * explicit control over timing and we don't want JdbcTemplate's exception
 * translation turning a DOWN datasource into a stack trace — we just want
 * a status code.
 */
@Service
public class DatabaseHealthService {

    /**
     * Registry of datasources keyed by a display name. Populated in the
     * constructor from the two injected beans — simple and explicit.
     */
    private final Map<String, DataSource> dataSources;
    private final AppProperties properties;

    public DatabaseHealthService(@Qualifier("oracleDataSource") DataSource oracle,
                                 @Qualifier("sybaseDataSource") DataSource sybase,
                                 AppProperties properties) {
        this.dataSources = Map.of(
                "oracle", oracle,
                "sybase", sybase
        );
        this.properties = properties;
    }

    /** Ping every registered datasource. Used by GET /api/db/health/all. */
    public List<ConnectionStatus> checkAll() {
        return dataSources.keySet().stream()
                .map(this::check)
                .toList();
    }

    /**
     * Ping a single datasource by name.
     *
     * <ul>
     *   <li>UP — connection obtained, validation query returned.</li>
     *   <li>DOWN — connection or query failed; message contains the exception.</li>
     *   <li>UNKNOWN — no datasource registered under that name.</li>
     * </ul>
     *
     * <p>Never throws — this is diagnostic, not functional.
     */
    public ConnectionStatus check(String name) {
        DataSource ds = dataSources.get(name);
        if (ds == null) {
            return new ConnectionStatus(name, "UNKNOWN", 0L, "No datasource registered with name: " + name);
        }

        String validationSql = resolveValidationQuery(name);
        long start = System.currentTimeMillis();

        try (Connection conn = ds.getConnection();
             Statement stmt = conn.createStatement()) {
            stmt.execute(validationSql);
            long elapsed = System.currentTimeMillis() - start;
            return new ConnectionStatus(name, "UP", elapsed, "OK");
        } catch (Exception e) {
            long elapsed = System.currentTimeMillis() - start;
            return new ConnectionStatus(name, "DOWN", elapsed, e.getMessage());
        }
    }

    /**
     * Find the configured validation query for a datasource, or fall back
     * to a sensible default. Oracle needs {@code FROM DUAL}; Sybase is happy
     * with a bare {@code SELECT 1}.
     */
    private String resolveValidationQuery(String name) {
        AppProperties.DbProps cfg = switch (name) {
            case "oracle" -> properties.oracle();
            case "sybase" -> properties.sybase();
            default       -> null;
        };
        if (cfg != null && cfg.validationQueries() != null && !cfg.validationQueries().isEmpty()) {
            return cfg.validationQueries().get(0);
        }
        return "oracle".equals(name) ? "SELECT 1 FROM DUAL" : "SELECT 1";
    }
}
