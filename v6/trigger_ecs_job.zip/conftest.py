"""
Shared fixtures and helper factories for TriggerEcsJob tests.

Imported automatically by pytest from all test_*.py files in this directory.
"""

import pytest
from unittest.mock import MagicMock, patch
from botocore.exceptions import ClientError


# ---------------------------------------------------------------------------
# Auto-mock write_log — prevents any test from hitting real DynamoDB.
# Patched at src.handler.write_log (the symbol handler.py actually imports).
# Also exposed as a named fixture so tests can assert on call args.
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _mock_write_log():
    """Patch write_log in src.handler for every test; yield the mock."""
    with patch("src.handler.write_log") as mock:
        yield mock


# ---------------------------------------------------------------------------
# Event factory
# ---------------------------------------------------------------------------

def make_event(
    runner_config_overrides: dict | None = None,
    job_param: dict | None = None,
    run_id: str = "run-001",
) -> dict:
    """Build a sample merged payload as produced by GetConfig."""
    runner_config = {
        "cluster": "my-ecs-cluster",
        "subnets": ["subnet-aaa111", "subnet-bbb222"],
        "security_groups": ["sg-abc123"],
        "task_definition": "default-task-def",
        "container_name": "default-container",
        "instance_size": "small",
        "image": "",
    }
    if runner_config_overrides:
        runner_config.update(runner_config_overrides)

    if job_param is None:
        job_param = {
            "source": {"type": "API", "name": "RDI"},
            "batch_size": 1000,
            "output": ["s3_path"],
        }

    return {
        "run_id": run_id,
        "job_id": "client",
        "job_type": "sourcing",
        "status": "WAITING",
        "job_config": {
            "job_runner": {
                "type": "ECS_Fargate",
                "name": "S2S3",
                "config": runner_config,
            },
            "job_param": job_param,
            "next_jobs": [],
        },
    }


# ---------------------------------------------------------------------------
# ECS client mocks
# ---------------------------------------------------------------------------

def mock_ecs_client_success() -> MagicMock:
    """Mock ECS client that returns a successful RunTask response."""
    mock_client = MagicMock()
    mock_client.run_task.return_value = {
        "tasks": [
            {
                "taskArn": "arn:aws:ecs:us-east-1:123456789012:task/my-ecs-cluster/abc123def456",
                "lastStatus": "PROVISIONING",
            }
        ],
        "failures": [],
    }
    return mock_client


def mock_ecs_client_no_tasks() -> MagicMock:
    """Mock ECS client where RunTask returns no tasks (placement failure)."""
    mock_client = MagicMock()
    mock_client.run_task.return_value = {
        "tasks": [],
        "failures": [
            {
                "arn": "arn:aws:ecs:us-east-1:123456789012:container-instance/xyz",
                "reason": "RESOURCE:MEMORY",
            }
        ],
    }
    return mock_client


def mock_ecs_client_with_error(code: str, message: str) -> MagicMock:
    """Mock ECS client that raises a ClientError with the given code/message."""
    mock_client = MagicMock()
    mock_client.run_task.side_effect = ClientError(
        error_response={"Error": {"Code": code, "Message": message}},
        operation_name="RunTask",
    )
    return mock_client


# ---------------------------------------------------------------------------
# Assertion helpers
# ---------------------------------------------------------------------------

def get_job_param_env(mock_ecs: MagicMock) -> dict:
    """Extract the JOB_PARAM env var from the last run_task call."""
    call_kwargs = mock_ecs.run_task.call_args.kwargs
    env_vars = call_kwargs["overrides"]["containerOverrides"][0]["environment"]
    return next(e for e in env_vars if e["name"] == "JOB_PARAM")
