import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Row mappers for {@link ExchangeInstrumentAlternateId}.
 *
 * <p>Two static methods so the migration class can A/B them on identical data:
 * <ul>
 *   <li>{@link #mapByIndex(ResultSet)} — positional reads, fastest, fragile
 *       to SELECT column reordering.</li>
 *   <li>{@link #mapByName(ResultSet)} — name-based reads, robust to column
 *       reordering, slight per-cell overhead.</li>
 * </ul>
 *
 * <p>Type-handling notes (consistent across all migrations):
 * <ul>
 *   <li>{@code Integer} fields use {@code (Integer) rs.getObject(...)} — null-safe;
 *       jconn4 doesn't support the two-arg {@code getObject(idx, Class)} overload.</li>
 *   <li>{@code Timestamp} field uses {@code rs.getTimestamp(...)}.</li>
 * </ul>
 */
public final class ExchangeInstrumentAlternateIdRowMapper {

    private ExchangeInstrumentAlternateIdRowMapper() {
        // utility class
    }

    /** Positional read — column index MUST match SELECT order. */
    public static ExchangeInstrumentAlternateId mapByIndex(ResultSet rs) throws SQLException {
        ExchangeInstrumentAlternateId row = new ExchangeInstrumentAlternateId();
        row.setID_IMNT(          (Integer) rs.getObject(1));
        row.setID_TYP_ALT_IMNT(            rs.getString(2));
        row.setID_EXCHANGE_KEY(  (Integer) rs.getObject(3));
        row.setID_IMNT_ALT(                rs.getString(4));
        row.setID_EXCH(          (Integer) rs.getObject(5));
        row.setID_VIEW_FLAG(               rs.getString(6));
        row.setDT_CHG_GRD(                 rs.getTimestamp(7));
        row.setID_DEL_GRD(                 rs.getString(8));
        row.setID_OWN_GRD(       (Integer) rs.getObject(9));
        return row;
    }

    /** Name-based read — robust to SELECT column reordering. */
    public static ExchangeInstrumentAlternateId mapByName(ResultSet rs) throws SQLException {
        ExchangeInstrumentAlternateId row = new ExchangeInstrumentAlternateId();
        row.setID_IMNT(          (Integer) rs.getObject("ID_IMNT"));
        row.setID_TYP_ALT_IMNT(            rs.getString("ID_TYP_ALT_IMNT"));
        row.setID_EXCHANGE_KEY(  (Integer) rs.getObject("ID_EXCHANGE_KEY"));
        row.setID_IMNT_ALT(                rs.getString("ID_IMNT_ALT"));
        row.setID_EXCH(          (Integer) rs.getObject("ID_EXCH"));
        row.setID_VIEW_FLAG(               rs.getString("ID_VIEW_FLAG"));
        row.setDT_CHG_GRD(                 rs.getTimestamp("DT_CHG_GRD"));
        row.setID_DEL_GRD(                 rs.getString("ID_DEL_GRD"));
        row.setID_OWN_GRD(       (Integer) rs.getObject("ID_OWN_GRD"));
        return row;
    }
}
