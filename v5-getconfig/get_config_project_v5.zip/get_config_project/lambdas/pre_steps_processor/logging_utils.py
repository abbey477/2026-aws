"""
Structured logging helper for PreStepsProcessor Lambda.

Every log line gets a step tag + key-value pairs for easy CloudWatch filtering.
"""

import logging

logger = logging.getLogger(__name__)


def _log(step: str, details: dict) -> None:
    """Structured info log — every line has a step tag + key-value pairs."""
    detail_str = ", ".join(f"{k}={v}" for k, v in details.items())
    logger.info(f"[PreStepsProcessor] [{step}] {detail_str}")
