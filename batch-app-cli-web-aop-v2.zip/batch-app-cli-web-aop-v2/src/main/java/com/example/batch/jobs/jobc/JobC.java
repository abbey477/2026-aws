package com.example.batch.jobs.jobc;

import com.example.batch.common.service.SimulatedProcessingService;
import com.example.batch.core.BatchJob;
import com.example.batch.core.JobContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class JobC implements BatchJob {

    private static final Logger log = LoggerFactory.getLogger(JobC.class);
    private final SimulatedProcessingService service;

    public JobC(SimulatedProcessingService service) {
        this.service = service;
    }

    @Override
    public String getName() { return "jobC"; }

    @Override
    public void execute(JobContext ctx) {
        log.info(">>> JobC running for runDate={}", ctx.getRunDate());
        service.process("jobC", ctx.getRunDate());
        log.info("<<< JobC done");
    }
}
