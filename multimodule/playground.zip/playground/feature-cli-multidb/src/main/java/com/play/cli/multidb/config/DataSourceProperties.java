package com.play.cli.multidb.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.Map;

/**
 * Binds {@code app.datasources.*} into a map keyed by datasource name.
 * This is the cleaner shape from the original multi-DB work: one record,
 * many named entries, instead of a separate prefix per database.
 *
 * <p>Example in application.properties:
 * <pre>
 * app.datasources.primary.url=jdbc:h2:mem:primary
 * app.datasources.secondary.url=jdbc:h2:mem:secondary
 * </pre>
 */
@ConfigurationProperties(prefix = "app")
public record DataSourceProperties(Map<String, DbConfig> datasources) {

    /** Connection settings for a single named datasource. */
    public record DbConfig(
            String url,
            String username,
            String password,
            String driverClassName
    ) {
    }
}
