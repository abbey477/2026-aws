package com.example.myapp.jobs;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class JobA implements Job {

    private static final Logger log = LoggerFactory.getLogger(JobA.class);

    @Override
    public String name() {
        return "jobA";
    }

    @Override
    public void run() {
        log.info("==> JobA starting");
        log.info("    JobA doing some work...");
        log.info("==> JobA finished");
    }
}
