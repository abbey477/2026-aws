# reset.ps1 — cleanup + setup in one go
$ErrorActionPreference = "Stop"
Set-Location -Path $PSScriptRoot

& "$PSScriptRoot\cleanup.ps1"
Write-Host ""
Write-Host "=== Cleanup complete, starting setup ===" -ForegroundColor Cyan
Write-Host ""
& "$PSScriptRoot\setup.ps1"
