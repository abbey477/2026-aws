# playground

A multi-module Spring Boot scratchpad. Each thing you want to try gets its own
`feature-*` module — a self-contained, runnable experiment — while sharing one
build setup through the parent `pom.xml`.

## Layout

```
playground/
├── pom.xml                 parent: holds Spring Boot version + module list
├── feature-common          shared library (NOT runnable, no main class)
├── feature-rest-config     web feature: @ConfigurationProperties over REST
├── feature-cli-hello       non-web feature: minimal CommandLineRunner
├── feature-cli-multidb     non-web feature: two datasources from one app
└── scripts/play.sh         build / run helper
```

## Requirements

- JDK 21
- Maven 3.9+ (`mvn` on PATH), or add a Maven wrapper (`mvn -N wrapper:wrapper`)
  in the repo root — `play.sh` uses `./mvnw` automatically if present.

## Build

```bash
./scripts/play.sh build                      # build everything
./scripts/play.sh build rest-config           # build one feature (+ common)
./scripts/play.sh build cli-hello cli-multidb  # build several
```

## Run

```bash
./scripts/play.sh list                  # show feature modules
./scripts/play.sh run cli-hello          # run a non-web feature
./scripts/play.sh run cli-hello Ada Bob  # ...with program arguments
./scripts/play.sh run rest-config        # run the web feature (Ctrl-C to stop)
```

The `feature-` prefix is optional: `run cli-hello` and `run feature-cli-hello`
are equivalent.

## The features

**feature-rest-config** — a web app (embedded Tomcat on port 8080). Binds
`app.*` from `application.properties` into a record and exposes it:

```
GET http://localhost:8080/api/config
GET http://localhost:8080/api/config/owner
GET http://localhost:8080/api/config/ping
```

**feature-cli-hello** — a non-web app. Has only `spring-boot-starter` on its
classpath, so Spring Boot runs the `CommandLineRunner` and exits. Greets any
names passed as arguments.

**feature-cli-multidb** — a non-web app that opens **two** datasources
(`primary` and `secondary`) from one application and queries each. Both are
H2 in-memory so it runs with zero setup. The pattern: a single
`@ConfigurationProperties` record holds a `Map<String, DbConfig>` of named
datasources; one `@Configuration` class per database builds its beans by
key. `primary` is `@Primary`; `secondary` must be reached by `@Qualifier`.
To test real databases, change the URLs/drivers in its
`application.properties` and add the matching JDBC dependency to its `pom.xml`.

## Adding a new feature

1. Copy the closest existing `feature-*` directory.
2. Give it a new `artifactId`, base package, and main class.
3. Add the module name to `<modules>` in the parent `pom.xml`.

That's it — no other build wiring. Web features depend on
`spring-boot-starter-web`; non-web features depend only on
`spring-boot-starter` and set `spring.main.web-application-type=none`.
