"""
Unit tests for the databricks_status module.

Tests:
    1.  Databricks job TERMINATED with SUCCESS → SUCCESS.
    2.  Databricks job TERMINATED with FAILED → FAILED.
    3.  Databricks job still RUNNING → RUNNING.
    4.  Databricks job in PENDING state → RUNNING.
    5.  Databricks job in TERMINATING state → RUNNING.
    6.  Unexpected lifecycle state → FAILED.
    7.  HTTP error from Databricks API → FAILED.
    8.  URL error (network failure) → FAILED.
    9.  Verify correct Databricks API URL is constructed.
    10. Databricks TERMINATED TIMEDOUT → FAILED.
"""

from unittest.mock import patch
from urllib.error import URLError, HTTPError

from check_job_status.databricks_status import check_databricks_job_status
from test.helpers import DBR_RUNNER_CONFIG, mock_urlopen_response


class TestCheckDatabricksJobStatus:
    """Tests for the check_databricks_job_status helper function."""

    @patch("check_job_status.databricks_status.urllib.request.urlopen")
    def test_terminated_success(self, mock_urlopen):
        """Databricks run TERMINATED with SUCCESS → SUCCESS."""
        mock_urlopen.return_value = mock_urlopen_response({
            "state": {
                "life_cycle_state": "TERMINATED",
                "result_state": "SUCCESS",
            },
            "notebook_output": {"result": "processed 1000 records"},
        })

        result = check_databricks_job_status("67890", DBR_RUNNER_CONFIG)

        assert result["job_status"] == "SUCCESS"
        assert "output" in result
        assert result["output"]["result"] == "processed 1000 records"

    @patch("check_job_status.databricks_status.urllib.request.urlopen")
    def test_terminated_failed(self, mock_urlopen):
        """Databricks run TERMINATED with FAILED → FAILED."""
        mock_urlopen.return_value = mock_urlopen_response({
            "state": {
                "life_cycle_state": "TERMINATED",
                "result_state": "FAILED",
                "state_message": "Notebook execution failed",
            },
        })

        result = check_databricks_job_status("67890", DBR_RUNNER_CONFIG)

        assert result["job_status"] == "FAILED"
        assert "Notebook execution failed" in result["error"]
        assert result["result_state"] == "FAILED"

    @patch("check_job_status.databricks_status.urllib.request.urlopen")
    def test_still_running(self, mock_urlopen):
        """Databricks run in RUNNING state → RUNNING."""
        mock_urlopen.return_value = mock_urlopen_response({
            "state": {"life_cycle_state": "RUNNING", "result_state": ""},
        })

        result = check_databricks_job_status("67890", DBR_RUNNER_CONFIG)

        assert result["job_status"] == "RUNNING"

    @patch("check_job_status.databricks_status.urllib.request.urlopen")
    def test_pending_state(self, mock_urlopen):
        """Databricks run in PENDING state → RUNNING."""
        mock_urlopen.return_value = mock_urlopen_response({
            "state": {"life_cycle_state": "PENDING", "result_state": ""},
        })

        result = check_databricks_job_status("67890", DBR_RUNNER_CONFIG)

        assert result["job_status"] == "RUNNING"

    @patch("check_job_status.databricks_status.urllib.request.urlopen")
    def test_terminating_state(self, mock_urlopen):
        """Databricks run in TERMINATING state → RUNNING."""
        mock_urlopen.return_value = mock_urlopen_response({
            "state": {"life_cycle_state": "TERMINATING", "result_state": ""},
        })

        result = check_databricks_job_status("67890", DBR_RUNNER_CONFIG)

        assert result["job_status"] == "RUNNING"

    @patch("check_job_status.databricks_status.urllib.request.urlopen")
    def test_unexpected_lifecycle_state(self, mock_urlopen):
        """Unexpected lifecycle state → FAILED."""
        mock_urlopen.return_value = mock_urlopen_response({
            "state": {"life_cycle_state": "SKIPPED", "result_state": ""},
        })

        result = check_databricks_job_status("67890", DBR_RUNNER_CONFIG)

        assert result["job_status"] == "FAILED"
        assert "Unexpected lifecycle state" in result["error"]

    @patch("check_job_status.databricks_status.urllib.request.urlopen")
    def test_http_error(self, mock_urlopen):
        """HTTPError from Databricks API → FAILED."""
        mock_urlopen.side_effect = HTTPError(
            url="https://example.com",
            code=401,
            msg="Unauthorized",
            hdrs={},
            fp=None,
        )

        result = check_databricks_job_status("67890", DBR_RUNNER_CONFIG)

        assert result["job_status"] == "FAILED"
        assert "error" in result

    @patch("check_job_status.databricks_status.urllib.request.urlopen")
    def test_url_error(self, mock_urlopen):
        """URLError (network failure) → FAILED."""
        mock_urlopen.side_effect = URLError("Connection timed out")

        result = check_databricks_job_status("67890", DBR_RUNNER_CONFIG)

        assert result["job_status"] == "FAILED"
        assert "Connection timed out" in result["error"]

    @patch("check_job_status.databricks_status.urllib.request.urlopen")
    def test_correct_api_url(self, mock_urlopen):
        """Verify the correct Databricks API URL is constructed."""
        mock_urlopen.return_value = mock_urlopen_response({
            "state": {"life_cycle_state": "RUNNING", "result_state": ""},
        })

        check_databricks_job_status("67890", DBR_RUNNER_CONFIG)

        call_args = mock_urlopen.call_args
        request_obj = call_args[0][0]
        assert "my-databricks-instance.cloud.databricks.com" in request_obj.full_url
        assert "/api/2.1/jobs/runs/get" in request_obj.full_url
        assert "run_id=67890" in request_obj.full_url

    @patch("check_job_status.databricks_status.urllib.request.urlopen")
    def test_terminated_timedout(self, mock_urlopen):
        """Databricks run TERMINATED with TIMEDOUT → FAILED."""
        mock_urlopen.return_value = mock_urlopen_response({
            "state": {
                "life_cycle_state": "TERMINATED",
                "result_state": "TIMEDOUT",
                "state_message": "Run exceeded timeout",
            },
        })

        result = check_databricks_job_status("67890", DBR_RUNNER_CONFIG)

        assert result["job_status"] == "FAILED"
        assert result["result_state"] == "TIMEDOUT"
        assert "Run exceeded timeout" in result["error"]
