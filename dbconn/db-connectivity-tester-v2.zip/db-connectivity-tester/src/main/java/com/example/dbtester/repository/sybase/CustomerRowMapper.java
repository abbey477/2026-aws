package com.example.dbtester.repository.sybase;

import com.example.dbtester.entity.Customer;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

/**
 * Translates one row of the CUSTOMER ResultSet into a {@link Customer} record.
 *
 * <p>See {@link com.example.dbtester.repository.oracle.ProductRowMapper} for
 * the general rationale; the only wrinkle here is the DATETIME-to-LocalDateTime
 * conversion.
 */
public class CustomerRowMapper implements RowMapper<Customer> {

    @Override
    public Customer mapRow(ResultSet rs, int rowNum) throws SQLException {
        // Sybase DATETIME maps to java.sql.Timestamp on the JDBC side.
        // Convert to LocalDateTime (our record's field type) — but only if
        // non-null, otherwise NPE from toLocalDateTime().
        Timestamp createdAt = rs.getTimestamp("created_at");

        return new Customer(
                rs.getLong("id"),
                rs.getString("first_name"),
                rs.getString("last_name"),
                rs.getString("email"),
                createdAt != null ? createdAt.toLocalDateTime() : null
        );
    }
}
