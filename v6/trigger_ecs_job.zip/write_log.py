"""
Thin shim around the shared DynamoDB audit-log writer.

Keeping the import here rather than directly in handler.py gives tests
a single, stable patch target (src.handler.write_log) that does not
depend on the lambdas package being installed.

In production the real lambdas.log_to_dynamo.write_log is called.
In tests the autouse fixture in conftest.py patches this symbol before
any test runs.
"""

from typing import Any


def write_log(
    run_id: str,
    job_id: str,
    stage: str,
    status: str,
    **kwargs: Any,
) -> None:
    """
    Write a stage-completion record to the DynamoDB audit log.

    Delegates to the shared Lambda layer implementation.
    Raises if the underlying call fails — callers should not swallow errors.
    """
    from lambdas.log_to_dynamo import write_log as _write_log  # noqa: PLC0415

    _write_log(run_id=run_id, job_id=job_id, stage=stage, status=status, **kwargs)
