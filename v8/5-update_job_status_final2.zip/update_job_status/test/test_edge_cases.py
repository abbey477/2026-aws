"""
test_edge_cases.py
Edge-case and validation tests for the UpdateJobStatus Lambda.
"""

import pytest
from test.conftest import make_event
from update_job_status.handler import lambda_handler


class TestEdgeCases:
    """Tests for edge cases and input validation."""

    # ------------------------------------------------------------------
    # Missing run_id
    # ------------------------------------------------------------------
    def test_missing_run_id_raises_error(self, dynamodb_setup, monkeypatch):
        """Missing run_id raises ValueError with a descriptive message."""
        dynamodb, _ = dynamodb_setup
        monkeypatch.setattr(
            "update_job_status.handler.get_dynamodb_resource",
            lambda: dynamodb,
        )

        event = make_event()
        del event["run_id"]

        with pytest.raises(ValueError, match="Missing required field"):
            lambda_handler(event, None)

    # ------------------------------------------------------------------
    # Unknown status
    # ------------------------------------------------------------------
    def test_unknown_status_treated_as_failed(self, dynamodb_setup, monkeypatch):
        """An unrecognised job_status is treated as FAILED."""
        dynamodb, table = dynamodb_setup
        monkeypatch.setattr(
            "update_job_status.handler.get_dynamodb_resource",
            lambda: dynamodb,
        )

        event = make_event(job_status="BIZARRE_STATUS")
        result = lambda_handler(event, None)

        item = table.get_item(Key={"run_id": "run-001"})["Item"]
        assert item["status"] == "FAILED"
        assert "Unknown status" in result["update_result"].get("error", "")
        assert "Unknown status" in item.get("error", "")

    # ------------------------------------------------------------------
    # Return value structure
    # ------------------------------------------------------------------
    def test_handler_always_returns_event(self, dynamodb_setup, monkeypatch):
        """lambda_handler always returns the mutated event dict."""
        dynamodb, _ = dynamodb_setup
        monkeypatch.setattr(
            "update_job_status.handler.get_dynamodb_resource",
            lambda: dynamodb,
        )

        event = make_event(job_status="SUCCESS")
        result = lambda_handler(event, None)

        assert isinstance(result, dict)
        assert "update_result" in result

    def test_update_result_always_has_effective_status(
        self, dynamodb_setup, monkeypatch
    ):
        """update_result always contains 'effective_status' key."""
        dynamodb, _ = dynamodb_setup
        monkeypatch.setattr(
            "update_job_status.handler.get_dynamodb_resource",
            lambda: dynamodb,
        )

        for status in ("SUCCESS", "RUNNING", "FAILED"):
            event = make_event(job_status=status)
            result = lambda_handler(event, None)
            assert "effective_status" in result["update_result"], (
                f"effective_status missing for status={status}"
            )

    # ------------------------------------------------------------------
    # Empty trigger_result
    # ------------------------------------------------------------------
    def test_empty_trigger_result_defaults_to_failed(
        self, dynamodb_setup, monkeypatch
    ):
        """An event with no trigger_result falls through to the FAILED branch."""
        dynamodb, table = dynamodb_setup
        monkeypatch.setattr(
            "update_job_status.handler.get_dynamodb_resource",
            lambda: dynamodb,
        )

        event = make_event()
        event["trigger_result"] = {}           # blank - job_status will be ""
        result = lambda_handler(event, None)

        item = table.get_item(Key={"run_id": "run-001"})["Item"]
        assert item["status"] == "FAILED"
