package com.example.dbtester.entity;

import java.time.LocalDateTime;

/**
 * Immutable domain record mapped to the Sybase CUSTOMER table.
 *
 * <p>Schema (see {@code sybase-schema.sql}):
 * <pre>
 *   id          BIGINT        IDENTITY PRIMARY KEY,
 *   first_name  VARCHAR(100)  NOT NULL,
 *   last_name   VARCHAR(100)  NOT NULL,
 *   email       VARCHAR(200)  NOT NULL UNIQUE,
 *   created_at  DATETIME      NOT NULL
 * </pre>
 *
 * <p>{@code id} is nullable so callers can construct a Customer before
 * persisting. After {@code insert()}, the returned record has {@code id}
 * populated with the server-assigned IDENTITY value.
 */
public record Customer(
        Long id,
        String firstName,
        String lastName,
        String email,
        LocalDateTime createdAt
) {}
