# Sybase jConnect Kerberos Test

## What you need

- JDK 11
- `jconn4.jar` in the same folder as the .java file
- The path to your **krb5.conf** file (the one you said is "already configured")
- A valid Kerberos ticket - run `kinit your_user@YOUR.REALM` first, check with `klist`

## What is kinit?

`kinit` is the command that gets you a Kerberos ticket. Think of it as "logging in" to Kerberos.

The flow looks like this:
1. You run `kinit your_user@YOUR.REALM` and type your password.
2. Kerberos contacts the KDC (the Kerberos server) and gets you a **TGT** (ticket-granting ticket).
3. The TGT is cached on your machine (usually in `/tmp/krb5cc_<uid>`).
4. When your Java app connects to Sybase, it grabs the cached ticket and uses it to prove who you are - no password needed in the code.

So the Java code never sees your password. It just trusts that whoever ran it already has a valid ticket sitting in the cache.

Useful related commands:
- `klist` - show your current ticket(s) and when they expire
- `kdestroy` - throw away your cached tickets (logout)
- `kinit -R` - renew an existing ticket without re-typing the password

Tickets typically expire after 8-24 hours, so if your app suddenly stops working, run `klist` first - you may just need to `kinit` again.

## Edit before compiling

Open `SybaseKerberosTest.java` and update these 5 lines at the top:
1. `host`
2. `port`
3. `database`
4. `servicePrincipal` (ask your DBA for this if you don't know it)
5. `krb5ConfPath` - the path to the krb5.conf file you mentioned

## Compile

```bash
javac -cp ".:jconn4.jar" SybaseKerberosTest.java
```

## Run

```bash
kinit your_user@YOUR.REALM
java -cp ".:jconn4.jar" SybaseKerberosTest
```

That's it. The Kerberos config path is set inside the Java code, so no extra `-D` flags needed.

## Common errors

- **`No valid credentials provided`** - run `kinit` first
- **`Server not found in Kerberos database`** - the SPN is wrong, ask your DBA
- **`Clock skew too great`** - your machine's clock is more than 5 min off, sync it
- **`ClassNotFoundException: com.sybase.jdbc4.jdbc.SybDriver`** - `jconn4.jar` not on classpath
- **`KrbException: Cannot locate default realm`** - the `krb5ConfPath` is wrong or the file is empty
