package com.example.dbtester.config;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;

/**
 * Oracle datasource + JdbcTemplate + transaction manager.
 * Marked @Primary so it wins any ambiguous injection.
 */
@Configuration
public class OracleDataSourceConfig {

    @Primary
    @Bean(name = "oracleDataSource", destroyMethod = "close")
    public DataSource oracleDataSource(AppProperties props) {
        AppProperties.Oracle cfg = props.oracle();
        AppProperties.OracleHikari h = cfg.hikari();

        HikariConfig hikari = new HikariConfig();
        hikari.setJdbcUrl(cfg.url());
        hikari.setUsername(cfg.username());
        hikari.setPassword(cfg.password());
        hikari.setDriverClassName(cfg.driverClassName());

        hikari.setMaximumPoolSize(h.maximumPoolSize());
        hikari.setMinimumIdle(h.minimumIdle());
        hikari.setConnectionTimeout(h.connectionTimeoutMs());
        hikari.setIdleTimeout(h.idleTimeoutMs());
        hikari.setMaxLifetime(h.maxLifetimeMs());
        hikari.setPoolName(h.poolName());

        cfg.properties().forEach(hikari::addDataSourceProperty);
        hikari.setConnectionTestQuery(cfg.validationQueries().get(0));

        return new HikariDataSource(hikari);
    }

    @Primary
    @Bean(name = "oracleJdbcTemplate")
    public JdbcTemplate oracleJdbcTemplate(DataSource oracleDataSource) {
        return new JdbcTemplate(oracleDataSource);
    }

    @Primary
    @Bean(name = "oracleTxManager")
    public PlatformTransactionManager oracleTxManager(DataSource oracleDataSource) {
        return new DataSourceTransactionManager(oracleDataSource);
    }
}
