"""Repository-level tests for get_job_run."""
import pytest
from botocore.exceptions import ClientError
from get_config.dynamodb_ops import get_job_run
from seed_data import make_job_run_item, raise_access_denied


class TestGetJobRunLatest:

    def test_returns_item(self, dynamodb_tables):
        result = get_job_run(dynamodb_tables.Table("app-jobRun"), "run-001")
        assert result["run_id"] == "run-001"

    def test_returns_newest(self, dynamodb_tables):
        table = dynamodb_tables.Table("app-jobRun")
        table.put_item(Item=make_job_run_item(last_updated_time="2024-12-01T00:00:00Z", status="SUCCESS"))
        result = get_job_run(table, "run-001")
        assert result["last_updated_time"] == "2024-12-01T00:00:00Z"

    def test_raises_when_not_found(self, dynamodb_tables):
        with pytest.raises(ValueError, match="No job_run found"):
            get_job_run(dynamodb_tables.Table("app-jobRun"), "does-not-exist")

    def test_raises_on_client_error(self, dynamodb_tables, monkeypatch):
        table = dynamodb_tables.Table("app-jobRun")
        monkeypatch.setattr(table, "query", raise_access_denied)
        with pytest.raises(ClientError):
            get_job_run(table, "run-001")


class TestGetJobRunExact:

    def test_exact_fetch(self, dynamodb_tables):
        table = dynamodb_tables.Table("app-jobRun")
        table.put_item(Item=make_job_run_item(last_updated_time="2024-06-01T00:00:00Z", status="RUNNING"))
        result = get_job_run(table, "run-001", "2024-06-01T00:00:00Z")
        assert result["status"] == "RUNNING"

    def test_exact_fetch_raises_when_missing(self, dynamodb_tables):
        with pytest.raises(ValueError, match="No job_run found"):
            get_job_run(dynamodb_tables.Table("app-jobRun"), "run-001", "2099-01-01T00:00:00Z")
