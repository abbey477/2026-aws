package com.myapp.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Root configuration properties, bound from the {@code app.*} prefix.
 *
 * <p>The whole tree is one record with nested records, so Spring Boot
 * binds it in a single pass via constructor binding (no Lombok, no setters).
 *
 * <p>Framework-owned keys ({@code spring.*}, {@code server.*}) are intentionally
 * NOT part of this class — those are read by Spring Boot's own autoconfiguration.
 */
@ConfigurationProperties(prefix = "app")
public record ApplicationProperties(
        Datasource datasource,
        Kerberos kerberos
) {

    /** Holds all three datasource definitions. */
    public record Datasource(
            DatasourceEntry mysql,
            DatasourceEntry postgres,
            DatasourceEntry h2
    ) {
    }

    /** A single datasource definition: connection + auth + pool settings. */
    public record DatasourceEntry(
            AuthType authType,
            String url,
            String driverClassName,
            String username,
            String credential,
            Hikari hikari,
            KerberosAuth kerberos
    ) {
    }

    /** Supported authentication mechanisms. */
    public enum AuthType {
        BASIC,
        KERBEROS
    }

    /** HikariCP pool tuning, per datasource. */
    public record Hikari(
            Integer maximumPoolSize,
            Integer minimumIdle,
            String poolName
    ) {
    }

    /** Per-datasource Kerberos settings (used when authType == KERBEROS). */
    public record KerberosAuth(
            String principal,
            String keytab,
            String realm,
            String kdc,
            String jaasApplicationName,
            String krbServerName
    ) {
    }

    /** Global Kerberos settings, bound from {@code app.kerberos.*}. */
    public record Kerberos(
            String krb5Conf,
            Boolean debug
    ) {
    }
}
