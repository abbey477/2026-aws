package com.example.dbtester.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Central HTTP exception mapper.
 *
 * <p>{@code @RestControllerAdvice} makes the exception handlers apply
 * across every {@code @RestController} in the app. Each handler converts
 * an exception type into a structured JSON error body + appropriate status.
 *
 * <p>Keeping this in one place avoids try/catch noise in controllers and
 * guarantees a consistent error shape for clients.
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    /**
     * 404 — resource not found. Thrown by service methods when an id
     * doesn't exist.
     */
    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<Map<String, Object>> handleNotFound(ResourceNotFoundException ex) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(body(HttpStatus.NOT_FOUND, ex.getMessage()));
    }

    /**
     * 400 — request body failed Bean Validation. Fired when {@code @Valid}
     * finds a violation in an incoming {@code @RequestBody}. We concatenate
     * all field errors into a single readable message.
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, Object>> handleValidation(MethodArgumentNotValidException ex) {
        String msg = ex.getBindingResult().getFieldErrors().stream()
                .map(fe -> fe.getField() + ": " + fe.getDefaultMessage())
                .collect(Collectors.joining("; "));
        return ResponseEntity.badRequest().body(body(HttpStatus.BAD_REQUEST, msg));
    }

    /**
     * 500 — catch-all. In production you'd log the full stack trace here
     * and return a generic message (don't leak internal details), but for
     * a connectivity tester echoing the cause is useful for debugging.
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, Object>> handleGeneric(Exception ex) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(body(HttpStatus.INTERNAL_SERVER_ERROR, ex.getMessage()));
    }

    /**
     * Standardized error body: timestamp, status, error, message.
     * Mirrors Spring Boot's default error attributes so clients that
     * already parse those don't need special handling.
     */
    private Map<String, Object> body(HttpStatus status, String message) {
        Map<String, Object> map = new HashMap<>();
        map.put("timestamp", Instant.now().toString());
        map.put("status", status.value());
        map.put("error", status.getReasonPhrase());
        map.put("message", message);
        return map;
    }
}
