import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Row mappers for {@link GRDInstrumentEvent}.
 *
 * <p>Two static methods so the migration class can A/B them on identical data:
 * <ul>
 *   <li>{@link #mapByIndex(ResultSet)} — positional reads, fastest, fragile
 *       to SELECT column reordering.</li>
 *   <li>{@link #mapByName(ResultSet)} — name-based reads, robust to column
 *       reordering, slight per-cell overhead.</li>
 * </ul>
 *
 * <p>Type-handling notes (consistent across all migrations):
 * <ul>
 *   <li>{@code Integer} fields use {@code (Integer) rs.getObject(...)} — null-safe;
 *       jconn4 doesn't support the two-arg {@code getObject(idx, Class)} overload.</li>
 *   <li>{@code Timestamp} field uses {@code rs.getTimestamp(...)}.</li>
 * </ul>
 */
public final class GRDInstrumentEventRowMapper {

    private GRDInstrumentEventRowMapper() {
        // utility class
    }

    /** Positional read — column index MUST match SELECT order. */
    public static GRDInstrumentEvent mapByIndex(ResultSet rs) throws SQLException {
        GRDInstrumentEvent row = new GRDInstrumentEvent();
        row.setID_IMNT(    (Integer) rs.getObject(1));
        row.setDT_CHG_GRD(           rs.getTimestamp(2));
        return row;
    }

    /** Name-based read — robust to SELECT column reordering. */
    public static GRDInstrumentEvent mapByName(ResultSet rs) throws SQLException {
        GRDInstrumentEvent row = new GRDInstrumentEvent();
        row.setID_IMNT(    (Integer) rs.getObject("ID_IMNT"));
        row.setDT_CHG_GRD(           rs.getTimestamp("DT_CHG_GRD"));
        return row;
    }
}
