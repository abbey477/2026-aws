package com.example.batch.web;

import com.example.batch.core.JobContext;
import com.example.batch.core.JobDispatcher;
import com.example.batch.core.JobResult;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

/**
 * REST entry point. Delegates to the same JobDispatcher the CLI uses.
 */
@RestController
@RequestMapping("/api/jobs")
public class JobController {

    private final JobDispatcher dispatcher;

    public JobController(JobDispatcher dispatcher) {
        this.dispatcher = dispatcher;
    }

    @PostMapping("/{jobName}/run")
    public ResponseEntity<JobResult> run(@PathVariable String jobName,
                                          @RequestParam(required = false) String runDate) {
        String date = (runDate != null) ? runDate : LocalDate.now().toString();
        JobResult result = dispatcher.dispatch(new JobContext(jobName, date));
        return result.isSuccess()
                ? ResponseEntity.ok(result)
                : ResponseEntity.status(400).body(result);
    }
}
