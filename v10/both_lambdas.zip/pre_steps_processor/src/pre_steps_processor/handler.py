"""
PreStepsProcessor Lambda Handler

Sits between GetConfig and RunnerTypeChoice in the Step Function.
Inspects the `pre_steps` array from the GetConfig output, routes each
step to the appropriate handler, and collects results.

Step Function uses ResultPath: $.pre_steps_result, which means:
  - The input payload (run_id, job_config, etc.) is preserved automatically
  - This lambda's return value is nested under $.pre_steps_result
  - We return ONLY the new data — no need to spread the input event

Output shape (returned by this lambda):
{
    "change_since_append": { ... },       # if that step ran
    "ddb_config_pull": { ... },           # if that step ran
}

Error handling:
    All exceptions are caught, logged, written to the logs table as
    FAILED, then re-raised so Step Functions' Catch block routes to
    HandleError.

AWS Lambda handler entry point: pre_steps_processor.handler.lambda_handler
"""

from typing import Any

from pre_steps_processor import logging_utils as log
from pre_steps_processor.log_to_dynamo import write_log
from pre_steps_processor.step_handlers import (
    handle_change_since_append,
    handle_ddb_config_pull,
    handle_no_pre_steps,
    handle_unknown_pre_step,
)


def _has_valid_pre_step_type(step: Any) -> bool:
    """True if step is a dict with a non-empty string pre_step_type."""
    if not isinstance(step, dict):
        return False
    value = step.get("pre_step_type")
    return isinstance(value, str) and value != ""


def _extract_pre_steps(event: dict) -> list:
    """Return pre_steps list, or [] if missing/None/not-a-list."""
    job_config = event.get("job_config") or {}
    pre_steps = job_config.get("pre_steps")
    if not isinstance(pre_steps, list):
        return []
    return pre_steps


def _process_step(step: dict, event: dict) -> dict:
    """Route a single step to its handler based on pre_step_type."""
    pre_step_type = step["pre_step_type"]  # safe: caller validated

    if pre_step_type == "change_since_append":
        log.info("PROCESSING_STEP", {
            "pre_step_type": pre_step_type,
            "action": "route_to_known_handler",
        })
        return handle_change_since_append(step, event)

    if pre_step_type == "ddb_config_pull":
        log.info("PROCESSING_STEP", {
            "pre_step_type": pre_step_type,
            "action": "route_to_known_handler",
        })
        return handle_ddb_config_pull(step, event)

    log.warn("PROCESSING_STEP", {
        "pre_step_type": pre_step_type,
        "action": "route_to_unknown",
    })
    return handle_unknown_pre_step(step)


def lambda_handler(event: dict, context: Any) -> dict:
    """
    Lambda entry point.

    Reads pre_steps from event["job_config"]["pre_steps"] and dispatches
    each step. Returns ONLY the results — Step Functions nests this under
    $.pre_steps_result via ResultPath and preserves the rest of the payload.
    """
    run_id = event.get("run_id", "<missing>")
    job_id = event.get("job_id", "<unknown>")

    log.info("HANDLER_START", {"run_id": run_id})

    try:
        pre_steps = _extract_pre_steps(event)
        valid_steps = [s for s in pre_steps if _has_valid_pre_step_type(s)]

        log.info("VALIDATION", {
            "raw_count": len(pre_steps),
            "valid_count": len(valid_steps),
        })

        # Collect results from each step handler, keyed by pre_step_type.
        # Step Functions will nest this entire dict under $.pre_steps_result.
        results: dict = {}

        if not valid_steps:
            log.info("NO_DATA", {"reason": "no valid pre_steps to process"})
            handle_no_pre_steps()
        else:
            for step in valid_steps:
                result = _process_step(step, event)
                if result:
                    results[step["pre_step_type"]] = result

        log.info("HANDLER_COMPLETE", {
            "run_id": run_id,
            "processed_count": len(valid_steps),
            "result_keys": list(results.keys()),
        })

        write_log(run_id=run_id, job_id=job_id, stage="PreStepsProcessor", status="SUCCESS")
        return results

    except Exception as e:
        log.error("HANDLER_FAILED", {
            "run_id": run_id,
            "job_id": job_id,
            "error_type": type(e).__name__,
            "error_message": str(e),
        })
        write_log(run_id=run_id, job_id=job_id, stage="PreStepsProcessor", status="FAILED")
        raise
