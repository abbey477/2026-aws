package com.example.dbtester.service;

import com.example.dbtester.config.DataSourceProperties;
import com.example.dbtester.dto.ConnectionStatus;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.Statement;
import java.util.List;
import java.util.Map;

@Service
public class DatabaseHealthService {

    private final Map<String, DataSource> dataSources;
    private final DataSourceProperties properties;

    public DatabaseHealthService(@Qualifier("oracleDataSource") DataSource oracle,
                                 @Qualifier("sybaseDataSource") DataSource sybase,
                                 DataSourceProperties properties) {
        this.dataSources = Map.of(
                "oracle", oracle,
                "sybase", sybase
        );
        this.properties = properties;
    }

    public List<ConnectionStatus> checkAll() {
        return dataSources.keySet().stream()
                .map(this::check)
                .toList();
    }

    public ConnectionStatus check(String name) {
        DataSource ds = dataSources.get(name);
        if (ds == null) {
            return new ConnectionStatus(name, "UNKNOWN", 0L, "No datasource registered with name: " + name);
        }

        String validationSql = resolveValidationQuery(name);
        long start = System.currentTimeMillis();
        try (Connection conn = ds.getConnection();
             Statement stmt = conn.createStatement()) {
            stmt.execute(validationSql);
            long elapsed = System.currentTimeMillis() - start;
            return new ConnectionStatus(name, "UP", elapsed, "OK");
        } catch (Exception e) {
            long elapsed = System.currentTimeMillis() - start;
            return new ConnectionStatus(name, "DOWN", elapsed, e.getMessage());
        }
    }

    private String resolveValidationQuery(String name) {
        DataSourceProperties.DbConfig cfg = properties.datasources().get(name);
        if (cfg != null && cfg.validationQueries() != null && !cfg.validationQueries().isEmpty()) {
            return cfg.validationQueries().get(0);
        }
        return "oracle".equals(name) ? "SELECT 1 FROM DUAL" : "SELECT 1";
    }
}
