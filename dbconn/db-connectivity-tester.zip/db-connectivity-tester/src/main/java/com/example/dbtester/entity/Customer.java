package com.example.dbtester.entity;

import java.time.LocalDateTime;

/**
 * Maps to Sybase CUSTOMER table:
 *   id BIGINT IDENTITY PRIMARY KEY,
 *   first_name VARCHAR(100),
 *   last_name  VARCHAR(100),
 *   email      VARCHAR(200),
 *   created_at DATETIME
 */
public record Customer(
        Long id,
        String firstName,
        String lastName,
        String email,
        LocalDateTime createdAt
) {}
