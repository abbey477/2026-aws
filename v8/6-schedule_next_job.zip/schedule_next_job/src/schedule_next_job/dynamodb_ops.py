"""
DynamoDB operations for ScheduleNextJob.

Isolates all boto3/DynamoDB calls so the scheduler logic stays
free of AWS SDK details and stays easy to mock in tests.
"""
from datetime import datetime, timezone, timedelta

import boto3
from botocore.exceptions import ClientError

from schedule_next_job.logger import log_info, log_error
from schedule_next_job.config import JOB_CONFIG_TABLE


def get_dynamodb_resource():
    """Return a DynamoDB resource. Separated for easy mocking in tests."""
    return boto3.resource("dynamodb")


def get_current_time_iso() -> str:
    """Return current UTC time in ISO 8601 format."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def get_next_minute_iso() -> str:
    """Return the next minute in ISO 8601 format (current time + 1 minute)."""
    next_min = datetime.now(timezone.utc) + timedelta(minutes=1)
    return next_min.strftime("%Y-%m-%dT%H:%M:%SZ")


def get_next_job_config(table, job_id: str, job_type: str) -> dict:
    """
    Fetch the job_config record for a next_job child from DynamoDB.

    Args:
        table: DynamoDB Table resource for job_config.
        job_id: The child job identifier (partition key).
        job_type: The child job type (sort key).

    Returns:
        dict: The child job_config item, or empty dict if not found.
    """
    log_info("FETCH_NEXT_JOB_CONFIG_START", {
        "job_id": job_id,
        "job_type": job_type,
        "table": JOB_CONFIG_TABLE,
    })

    try:
        response = table.get_item(Key={"job_id": job_id, "job_type": job_type})
    except ClientError as e:
        log_error("FETCH_NEXT_JOB_CONFIG_FAILED", {
            "job_id": job_id,
            "job_type": job_type,
            "error": str(e),
            "error_code": e.response.get("Error", {}).get("Code", "Unknown"),
        }, exc_info=True)
        # Re-raise so the Lambda fails loudly instead of silently scheduling nothing.
        raise

    if "Item" not in response:
        log_info("FETCH_NEXT_JOB_CONFIG_NOT_FOUND", {
            "job_id": job_id,
            "job_type": job_type,
            "reason": "No job_config found - will use defaults",
        })
        return {}

    item = response["Item"]
    log_info("FETCH_NEXT_JOB_CONFIG_SUCCESS", {
        "job_id": job_id,
        "job_type": job_type,
        "enabled": item.get("enabled", "N/A"),
        "trigger_type": item.get("trigger_type", "N/A"),
        "runner_name": item.get("job_runner", {}).get("name", "N/A"),
    })
    return item


def put_job_run(table, item: dict) -> None:
    """
    Insert a new job_run record.

    Args:
        table: DynamoDB Table resource for job_run.
        item: The job_run record to insert.

    Raises:
        ClientError: If the put_item operation fails.
    """
    try:
        table.put_item(Item=item)
    except ClientError as e:
        log_error("PUT_JOB_RUN_FAILED", {
            "run_id": item.get("run_id", "N/A"),
            "job_id": item.get("job_id", "N/A"),
            "error": str(e),
            "error_code": e.response.get("Error", {}).get("Code", "Unknown"),
        }, exc_info=True)
        raise
