package com.example.myapp;

import com.example.myapp.config.AppProperties;
import com.example.myapp.jobs.Job;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@SpringBootApplication
@EnableConfigurationProperties(AppProperties.class)
public class MyAppApplication implements ApplicationRunner {

    private static final Logger log = LoggerFactory.getLogger(MyAppApplication.class);

    private final AppProperties properties;
    private final Map<String, Job> jobsByName;

    public MyAppApplication(AppProperties properties, List<Job> jobs) {
        this.properties = properties;
        this.jobsByName = jobs.stream().collect(Collectors.toMap(Job::name, Function.identity()));
    }

    public static void main(String[] args) {
        // Web app type is NONE — no Tomcat, no port; just run and exit.
        SpringApplication app = new SpringApplication(MyAppApplication.class);
        app.setWebApplicationType(org.springframework.boot.WebApplicationType.NONE);
        System.exit(SpringApplication.exit(app.run(args)));
    }

    @Override
    public void run(ApplicationArguments args) {
        printProperties();

        String jobName = resolveJobName(args);
        if (jobName == null) {
            log.error("No job specified. Pass --job=<name>. Available jobs: {}", jobsByName.keySet());
            throw new IllegalArgumentException("No job specified");
        }

        Job job = jobsByName.get(jobName);
        if (job == null) {
            log.error("Unknown job '{}'. Available jobs: {}", jobName, jobsByName.keySet());
            throw new IllegalArgumentException("Unknown job: " + jobName);
        }

        log.info("Dispatching to job: {}", jobName);
        job.run();
    }

    private void printProperties() {
        log.info("===== Application Properties =====");
        log.info("  app.name        = {}", properties.name());
        log.info("  app.environment = {}", properties.environment());
        if (properties.db() != null) {
            log.info("  app.db.url      = {}", properties.db().url());
            log.info("  app.db.username = {}", properties.db().username());
            log.info("  app.db.poolSize = {}", properties.db().poolSize());
        }
        log.info("==================================");
    }

    private String resolveJobName(ApplicationArguments args) {
        // Prefer --job=<name>
        if (args.containsOption("job")) {
            List<String> values = args.getOptionValues("job");
            if (values != null && !values.isEmpty()) {
                return values.get(0);
            }
        }
        // Fallback: first non-option positional arg
        List<String> positional = args.getNonOptionArgs();
        if (!positional.isEmpty()) {
            return positional.get(0);
        }
        return null;
    }
}
