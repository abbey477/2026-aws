package com.example.batch.jobs.jobb;

import com.example.batch.common.service.SimulatedProcessingService;
import com.example.batch.core.BatchJob;
import com.example.batch.core.JobContext;
import com.example.batch.core.JobResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class JobB implements BatchJob {

    private static final Logger log = LoggerFactory.getLogger(JobB.class);

    private final SimulatedProcessingService service;

    public JobB(SimulatedProcessingService service) {
        this.service = service;
    }

    @Override
    public String getName() {
        return "jobB";
    }

    @Override
    public JobResult execute(JobContext context) {
        log.info(">>> JobB starting for runDate={}", context.getRunDate());
        int count = service.process("jobB", context.getRunDate());
        log.info("<<< JobB done. {} records.", count);
        return JobResult.success(count);
    }
}
