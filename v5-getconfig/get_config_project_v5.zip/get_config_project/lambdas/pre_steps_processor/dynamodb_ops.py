"""
DynamoDB data access for PreStepsProcessor Lambda.

Contains:
- Resource factory (separated for easy mocking in tests)
- Table/index name constants (env-driven)
- Query functions used by step handlers
"""

import os
import boto3
from botocore.exceptions import ClientError
from boto3.dynamodb.conditions import Key, Attr

from .logging_utils import _log


# -----------------------------------------------------------------------------
# Table & index names — env-driven with sensible defaults
# -----------------------------------------------------------------------------
# Re-use the same job_run table that GetConfig reads. GSI-2 is defined in the
# table schema as `jobIdQuery` with PK=job_id, SK=start_time, Projection=ALL.
# -----------------------------------------------------------------------------
JOB_RUN_TABLE = os.environ.get("JOB_RUN_TABLE", "job_run")
JOB_ID_QUERY_INDEX = os.environ.get("JOB_ID_QUERY_INDEX", "jobIdQuery")


def get_dynamodb_resource():
    """Return a DynamoDB resource. Separated for easy mocking in tests."""
    return boto3.resource("dynamodb")


def get_last_successful_run_start_time(
    table,
    job_id: str,
    job_type: str,
) -> str | None:
    """
    Query GSI-2 (jobIdQuery) on the job_run table to find the most recent
    successful run for a given (job_id, job_type), and return its start_time.

    Query plan:
      KeyCondition       : job_id = <job_id>         (GSI-2 partition key)
      FilterExpression   : job_type = <job_type> AND status = "SUCCESS"
      ScanIndexForward   : False  (newest first, since SK is start_time)
      Limit              : 1      (only need the latest match)

    Args:
        table: DynamoDB Table resource for job_run.
        job_id: The job identifier — comes from event["job_id"].
        job_type: The job type — comes from event["job_type"].
                  NOTE: an earlier discussion raised whether this should be
                  the literal string "change_since_append" (because that's
                  the pre_step_type) rather than the event's job_type.
                  Using the event value for now; change here if the
                  architect decides otherwise.

    Returns:
        The start_time string of the latest successful run, or None if no
        such run exists (brand-new job, or all prior runs failed).
        The caller decides what to do with None — placeholder for now.

    Raises:
        ClientError: If DynamoDB call fails (throttling, permissions, etc.).
    """
    _log("QUERY_LAST_SUCCESS_START", {
        "job_id": job_id,
        "job_type": job_type,
        "table": JOB_RUN_TABLE,
        "index": JOB_ID_QUERY_INDEX,
    })

    try:
        # NOTE: DynamoDB applies Limit BEFORE FilterExpression, so we can't
        # use Limit=1 here — it would return the newest matching KeyCondition
        # row (regardless of job_type/status), then filter it out and stop.
        # Instead we scan the index in newest-first order and return the
        # first row that passes the filter. Pagination is handled by boto3
        # via LastEvaluatedKey if needed.
        response = table.query(
            IndexName=JOB_ID_QUERY_INDEX,
            KeyConditionExpression=Key("job_id").eq(job_id),
            FilterExpression=(
                Attr("job_type").eq(job_type) & Attr("status").eq("SUCCESS")
            ),
            ScanIndexForward=False,  # newest start_time first
        )
    except ClientError as e:
        _log("QUERY_LAST_SUCCESS_ERROR", {
            "job_id": job_id,
            "job_type": job_type,
            "error_code": e.response.get("Error", {}).get("Code", "Unknown"),
            "error_message": str(e),
        })
        raise

    items = response.get("Items", [])
    if not items:
        # No prior successful run. Placeholder behaviour for now —
        # architect to confirm: should this be epoch 0, None, or an error?
        _log("QUERY_LAST_SUCCESS_NONE_FOUND", {
            "job_id": job_id,
            "job_type": job_type,
        })
        return None

    start_time = items[0].get("start_time")
    _log("QUERY_LAST_SUCCESS_FOUND", {
        "job_id": job_id,
        "job_type": job_type,
        "start_time": start_time,
    })
    return start_time


def pull_config_from_table(
    table,
    table_name: str,
    job_id: str,
    job_type: str,
) -> dict | None:
    """
    Look up a single config row by (job_id, job_type) from a config table.

    Assumes the table uses a two-part key:
      PK=job_id (HASH), SK=job_type (RANGE)

    NOTE: These config tables (e.g. service_config, table_config) are not
    yet created. The architect should confirm the key schema when they are
    designed. If the real schema differs, only this function needs to change.

    Args:
        table: DynamoDB Table resource for the config table.
        table_name: Display name of the table (for logging only).
        job_id: The job identifier (partition key).
        job_type: The job type (sort key).

    Returns:
        The row dict if found, or None if no row exists for this
        (job_id, job_type). Caller decides how to represent "not found"
        in the output.

    Raises:
        ClientError: If DynamoDB call fails (throttling, permissions, etc.).
    """
    _log("PULL_CONFIG_START", {
        "table": table_name,
        "job_id": job_id,
        "job_type": job_type,
    })

    try:
        response = table.get_item(Key={"job_id": job_id, "job_type": job_type})
    except ClientError as e:
        _log("PULL_CONFIG_ERROR", {
            "table": table_name,
            "job_id": job_id,
            "job_type": job_type,
            "error_code": e.response.get("Error", {}).get("Code", "Unknown"),
            "error_message": str(e),
        })
        raise

    item = response.get("Item")
    if item is None:
        _log("PULL_CONFIG_NOT_FOUND", {
            "table": table_name,
            "job_id": job_id,
            "job_type": job_type,
        })
        return None

    _log("PULL_CONFIG_FOUND", {
        "table": table_name,
        "job_id": job_id,
        "job_type": job_type,
    })
    return item
