package com.example.dbtester.repository.oracle;

import com.example.dbtester.entity.Product;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class ProductRepository {

    private static final String SQL_NEXT_ID =
            "SELECT PRODUCT_SEQ.NEXTVAL FROM DUAL";

    private static final String SQL_FIND_ALL =
            "SELECT id, sku, name, price, in_stock FROM PRODUCT";

    private static final String SQL_FIND_BY_ID =
            "SELECT id, sku, name, price, in_stock FROM PRODUCT WHERE id = ?";

    private static final String SQL_INSERT =
            "INSERT INTO PRODUCT (id, sku, name, price, in_stock) VALUES (?, ?, ?, ?, ?)";

    private static final String SQL_UPDATE =
            "UPDATE PRODUCT SET sku = ?, name = ?, price = ?, in_stock = ? WHERE id = ?";

    private static final String SQL_DELETE =
            "DELETE FROM PRODUCT WHERE id = ?";

    private final JdbcTemplate jdbc;
    private final ProductRowMapper rowMapper = new ProductRowMapper();

    public ProductRepository(@Qualifier("oracleJdbcTemplate") JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public List<Product> findAll() {
        return jdbc.query(SQL_FIND_ALL, rowMapper);
    }

    public Optional<Product> findById(Long id) {
        return jdbc.query(SQL_FIND_BY_ID, rowMapper, id).stream().findFirst();
    }

    public Product insert(Product product) {
        Long id = jdbc.queryForObject(SQL_NEXT_ID, Long.class);
        jdbc.update(SQL_INSERT,
                id,
                product.sku(),
                product.name(),
                product.price(),
                product.inStock() ? 1 : 0);
        return findById(id).orElseThrow();
    }

    public int update(Long id, Product product) {
        return jdbc.update(SQL_UPDATE,
                product.sku(),
                product.name(),
                product.price(),
                product.inStock() ? 1 : 0,
                id);
    }

    public int delete(Long id) {
        return jdbc.update(SQL_DELETE, id);
    }
}
