#!/usr/bin/env bash
# cleanup.sh — delete ALL items from app-jobConfig, app-jobRun, app-jobLog
set -euo pipefail
cd "$(dirname "$0")"

echo "=== Cleanup ==="
echo "This will DELETE every item from:"
echo "  - app-jobConfig"
echo "  - app-jobRun"
echo "  - app-jobLog"
echo "(The tables themselves will remain.)"
read -r -p "Type 'yes' to confirm: " confirm
if [[ "$confirm" != "yes" ]]; then
  echo "Aborted."
  exit 1
fi

python3 _cleanup.py
