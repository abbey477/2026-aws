package com.example.dbtester.exception;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

class GlobalExceptionHandlerTest {

    private final GlobalExceptionHandler handler = new GlobalExceptionHandler();

    @Test
    void notFoundReturns404() {
        ResponseEntity<Map<String, Object>> resp =
                handler.handleNotFound(new ResourceNotFoundException("missing"));

        assertThat(resp.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
        assertThat(resp.getBody()).containsEntry("status", 404);
        assertThat(resp.getBody()).containsEntry("message", "missing");
        assertThat(resp.getBody()).containsKey("timestamp");
    }

    @Test
    void genericExceptionReturns500() {
        ResponseEntity<Map<String, Object>> resp =
                handler.handleGeneric(new RuntimeException("boom"));

        assertThat(resp.getStatusCode()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
        assertThat(resp.getBody()).containsEntry("status", 500);
        assertThat(resp.getBody()).containsEntry("message", "boom");
    }
}
