"""
GetConfig Lambda Handler — v2

Fetches job configuration from DynamoDB.
Step 1: Query `job_run` table using run_id to get job run metadata.
Step 2: Query `job_config` table using job_id (partition key) and job_type (sort key)
        to get the full job configuration (including runner infra config
        embedded in job_runner.config, and pre_steps added in v2).

Input:  { "run_id": "cscc66s6d78d6cc" }
Output: Merged payload — job_run fields at top level, job_config nested under
        "job_config" key.

Schema-agnostic by design: the handler forwards whatever fields exist in
the job_config row. New fields added to the table (like pre_steps in v2)
pass through automatically with no code changes required here.
"""

import json
from datetime import datetime, timezone

from lambdas.log_to_dynamo import write_log

from .logging_utils import _log
from .dynamodb_ops import (
    JOB_RUN_TABLE,
    JOB_CONFIG_TABLE,
    get_dynamodb_resource,
    get_job_run,
    get_job_config,
)


def lambda_handler(event, context):
    """
    Lambda entry point.

    Input event:
        { "run_id": "cscc66s6d78d6cc" }

    Output:
        Merged payload — all job_run fields at top level,
        full job_config nested under `job_config` key.
    """
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    _log("HANDLER_START", {
        "timestamp": timestamp,
        "input_event": json.dumps(event),
    })

    # --- Validate input ---
    run_id = event.get("run_id")
    if not run_id:
        _log("VALIDATION_ERROR", {"error": "Missing required input: 'run_id'"})
        raise ValueError("Missing required input: 'run_id'")

    _log("INPUT_VALIDATED", {"run_id": run_id})

    dynamodb = get_dynamodb_resource()

    # --- Step 1: Get job run metadata ---
    _log("STEP_1", {"action": "Querying job_run table", "run_id": run_id})
    job_run_table = dynamodb.Table(JOB_RUN_TABLE)
    job_run = get_job_run(job_run_table, run_id)

    # --- Extract keys for config lookup ---
    job_id = job_run.get("job_id")
    job_type = job_run.get("job_type")

    if not job_id or not job_type:
        _log("VALIDATION_ERROR", {
            "error": "job_run record missing job_id or job_type",
            "job_id": job_id,
            "job_type": job_type,
        })
        raise ValueError(
            f"job_run record is missing 'job_id' or 'job_type'. "
            f"Got job_id={job_id}, job_type={job_type}"
        )

    # --- Step 2: Get job configuration ---
    _log("STEP_2", {
        "action": "Querying job_config table",
        "job_id": job_id,
        "job_type": job_type,
    })
    job_config_table = dynamodb.Table(JOB_CONFIG_TABLE)
    job_config = get_job_config(job_config_table, job_id, job_type)

    # --- Build merged output ---
    # Spread all job_run fields at top level; nest the full job_config row.
    # Any new fields added to job_config (e.g. pre_steps) flow through as-is.
    output = {**job_run, "job_config": job_config}

    # --- Log success AFTER we know the full payload is valid ---
    _log("HANDLER_COMPLETE", {
        "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "run_id": run_id,
        "job_id": job_id,
        "job_type": job_type,
        "runner_name": job_config.get("job_runner", {}).get("name", "N/A"),
        "output_keys": list(output.keys()),
    })

    write_log(run_id=run_id, job_id=job_id, stage="GetConfig", status="SUCCESS")

    return output
