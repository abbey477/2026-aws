"""
dynamo_log.py
DynamoDB log writer for TriggerDbrJob.

This module is patched in tests via conftest.py (autouse mock_write_log).
In production this should write a status record to the orchestration DynamoDB table.
"""

import logging

logger = logging.getLogger(__name__)


def write_log(run_id: str, job_id: str, stage: str, status: str) -> None:
    """
    Write a job status record to DynamoDB.

    Args:
        run_id: Unique run identifier.
        job_id: Job identifier.
        stage:  Lambda stage name (e.g. "TriggerDbrJob").
        status: Outcome status (e.g. "TRIGGERED", "TRIGGER_FAILED").
    """
    # TODO: replace with real DynamoDB boto3 put_item call
    logger.info(f"[write_log] run_id={run_id} job_id={job_id} stage={stage} status={status}")
