#!/usr/bin/env bash
# load_all.sh — load all jobConfig / jobRun / jobLog batches into DynamoDB
#
# Usage:
#   ./load_all.sh                    # uses default table names: jobConfig / jobRun / jobLog
#   ./load_all.sh --prefix app-      # prepends "app-" to each table name
#   ./load_all.sh --dry-run          # prints commands without executing
#
# Requires: aws CLI configured (run `aws configure` first), jq (for --prefix rewriting)

set -euo pipefail

PREFIX=""
DRY_RUN=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --prefix) PREFIX="$2"; shift 2 ;;
    --dry-run) DRY_RUN=1; shift ;;
    -h|--help)
      grep '^#' "$0" | sed 's/^# \{0,1\}//'
      exit 0
      ;;
    *) echo "Unknown arg: $1"; exit 1 ;;
  esac
done

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Ordered so jobConfig loads first (parent), then jobRun, then jobLog.
FILES=(
  "jobConfig_part1_of_1.json"
  "jobRun_part1_of_2.json"
  "jobRun_part2_of_2.json"
  "jobLog_part1_of_4.json"
  "jobLog_part2_of_4.json"
  "jobLog_part3_of_4.json"
  "jobLog_part4_of_4.json"
)

echo "=== DynamoDB seed loader ==="
echo "Prefix: '${PREFIX}'"
echo "Files:  ${#FILES[@]}"
echo ""

TMPDIR="$(mktemp -d)"
trap 'rm -rf "$TMPDIR"' EXIT

for f in "${FILES[@]}"; do
  if [[ ! -f "$f" ]]; then
    echo "MISSING: $f" >&2
    exit 1
  fi

  if [[ -n "$PREFIX" ]]; then
    # Rewrite the single top-level key with the prefix.
    if ! command -v jq >/dev/null; then
      echo "jq is required when using --prefix" >&2
      exit 1
    fi
    OUT="$TMPDIR/$f"
    jq --arg p "$PREFIX" 'to_entries | map({(($p + .key)): .value}) | add' "$f" > "$OUT"
    TARGET_FILE="$OUT"
  else
    TARGET_FILE="$f"
  fi

  CMD="aws dynamodb batch-write-item --request-items file://$TARGET_FILE"
  echo ">>> $CMD"

  if [[ $DRY_RUN -eq 1 ]]; then
    continue
  fi

  RESP="$(eval "$CMD")"
  # batch-write-item can return UnprocessedItems on throttling — surface it.
  UNPROCESSED=$(echo "$RESP" | python3 -c "import sys,json; d=json.load(sys.stdin); u=d.get('UnprocessedItems') or {}; print(sum(len(v) for v in u.values()))" 2>/dev/null || echo 0)
  if [[ "$UNPROCESSED" != "0" ]]; then
    echo "    WARN: $UNPROCESSED unprocessed items — rerun this file or inspect response:"
    echo "$RESP"
  else
    echo "    OK"
  fi
done

echo ""
echo "Done. Verify with:"
TBL_CFG="${PREFIX}jobConfig"
TBL_RUN="${PREFIX}jobRun"
TBL_LOG="${PREFIX}jobLog"
echo "  aws dynamodb scan --table-name $TBL_CFG --select COUNT"
echo "  aws dynamodb scan --table-name $TBL_RUN --select COUNT"
echo "  aws dynamodb scan --table-name $TBL_LOG --select COUNT"
echo "Expected: 15, 50, 100"
