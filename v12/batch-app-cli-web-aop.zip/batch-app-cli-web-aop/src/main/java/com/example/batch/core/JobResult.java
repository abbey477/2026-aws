package com.example.batch.core;

/**
 * Standardized result of a job execution.
 *
 * <p>Now carries an {@code exitCode} so the CLI main can pass it to System.exit()
 * and Autosys reads it. By convention:
 * <ul>
 *   <li>0 = success</li>
 *   <li>1 = generic failure (unexpected exception)</li>
 *   <li>2 = bad arguments</li>
 *   <li>3+ = specific business errors (defined per exception)</li>
 * </ul>
 */
public class JobResult {

    private final boolean success;
    private final int recordsProcessed;
    private final String message;
    private final int exitCode;

    private JobResult(boolean success, int recordsProcessed, String message, int exitCode) {
        this.success = success;
        this.recordsProcessed = recordsProcessed;
        this.message = message;
        this.exitCode = exitCode;
    }

    public static JobResult success(int recordsProcessed) {
        return new JobResult(true, recordsProcessed, null, 0);
    }

    public static JobResult failure(String message, int exitCode) {
        return new JobResult(false, 0, message, exitCode);
    }

    public static JobResult failure(String message) {
        return failure(message, 1);  // generic failure
    }

    public boolean isSuccess()       { return success; }
    public int getRecordsProcessed() { return recordsProcessed; }
    public String getMessage()       { return message; }
    public int getExitCode()         { return exitCode; }
}
