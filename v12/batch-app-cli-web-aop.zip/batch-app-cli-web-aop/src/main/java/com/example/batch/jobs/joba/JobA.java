package com.example.batch.jobs.joba;

import com.example.batch.common.service.SimulatedProcessingService;
import com.example.batch.core.BatchJob;
import com.example.batch.core.JobContext;
import com.example.batch.core.JobResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Job A — first job in the sequence.
 *
 * <p>Notice this class doesn't know or care HOW it was invoked. It's called the
 * same way whether the trigger was a POST to /api/jobs/jobA/run or the CLI with
 * --job=jobA. That's the point of the dispatcher pattern.
 */
@Component
public class JobA implements BatchJob {

    private static final Logger log = LoggerFactory.getLogger(JobA.class);

    private final SimulatedProcessingService service;

    public JobA(SimulatedProcessingService service) {
        this.service = service;
    }

    @Override
    public String getName() {
        return "jobA";
    }

    @Override
    public JobResult execute(JobContext context) {
        log.info(">>> JobA starting for runDate={}", context.getRunDate());
        int count = service.process("jobA", context.getRunDate());
        log.info("<<< JobA done. {} records.", count);
        return JobResult.success(count);
    }
}
