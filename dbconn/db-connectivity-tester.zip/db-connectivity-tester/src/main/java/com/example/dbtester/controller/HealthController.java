package com.example.dbtester.controller;

import com.example.dbtester.dto.ConnectionStatus;
import com.example.dbtester.service.DatabaseHealthService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/db/health")
public class HealthController {

    private final DatabaseHealthService healthService;

    public HealthController(DatabaseHealthService healthService) {
        this.healthService = healthService;
    }

    @GetMapping("/all")
    public List<ConnectionStatus> all() {
        return healthService.checkAll();
    }

    @GetMapping("/{name}")
    public ConnectionStatus one(@PathVariable String name) {
        return healthService.check(name);
    }
}
