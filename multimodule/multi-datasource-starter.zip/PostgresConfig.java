package com.myapp.config;

import com.myapp.config.ApplicationProperties.DatasourceEntry;
import com.myapp.config.ApplicationProperties.Hikari;
import com.myapp.config.ApplicationProperties.KerberosAuth;
import com.zaxxer.hikari.HikariDataSource;
import javax.sql.DataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 * PostgreSQL datasource configuration — fully self-contained.
 *
 * <p>This class owns its own {@code switch} on {@code auth-type} and builds the
 * PostgreSQL {@link DataSource} directly, so changing PostgreSQL behaviour means
 * editing only this file.
 *
 * <p>Beans are {@link Lazy} so the app boots even when no PostgreSQL server is
 * reachable. Inject with {@code @Qualifier("postgresJdbcTemplate")}.
 */
@Configuration
public class PostgresConfig {

    private static final Logger log = LoggerFactory.getLogger(PostgresConfig.class);

    @Lazy
    @Bean(name = "postgresDataSource", destroyMethod = "close")
    public DataSource postgresDataSource(ApplicationProperties props) {
        DatasourceEntry entry = props.datasource().postgres();

        HikariDataSource ds = new HikariDataSource();
        ds.setJdbcUrl(entry.url());
        ds.setDriverClassName(entry.driverClassName());
        applyHikari(ds, entry.hikari());

        switch (entry.authType()) {
            case BASIC -> {
                log.info("[postgres] configuring BASIC auth (username/credential)");
                ds.setUsername(entry.username());
                ds.setPassword(entry.credential());
            }
            case KERBEROS -> {
                log.info("[postgres] configuring KERBEROS auth (GSSAPI)");
                KerberosAuth k = entry.kerberos();
                if (k == null) {
                    throw new IllegalStateException(
                            "[postgres] auth-type=kerberos but no kerberos properties provided");
                }
                // Identity comes from the principal + keytab, not username/credential.
                log.info("[postgres] kerberos principal={}, keytab={}", k.principal(), k.keytab());
                // PostgreSQL JDBC GSSAPI hints.
                if (k.jaasApplicationName() != null) {
                    ds.addDataSourceProperty("jaasApplicationName", k.jaasApplicationName());
                }
                if (k.krbServerName() != null) {
                    ds.addDataSourceProperty("kerberosServerName", k.krbServerName());
                }
                ds.addDataSourceProperty("gsslib", "gssapi");
                // TODO (infra): perform a JAAS LoginContext login with the keytab
                // and principal above, ensure java.security.krb5.conf points at a
                // valid krb5.conf, and validate the KDC ({@code k.kdc()}) is reachable.
                log.warn("[postgres] KERBEROS branch is a scaffold — complete JAAS/GSSAPI "
                        + "wiring with real infra before connecting");
            }
            default -> throw new IllegalStateException(
                    "[postgres] unsupported auth-type: " + entry.authType());
        }
        return ds;
    }

    @Lazy
    @Bean("postgresJdbcTemplate")
    public JdbcTemplate postgresJdbcTemplate(
            @Qualifier("postgresDataSource") DataSource postgresDataSource) {
        return new JdbcTemplate(postgresDataSource);
    }

    private static void applyHikari(HikariDataSource ds, Hikari hikari) {
        if (hikari == null) {
            return;
        }
        if (hikari.maximumPoolSize() != null) {
            ds.setMaximumPoolSize(hikari.maximumPoolSize());
        }
        if (hikari.minimumIdle() != null) {
            ds.setMinimumIdle(hikari.minimumIdle());
        }
        ds.setPoolName(hikari.poolName() != null ? hikari.poolName() : "postgres-pool");
    }
}
