"""
time_utils.py
Date/time helper utilities for the UpdateJobStatus Lambda.
"""

from datetime import datetime, timedelta, timezone

# ISO 8601 format used throughout the system
_ISO_FMT = "%Y-%m-%dT%H:%M:%SZ"


def get_current_time_iso() -> str:
    """Return the current UTC time in ISO 8601 format."""
    return datetime.now(timezone.utc).strftime(_ISO_FMT)


def get_next_minute_iso() -> str:
    """Return current UTC time + 1 minute in ISO 8601 format."""
    next_min = datetime.now(timezone.utc) + timedelta(minutes=1)
    return next_min.strftime(_ISO_FMT)


def get_extended_expiry_iso(minutes: int = 5) -> str:
    """Return current UTC time + *minutes* in ISO 8601 format."""
    expiry = datetime.now(timezone.utc) + timedelta(minutes=minutes)
    return expiry.strftime(_ISO_FMT)
