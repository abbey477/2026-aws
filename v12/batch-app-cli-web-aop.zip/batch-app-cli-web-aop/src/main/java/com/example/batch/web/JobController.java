package com.example.batch.web;

import com.example.batch.core.JobContext;
import com.example.batch.core.JobDispatcher;
import com.example.batch.core.JobResult;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.Map;

/**
 * REST entry point — the "old way" of triggering jobs.
 *
 * <p>{@code @ConditionalOnWebApplication} makes this controller only load when
 * running in web mode (BatchWebApplication). In CLI mode (BatchCliApplication
 * sets WebApplicationType.NONE) this class is skipped, even though it's on
 * the classpath.
 *
 * <p>Crucially, the controller does NOT contain business logic. It just
 * delegates to {@link JobDispatcher} — the SAME dispatcher the CLI mode uses.
 * One business path, two transports.
 */
@RestController
@RequestMapping("/api/jobs")
@ConditionalOnWebApplication
public class JobController {

    private final JobDispatcher dispatcher;

    public JobController(JobDispatcher dispatcher) {
        this.dispatcher = dispatcher;
    }

    @PostMapping("/{jobName}/run")
    public ResponseEntity<Map<String, Object>> runJob(
            @PathVariable String jobName,
            @RequestParam(required = false) String runDate) {

        String date = (runDate != null) ? runDate : LocalDate.now().toString();
        JobContext context = new JobContext(jobName, date);

        JobResult result = dispatcher.dispatch(context);

        Map<String, Object> response = Map.of(
                "job", jobName,
                "runDate", date,
                "success", result.isSuccess(),
                "recordsProcessed", result.getRecordsProcessed(),
                "message", result.getMessage() != null ? result.getMessage() : ""
        );

        return result.isSuccess()
                ? ResponseEntity.ok(response)
                : ResponseEntity.status(500).body(response);
    }

    @GetMapping("/health")
    public Map<String, String> health() {
        return Map.of("status", "ok");
    }
}
