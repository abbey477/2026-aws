"""
Configuration for ScheduleNextJob Lambda.

All environment variable reads live here so the rest of the code
imports named constants instead of calling os.environ directly.
"""
import os

JOB_RUN_TABLE = os.environ.get("JOB_RUN_TABLE", "job_run")
JOB_CONFIG_TABLE = os.environ.get("JOB_CONFIG_TABLE", "job_config")

# Default trigger_type when a child job_config is missing one.
DEFAULT_TRIGGER_TYPE = "PIPELINE"

# Default run_frequency_in_mins when a child job_config is missing one.
DEFAULT_RUN_FREQUENCY_MINS = 0
