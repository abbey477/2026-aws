package com.example.dbtester.service;

import com.example.dbtester.dto.ProductRequest;
import com.example.dbtester.entity.Product;
import com.example.dbtester.exception.ResourceNotFoundException;
import com.example.dbtester.repository.oracle.ProductRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Orchestrates Product CRUD against Oracle.
 *
 * <p>The service layer is thin — it's here to:
 * <ul>
 *   <li>Own transaction boundaries (the {@code transactionManager}
 *       argument is critical: without it, Spring would grab the @Primary
 *       manager, which is still Oracle's here but brittle).</li>
 *   <li>Translate "no rows affected" into a domain-level
 *       {@link ResourceNotFoundException} so the controller can map it to 404.</li>
 *   <li>Convert incoming {@link ProductRequest} DTOs into persistence-ready
 *       {@link Product} records.</li>
 * </ul>
 *
 * <p>All read methods use {@code readOnly = true} — a hint to the driver
 * and transaction manager that can enable optimizations like read-only
 * prepared statement caching.
 */
@Service
public class OracleProductService {

    private final ProductRepository repository;

    public OracleProductService(ProductRepository repository) {
        this.repository = repository;
    }

    @Transactional(transactionManager = "oracleTxManager", readOnly = true)
    public List<Product> findAll() {
        return repository.findAll();
    }

    @Transactional(transactionManager = "oracleTxManager", readOnly = true)
    public Product findById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found: " + id));
    }

    /**
     * Create. Id and any DB-generated defaults come back from the repo.
     */
    @Transactional(transactionManager = "oracleTxManager")
    public Product create(ProductRequest request) {
        Product toCreate = new Product(null, request.sku(), request.name(), request.price(), request.inStock());
        return repository.insert(toCreate);
    }

    /**
     * Update-or-404.
     *
     * <p>We fetch first to validate existence (gives a clear 404), then
     * issue the UPDATE. The second update returning 0 rows after findById
     * succeeded would only happen under a concurrent delete — we treat
     * that as a 404 as well.
     */
    @Transactional(transactionManager = "oracleTxManager")
    public Product update(Long id, ProductRequest request) {
        Product existing = findById(id);
        Product updated = new Product(
                existing.id(),
                request.sku(),
                request.name(),
                request.price(),
                request.inStock()
        );
        int rows = repository.update(id, updated);
        if (rows == 0) {
            throw new ResourceNotFoundException("Product not found: " + id);
        }
        return updated;
    }

    @Transactional(transactionManager = "oracleTxManager")
    public void delete(Long id) {
        int rows = repository.delete(id);
        if (rows == 0) {
            throw new ResourceNotFoundException("Product not found: " + id);
        }
    }

    // =========================================================================
    //  Bulk operations
    // =========================================================================

    /**
     * Bulk insert wrapped in a single transaction. Entire batch rolls back
     * on any failure — this is the key win over looping {@code create()} per row.
     *
     * @return the generated ids, in input order
     */
    @Transactional(transactionManager = "oracleTxManager")
    public List<Long> createAll(List<ProductRequest> requests) {
        List<Product> toInsert = requests.stream()
                .map(r -> new Product(null, r.sku(), r.name(), r.price(), r.inStock()))
                .toList();
        return repository.insertAll(toInsert);
    }

    /**
     * Bulk update by id. Caller supplies full Product records with ids set.
     * Returns total rows affected across all chunks.
     */
    @Transactional(transactionManager = "oracleTxManager")
    public int updateAll(List<Product> products) {
        return repository.updateAll(products);
    }

    /**
     * Bulk delete by id list.
     */
    @Transactional(transactionManager = "oracleTxManager")
    public int deleteAll(List<Long> ids) {
        return repository.deleteAll(ids);
    }
}
