package com.play.cli.hello;

import com.play.common.FeatureBanner;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Minimal non-web feature. Implements {@link CommandLineRunner}, so the
 * {@code run} method executes once the context is ready, then the JVM exits.
 *
 * <p>Pass args through Maven with:
 * {@code mvn -pl feature-cli-hello spring-boot:run -Dspring-boot.run.arguments=Ada,Bob}
 */
@SpringBootApplication
public class CliHelloApp implements CommandLineRunner {

    public static void main(String[] args) {
        SpringApplication.run(CliHelloApp.class, args);
    }

    @Override
    public void run(String... args) {
        System.out.println(FeatureBanner.of("cli-hello"));
        if (args.length == 0) {
            System.out.println("Hello, world! (pass names as args to greet them)");
        } else {
            for (String name : args) {
                System.out.println("Hello, " + name + "!");
            }
        }
    }
}
