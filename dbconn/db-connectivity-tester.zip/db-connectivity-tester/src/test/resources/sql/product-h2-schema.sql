-- H2 test DDL for Product, run in Oracle compatibility mode.
-- Mirrors src/main/resources/sql/oracle-schema.sql but uses H2-friendly syntax.

CREATE TABLE PRODUCT (
    id       NUMBER(19)    NOT NULL,
    sku      VARCHAR2(50)  NOT NULL,
    name     VARCHAR2(200) NOT NULL,
    price    NUMBER(12,2)  NOT NULL,
    in_stock NUMBER(1)     DEFAULT 1 NOT NULL,
    CONSTRAINT pk_product     PRIMARY KEY (id),
    CONSTRAINT uk_product_sku UNIQUE (sku)
);

CREATE SEQUENCE PRODUCT_SEQ START WITH 1 INCREMENT BY 1;
