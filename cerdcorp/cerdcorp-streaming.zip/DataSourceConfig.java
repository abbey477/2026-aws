import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.sql.DataSource;

/**
 * Wires up two separate datasources and JdbcTemplates — one for Sybase,
 * one for Oracle — from properties in application.yml.
 *
 * Expected properties:
 *   sybase.datasource.url, username, password, driver-class-name
 *   oracle.datasource.url, username, password, driver-class-name
 */
@Configuration
public class DataSourceConfig {

    // --- Sybase ---

    @Bean("sybaseDataSource")
    @ConfigurationProperties(prefix = "sybase.datasource")
    public DataSource sybaseDataSource() {
        return DataSourceBuilder.create().build();
    }

    @Bean("sybaseJdbc")
    public JdbcTemplate sybaseJdbc(@Qualifier("sybaseDataSource") DataSource ds) {
        return new JdbcTemplate(ds);
    }

    // --- Oracle ---

    @Primary
    @Bean("oracleDataSource")
    @ConfigurationProperties(prefix = "oracle.datasource")
    public DataSource oracleDataSource() {
        return DataSourceBuilder.create().build();
    }

    @Bean("oracleJdbc")
    public JdbcTemplate oracleJdbc(@Qualifier("oracleDataSource") DataSource ds) {
        return new JdbcTemplate(ds);
    }
}
