"""
log_utils.py
Structured logging utilities for TriggerDbrJob.

Every log line carries a step tag + key-value detail pairs.
Log levels:
  DEBUG   — verbose internals (request details, payload keys)
  INFO    — normal flow milestones (start, success, complete)
  WARNING — unexpected but non-fatal (missing config keys, empty run_id)
  ERROR   — caught exceptions and failures
"""

import logging

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

if not logger.handlers:
    _handler = logging.StreamHandler()
    _handler.setLevel(logging.DEBUG)
    _formatter = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s")
    _handler.setFormatter(_formatter)
    logger.addHandler(_handler)


def _format(step: str, details: dict) -> str:
    detail_str = ", ".join(f"{k}={v}" for k, v in details.items())
    return f"[TriggerDbrJob] [{step}] {detail_str}"


def log_debug(step: str, details: dict) -> None:
    """Verbose internals — request construction, payload inspection."""
    logger.debug(_format(step, details))


def log_info(step: str, details: dict) -> None:
    """Normal flow milestones — handler start, trigger success, completion."""
    logger.info(_format(step, details))


def log_warning(step: str, details: dict) -> None:
    """Unexpected but non-fatal — missing config keys, empty run_id returned."""
    logger.warning(_format(step, details))


def log_error(step: str, details: dict) -> None:
    """Caught exceptions and trigger failures."""
    logger.error(_format(step, details))
