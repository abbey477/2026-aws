# DynamoDB Seed Data — Job Orchestration Platform

Test data for three DynamoDB tables: `jobConfig`, `jobRun`, `jobLog`.

## Contents

| File | Items | Purpose |
|---|---|---|
| `jobConfig_part1_of_1.json` | 15 | Job definitions (sourcing / silver_load / gold_load / validation) |
| `jobRun_part1_of_2.json` | 25 | Run records — part 1 |
| `jobRun_part2_of_2.json` | 25 | Run records — part 2 |
| `jobLog_part1_of_4.json` | 25 | Run logs — part 1 |
| `jobLog_part2_of_4.json` | 25 | Run logs — part 2 |
| `jobLog_part3_of_4.json` | 25 | Run logs — part 3 |
| `jobLog_part4_of_4.json` | 25 | Run logs — part 4 |
| `load_all.sh` | — | Bash runner (macOS / Linux / WSL) |
| `load_all.ps1` | — | PowerShell runner (Windows) |

**Totals:** 15 configs, 50 runs, 100 logs. Run status mix: 25 SUCCESS, 10 FAILED, 8 RUNNING, 7 WAITING.

## Prerequisites

1. AWS CLI installed and configured: `aws configure`
2. The three tables (`jobConfig`, `jobRun`, `jobLog`) must already exist with the documented keys:
   - `jobConfig`: PK `job_id` (S), SK `job_type` (S)
   - `jobRun`: PK `run_id` (S), SK `last_updated_time` (S)
   - `jobLog`: PK `run_id` (S), SK `time` (S)
3. `jq` installed if you plan to use the `--prefix` option (bash runner only)

## Usage

### macOS / Linux / WSL

```bash
chmod +x load_all.sh
./load_all.sh                 # default table names
./load_all.sh --prefix app-   # rewrites to app-jobConfig, app-jobRun, app-jobLog
./load_all.sh --dry-run       # prints commands without running
```

### Windows PowerShell

```powershell
.\load_all.ps1
.\load_all.ps1 -Prefix "app-"
.\load_all.ps1 -DryRun
```

### Manual (no script)

If your table names match exactly:

```bash
for f in jobConfig_part*.json jobRun_part*.json jobLog_part*.json; do
  aws dynamodb batch-write-item --request-items file://$f
done
```

## Verify the load

```bash
aws dynamodb scan --table-name jobConfig --select COUNT
aws dynamodb scan --table-name jobRun    --select COUNT
aws dynamodb scan --table-name jobLog    --select COUNT
```

Expected: **15**, **50**, **100**.

## What's in the data

**15 configs** form three parallel three-stage pipelines (sourcing → silver_load → gold_load) for `client`, `country`, `currency`, and `product` subjects, plus three standalone jobs:
- `trade_ref` — ADHOC sourcing
- `dq_check` — scheduled validation
- `legacy_feed` — disabled (tests dispatcher skip behavior)

**50 runs** include:
- 5 complete end-to-end chains (15 runs) where sourcing → silver → gold, linked via `custom_attributes.parent_run_id`
- 10 FAILED runs with realistic errors (timeouts, IDA auth failures, OOM, merge conflicts, expiry overruns, DQ breaches)
- 8 RUNNING runs with fresh heartbeats and `expiry_time` set 5 minutes out (matches orchestrator behavior)
- 7 WAITING runs with `next_scheduled_run_time` in the near future (exercises the `statusCheck` GSI path)

**100 logs**: 2 per run, covering START/END for completed runs and START/HEARTBEAT or QUEUED/DISPATCH for in-flight ones.

## Notes

- `batch-write-item` caps at 25 items per call — that's why runs and logs are split across multiple files.
- `delete_at` (TTL) is set to a timestamp in Dec 2026; adjust the generator if your TTL window matters.
- All data integrity is verified: every `jobRun.job_id` references a real `jobConfig`, every `jobLog.run_id` references a real `jobRun`, and all PK+SK pairs are unique per table.
- If `batch-write-item` returns `UnprocessedItems`, it's usually throttling — the runner scripts surface this; just rerun the affected file.
