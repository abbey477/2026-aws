# multi-datasource-starter

A Spring Boot starter project wiring **three datasources** — MySQL, PostgreSQL,
and H2 — each supporting **basic** or **kerberos** authentication, selected per
database via an `auth-type` property.

The project **builds, starts, and prints its bound configuration to the
console**. Datasource beans are lazy, so the application boots cleanly even
when no database server is reachable.

## Requirements

- Java 17+
- Maven 3.9+
- Spring Boot 3.3.x (managed by the parent POM)

## Project layout

```
multi-datasource-starter/
├── pom.xml
└── src/
    ├── main/
    │   ├── java/com/myapp/
    │   │   ├── MultiDatasourceApplication.java   Entry point
    │   │   └── config/
    │   │       ├── ApplicationProperties.java    One root record + nested records (app.*)
    │   │       ├── MySqlConfig.java               Self-contained MySQL config + auth switch
    │   │       ├── PostgresConfig.java             Self-contained PostgreSQL config + auth switch
    │   │       ├── H2Config.java                   Self-contained H2 config (kerberos rejected)
    │   │       └── PropertiesLogger.java          Prints properties at startup (credential masked)
    │   └── resources/
    │       ├── application.properties             Common settings + spring.profiles.active
    │       ├── application-uat.properties          UAT overrides (basic auth)
    │       ├── application-prod.properties          PROD overrides (kerberos auth)
    │       └── logback-spring.xml                  Console appender + per-profile log levels
    └── test/java/com/myapp/
        └── MultiDatasourceApplicationTests.java   Context-load test
```

## Configuration

All custom properties live under the `app.*` prefix and bind to the
`ApplicationProperties` record. Each datasource has its own block:

```properties
app.datasource.<db>.auth-type=basic|kerberos
app.datasource.<db>.url=...
app.datasource.<db>.driver-class-name=...
app.datasource.<db>.username=...            # used when auth-type=basic
app.datasource.<db>.credential=${ENV_VAR}   # used when auth-type=basic
app.datasource.<db>.hikari.*                # pool tuning
app.datasource.<db>.kerberos.*              # used when auth-type=kerberos
```

Secrets are never hardcoded — `credential` resolves from an environment
variable via `${...}` placeholders.

### Authentication

Each config class contains its own `switch` on `auth-type`:

- **basic** — username + credential, fully functional.
- **kerberos** — a correct scaffold: it reads the Kerberos properties and sets
  the GSSAPI/JDBC connection properties, but completing a real login requires a
  live KDC, valid keytab files, and `krb5.conf` on the host (see the `TODO`
  comments in `MySqlConfig` / `PostgresConfig`).

H2 has no Kerberos support, so `H2Config` rejects `auth-type=kerberos` with a
clear exception.

## Profiles

| Profile | Datasource auth      | Notes                          |
|---------|----------------------|--------------------------------|
| `uat`   | basic                | Default profile                |
| `prod`  | kerberos (MySQL/PG)  | Requires KDC + keytabs on host  |

## Running

```bash
# UAT (default)
mvn spring-boot:run

# PROD
mvn spring-boot:run -Dspring-boot.run.profiles=prod

# Build a jar
mvn clean package
java -jar target/multi-datasource-starter-0.0.1-SNAPSHOT.jar --spring.profiles.active=uat
```

On startup, `PropertiesLogger` prints all bound properties to the console with
the `credential` field masked.

## Environment variables

Set these before running with real databases:

```bash
export MYSQL_DB_SECRET=...
export POSTGRES_DB_SECRET=...
# H2_DB_SECRET is optional (defaults to empty)
```
