import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;

import java.util.ArrayList;
import java.util.List;

/**
 * Streaming migration for Instrument (Sybase -> Oracle).
 *
 * <p>Streams rows from Sybase via {@link RowCallbackHandler}, buffers them,
 * and flushes batches to Oracle through {@link InstrumentOracleRepository}.
 * Memory is bounded at ~BATCH_SIZE rows.
 *
 * <p>Row mapping is delegated to {@link InstrumentRowMapper} because Instrument
 * has 100+ columns; inlining the mapping would dominate this file. See that
 * class for type-handling notes (Integer/Float casts, Date as Timestamp).
 *
 * <p>Two variants for A/B comparison: {@link #migrateByIndex()} (positional,
 * fastest) and {@link #migrateByName()} (by name, robust to SELECT reordering).
 */
@Slf4j
public class InstrumentMigration {

    private static final int FETCH_SIZE = 2000;
    private static final int BATCH_SIZE = 5000;

    /**
     * SELECT column order MUST match the order used by
     * {@link InstrumentRowMapper#mapByIndex} when reading positionally.
     */
    private static final String SELECT_SQL =
            "SELECT ID_IMNT, NM_IMNT, TX_IMNT, PR_SCALING, AM_DIV_PR, " +
            "       ID_CL_UND, ID_RL_CL_UND, AM_MULT_TRD, CT_PREC_DEC_PR, ID_TRUNC_RND_PR_CL, " +
            "       ID_TYP_PR, ID_ACC_CPTY, ID_MKT, ID_TYP_MKT_PR, ID_TYP_BOOKING, " +
            "       ID_REGION, ID_TYP_IMNT, ID_IMNT_UND_MAIN, ID_IMNT_MOSS, ID_IMNT_RIC, " +
            "       ID_EXCH_PR, ID_IMNT_RST, ID_CCY_MAIN, ID_CCY_CTRT, ID_CCY_CNTR, " +
            "       ID_CCY_DIV, ID_MULT_CCY, ID_UNIT_CCY_BSE, ID_TP_INDX, ID_ST_OPTN, " +
            "       ID_VERSION, AM_DIV_INDX, ID_RV_DIV, CT_YR_DIV_NUM, ID_NTAX_TAX_IMNT, " +
            "       ID_SCTY_RISS_WI, ID_MARGIN, AM_ISSUE, ID_MD_DELIV, AM_TRD_MIN, " +
            "       AM_SZ_CTRT, DT_ISSUE, DT_DELIV, DT_TRD_LAST, DT_TRD_FRT, " +
            "       AM_TICK_SIZE, ID_CMP_FLAG, ID_EXST_IN, ID_EXCH_OTC, ID_CL_PUT, " +
            "       DT_ST_OPTN, DT_EXPY_IMNT, DT_PMT_IMNT, ID_MD_PMT_PRM, ID_TYP_PMT_OPTN, " +
            "       ID_FTR_CSH, AM_PAYOUT, AM_STRIKE_INIT, AM_STRIKE_CURR, ID_IND_CAP, " +
            "       CT_PRD_UNCAP, ID_TYP_SETT_EXRC, ID_CL_OPTN, ID_STY_OPTN, ID_THEO_MTM, " +
            "       ID_MDL, AM_NOTL, RT_FX_CROSS, CT_ROLL_DELIV, ID_CV_DYBU, " +
            "       ID_TYP_TRSRY, ID_ARSR, ID_TYP_IMNT_LIMIT, ID_DATA_MKT, ID_BS_CR, " +
            "       RT_CPN, RT_SPRD, ID_LIBOR_HEDGE, ID_TYP_LEG, ID_PAY_RECV, " +
            "       ID_EXCH_PPAL, ID_ISSUER, ID_JPMSI_MKT_MKR, ID_ROUTE, ID_SECTOR, " +
            "       ID_UV_IMNT, ID_SEC_FEE, ID_MRV_EXCHANGE, ID_CTRY_ISSUER, ID_CTRY_REG, " +
            "       ID_STS_MNT, ID_REPLACED, ID_SETT_SA, ID_CCY_ISSUE, ID_REGS, " +
            "       ID_REG144A, DT_CREATE, ID_USER_CREATE, DT_CHG_LST, ID_USER_CHG_LST, " +
            "       DT_CHG_GRD, ID_DEL_GRD, ID_OWN_GRD " +
            "FROM INSTRUMENT";

    private static final String TABLE_LABEL = "INSTRUMENT";

    private final JdbcTemplate sybaseJdbcTemplate;
    private final InstrumentOracleRepository oracleRepo;

    public InstrumentMigration(
            @Qualifier("sybaseJdbcTemplate") JdbcTemplate sybaseJdbcTemplate,
            InstrumentOracleRepository oracleRepo) {
        this.sybaseJdbcTemplate = sybaseJdbcTemplate;
        this.oracleRepo = oracleRepo;

        // CRITICAL: without this jconn4 uses a tiny default fetch size.
        this.sybaseJdbcTemplate.setFetchSize(FETCH_SIZE);
    }

    /** Variant A — positional read. */
    public void migrateByIndex() {
        run("byIndex", InstrumentRowMapper::mapByIndex);
    }

    /** Variant B — by-name read. */
    public void migrateByName() {
        run("byName", InstrumentRowMapper::mapByName);
    }

    /**
     * Shared streaming pipeline. The variants only differ in which mapper they pass in,
     * so the orchestration is parameterized to avoid code duplication.
     */
    private void run(String variant, RowMapperFn mapper) {
        log.info("[{}] Starting migration (variant={}, fetchSize={}, batchSize={})",
                TABLE_LABEL, variant, FETCH_SIZE, BATCH_SIZE);
        final long startNanos = System.nanoTime();

        oracleRepo.truncate();

        final List<Instrument> buffer = new ArrayList<>(BATCH_SIZE);
        final MigrationStats stats = new MigrationStats();

        sybaseJdbcTemplate.query(SELECT_SQL, (RowCallbackHandler) rs -> {
            buffer.add(mapper.apply(rs));
            if (buffer.size() >= BATCH_SIZE) {
                flush(stats, buffer);
            }
        });

        if (!buffer.isEmpty()) {
            flush(stats, buffer);
        }

        logCompletion(variant, stats, startNanos);
    }

    private void flush(MigrationStats stats, List<Instrument> buffer) {
        final int rowsInThisBatch = buffer.size();
        final long batchStartNanos = System.nanoTime();

        oracleRepo.batchInsert(buffer);

        final long batchElapsedMs = (System.nanoTime() - batchStartNanos) / 1_000_000;
        stats.batchCount++;
        stats.totalRows += rowsInThisBatch;

        log.debug("[{}] Batch {} complete — rows={}, elapsedMs={}, totalRowsSoFar={}",
                TABLE_LABEL, stats.batchCount, rowsInThisBatch, batchElapsedMs, stats.totalRows);

        buffer.clear();
    }

    private void logCompletion(String variant, MigrationStats stats, long startNanos) {
        final long totalElapsedMs = (System.nanoTime() - startNanos) / 1_000_000;
        final double seconds = Math.max(totalElapsedMs / 1000.0, 0.001);
        final long rowsPerSec = (long) (stats.totalRows / seconds);

        log.info("[{}] Migration complete (variant={}) — totalRows={}, batches={}, elapsedMs={}, throughput={} rows/sec",
                TABLE_LABEL, variant, stats.totalRows, stats.batchCount, totalElapsedMs, rowsPerSec);
    }

    /** Functional interface so we can pass a checked-exception-throwing mapper as a method reference. */
    @FunctionalInterface
    private interface RowMapperFn {
        Instrument apply(java.sql.ResultSet rs) throws java.sql.SQLException;
    }

    private static final class MigrationStats {
        long totalRows = 0;
        int batchCount = 0;
    }
}
