"""
DynamoDB data access for GetConfig Lambda.

Contains:
- Resource factory (separated for easy mocking in tests)
- Table name constants (env-driven)
- Repository functions for job_run and job_config tables
"""

import os
import boto3
from botocore.exceptions import ClientError

from .logging_utils import _log


# Table names — env-driven with sensible defaults
JOB_RUN_TABLE = os.environ.get("JOB_RUN_TABLE", "job_run")
JOB_CONFIG_TABLE = os.environ.get("JOB_CONFIG_TABLE", "job_config")


def get_dynamodb_resource():
    """Return a DynamoDB resource. Separated for easy mocking in tests."""
    return boto3.resource("dynamodb")


def get_job_run(table, run_id: str) -> dict:
    """
    Fetch job run record from the job_run DynamoDB table.

    Args:
        table: DynamoDB Table resource for job_run.
        run_id: The unique run identifier.

    Returns:
        dict: The job run item from DynamoDB.

    Raises:
        ValueError: If no record found for the given run_id.
        ClientError: If DynamoDB call fails (throttling, permissions, etc.).
    """
    _log("FETCH_JOB_RUN_START", {"run_id": run_id, "table": JOB_RUN_TABLE})

    try:
        response = table.get_item(Key={"run_id": run_id})
    except ClientError as e:
        _log("FETCH_JOB_RUN_ERROR", {
            "run_id": run_id,
            "error_code": e.response.get("Error", {}).get("Code", "Unknown"),
            "error_message": str(e),
        })
        raise

    if "Item" not in response:
        _log("FETCH_JOB_RUN_FAILED", {
            "run_id": run_id,
            "reason": "No item found in job_run table",
        })
        raise ValueError(f"No job_run found for run_id: {run_id}")

    item = response["Item"]
    _log("FETCH_JOB_RUN_SUCCESS", {
        "run_id": run_id,
        "job_id": item.get("job_id", "N/A"),
        "job_type": item.get("job_type", "N/A"),
        "status": item.get("status", "N/A"),
        "trigger_type": item.get("trigger_type", "N/A"),
    })
    return item


def get_job_config(table, job_id: str, job_type: str) -> dict:
    """
    Fetch job configuration from the job_config DynamoDB table.

    Note: This function is schema-agnostic — any new fields added to the
    job_config table row (e.g. pre_steps in v2) automatically flow through
    to the caller without code changes here.

    Args:
        table: DynamoDB Table resource for job_config.
        job_id: The job identifier (partition key).
        job_type: The job type (sort key).

    Returns:
        dict: The job config item from DynamoDB (full row, no filtering).

    Raises:
        ValueError: If no config found for the given job_id + job_type.
        ClientError: If DynamoDB call fails (throttling, permissions, etc.).
    """
    _log("FETCH_JOB_CONFIG_START", {
        "job_id": job_id,
        "job_type": job_type,
        "table": JOB_CONFIG_TABLE,
    })

    try:
        response = table.get_item(Key={"job_id": job_id, "job_type": job_type})
    except ClientError as e:
        _log("FETCH_JOB_CONFIG_ERROR", {
            "job_id": job_id,
            "job_type": job_type,
            "error_code": e.response.get("Error", {}).get("Code", "Unknown"),
            "error_message": str(e),
        })
        raise

    if "Item" not in response:
        _log("FETCH_JOB_CONFIG_FAILED", {
            "job_id": job_id,
            "job_type": job_type,
            "reason": "No item found in job_config table",
        })
        raise ValueError(
            f"No job_config found for job_id: {job_id}, job_type: {job_type}"
        )

    item = response["Item"]
    runner = item.get("job_runner", {})
    _log("FETCH_JOB_CONFIG_SUCCESS", {
        "job_id": job_id,
        "job_type": job_type,
        "enabled": item.get("enabled", "N/A"),
        "runner_type": runner.get("type", "N/A"),
        "runner_name": runner.get("name", "N/A"),
        "has_next_jobs": bool(item.get("next_jobs")),
        "next_jobs_count": len(item.get("next_jobs", [])),
        # v2: log pre_steps presence & count for observability
        "has_pre_steps": bool(item.get("pre_steps")),
        "pre_steps_count": len(item.get("pre_steps", [])),
    })
    return item
