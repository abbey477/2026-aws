package com.example.dbtester.dto;

public record ConnectionStatus(
        String datasource,
        String status,
        long latencyMs,
        String message
) {}
