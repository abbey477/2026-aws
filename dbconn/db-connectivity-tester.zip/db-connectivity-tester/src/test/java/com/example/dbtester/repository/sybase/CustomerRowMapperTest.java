package com.example.dbtester.repository.sybase;

import com.example.dbtester.entity.Customer;
import org.junit.jupiter.api.Test;

import java.sql.ResultSet;
import java.sql.Timestamp;
import java.time.LocalDateTime;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class CustomerRowMapperTest {

    private final CustomerRowMapper mapper = new CustomerRowMapper();

    @Test
    void mapsAllColumns() throws Exception {
        LocalDateTime now = LocalDateTime.of(2025, 1, 15, 10, 30);
        ResultSet rs = mock(ResultSet.class);
        when(rs.getLong("id")).thenReturn(42L);
        when(rs.getString("first_name")).thenReturn("Ada");
        when(rs.getString("last_name")).thenReturn("Lovelace");
        when(rs.getString("email")).thenReturn("ada@example.com");
        when(rs.getTimestamp("created_at")).thenReturn(Timestamp.valueOf(now));

        Customer c = mapper.mapRow(rs, 0);

        assertThat(c.id()).isEqualTo(42L);
        assertThat(c.firstName()).isEqualTo("Ada");
        assertThat(c.lastName()).isEqualTo("Lovelace");
        assertThat(c.email()).isEqualTo("ada@example.com");
        assertThat(c.createdAt()).isEqualTo(now);
    }

    @Test
    void handlesNullCreatedAt() throws Exception {
        ResultSet rs = mock(ResultSet.class);
        when(rs.getLong("id")).thenReturn(1L);
        when(rs.getString("first_name")).thenReturn("A");
        when(rs.getString("last_name")).thenReturn("B");
        when(rs.getString("email")).thenReturn("a@b.com");
        when(rs.getTimestamp("created_at")).thenReturn(null);

        Customer c = mapper.mapRow(rs, 0);

        assertThat(c.createdAt()).isNull();
    }
}
