"""DynamoDB data access for PreStepsProcessor Lambda."""

import os
import boto3
from botocore.exceptions import ClientError
from boto3.dynamodb.conditions import Key, Attr
from pre_steps_processor import logging_utils as log

JOB_RUN_TABLE = os.environ.get("JOB_RUN_TABLE", "app-jobRun")
JOB_ID_QUERY_INDEX = os.environ.get("JOB_ID_QUERY_INDEX", "jobIdQuery")


def get_dynamodb_resource():
    return boto3.resource("dynamodb")


def get_last_successful_run_start_time(table, job_id: str, job_type: str) -> str | None:
    """Find start_time of the newest COMPLETED run for (job_id, job_type) via GSI-2."""
    log.info("QUERY_LAST_SUCCESS_START", {"job_id": job_id, "job_type": job_type})

    try:
        response = table.query(
            IndexName=JOB_ID_QUERY_INDEX,
            KeyConditionExpression=Key("job_id").eq(job_id),
            FilterExpression=(Attr("job_type").eq(job_type) & Attr("status").eq("COMPLETED")),
            ScanIndexForward=False,
        )
    except ClientError as e:
        log.error("QUERY_LAST_SUCCESS_ERROR", {"job_id": job_id, "error_message": str(e)})
        raise

    items = response.get("Items", [])
    if not items:
        log.warn("QUERY_LAST_SUCCESS_NONE_FOUND", {"job_id": job_id, "job_type": job_type})
        return None

    start_time = items[0].get("start_time")
    log.info("QUERY_LAST_SUCCESS_FOUND", {"job_id": job_id, "start_time": start_time})
    return start_time


def pull_config_from_table(table, table_name: str, job_id: str, job_type: str) -> dict | None:
    """
    Look up a config row by (job_id, job_type). Returns row or None.

    If the table doesn't exist yet in DynamoDB (ResourceNotFoundException),
    returns None and logs a warning instead of crashing. This allows the
    lambda to run gracefully before config tables are created.
    """
    log.info("PULL_CONFIG_START", {"table": table_name, "job_id": job_id, "job_type": job_type})

    try:
        response = table.get_item(Key={"job_id": job_id, "job_type": job_type})
    except ClientError as e:
        error_code = e.response.get("Error", {}).get("Code", "Unknown")

        # Table doesn't exist yet — not an error, just no data available.
        if error_code == "ResourceNotFoundException":
            log.warn("PULL_CONFIG_TABLE_NOT_FOUND", {
                "table": table_name,
                "job_id": job_id,
                "job_type": job_type,
                "message": "Table does not exist yet — returning null",
            })
            return None

        # Any other ClientError (throttling, permissions, etc.) — re-raise.
        log.error("PULL_CONFIG_ERROR", {"table": table_name, "error_message": str(e)})
        raise

    item = response.get("Item")
    if item is None:
        log.warn("PULL_CONFIG_NOT_FOUND", {"table": table_name, "job_id": job_id})
        return None

    log.info("PULL_CONFIG_FOUND", {"table": table_name, "job_id": job_id})
    return item
