# GetConfig Lambda

Fetches job run metadata and configuration from DynamoDB. This is the **first
lambda** in the orchestrator Step Function — its output feeds into
PreStepsProcessor → RunnerTypeChoice.

---

## Project structure

```
get_config/
├── src/
│   └── get_config/                  ← the lambda code (importable package)
│       ├── __init__.py
│       ├── handler.py               ← entry point (lambda_handler lives here)
│       ├── dynamodb_ops.py          ← reads job_run and job_config tables
│       ├── logging_utils.py         ← structured logging (info/warn/error/debug)
│       └── log_to_dynamo.py         ← writes to the shared logs table
│
├── test/                            ← unit tests
│   ├── conftest.py                  ← shared fixtures (auto-loaded by pytest)
│   ├── seed_data.py                 ← test data builders (importable helper)
│   ├── test_handler_happy_path.py   ← successful retrieval
│   ├── test_handler_validation.py   ← bad input / missing rows
│   ├── test_handler_restart.py      ← restart from a historical state
│   ├── test_handler_errors.py       ← DynamoDB failures
│   ├── test_get_job_run.py          ← DAO-level tests
│   ├── test_get_job_config.py       ← DAO-level tests
│   └── test_get_last_updated_time.py← helper function tests
│
├── Makefile                         ← run common tasks with `make <target>`
├── pytest.ini                       ← tells pytest where to find code + tests
├── requirements.txt                 ← production dependencies
├── requirements-dev.txt             ← test/lint dependencies
├── pyproject.toml                   ← Poetry config (optional)
├── poetry.toml                      ← Poetry settings (optional)
└── .gitignore
```

---

## Getting started

### Prerequisites

- **Python 3.12** or newer
- That's it! (Poetry is optional)

### Option A — Plain pip + venv (recommended for beginners)

This is the simplest way. It creates a virtual environment and installs
everything you need.

```bash
# 1. Go into the project folder
cd lambdas/get_config

# 2. Create the virtual environment and install dependencies
make venv

# 3. Run the tests
make test
```

**What `make venv` does behind the scenes:**
```bash
python3 -m venv .venv                                          # create venv
.venv/bin/pip install -r requirements.txt -r requirements-dev.txt  # install deps
```

If you prefer to do it manually (without Make):
```bash
python3 -m venv .venv
source .venv/bin/activate          # activate the venv (Linux/Mac)
pip install -r requirements.txt -r requirements-dev.txt
pytest                             # run the tests
```

### Option B — Poetry (full dependency management)

If you already have [Poetry](https://python-poetry.org/) installed:

```bash
cd lambdas/get_config
make install     # runs `poetry install`
make test        # runs `poetry run pytest`
```

---

## Running things

All commands work with **both** setup options (pip+venv or Poetry).

| What you want | Command | What it does |
|---|---|---|
| Run tests | `make test` | Runs all 29 unit tests |
| Run linting | `make lint` | Checks code style (ruff) + types (mypy) |
| Auto-format code | `make format` | Fixes formatting (black + ruff) |
| Clean everything | `make clean` | Removes .venv, caches, build files |
| Build deployment zip | `make package` | Creates `dist/get_config.zip` for AWS |

---

## What this lambda does

### Step-by-step flow

1. **Receives** an event from the Step Function with a `run_id`
2. **Reads** the `job_run` DynamoDB table to get run metadata (status, job_id, etc.)
3. **Reads** the `job_config` DynamoDB table to get the full job configuration
4. **Merges** both into a single output payload
5. **Logs** success to the `logs` DynamoDB table
6. **Returns** the merged payload to the next step in the Step Function

### Input examples

**Normal run** (most common):
```json
{
    "run_id": "run-001"
}
```

**Restart a run** from a specific historical state:
```json
{
    "run_id": "run-001",
    "last_updated_time": "2024-03-15T10:00:00Z"
}
```

When `last_updated_time` is omitted, the lambda automatically fetches the
**latest** state for that `run_id`. When it's provided, it fetches that
**exact historical snapshot** — useful for re-running a job from a known
point in time.

### Output example

```json
{
    "run_id": "run-001",
    "last_updated_time": "2024-01-01T00:00:00Z",
    "job_id": "client",
    "job_type": "sourcing",
    "status": "WAITING",
    "trigger_type": "SCHEDULER",
    "custom_attributes": {},
    "...other job_run fields...": "...",

    "job_config": {
        "enabled": true,
        "job_runner": {
            "type": "ECS_Fargate",
            "name": "S2S3",
            "config": { "cluster": "...", "..." : "..." }
        },
        "pre_steps": [ ... ],
        "job_param": { ... },
        "next_jobs": [ ... ]
    }
}
```

---

## DynamoDB tables this lambda uses

| Table | PK | SK | Read/Write |
|---|---|---|---|
| `job_run` | `run_id` | `last_updated_time` | **Read** |
| `job_config` | `job_id` | `job_type` | **Read** |
| `logs` | `run_id` | `time` | **Write** |

Table names can be changed via environment variables: `JOB_RUN_TABLE`,
`JOB_CONFIG_TABLE`, `LOGS_TABLE`.

---

## Deploying to AWS Lambda

```bash
# 1. Build the deployment zip
make package

# 2. Upload dist/get_config.zip to AWS Lambda

# 3. Set these in the Lambda configuration:
#    Runtime:  Python 3.12
#    Handler:  get_config.handler.lambda_handler
```

---

## Test files explained

Each test file focuses on one thing — you can open any single file and
understand what it's testing without reading the others.

| Test file | What it tests | # tests |
|---|---|---|
| `test_handler_happy_path.py` | Everything works — valid input, correct output | 4 |
| `test_handler_validation.py` | Bad input: missing run_id, missing rows | 7 |
| `test_handler_restart.py` | Restart feature (latest vs exact fetch) | 3 |
| `test_handler_errors.py` | DynamoDB crashes don't get swallowed silently | 1 |
| `test_get_job_run.py` | The `get_job_run` function in isolation | 6 |
| `test_get_job_config.py` | The `get_job_config` function in isolation | 4 |
| `test_get_last_updated_time.py` | The timestamp helper | 4 |

**Total: 29 tests**

---

## File-by-file guide (for code readers)

If you want to understand the code, read in this order:

1. **`handler.py`** — start here. It's short. It validates input, calls two
   functions, merges the results, done.
2. **`dynamodb_ops.py`** — the two functions the handler calls. One reads
   `job_run`, one reads `job_config`. Also has the `get_last_updated_time`
   helper.
3. **`logging_utils.py`** — tiny file. Four functions: `info`, `warn`,
   `error`, `debug`.
4. **`log_to_dynamo.py`** — writes a log row to DynamoDB after each
   successful run.

Skip `__init__.py` — it's one line.
