package com.myapp.webapp.controller;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.reactive.function.client.WebClient;

/**
 * Web Application Controllers.
 *
 * Demonstrates fetching data from the Resource Server using the access token
 * stored in the OAuth2AuthorizedClientRepository.
 */
@Controller
public class DashboardController {

    private final WebClient webClient;

    public DashboardController(WebClient webClient) {
        this.webClient = webClient;
    }

    @GetMapping("/")
    public String home() {
        return "home";
    }

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @GetMapping("/dashboard")
    public String dashboard(@AuthenticationPrincipal OidcUser oidcUser, Model model) {
        model.addAttribute("user", oidcUser);
        model.addAttribute("subject", oidcUser.getSubject());
        model.addAttribute("email", oidcUser.getEmail());

        // Call the Resource Server — Bearer token injected automatically by WebClient
        try {
            String message = webClient.get()
                    .uri("/api/hello")
                    .retrieve()
                    .bodyToMono(String.class)
                    .block();
            model.addAttribute("apiMessage", message);
        } catch (Exception ex) {
            model.addAttribute("apiMessage", "Error calling Resource Server: " + ex.getMessage());
        }

        return "dashboard";
    }
}
