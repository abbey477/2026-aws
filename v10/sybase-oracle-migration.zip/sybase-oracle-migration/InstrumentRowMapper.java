import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Row mappers for {@link Instrument}, extracted from the migration class
 * because Instrument has 107 columns and inlining two copies of the mapping
 * logic would dominate the migration file.
 *
 * <p>Two static methods are provided so the migration class can A/B them
 * on identical data:
 * <ul>
 *   <li>{@link #mapByIndex(ResultSet)} — positional reads, fastest, fragile
 *       to SELECT column reordering.</li>
 *   <li>{@link #mapByName(ResultSet)} — name-based reads, robust to column
 *       reordering, slight per-cell overhead.</li>
 * </ul>
 *
 * <p>Both methods produce identical Instrument objects from the same row.
 *
 * <p>Type notes:
 * <ul>
 *   <li>{@code Integer} fields use {@code (Integer) rs.getObject(...)} — the
 *       two-arg {@code getObject(idx, Class)} overload is not supported by
 *       jconn4. The cast is null-safe.</li>
 *   <li>{@code Float} fields use {@code (Float) rs.getObject(...)} for the
 *       same reason. Note: {@code Float} is 32-bit IEEE 754 and is generally
 *       a poor choice for financial values, but field types are preserved
 *       to match the existing model.</li>
 *   <li>{@code Date} fields use {@code rs.getTimestamp(...)} which returns
 *       a {@code java.sql.Timestamp}; this upcasts cleanly to
 *       {@code java.util.Date}. If any Date field is actually
 *       {@code java.sql.Date}, swap that specific call to {@code rs.getDate}.</li>
 * </ul>
 */
public final class InstrumentRowMapper {

    private InstrumentRowMapper() {
        // utility class
    }

    /** Positional read — column index MUST match SELECT order. */
    public static Instrument mapByIndex(ResultSet rs) throws SQLException {
        Instrument row = new Instrument();
        row.setID_IMNT(            (Integer) rs.getObject(1));
        row.setNM_IMNT(                      rs.getString(2));
        row.setTX_IMNT(                      rs.getString(3));
        row.setPR_SCALING(           (Float) rs.getObject(4));
        row.setAM_DIV_PR(            (Float) rs.getObject(5));
        row.setID_CL_UND(          (Integer) rs.getObject(6));
        row.setID_RL_CL_UND(                 rs.getString(7));
        row.setAM_MULT_TRD(          (Float) rs.getObject(8));
        row.setCT_PREC_DEC_PR(     (Integer) rs.getObject(9));
        row.setID_TRUNC_RND_PR_CL(           rs.getString(10));
        row.setID_TYP_PR(                    rs.getString(11));
        row.setID_ACC_CPTY(        (Integer) rs.getObject(12));
        row.setID_MKT(             (Integer) rs.getObject(13));
        row.setID_TYP_MKT_PR(                rs.getString(14));
        row.setID_TYP_BOOKING(               rs.getString(15));
        row.setID_REGION(          (Integer) rs.getObject(16));
        row.setID_TYP_IMNT(                  rs.getString(17));
        row.setID_IMNT_UND_MAIN(   (Integer) rs.getObject(18));
        row.setID_IMNT_MOSS(                 rs.getString(19));
        row.setID_IMNT_RIC(                  rs.getString(20));
        row.setID_EXCH_PR(         (Integer) rs.getObject(21));
        row.setID_IMNT_RST(                  rs.getString(22));
        row.setID_CCY_MAIN(                  rs.getString(23));
        row.setID_CCY_CTRT(                  rs.getString(24));
        row.setID_CCY_CNTR(                  rs.getString(25));
        row.setID_CCY_DIV(                   rs.getString(26));
        row.setID_MULT_CCY(                  rs.getString(27));
        row.setID_UNIT_CCY_BSE(    (Integer) rs.getObject(28));
        row.setID_TP_INDX(                   rs.getString(29));
        row.setID_ST_OPTN(                   rs.getString(30));
        row.setID_VERSION(         (Integer) rs.getObject(31));
        row.setAM_DIV_INDX(          (Float) rs.getObject(32));
        row.setID_RV_DIV(                    rs.getString(33));
        row.setCT_YR_DIV_NUM(      (Integer) rs.getObject(34));
        row.setID_NTAX_TAX_IMNT(             rs.getString(35));
        row.setID_SCTY_RISS_WI(              rs.getString(36));
        row.setID_MARGIN(                    rs.getString(37));
        row.setAM_ISSUE(             (Float) rs.getObject(38));
        row.setID_MD_DELIV(                  rs.getString(39));
        row.setAM_TRD_MIN(           (Float) rs.getObject(40));
        row.setAM_SZ_CTRT(           (Float) rs.getObject(41));
        row.setDT_ISSUE(                     rs.getTimestamp(42));
        row.setDT_DELIV(                     rs.getTimestamp(43));
        row.setDT_TRD_LAST(                  rs.getTimestamp(44));
        row.setDT_TRD_FRT(                   rs.getTimestamp(45));
        row.setAM_TICK_SIZE(         (Float) rs.getObject(46));
        row.setID_CMP_FLAG(                  rs.getString(47));
        row.setID_EXST_IN(                   rs.getString(48));
        row.setID_EXCH_OTC(                  rs.getString(49));
        row.setID_CL_PUT(                    rs.getString(50));
        row.setDT_ST_OPTN(                   rs.getTimestamp(51));
        row.setDT_EXPY_IMNT(                 rs.getTimestamp(52));
        row.setDT_PMT_IMNT(                  rs.getTimestamp(53));
        row.setID_MD_PMT_PRM(                rs.getString(54));
        row.setID_TYP_PMT_OPTN(              rs.getString(55));
        row.setID_FTR_CSH(                   rs.getString(56));
        row.setAM_PAYOUT(            (Float) rs.getObject(57));
        row.setAM_STRIKE_INIT(       (Float) rs.getObject(58));
        row.setAM_STRIKE_CURR(       (Float) rs.getObject(59));
        row.setID_IND_CAP(                   rs.getString(60));
        row.setCT_PRD_UNCAP(       (Integer) rs.getObject(61));
        row.setID_TYP_SETT_EXRC(             rs.getString(62));
        row.setID_CL_OPTN(                   rs.getString(63));
        row.setID_STY_OPTN(                  rs.getString(64));
        row.setID_THEO_MTM(                  rs.getString(65));
        row.setID_MDL(             (Integer) rs.getObject(66));
        row.setAM_NOTL(              (Float) rs.getObject(67));
        row.setRT_FX_CROSS(          (Float) rs.getObject(68));
        row.setCT_ROLL_DELIV(      (Integer) rs.getObject(69));
        row.setID_CV_DYBU(                   rs.getString(70));
        row.setID_TYP_TRSRY(                 rs.getString(71));
        row.setID_ARSR(                      rs.getString(72));
        row.setID_TYP_IMNT_LIMIT(            rs.getString(73));
        row.setID_DATA_MKT(                  rs.getString(74));
        row.setID_BS_CR(                     rs.getString(75));
        row.setRT_CPN(               (Float) rs.getObject(76));
        row.setRT_SPRD(              (Float) rs.getObject(77));
        row.setID_LIBOR_HEDGE(               rs.getString(78));
        row.setID_TYP_LEG(                   rs.getString(79));
        row.setID_PAY_RECV(                  rs.getString(80));
        row.setID_EXCH_PPAL(                 rs.getString(81));
        row.setID_ISSUER(                    rs.getString(82));
        row.setID_JPMSI_MKT_MKR(             rs.getString(83));
        row.setID_ROUTE(                     rs.getString(84));
        row.setID_SECTOR(          (Integer) rs.getObject(85));
        row.setID_UV_IMNT(                   rs.getString(86));
        row.setID_SEC_FEE(                   rs.getString(87));
        row.setID_MRV_EXCHANGE(              rs.getString(88));
        row.setID_CTRY_ISSUER(               rs.getString(89));
        row.setID_CTRY_REG(                  rs.getString(90));
        row.setID_STS_MNT(                   rs.getString(91));
        row.setID_REPLACED(                  rs.getString(92));
        row.setID_SETT_SA(                   rs.getString(93));
        row.setID_CCY_ISSUE(                 rs.getString(94));
        row.setID_REGS(                      rs.getString(95));
        row.setID_REG144A(                   rs.getString(96));
        row.setDT_CREATE(                    rs.getTimestamp(97));
        row.setID_USER_CREATE(               rs.getString(98));
        row.setDT_CHG_LST(                   rs.getTimestamp(99));
        row.setID_USER_CHG_LST(              rs.getString(100));
        row.setDT_CHG_GRD(                   rs.getTimestamp(101));
        row.setID_DEL_GRD(                   rs.getString(102));
        row.setID_OWN_GRD(         (Integer) rs.getObject(103));
        return row;
    }

    /** Name-based read — robust to SELECT column reordering. */
    public static Instrument mapByName(ResultSet rs) throws SQLException {
        Instrument row = new Instrument();
        row.setID_IMNT(            (Integer) rs.getObject("ID_IMNT"));
        row.setNM_IMNT(                      rs.getString("NM_IMNT"));
        row.setTX_IMNT(                      rs.getString("TX_IMNT"));
        row.setPR_SCALING(           (Float) rs.getObject("PR_SCALING"));
        row.setAM_DIV_PR(            (Float) rs.getObject("AM_DIV_PR"));
        row.setID_CL_UND(          (Integer) rs.getObject("ID_CL_UND"));
        row.setID_RL_CL_UND(                 rs.getString("ID_RL_CL_UND"));
        row.setAM_MULT_TRD(          (Float) rs.getObject("AM_MULT_TRD"));
        row.setCT_PREC_DEC_PR(     (Integer) rs.getObject("CT_PREC_DEC_PR"));
        row.setID_TRUNC_RND_PR_CL(           rs.getString("ID_TRUNC_RND_PR_CL"));
        row.setID_TYP_PR(                    rs.getString("ID_TYP_PR"));
        row.setID_ACC_CPTY(        (Integer) rs.getObject("ID_ACC_CPTY"));
        row.setID_MKT(             (Integer) rs.getObject("ID_MKT"));
        row.setID_TYP_MKT_PR(                rs.getString("ID_TYP_MKT_PR"));
        row.setID_TYP_BOOKING(               rs.getString("ID_TYP_BOOKING"));
        row.setID_REGION(          (Integer) rs.getObject("ID_REGION"));
        row.setID_TYP_IMNT(                  rs.getString("ID_TYP_IMNT"));
        row.setID_IMNT_UND_MAIN(   (Integer) rs.getObject("ID_IMNT_UND_MAIN"));
        row.setID_IMNT_MOSS(                 rs.getString("ID_IMNT_MOSS"));
        row.setID_IMNT_RIC(                  rs.getString("ID_IMNT_RIC"));
        row.setID_EXCH_PR(         (Integer) rs.getObject("ID_EXCH_PR"));
        row.setID_IMNT_RST(                  rs.getString("ID_IMNT_RST"));
        row.setID_CCY_MAIN(                  rs.getString("ID_CCY_MAIN"));
        row.setID_CCY_CTRT(                  rs.getString("ID_CCY_CTRT"));
        row.setID_CCY_CNTR(                  rs.getString("ID_CCY_CNTR"));
        row.setID_CCY_DIV(                   rs.getString("ID_CCY_DIV"));
        row.setID_MULT_CCY(                  rs.getString("ID_MULT_CCY"));
        row.setID_UNIT_CCY_BSE(    (Integer) rs.getObject("ID_UNIT_CCY_BSE"));
        row.setID_TP_INDX(                   rs.getString("ID_TP_INDX"));
        row.setID_ST_OPTN(                   rs.getString("ID_ST_OPTN"));
        row.setID_VERSION(         (Integer) rs.getObject("ID_VERSION"));
        row.setAM_DIV_INDX(          (Float) rs.getObject("AM_DIV_INDX"));
        row.setID_RV_DIV(                    rs.getString("ID_RV_DIV"));
        row.setCT_YR_DIV_NUM(      (Integer) rs.getObject("CT_YR_DIV_NUM"));
        row.setID_NTAX_TAX_IMNT(             rs.getString("ID_NTAX_TAX_IMNT"));
        row.setID_SCTY_RISS_WI(              rs.getString("ID_SCTY_RISS_WI"));
        row.setID_MARGIN(                    rs.getString("ID_MARGIN"));
        row.setAM_ISSUE(             (Float) rs.getObject("AM_ISSUE"));
        row.setID_MD_DELIV(                  rs.getString("ID_MD_DELIV"));
        row.setAM_TRD_MIN(           (Float) rs.getObject("AM_TRD_MIN"));
        row.setAM_SZ_CTRT(           (Float) rs.getObject("AM_SZ_CTRT"));
        row.setDT_ISSUE(                     rs.getTimestamp("DT_ISSUE"));
        row.setDT_DELIV(                     rs.getTimestamp("DT_DELIV"));
        row.setDT_TRD_LAST(                  rs.getTimestamp("DT_TRD_LAST"));
        row.setDT_TRD_FRT(                   rs.getTimestamp("DT_TRD_FRT"));
        row.setAM_TICK_SIZE(         (Float) rs.getObject("AM_TICK_SIZE"));
        row.setID_CMP_FLAG(                  rs.getString("ID_CMP_FLAG"));
        row.setID_EXST_IN(                   rs.getString("ID_EXST_IN"));
        row.setID_EXCH_OTC(                  rs.getString("ID_EXCH_OTC"));
        row.setID_CL_PUT(                    rs.getString("ID_CL_PUT"));
        row.setDT_ST_OPTN(                   rs.getTimestamp("DT_ST_OPTN"));
        row.setDT_EXPY_IMNT(                 rs.getTimestamp("DT_EXPY_IMNT"));
        row.setDT_PMT_IMNT(                  rs.getTimestamp("DT_PMT_IMNT"));
        row.setID_MD_PMT_PRM(                rs.getString("ID_MD_PMT_PRM"));
        row.setID_TYP_PMT_OPTN(              rs.getString("ID_TYP_PMT_OPTN"));
        row.setID_FTR_CSH(                   rs.getString("ID_FTR_CSH"));
        row.setAM_PAYOUT(            (Float) rs.getObject("AM_PAYOUT"));
        row.setAM_STRIKE_INIT(       (Float) rs.getObject("AM_STRIKE_INIT"));
        row.setAM_STRIKE_CURR(       (Float) rs.getObject("AM_STRIKE_CURR"));
        row.setID_IND_CAP(                   rs.getString("ID_IND_CAP"));
        row.setCT_PRD_UNCAP(       (Integer) rs.getObject("CT_PRD_UNCAP"));
        row.setID_TYP_SETT_EXRC(             rs.getString("ID_TYP_SETT_EXRC"));
        row.setID_CL_OPTN(                   rs.getString("ID_CL_OPTN"));
        row.setID_STY_OPTN(                  rs.getString("ID_STY_OPTN"));
        row.setID_THEO_MTM(                  rs.getString("ID_THEO_MTM"));
        row.setID_MDL(             (Integer) rs.getObject("ID_MDL"));
        row.setAM_NOTL(              (Float) rs.getObject("AM_NOTL"));
        row.setRT_FX_CROSS(          (Float) rs.getObject("RT_FX_CROSS"));
        row.setCT_ROLL_DELIV(      (Integer) rs.getObject("CT_ROLL_DELIV"));
        row.setID_CV_DYBU(                   rs.getString("ID_CV_DYBU"));
        row.setID_TYP_TRSRY(                 rs.getString("ID_TYP_TRSRY"));
        row.setID_ARSR(                      rs.getString("ID_ARSR"));
        row.setID_TYP_IMNT_LIMIT(            rs.getString("ID_TYP_IMNT_LIMIT"));
        row.setID_DATA_MKT(                  rs.getString("ID_DATA_MKT"));
        row.setID_BS_CR(                     rs.getString("ID_BS_CR"));
        row.setRT_CPN(               (Float) rs.getObject("RT_CPN"));
        row.setRT_SPRD(              (Float) rs.getObject("RT_SPRD"));
        row.setID_LIBOR_HEDGE(               rs.getString("ID_LIBOR_HEDGE"));
        row.setID_TYP_LEG(                   rs.getString("ID_TYP_LEG"));
        row.setID_PAY_RECV(                  rs.getString("ID_PAY_RECV"));
        row.setID_EXCH_PPAL(                 rs.getString("ID_EXCH_PPAL"));
        row.setID_ISSUER(                    rs.getString("ID_ISSUER"));
        row.setID_JPMSI_MKT_MKR(             rs.getString("ID_JPMSI_MKT_MKR"));
        row.setID_ROUTE(                     rs.getString("ID_ROUTE"));
        row.setID_SECTOR(          (Integer) rs.getObject("ID_SECTOR"));
        row.setID_UV_IMNT(                   rs.getString("ID_UV_IMNT"));
        row.setID_SEC_FEE(                   rs.getString("ID_SEC_FEE"));
        row.setID_MRV_EXCHANGE(              rs.getString("ID_MRV_EXCHANGE"));
        row.setID_CTRY_ISSUER(               rs.getString("ID_CTRY_ISSUER"));
        row.setID_CTRY_REG(                  rs.getString("ID_CTRY_REG"));
        row.setID_STS_MNT(                   rs.getString("ID_STS_MNT"));
        row.setID_REPLACED(                  rs.getString("ID_REPLACED"));
        row.setID_SETT_SA(                   rs.getString("ID_SETT_SA"));
        row.setID_CCY_ISSUE(                 rs.getString("ID_CCY_ISSUE"));
        row.setID_REGS(                      rs.getString("ID_REGS"));
        row.setID_REG144A(                   rs.getString("ID_REG144A"));
        row.setDT_CREATE(                    rs.getTimestamp("DT_CREATE"));
        row.setID_USER_CREATE(               rs.getString("ID_USER_CREATE"));
        row.setDT_CHG_LST(                   rs.getTimestamp("DT_CHG_LST"));
        row.setID_USER_CHG_LST(              rs.getString("ID_USER_CHG_LST"));
        row.setDT_CHG_GRD(                   rs.getTimestamp("DT_CHG_GRD"));
        row.setID_DEL_GRD(                   rs.getString("ID_DEL_GRD"));
        row.setID_OWN_GRD(         (Integer) rs.getObject("ID_OWN_GRD"));
        return row;
    }
}
