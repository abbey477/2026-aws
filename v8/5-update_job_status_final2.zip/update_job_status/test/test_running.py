"""
test_running.py
Tests for the RUNNING (heartbeat) status path of the UpdateJobStatus Lambda.
"""

from test.conftest import make_event
from update_job_status.handler import lambda_handler


class TestUpdateRunning:
    """Tests for RUNNING (still running) outcome."""

    def test_running_updates_heartbeat(self, dynamodb_setup, monkeypatch):
        """RUNNING updates last_heartbeat_time and extends expiry_time."""
        dynamodb, table = dynamodb_setup
        monkeypatch.setattr(
            "update_job_status.handler.get_dynamodb_resource",
            lambda: dynamodb,
        )

        event = make_event(job_status="RUNNING")
        result = lambda_handler(event, None)

        assert result["update_result"]["effective_status"] == "RUNNING"

        item = table.get_item(Key={"run_id": "run-001"})["Item"]
        assert item["last_heartbeat_time"] != ""
        assert item["expiry_time"] != ""

    def test_running_expiry_is_after_heartbeat(self, dynamodb_setup, monkeypatch):
        """expiry_time must be strictly after last_heartbeat_time (+5 min)."""
        from datetime import datetime

        dynamodb, table = dynamodb_setup
        monkeypatch.setattr(
            "update_job_status.handler.get_dynamodb_resource",
            lambda: dynamodb,
        )

        event = make_event(job_status="RUNNING")
        lambda_handler(event, None)

        item = table.get_item(Key={"run_id": "run-001"})["Item"]
        fmt = "%Y-%m-%dT%H:%M:%SZ"
        heartbeat = datetime.strptime(item["last_heartbeat_time"], fmt)
        expiry = datetime.strptime(item["expiry_time"], fmt)

        assert expiry > heartbeat

    def test_running_does_not_change_status_field(self, dynamodb_setup, monkeypatch):
        """RUNNING heartbeat update must NOT alter the status field."""
        dynamodb, table = dynamodb_setup
        monkeypatch.setattr(
            "update_job_status.handler.get_dynamodb_resource",
            lambda: dynamodb,
        )

        event = make_event(job_status="RUNNING")
        lambda_handler(event, None)

        item = table.get_item(Key={"run_id": "run-001"})["Item"]
        # status should remain as seeded ("WAITING") - RUNNING only touches
        # heartbeat and expiry
        assert item["status"] == "WAITING"
