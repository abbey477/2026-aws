package com.myapp.config;

import com.myapp.config.ApplicationProperties.DatasourceEntry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

/**
 * Prints the bound {@link ApplicationProperties} to the console once the
 * application context is ready.
 *
 * <p>The {@code credential} field is masked so secrets never reach the logs
 * (or any downstream log aggregator / secret scanner).
 */
@Component
public class PropertiesLogger implements ApplicationRunner {

    private static final Logger log = LoggerFactory.getLogger(PropertiesLogger.class);
    private static final String MASK = "********";

    private final ApplicationProperties props;
    private final Environment env;

    public PropertiesLogger(ApplicationProperties props, Environment env) {
        this.props = props;
        this.env = env;
    }

    @Override
    public void run(ApplicationArguments args) {
        log.info("==================== APPLICATION PROPERTIES ====================");
        log.info("Active profiles : {}", String.join(",", env.getActiveProfiles()));

        logDatasource("MySQL", props.datasource().mysql());
        logDatasource("PostgreSQL", props.datasource().postgres());
        logDatasource("H2", props.datasource().h2());

        ApplicationProperties.Kerberos k = props.kerberos();
        if (k != null) {
            log.info("[Kerberos/global] krb5Conf={}, debug={}", k.krb5Conf(), k.debug());
        }
        log.info("================================================================");
    }

    private void logDatasource(String name, DatasourceEntry e) {
        if (e == null) {
            log.info("[{}] (not configured)", name);
            return;
        }
        log.info("[{}] authType={}", name, e.authType());
        log.info("[{}]   url={}", name, e.url());
        log.info("[{}]   driver={}", name, e.driverClassName());
        log.info("[{}]   username={}", name, e.username());
        log.info("[{}]   credential={}", name, mask(e.credential()));
        if (e.hikari() != null) {
            log.info("[{}]   hikari: maxPoolSize={}, minIdle={}, poolName={}",
                    name, e.hikari().maximumPoolSize(),
                    e.hikari().minimumIdle(), e.hikari().poolName());
        }
        if (e.kerberos() != null) {
            ApplicationProperties.KerberosAuth ka = e.kerberos();
            log.info("[{}]   kerberos: principal={}, keytab={}, realm={}, kdc={}",
                    name, ka.principal(), ka.keytab(), ka.realm(), ka.kdc());
        }
    }

    /** Masks a secret; treats null/blank as "(none)" so the log stays readable. */
    private String mask(String value) {
        if (value == null || value.isBlank()) {
            return "(none)";
        }
        return MASK;
    }
}
