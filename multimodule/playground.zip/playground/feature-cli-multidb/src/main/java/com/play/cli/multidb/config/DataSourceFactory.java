package com.play.cli.multidb.config;

import com.zaxxer.hikari.HikariDataSource;
import org.springframework.boot.jdbc.DataSourceBuilder;

import javax.sql.DataSource;

/**
 * Builds a pooled {@link DataSource} from a {@link DataSourceProperties.DbConfig}.
 * Centralised so every per-DB config class builds its datasource identically.
 */
final class DataSourceFactory {

    private DataSourceFactory() {
    }

    static DataSource build(String name, DataSourceProperties.DbConfig cfg) {
        if (cfg == null) {
            throw new IllegalStateException("Missing config for datasource: " + name);
        }
        HikariDataSource ds = DataSourceBuilder.create()
                .type(HikariDataSource.class)
                .url(cfg.url())
                .username(cfg.username())
                .password(cfg.password())
                .driverClassName(cfg.driverClassName())
                .build();
        ds.setPoolName(name + "-pool");
        return ds;
    }
}
