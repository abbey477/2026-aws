"""
Shared pytest fixtures for GetConfig tests.

pytest auto-discovers this file; fixtures defined here are available to
every test_*.py in this directory without explicit import.

We also add this directory to sys.path so tests can `from seed_data import ...`
(conftest.py is not importable as a regular module, but seed_data.py is).
"""

import sys
from pathlib import Path

# Make the test/ directory itself importable so `from seed_data import ...` works.
sys.path.insert(0, str(Path(__file__).parent))

import pytest
import boto3
from moto import mock_aws
from unittest.mock import patch

from seed_data import make_job_run_item, make_job_config_item


@pytest.fixture(autouse=True)
def mock_write_log():
    """
    Prevent write_log from hitting real DynamoDB in most tests.

    Applied automatically (autouse) — tests don't need to request it.
    Yields the mock so tests can assert call args.

    Patch target: where write_log is *used* (the handler module), not
    where it's defined — because handler.py does `from ... import write_log`.
    """
    with patch("get_config.handler.write_log") as m:
        yield m


@pytest.fixture
def _mock_write_log(mock_write_log):
    """Alias for tests written against the underscore-prefixed name."""
    return mock_write_log


@pytest.fixture
def dynamodb_tables():
    """
    Create mock DynamoDB tables matching production schema:
      - job_run: composite key (run_id, last_updated_time)
      - job_config: composite key (job_id, job_type)
    Seeded with one default row each.
    """
    with mock_aws():
        dynamodb = boto3.resource("dynamodb", region_name="us-east-1")

        job_run_table = dynamodb.create_table(
            TableName="app-jobRun",
            KeySchema=[
                {"AttributeName": "run_id", "KeyType": "HASH"},
                {"AttributeName": "last_updated_time", "KeyType": "RANGE"},
            ],
            AttributeDefinitions=[
                {"AttributeName": "run_id", "AttributeType": "S"},
                {"AttributeName": "last_updated_time", "AttributeType": "S"},
            ],
            BillingMode="PAY_PER_REQUEST",
        )

        job_config_table = dynamodb.create_table(
            TableName="app-jobConfig",
            KeySchema=[
                {"AttributeName": "job_id", "KeyType": "HASH"},
                {"AttributeName": "job_type", "KeyType": "RANGE"},
            ],
            AttributeDefinitions=[
                {"AttributeName": "job_id", "AttributeType": "S"},
                {"AttributeName": "job_type", "AttributeType": "S"},
            ],
            BillingMode="PAY_PER_REQUEST",
        )

        job_run_table.put_item(Item=make_job_run_item())
        job_config_table.put_item(Item=make_job_config_item())

        yield dynamodb


@pytest.fixture
def patched_handler(dynamodb_tables, monkeypatch):
    """
    Patch get_dynamodb_resource so the handler uses the mock tables.

    handler.py does `from get_config.dynamodb_ops import get_dynamodb_resource`,
    so the handler captures its own reference at import time. We patch it
    where it's *used* (in handler) — not where it was defined.
    """
    monkeypatch.setattr(
        "get_config.handler.get_dynamodb_resource",
        lambda: dynamodb_tables,
    )
    return dynamodb_tables
