"""
test_handler.py
Integration tests for handler.lambda_handler.

Tests:
  1. Success — trigger_result added with TRIGGERED + runner metadata
  2. Failure — trigger_result added with TRIGGER_FAILED + runner metadata
  3. Original event fields are preserved in the returned payload
  4. Handler sets runner_name and runner_type on trigger_result
  5. write_log called with correct args on success
  6. write_log called with correct args on failure
"""

import urllib.error
import pytest
from unittest.mock import patch, call

from handler import lambda_handler

_URLOPEN = "databricks_client.urllib.request.urlopen"


# ---------------------------------------------------------------------------
# Success
# ---------------------------------------------------------------------------

class TestLambdaHandlerSuccess:

    @patch(_URLOPEN)
    def test_trigger_result_added_on_success(self, mock_urlopen, make_event, mock_urlopen_success):
        """Handler adds trigger_result with TRIGGERED status and run_id."""
        mock_urlopen.return_value = mock_urlopen_success("67890")
        event = make_event()

        result = lambda_handler(event, None)

        assert "trigger_result" in result
        tr = result["trigger_result"]
        assert tr["trigger_status"] == "TRIGGERED"
        assert tr["dbr_run_id"] == "67890"
        assert tr["runner_name"] == "DBR"
        assert tr["runner_type"] == "DBR"

    @patch(_URLOPEN)
    def test_original_event_fields_preserved(self, mock_urlopen, make_event, mock_urlopen_success):
        """Handler returns all original event fields plus trigger_result."""
        mock_urlopen.return_value = mock_urlopen_success("67890")
        event = make_event()

        result = lambda_handler(event, None)

        assert result["run_id"] == "run-002"
        assert result["job_id"] == "dbr-client"
        assert result["job_config"]["job_runner"]["type"] == "Databricks"
        assert "trigger_result" in result

    @patch(_URLOPEN)
    def test_write_log_called_with_triggered_status(self, mock_urlopen, make_event, mock_urlopen_success, mock_write_log):
        """write_log receives TRIGGERED status on success."""
        mock_urlopen.return_value = mock_urlopen_success("67890")
        event = make_event()

        with patch("handler.write_log") as patched_write_log:
            lambda_handler(event, None)
            patched_write_log.assert_called_once_with(
                run_id="run-002",
                job_id="dbr-client",
                stage="TriggerDbrJob",
                status="TRIGGERED",
            )


# ---------------------------------------------------------------------------
# Failure
# ---------------------------------------------------------------------------

class TestLambdaHandlerFailure:

    @patch(_URLOPEN)
    def test_trigger_result_added_on_failure(self, mock_urlopen, make_event):
        """Handler adds trigger_result with TRIGGER_FAILED on network error."""
        mock_urlopen.side_effect = urllib.error.URLError("Connection refused")
        event = make_event()

        result = lambda_handler(event, None)

        tr = result["trigger_result"]
        assert tr["trigger_status"] == "TRIGGER_FAILED"
        assert tr["runner_name"] == "DBR"
        assert tr["runner_type"] == "DBR"
        assert tr["dbr_run_id"] == ""

    @patch(_URLOPEN)
    def test_write_log_called_with_failed_status(self, mock_urlopen, make_event):
        """write_log receives TRIGGER_FAILED status on error."""
        mock_urlopen.side_effect = urllib.error.URLError("Connection refused")
        event = make_event()

        with patch("handler.write_log") as patched_write_log:
            lambda_handler(event, None)
            patched_write_log.assert_called_once_with(
                run_id="run-002",
                job_id="dbr-client",
                stage="TriggerDbrJob",
                status="TRIGGER_FAILED",
            )


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------

class TestLambdaHandlerEdgeCases:

    @patch(_URLOPEN)
    def test_missing_run_id_uses_unknown(self, mock_urlopen, make_event, mock_urlopen_success):
        """Handler falls back to UNKNOWN when event has no run_id."""
        mock_urlopen.return_value = mock_urlopen_success()
        event = make_event()
        del event["run_id"]

        result = lambda_handler(event, None)

        assert "trigger_result" in result

    @patch(_URLOPEN)
    def test_empty_job_config_does_not_raise(self, mock_urlopen, make_event):
        """Handler handles missing job_config gracefully without raising."""
        mock_urlopen.side_effect = urllib.error.URLError("no host")
        event = make_event()
        event["job_config"] = {}

        result = lambda_handler(event, None)

        assert result["trigger_result"]["trigger_status"] == "TRIGGER_FAILED"
