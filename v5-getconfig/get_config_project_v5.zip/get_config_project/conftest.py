"""
pytest configuration — ensures the project root is on sys.path
so `from lambdas.get_config.handler import ...` resolves.

Also sets dummy AWS env vars so boto3 resource creation works locally.
moto ignores these values but boto3 requires them to be set.

NOTE: Only needed for running tests standalone. If your real project
already handles Python path / AWS creds elsewhere, you can delete this file.
"""

import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

os.environ.setdefault("AWS_DEFAULT_REGION", "us-east-1")
os.environ.setdefault("AWS_ACCESS_KEY_ID", "testing")
os.environ.setdefault("AWS_SECRET_ACCESS_KEY", "testing")
os.environ.setdefault("AWS_SESSION_TOKEN", "testing")
