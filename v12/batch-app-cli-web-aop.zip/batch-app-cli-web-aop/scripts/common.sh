#!/bin/bash
# ============================================================
# common.sh — shared logic for all run-batch-<env>.sh scripts
#
# Don't run this directly. It's sourced by the per-env wrappers
# (run-batch-dev.sh, run-batch-test.sh, run-batch-prod.sh).
#
# The per-env wrapper sets these variables before sourcing this:
#   ENV          — dev | test | prod
#   APP_HOME     — directory containing the jar
#   JAR_NAME     — jar filename (typically a symlink to current version)
#   LOG_DIR      — where to write log files
#   JAVA_OPTS    — JVM options (heap, GC, etc.)
#   SPRING_PROFILE — Spring profile name (usually same as ENV)
# ============================================================

set -euo pipefail

# Valid job names — keep in sync with @Component BatchJob classes.
VALID_JOBS=("jobA" "jobB" "jobC")

run_batch_job() {
    local job_name="${1:-}"

    # ---- Argument validation ----
    if [[ -z "$job_name" ]]; then
        echo "ERROR: Job name is required." >&2
        echo "Usage: $0 <jobName>" >&2
        echo "Valid jobs: ${VALID_JOBS[*]}" >&2
        exit 64    # standard "command line usage error"
    fi

    if [[ ! " ${VALID_JOBS[*]} " =~ " ${job_name} " ]]; then
        echo "ERROR: Unknown job '$job_name'." >&2
        echo "Valid jobs: ${VALID_JOBS[*]}" >&2
        exit 64
    fi

    # ---- Required env vars from caller ----
    : "${ENV:?ENV must be set by the caller}"
    : "${APP_HOME:?APP_HOME must be set}"
    : "${JAR_NAME:?JAR_NAME must be set}"
    : "${LOG_DIR:?LOG_DIR must be set}"
    : "${JAVA_OPTS:?JAVA_OPTS must be set}"
    : "${SPRING_PROFILE:?SPRING_PROFILE must be set}"

    # ---- Resolve paths ----
    local jar_path="${APP_HOME}/${JAR_NAME}"
    if [[ ! -f "$jar_path" ]]; then
        echo "ERROR: Jar not found at $jar_path" >&2
        exit 66    # "cannot open input"
    fi

    mkdir -p "$LOG_DIR"
    local timestamp=$(date +%Y%m%d_%H%M%S)
    local run_date=$(date +%Y-%m-%d)
    local log_file="${LOG_DIR}/${job_name}_${timestamp}.log"

    # ---- Fetch secrets (replace this with your real secret retrieval) ----
    # Example with HashiCorp Vault CLI:
    #   export DB_PASSWORD=$(vault kv get -field=password secret/batch/${ENV}/db)
    # Example with AWS Secrets Manager:
    #   export DB_PASSWORD=$(aws secretsmanager get-secret-value --secret-id batch/${ENV}/db --query SecretString --output text)
    # For now, expect DB_PASSWORD to already be set in the environment.
    if [[ "$ENV" != "dev" && -z "${DB_PASSWORD:-}" ]]; then
        echo "WARN: DB_PASSWORD not set. Update common.sh with your secret fetching logic." >&2
    fi

    # ---- Log what we're about to do ----
    echo "============================================================"
    echo "Starting batch job"
    echo "  env:        $ENV"
    echo "  job:        $job_name"
    echo "  runDate:    $run_date"
    echo "  profile:    $SPRING_PROFILE"
    echo "  jar:        $jar_path"
    echo "  log:        $log_file"
    echo "  java opts:  $JAVA_OPTS"
    echo "============================================================"

    # ---- Invoke Java (foreground, exit code propagates) ----
    # Note: jar's default main is BatchWebApplication (REST mode).
    # We invoke BatchCliApplication explicitly via Spring Boot's PropertiesLauncher.
    java $JAVA_OPTS \
        -Dspring.profiles.active="$SPRING_PROFILE" \
        -Dlogging.file.name="$log_file" \
        -Dloader.main=com.example.batch.BatchCliApplication \
        -cp "$jar_path" \
        org.springframework.boot.loader.launch.PropertiesLauncher \
        --job="$job_name" \
        --runDate="$run_date"

    local exit_code=$?
    echo "Job '$job_name' exited with code $exit_code"
    exit $exit_code
}
