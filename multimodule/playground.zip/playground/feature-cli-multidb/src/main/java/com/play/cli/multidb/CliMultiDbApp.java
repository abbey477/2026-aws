package com.play.cli.multidb;

import com.play.common.FeatureBanner;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 * Non-web feature: opens two datasources from one application and runs a
 * query against each, proving both connections work independently.
 *
 * <p>{@code DataSourceAutoConfiguration} is excluded because we build the
 * datasources by hand — otherwise Boot would also try to auto-create one
 * from {@code spring.datasource.*} and the bean wiring gets ambiguous.
 */
@SpringBootApplication(exclude = DataSourceAutoConfiguration.class)
@ConfigurationPropertiesScan
public class CliMultiDbApp implements CommandLineRunner {

    private final JdbcTemplate primary;
    private final JdbcTemplate secondary;

    public CliMultiDbApp(
            @Qualifier("primaryJdbcTemplate") JdbcTemplate primary,
            @Qualifier("secondaryJdbcTemplate") JdbcTemplate secondary) {
        this.primary = primary;
        this.secondary = secondary;
    }

    public static void main(String[] args) {
        SpringApplication.run(CliMultiDbApp.class, args);
    }

    @Override
    public void run(String... args) {
        System.out.println(FeatureBanner.of("cli-multidb"));
        check("primary", primary);
        check("secondary", secondary);
    }

    private void check(String label, JdbcTemplate jdbc) {
        try {
            String version = jdbc.queryForObject("SELECT H2VERSION()", String.class);
            String url = jdbc.queryForObject(
                    "SELECT SETTING_VALUE FROM INFORMATION_SCHEMA.SETTINGS WHERE SETTING_NAME = 'CREATE_BUILD'",
                    String.class);
            System.out.printf("[%s] connected OK  (H2 %s, build %s)%n", label, version, url);
        } catch (Exception e) {
            System.err.printf("[%s] connection FAILED: %s%n", label, e.getMessage());
        }
    }
}
