package com.example.dbtester.entity;

import java.math.BigDecimal;

/**
 * Maps to Oracle PRODUCT table:
 *   id       NUMBER(19) PRIMARY KEY,
 *   sku      VARCHAR2(50),
 *   name     VARCHAR2(200),
 *   price    NUMBER(12,2),
 *   in_stock NUMBER(1)   -- 0/1 mapped to boolean
 */
public record Product(
        Long id,
        String sku,
        String name,
        BigDecimal price,
        boolean inStock
) {}
