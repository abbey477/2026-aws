#!/bin/bash
# ============================================================
# run-batch-test.sh — entry point for Autosys (test environment)
# Usage: run-batch-test.sh <jobName>
# ============================================================

export ENV="test"
export APP_HOME="/opt/jobs/test"
export JAR_NAME="batch-app.jar"
export LOG_DIR="/var/log/batch/test"
export JAVA_OPTS="-Xms512m -Xmx2g -XX:+HeapDumpOnOutOfMemoryError"
export SPRING_PROFILE="test"

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
source "${SCRIPT_DIR}/common.sh"

run_batch_job "$@"
