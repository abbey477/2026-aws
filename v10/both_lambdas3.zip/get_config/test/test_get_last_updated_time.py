"""Tests for the get_last_updated_time helper."""
from datetime import datetime
from get_config.dynamodb_ops import get_last_updated_time


class TestGetLastUpdatedTime:

    def test_returns_provided_value(self):
        assert get_last_updated_time("2024-03-15T10:00:00Z") == "2024-03-15T10:00:00Z"

    def test_auto_sets_when_none(self):
        result = get_last_updated_time(None)
        assert result.endswith("Z")
        datetime.strptime(result, "%Y-%m-%dT%H:%M:%SZ")

    def test_auto_sets_when_empty(self):
        result = get_last_updated_time("")
        assert result != "" and result.endswith("Z")

    def test_auto_sets_when_omitted(self):
        result = get_last_updated_time()
        assert result.endswith("Z")
