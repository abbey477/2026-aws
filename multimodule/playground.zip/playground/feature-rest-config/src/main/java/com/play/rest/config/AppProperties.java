package com.play.rest.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Type-safe binding of {@code app.*} from application.properties.
 * Discovered via {@code @ConfigurationPropertiesScan} on the main class.
 */
@ConfigurationProperties(prefix = "app")
public record AppProperties(
        String name,
        String environment,
        Owner owner
) {
    public record Owner(String team, String contact) {
    }
}
