"""
Stub for write_log — this module already exists in your codebase.
Included here so the handler import resolves during local testing.
Replace with your actual implementation or remove this file if
your real `lambdas/log_to_dynamo.py` is present.
"""


def write_log(run_id: str, job_id: str, stage: str, status: str) -> None:
    """Write a stage-level log entry to DynamoDB."""
    pass
