# PreStepsProcessor Lambda

Processes the `pre_steps` array from GetConfig's output before the job
is routed to the right runner. This lambda sits **between GetConfig and
RunnerTypeChoice** in the orchestrator Step Function.

---

## Project structure

```
pre_steps_processor/
├── src/
│   └── pre_steps_processor/             ← the lambda code (importable package)
│       ├── __init__.py
│       ├── handler.py                   ← entry point (lambda_handler lives here)
│       ├── step_handlers.py             ← one function per pre_step_type
│       ├── dynamodb_ops.py              ← DynamoDB query helpers
│       ├── logging_utils.py             ← structured logging (info/warn/error/debug)
│       └── log_to_dynamo.py             ← writes to the shared logs table
│
├── test/                                ← unit tests
│   ├── conftest.py                      ← shared fixtures (auto-loaded by pytest)
│   ├── seed_data.py                     ← test data builders (importable helper)
│   ├── test_routing_no_data.py          ← no pre_steps / empty / invalid
│   ├── test_routing_known.py            ← known pre_step_type routing
│   ├── test_routing_unknown.py          ← unknown pre_step_type handling
│   ├── test_output_shape.py             ← output contract verification
│   ├── test_change_since_append.py      ← query helper + end-to-end
│   └── test_ddb_config_pull.py          ← query helper + end-to-end
│
├── Makefile                             ← run common tasks with `make <target>`
├── pytest.ini                           ← tells pytest where to find code + tests
├── requirements.txt                     ← production dependencies
├── requirements-dev.txt                 ← test/lint dependencies
├── pyproject.toml                       ← Poetry config (optional)
├── poetry.toml                          ← Poetry settings (optional)
└── .gitignore
```

---

## Getting started

### Prerequisites

- **Python 3.12** or newer
- That's it! (Poetry is optional)

### Option A — Plain pip + venv (recommended for beginners)

This is the simplest way. It creates a virtual environment and installs
everything you need.

```bash
# 1. Go into the project folder
cd lambdas/pre_steps_processor

# 2. Create the virtual environment and install dependencies
make venv

# 3. Run the tests
make test
```

**What `make venv` does behind the scenes:**
```bash
python3 -m venv .venv                                              # create venv
.venv/bin/pip install -r requirements.txt -r requirements-dev.txt  # install deps
```

If you prefer to do it manually (without Make):
```bash
python3 -m venv .venv
source .venv/bin/activate          # activate the venv (Linux/Mac)
pip install -r requirements.txt -r requirements-dev.txt
pytest                             # run the tests
```

### Option B — Poetry (full dependency management)

If you already have [Poetry](https://python-poetry.org/) installed:

```bash
cd lambdas/pre_steps_processor
make install     # runs `poetry install`
make test        # runs `poetry run pytest`
```

---

## Running things

All commands work with **both** setup options (pip+venv or Poetry).

| What you want | Command | What it does |
|---|---|---|
| Run tests | `make test` | Runs all 36 unit tests |
| Run linting | `make lint` | Checks code style (ruff) + types (mypy) |
| Auto-format code | `make format` | Fixes formatting (black + ruff) |
| Clean everything | `make clean` | Removes .venv, caches, build files |
| Build deployment zip | `make package` | Creates `dist/pre_steps_processor.zip` for AWS |

---

## What this lambda does

### The big picture

GetConfig returns a payload that contains a `pre_steps` array. Each item in
that array describes something that needs to happen **before** the job
runs. This lambda iterates through those items and routes each one to the
right handler.

### Routing rules (how each `pre_step_type` is handled)

| `pre_step_type` value | What happens | Where the result goes |
|---|---|---|
| `change_since_append` | Queries DynamoDB to find the start_time of the last successful run | `pre_steps_results.change_since_append` |
| `ddb_config_pull` | Reads config tables listed in `tables` field | Merged into `job_config.job_param` (by table name) |
| anything else | Logs a warning, calls a stub handler | Logged only |
| (no data / empty) | Calls `handle_no_pre_steps` stub | Nothing |

### Input example

This lambda receives the **entire output from GetConfig** — a big JSON payload.
The relevant part is `event["job_config"]["pre_steps"]`:

```json
{
    "run_id": "run-001",
    "job_id": "client",
    "job_type": "sourcing",
    "job_config": {
        "pre_steps": [
            { "pre_step_type": "change_since_append" },
            {
                "pre_step_type": "ddb_config_pull",
                "tables": ["service_config", "table_config"]
            }
        ],
        "job_param": { "batch_size": 1000 },
        "...": "..."
    }
}
```

### Output example

The input event is returned with two possible additions:

```json
{
    "run_id": "run-001",
    "job_id": "client",
    "...all original fields...": "...",

    "job_config": {
        "job_param": {
            "batch_size": 1000,
            "service_config": { "...pulled row..." },
            "table_config": null
        },
        "...": "..."
    },

    "pre_steps_results": {
        "change_since_append": {
            "last_successful_start_time": "2024-01-01T00:00:00Z",
            "placeholder": true
        }
    }
}
```

**Key points about the output:**
- `ddb_config_pull` results go **into `job_param`**, keyed by table name.
  Missing rows show up as `null`.
- Other handler results go **into `pre_steps_results`**, keyed by
  `pre_step_type`.
- All original fields from the input are preserved.

---

## DynamoDB tables this lambda uses

| Table | PK | SK | Read/Write | Used by |
|---|---|---|---|---|
| `job_run` | `run_id` | `last_updated_time` | **Read** (GSI-2) | `change_since_append` |
| `service_config` | `job_id` | `job_type` | **Read** | `ddb_config_pull` |
| `table_config` | `job_id` | `job_type` | **Read** | `ddb_config_pull` |
| `logs` | `run_id` | `time` | **Write** | `log_to_dynamo` |

Config table schemas (`service_config`, `table_config`) are assumed to be
PK=`job_id`, SK=`job_type`. These tables are **not yet created** — the
architect will confirm the key schema.

---

## Deploying to AWS Lambda

```bash
# 1. Build the deployment zip
make package

# 2. Upload dist/pre_steps_processor.zip to AWS Lambda

# 3. Set these in the Lambda configuration:
#    Runtime:  Python 3.12
#    Handler:  pre_steps_processor.handler.lambda_handler
```

---

## Test files explained

Each test file focuses on one thing — you can open any single file and
understand what it's testing without reading the others.

| Test file | What it tests | # tests |
|---|---|---|
| `test_routing_no_data.py` | No pre_steps, empty array, invalid items | 12 |
| `test_routing_known.py` | Known types route to the right handler | 4 |
| `test_routing_unknown.py` | Unknown types route to unknown handler | 3 |
| `test_output_shape.py` | Output has the right structure | 6 |
| `test_change_since_append.py` | DynamoDB query logic (success, no rows, errors) | 5 |
| `test_ddb_config_pull.py` | Config table pulls + end-to-end merge into job_param | 6 |

**Total: 36 tests**

---

## File-by-file guide (for code readers)

If you want to understand the code, read in this order:

1. **`handler.py`** — start here. It extracts `pre_steps`, loops through
   them, routes each to a handler, collects results.
2. **`step_handlers.py`** — the four handler functions. Two are real
   (`change_since_append`, `ddb_config_pull`), two are stubs for now.
3. **`dynamodb_ops.py`** — the DynamoDB queries those handlers call.
4. **`logging_utils.py`** — tiny file. Four functions: `info`, `warn`,
   `error`, `debug`.
5. **`log_to_dynamo.py`** — writes a log row to DynamoDB.

Skip `__init__.py` — it's one line.
