# terraform-hello

Minimal Step Functions state machine deployed via Terraform. No Lambdas — just two `Pass` states — so you can verify the full deploy pipeline before adding real code.

---

## 0. Prereqs (one-time)

1. Install Terraform (check version: `terraform version`)
2. Configure AWS auth — SSO, profile, or env vars. Test with:
   ```
   aws sts get-caller-identity
   ```
3. Edit the `<<< PLACEHOLDER >>>` values in:
   - `backend.tf` → your firm's state bucket / lock table
   - `variables/local.tfvars` → tags, owner, etc.

---

## 1. Initialize

From inside `terraform-hello/`:

```
terraform init
```

This downloads the AWS provider and connects to the remote state backend. Only needed on first run or when backend/provider versions change.

---

## 2. Plan

```
terraform plan -var-file=variables/local.tfvars -out=tfplan
```

Expect to see ~2 resources being created:
- `aws_iam_role.sfn`
- `aws_sfn_state_machine.hello`

Review the plan carefully. If anything looks wrong, fix before applying.

---

## 3. Apply

```
terraform apply tfplan
```

Or in one shot:

```
terraform apply -var-file=variables/local.tfvars
```

Terraform will print the `state_machine_arn` output when done. Save it — you'll need it for testing.

---

## 4. Test from AWS Console (browser)

1. Open AWS Console → **Step Functions** → **State machines**
2. Click `terraform-hello-dev-hello`
3. Click **Start execution**
4. Leave input as `{}` (or paste any JSON)
5. Click **Start execution**
6. Watch the graph — both states should turn green
7. Click the execution to see the input/output at each step

---

## 5. Test from AWS CLI

Start an execution:

```
aws stepfunctions start-execution ^
  --state-machine-arn <PASTE_ARN_FROM_OUTPUT> ^
  --input "{}"
```

(On Linux/Mac, use `\` line continuations instead of `^`.)

That returns an `executionArn`. Check its status:

```
aws stepfunctions describe-execution --execution-arn <EXECUTION_ARN>
```

Look for `"status": "SUCCEEDED"` and the `output` field.

List recent executions:

```
aws stepfunctions list-executions --state-machine-arn <PASTE_ARN_FROM_OUTPUT>
```

---

## 6. Iterate

When you change `definition.json` or any `.tf` file:

```
terraform plan  -var-file=variables/local.tfvars
terraform apply -var-file=variables/local.tfvars
```

---

## 7. Tear down

When done testing:

```
terraform destroy -var-file=variables/local.tfvars
```

---

## Folder layout

```
terraform-hello/
├── backend.tf           # remote state config
├── providers.tf         # AWS provider
├── variables.tf         # input variable declarations
├── main.tf              # IAM role + state machine
├── outputs.tf           # ARNs after apply
├── variables/
│   └── local.tfvars     # env-specific values
└── step-function/
    └── definition.json  # state machine JSON
```

---

## Next steps

- Add `dev.tfvars`, `test.tfvars` etc. in `variables/` for more envs
- Add two Lambdas under a new `lambdas/` folder
- Update `main.tf` to use `templatefile()` with Lambda ARNs
- Add `lambda:InvokeFunction` permission to the Step Functions IAM role
