"""
Shared fixtures for ScheduleNextJob tests.
Sets up moto-backed DynamoDB tables and a sample event builder.
"""
import os
import sys
import unittest.mock as mock

import boto3
import pytest
from moto import mock_aws

# Make the src package importable
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))


@pytest.fixture(autouse=True)
def _mock_log_to_dynamo(monkeypatch):
    """Stop log_to_dynamo from hitting real DynamoDB in every test."""
    from schedule_next_job import log_to_dynamo
    monkeypatch.setattr(log_to_dynamo, "_dynamodb_resource", mock.MagicMock())


@pytest.fixture
def dynamodb_setup():
    """
    Spin up moto-backed DynamoDB tables, seed them, and yield.
    Yields: (dynamodb, job_run_table, job_config_table, logs_table)
    """
    with mock_aws():
        dynamodb = boto3.resource("dynamodb", region_name="us-east-1")

        job_run_table = dynamodb.create_table(
            TableName="job_run",
            KeySchema=[{"AttributeName": "run_id", "KeyType": "HASH"}],
            AttributeDefinitions=[{"AttributeName": "run_id", "AttributeType": "S"}],
            BillingMode="PAY_PER_REQUEST",
        )

        job_config_table = dynamodb.create_table(
            TableName="job_config",
            KeySchema=[
                {"AttributeName": "job_id", "KeyType": "HASH"},
                {"AttributeName": "job_type", "KeyType": "RANGE"},
            ],
            AttributeDefinitions=[
                {"AttributeName": "job_id", "AttributeType": "S"},
                {"AttributeName": "job_type", "AttributeType": "S"},
            ],
            BillingMode="PAY_PER_REQUEST",
        )

        logs_table = dynamodb.create_table(
            TableName="logs",
            KeySchema=[
                {"AttributeName": "run_id", "KeyType": "HASH"},
                {"AttributeName": "time",   "KeyType": "RANGE"},
            ],
            AttributeDefinitions=[
                {"AttributeName": "run_id", "AttributeType": "S"},
                {"AttributeName": "time",   "AttributeType": "S"},
            ],
            BillingMode="PAY_PER_REQUEST",
        )

        # Seed parent job_run
        job_run_table.put_item(Item={
            "run_id": "run-001", "job_id": "client", "job_type": "sourcing",
            "trigger_type": "SCHEDULER", "status": "SUCCESS",
            "start_time": "2024-04-01T00:00:00Z", "end_time": "2024-04-01T00:05:00Z",
            "next_scheduled_run_time": "", "last_heartbeat_time": "",
            "expiry_time": "", "mark_for_delete": False,
            "custom_attributes": {}, "error": "", "delete_at": 0,
        })

        # Seed child job_configs
        job_config_table.put_item(Item={
            "job_id": "dbr_client", "job_type": "silver_load",
            "enabled": True, "trigger_type": "PIPELINE", "run_frequency_in_mins": 0,
            "concurrent_runs_enabled": False,
            "job_runner": {"type": "Databricks", "name": "DBR", "config": {"job_id": "99999"}},
            "job_param": {"target": "silver_table"}, "next_jobs": [],
            "created_at": "2024-01-01T00:00:00Z", "updated_at": "2024-01-01T00:00:00Z",
        })

        job_config_table.put_item(Item={
            "job_id": "dbr_gold", "job_type": "gold_load",
            "enabled": True, "trigger_type": "PIPELINE", "run_frequency_in_mins": 0,
            "concurrent_runs_enabled": False,
            "job_runner": {"type": "Databricks", "name": "DBR", "config": {"job_id": "88888"}},
            "job_param": {"target": "gold_table"}, "next_jobs": [],
            "created_at": "2024-01-01T00:00:00Z", "updated_at": "2024-01-01T00:00:00Z",
        })

        yield dynamodb, job_run_table, job_config_table, logs_table


def _make_event(next_jobs=None, job_output=None):
    """Build a sample Lambda event payload as it arrives from UpdateJobStatus."""
    return {
        "run_id": "run-001",
        "job_id": "client",
        "job_type": "sourcing",
        "status": "SUCCESS",
        "job_config": {
            "job_runner": {"name": "S2S3", "type": "ECS_Fargate"},
            "job_param": {"output": ["s3_path"]},
            "next_jobs": next_jobs or [],
        },
        "trigger_result": {
            "trigger_status": "TRIGGERED", "runner_type": "ECS",
            "runner_name": "S2S3",
            "task_arn": "arn:aws:ecs:us-east-1:123:task/cluster/abc123",
            "job_status": "SUCCESS", "output": job_output or {},
        },
        "update_result": {"effective_status": "SUCCESS"},
    }
