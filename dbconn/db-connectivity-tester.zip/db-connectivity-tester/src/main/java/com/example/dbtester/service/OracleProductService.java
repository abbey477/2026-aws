package com.example.dbtester.service;

import com.example.dbtester.dto.ProductRequest;
import com.example.dbtester.entity.Product;
import com.example.dbtester.exception.ResourceNotFoundException;
import com.example.dbtester.repository.oracle.ProductRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class OracleProductService {

    private final ProductRepository repository;

    public OracleProductService(ProductRepository repository) {
        this.repository = repository;
    }

    @Transactional(transactionManager = "oracleTxManager", readOnly = true)
    public List<Product> findAll() {
        return repository.findAll();
    }

    @Transactional(transactionManager = "oracleTxManager", readOnly = true)
    public Product findById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found: " + id));
    }

    @Transactional(transactionManager = "oracleTxManager")
    public Product create(ProductRequest request) {
        Product toCreate = new Product(null, request.sku(), request.name(), request.price(), request.inStock());
        return repository.insert(toCreate);
    }

    @Transactional(transactionManager = "oracleTxManager")
    public Product update(Long id, ProductRequest request) {
        Product existing = findById(id);
        Product updated = new Product(
                existing.id(),
                request.sku(),
                request.name(),
                request.price(),
                request.inStock()
        );
        int rows = repository.update(id, updated);
        if (rows == 0) {
            throw new ResourceNotFoundException("Product not found: " + id);
        }
        return updated;
    }

    @Transactional(transactionManager = "oracleTxManager")
    public void delete(Long id) {
        int rows = repository.delete(id);
        if (rows == 0) {
            throw new ResourceNotFoundException("Product not found: " + id);
        }
    }
}
