"""
logger.py
Structured logging utilities for the UpdateJobStatus Lambda.

Supports LOG_LEVEL environment variable (DEBUG, INFO, WARNING, ERROR, CRITICAL).
Defaults to INFO if not set or invalid.
"""

import logging
import os

# ---------------------------------------------------------------------------
# Root logger configuration
# ---------------------------------------------------------------------------
_LOG_LEVEL_ENV = os.environ.get("LOG_LEVEL", "INFO").upper()
_VALID_LEVELS = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}
_LOG_LEVEL = _LOG_LEVEL_ENV if _LOG_LEVEL_ENV in _VALID_LEVELS else "INFO"

logging.basicConfig(
    format="%(asctime)s [%(levelname)s] %(name)s - %(message)s",
    level=getattr(logging, _LOG_LEVEL),
)


def get_logger(name: str = __name__) -> logging.Logger:
    """Return a named logger that inherits the root level."""
    return logging.getLogger(name)


# ---------------------------------------------------------------------------
# Structured step logger
# ---------------------------------------------------------------------------
_default_logger = get_logger("UpdateJobStatus")


def log_step(
    step: str,
    details: dict,
    level: str = "INFO",
    logger: logging.Logger = _default_logger,
) -> None:
    """
    Emit a structured log line.

    Every line carries a step tag plus key-value pairs so log queries are easy.

    Args:
        step:    Short identifier for the log event (e.g. "UPDATE_SUCCESS").
        details: Arbitrary key-value context to include in the log message.
        level:   Log level string - DEBUG | INFO | WARNING | ERROR | CRITICAL.
                 Defaults to "INFO".
        logger:  Logger instance to use. Defaults to the module-level logger.
    """
    detail_str = ", ".join(f"{k}={v}" for k, v in details.items())
    message = f"[UpdateJobStatus] [{step}] {detail_str}"

    log_fn = getattr(logger, level.lower(), logger.info)
    log_fn(message)
