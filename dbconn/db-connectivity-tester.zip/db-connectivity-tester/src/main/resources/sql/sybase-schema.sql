-- Sybase ASE CUSTOMER table
-- Run once against the target Sybase database before using the CRUD endpoints.

CREATE TABLE CUSTOMER (
    id          BIGINT        IDENTITY     NOT NULL,
    first_name  VARCHAR(100)               NOT NULL,
    last_name   VARCHAR(100)               NOT NULL,
    email       VARCHAR(200)               NOT NULL,
    created_at  DATETIME                   NOT NULL DEFAULT getdate(),
    PRIMARY KEY (id)
)
go

CREATE UNIQUE INDEX ux_customer_email ON CUSTOMER (email)
go
