#!/bin/bash
# ============================================================
# run-batch-prod.sh — entry point for Autosys (prod environment)
# Usage: run-batch-prod.sh <jobName>
# ============================================================

export ENV="prod"
export APP_HOME="/opt/jobs/prod"
export JAR_NAME="batch-app.jar"
export LOG_DIR="/var/log/batch/prod"
export JAVA_OPTS="-Xms2g -Xmx8g -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=${LOG_DIR:-/tmp}"
export SPRING_PROFILE="prod"

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
source "${SCRIPT_DIR}/common.sh"

run_batch_job "$@"
