package com.example.dbtester.dto;

import java.util.List;

/**
 * Bulk operation response.
 * ids is populated for Oracle inserts, empty for Sybase inserts (IDENTITY
 * columns don't surface generated keys reliably through JDBC batch mode)
 * and for all update/delete operations.
 */
public record BulkResult(
        int processed,
        List<Long> ids
) {
    public static BulkResult of(int processed) {
        return new BulkResult(processed, List.of());
    }

    public static BulkResult of(List<Long> ids) {
        return new BulkResult(ids.size(), ids);
    }
}
