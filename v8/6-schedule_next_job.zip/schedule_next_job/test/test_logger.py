"""Tests for logger.py"""
import os, sys, logging
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from schedule_next_job.logger import log_info, log_error, _format_details


class TestFormatDetails:
    def test_empty(self):       assert _format_details({}) == ""
    def test_none(self):        assert _format_details(None) == ""
    def test_single(self):      assert _format_details({"k": "v"}) == "k=v"
    def test_multiple(self):    assert _format_details({"a": 1, "b": 2}) == "a=1, b=2"

class TestLogInfo:
    def test_level(self, caplog):
        with caplog.at_level(logging.INFO, logger="ScheduleNextJob"):
            log_info("STEP", {"k": "v"})
        assert caplog.records[0].levelname == "INFO"

    def test_format(self, caplog):
        with caplog.at_level(logging.INFO, logger="ScheduleNextJob"):
            log_info("STEP", {"k": "v"})
        assert caplog.records[0].message == "[ScheduleNextJob] [STEP] k=v"

class TestLogError:
    def test_level(self, caplog):
        with caplog.at_level(logging.ERROR, logger="ScheduleNextJob"):
            log_error("FAIL", {"error": "boom"})
        assert caplog.records[0].levelname == "ERROR"

    def test_exc_info(self, caplog):
        with caplog.at_level(logging.ERROR, logger="ScheduleNextJob"):
            try:
                raise ValueError("oops")
            except ValueError:
                log_error("FAIL", {}, exc_info=True)
        assert caplog.records[0].exc_info[0] is ValueError
