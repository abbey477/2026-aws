package com.example.batch;

import com.example.batch.core.JobContext;
import com.example.batch.core.JobDispatcher;
import com.example.batch.core.JobResult;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(
        classes = BatchCliApplication.class,
        properties = "spring.main.web-application-type=none"
)
class DispatcherTest {

    @Autowired
    private JobDispatcher dispatcher;

    @Test
    void success_returnsExitCode0() {
        JobResult r = dispatcher.dispatch(new JobContext("jobA", "2026-05-16"));
        assertThat(r.getExitCode()).isEqualTo(0);
    }

    @Test
    void businessFailure_returnsExitCode3() {
        JobResult r = dispatcher.dispatch(new JobContext("jobA", "FAIL"));
        assertThat(r.getExitCode()).isEqualTo(3);
    }

    @Test
    void unknownJob_returnsExitCode2() {
        JobResult r = dispatcher.dispatch(new JobContext("jobX", "2026-05-16"));
        assertThat(r.getExitCode()).isEqualTo(2);
    }
}
