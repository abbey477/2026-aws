package com.example.dbtester.service;

import com.example.dbtester.dto.CustomerRequest;
import com.example.dbtester.entity.Customer;
import com.example.dbtester.exception.ResourceNotFoundException;
import com.example.dbtester.repository.sybase.CustomerRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Customer CRUD orchestration. Owns Sybase transaction boundaries and
 * translates "no rows" into a 404.
 *
 * Note the explicit transactionManager = "sybaseTxManager" on every method —
 * without it, Spring would pick the @Primary Oracle manager.
 */
@Service
public class SybaseCustomerService {

    private final CustomerRepository repository;

    public SybaseCustomerService(CustomerRepository repository) {
        this.repository = repository;
    }

    // ---- Single row ----

    @Transactional(transactionManager = "sybaseTxManager", readOnly = true)
    public List<Customer> findAll() {
        return repository.findAll();
    }

    @Transactional(transactionManager = "sybaseTxManager", readOnly = true)
    public Customer findById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found: " + id));
    }

    @Transactional(transactionManager = "sybaseTxManager")
    public Customer create(CustomerRequest request) {
        Customer toCreate = new Customer(null, request.firstName(), request.lastName(), request.email(), null);
        return repository.insert(toCreate);
    }

    @Transactional(transactionManager = "sybaseTxManager")
    public Customer update(Long id, CustomerRequest request) {
        Customer existing = findById(id);
        Customer updated = new Customer(
                existing.id(),
                request.firstName(),
                request.lastName(),
                request.email(),
                existing.createdAt()  // preserve original creation timestamp
        );
        if (repository.update(id, updated) == 0) {
            throw new ResourceNotFoundException("Customer not found: " + id);
        }
        return updated;
    }

    @Transactional(transactionManager = "sybaseTxManager")
    public void delete(Long id) {
        if (repository.delete(id) == 0) {
            throw new ResourceNotFoundException("Customer not found: " + id);
        }
    }

    // ---- Bulk ----

    @Transactional(transactionManager = "sybaseTxManager")
    public int createAll(List<CustomerRequest> requests) {
        List<Customer> toInsert = requests.stream()
                .map(r -> new Customer(null, r.firstName(), r.lastName(), r.email(), null))
                .toList();
        return repository.insertAll(toInsert);
    }

    @Transactional(transactionManager = "sybaseTxManager")
    public int updateAll(List<Customer> customers) {
        return repository.updateAll(customers);
    }

    @Transactional(transactionManager = "sybaseTxManager")
    public int deleteAll(List<Long> ids) {
        return repository.deleteAll(ids);
    }
}
