import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repository for the Oracle target table {@code TEMP_EXCH_INST_ALT_ID}.
 *
 * <p>Owns all SQL and JDBC operations that touch this table on the Oracle side.
 * Holds no migration logic — it doesn't know about Sybase, streaming, or buffers.
 * The migration class composes this repository with a Sybase reader to perform
 * the end-to-end flow.
 *
 * <p>Single responsibility: "things you do to TEMP_EXCH_INST_ALT_ID in Oracle."
 */
@Slf4j
@Repository
public class ExchangeInstrumentAlternateIdOracleRepository {

    private static final int BATCH_SIZE = 5000;

    private static final String TRUNCATE_SQL =
            "TRUNCATE TABLE TEMP_EXCH_INST_ALT_ID";

    private static final String COUNT_SQL =
            "SELECT COUNT(*) FROM TEMP_EXCH_INST_ALT_ID";

    /**
     * Insert SQL with positional binds. Column order here MUST match the order
     * used by {@link ColumnMapper#setParameters} when binding a row.
     */
    private static final String INSERT_SQL =
            "INSERT INTO TEMP_EXCH_INST_ALT_ID (" +
            "    ID_IMNT, ID_TYP_ALT_IMNT, ID_EXCHANGE_KEY, ID_IMNT_ALT, " +
            "    ID_EXCH, ID_VIEW_FLAG, DT_CHG_GRD, ID_DEL_GRD, ID_OWN_GRD" +
            ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

    private final JdbcTemplate oracleJdbcTemplate;
    private final ColumnMapper<ExchangeInstrumentAlternateId> columnMapper;

    /**
     * @param oracleJdbcTemplate template bound to the Oracle DataSource.
     *                           Use {@code @Qualifier} when more than one
     *                           JdbcTemplate bean is in the context.
     */
    public ExchangeInstrumentAlternateIdOracleRepository(
            @Qualifier("oracleJdbcTemplate") JdbcTemplate oracleJdbcTemplate) {
        this.oracleJdbcTemplate = oracleJdbcTemplate;
        this.columnMapper = new ColumnMapper<>();
    }

    /**
     * Empties the target table. Faster than DELETE for full reloads — DDL,
     * minimal redo, resets the high water mark.
     *
     * <p>Note: TRUNCATE in Oracle commits implicitly and cannot be rolled back.
     * If a future use case needs rollback support, switch to DELETE.
     */
    public void truncate() {
        oracleJdbcTemplate.update(TRUNCATE_SQL);
        log.debug("Truncated TEMP_EXCH_INST_ALT_ID");
    }

    /**
     * Inserts a batch of rows. Caller controls the batch size by passing in
     * lists of the desired size (typically {@link #BATCH_SIZE}).
     *
     * <p>Returns the cumulative row count reported by the JDBC driver. With
     * Oracle's driver this is generally accurate; some drivers return -2
     * ({@code SUCCESS_NO_INFO}) per row in batch mode, which would skew this
     * total — worth verifying once on your driver version if exact counts matter.
     *
     * @param rows rows to insert
     * @return number of rows reported inserted
     */
    public int batchInsert(List<ExchangeInstrumentAlternateId> rows) {
        if (rows == null || rows.isEmpty()) {
            return 0;
        }
        int[] perBatchCounts = oracleJdbcTemplate.batchUpdate(
                INSERT_SQL,
                rows,
                BATCH_SIZE,
                columnMapper::setParameters
        );
        int total = 0;
        for (int[] batch : new int[][]{perBatchCounts}) {
            for (int n : batch) {
                if (n > 0) total += n;
            }
        }
        return total;
    }

    /**
     * Counts rows in the target table. Used after a migration to verify the
     * Oracle row count matches what was read from Sybase.
     */
    public long count() {
        Long n = oracleJdbcTemplate.queryForObject(COUNT_SQL, Long.class);
        return n == null ? 0L : n;
    }
}
