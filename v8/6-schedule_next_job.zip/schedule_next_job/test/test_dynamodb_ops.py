"""Tests for dynamodb_ops.py"""
import os, sys, re
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from schedule_next_job.dynamodb_ops import (
    get_current_time_iso, get_next_minute_iso,
    get_next_job_config, put_job_run,
)

ISO = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$")


class TestGetNextJobConfig:
    def test_found(self, dynamodb_setup):
        _, _, job_config_table, _ = dynamodb_setup
        r = get_next_job_config(job_config_table, "dbr_client", "silver_load")
        assert r["job_id"] == "dbr_client"
        assert r["job_runner"]["name"] == "DBR"

    def test_not_found(self, dynamodb_setup):
        _, _, job_config_table, _ = dynamodb_setup
        assert get_next_job_config(job_config_table, "nope", "nope") == {}

    def test_wrong_sort_key(self, dynamodb_setup):
        _, _, job_config_table, _ = dynamodb_setup
        assert get_next_job_config(job_config_table, "dbr_client", "wrong") == {}


class TestPutJobRun:
    def test_inserts_item(self, dynamodb_setup):
        _, job_run_table, _, _ = dynamodb_setup
        item = {
            "run_id": "test-999", "job_id": "dbr_client", "job_type": "silver_load",
            "trigger_type": "PIPELINE", "status": "WAITING", "start_time": "",
            "end_time": "", "next_scheduled_run_time": "2024-04-01T00:01:00Z",
            "last_heartbeat_time": "", "expiry_time": "", "mark_for_delete": False,
            "custom_attributes": {"s3_path": "s3://b/d"}, "error": "", "delete_at": 0,
        }
        put_job_run(job_run_table, item)
        stored = job_run_table.get_item(Key={"run_id": "test-999"})["Item"]
        assert stored["status"] == "WAITING"
        assert stored["custom_attributes"] == {"s3_path": "s3://b/d"}


class TestTimeHelpers:
    def test_current_time_format(self):  assert ISO.match(get_current_time_iso())
    def test_next_minute_format(self):   assert ISO.match(get_next_minute_iso())
    def test_next_after_current(self):   assert get_next_minute_iso() > get_current_time_iso()
