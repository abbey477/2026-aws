package com.example.dbtester.service;

import com.example.dbtester.config.AppProperties;
import com.example.dbtester.dto.ConnectionStatus;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.Statement;
import java.util.List;

/**
 * Pings each datasource and reports UP/DOWN with latency.
 */
@Service
public class DatabaseHealthService {

    private final DataSource oracle;
    private final DataSource sybase;
    private final AppProperties props;

    public DatabaseHealthService(@Qualifier("oracleDataSource") DataSource oracle,
                                 @Qualifier("sybaseDataSource") DataSource sybase,
                                 AppProperties props) {
        this.oracle = oracle;
        this.sybase = sybase;
        this.props = props;
    }

    public List<ConnectionStatus> checkAll() {
        return List.of(check("oracle"), check("sybase"));
    }

    public ConnectionStatus check(String name) {
        DataSource ds;
        String query;

        switch (name) {
            case "oracle" -> {
                ds = oracle;
                query = props.oracle().validationQueries().get(0);
            }
            case "sybase" -> {
                ds = sybase;
                query = props.sybase().validationQueries().get(0);
            }
            default -> {
                return new ConnectionStatus(name, "UNKNOWN", 0L, "No datasource: " + name);
            }
        }

        long start = System.currentTimeMillis();
        try (Connection conn = ds.getConnection();
             Statement stmt = conn.createStatement()) {
            stmt.execute(query);
            return new ConnectionStatus(name, "UP", System.currentTimeMillis() - start, "OK");
        } catch (Exception e) {
            return new ConnectionStatus(name, "DOWN", System.currentTimeMillis() - start, e.getMessage());
        }
    }
}
