# MyApp — Spring Boot 3 OAuth2 Multi-Module Project

A Maven multi-module project implementing a full OAuth2 / OIDC flow using
**Spring Boot 3**, **Spring Security 6**, and **Spring Authorization Server 1.3**.

```
myapp/
├── pom.xml               ← Parent POM (manages all modules)
├── myapp.sh              ← Build & run helper script
├── authserver/           ← OAuth2 / OIDC Authorization Server  (port 9000)
├── resserver/            ← OAuth2 Resource Server / REST API   (port 8081)
└── webapp/               ← OAuth2 Client Web Application       (port 8080)
```

---

## Architecture

```
Browser
  │
  ▼
[webapp :8080]  ──── Authorization Code Flow ────►  [authserver :9000]
  │                                                        │
  │   Bearer JWT (access token)                            │  Issues JWT
  ▼                                                        │
[resserver :8081]  ◄───────────────────────────────────────┘
  │  Validates JWT via JWKS endpoint (http://localhost:9000/oauth2/jwks)
  │  Returns protected API data
```

### Modules

| Module | Port | Role |
|---|---|---|
| `authserver` | 9000 | Issues JWTs, hosts `/oauth2/token`, `/userinfo`, `/.well-known/openid-configuration` |
| `resserver` | 8081 | Stateless REST API; validates Bearer JWTs against the Auth Server's JWKS |
| `webapp` | 8080 | Browser-facing app; redirects users to Auth Server login, then calls Resource Server |

---

## Prerequisites

| Requirement | Version |
|---|---|
| Java | 21+ |
| Maven | 3.9+ (or use `./mvnw` wrapper if added) |

Verify:
```bash
java -version
mvn -version
```

---

## Quick Start (all three modules)

### Step 1 — Build everything

```bash
./myapp.sh build
```

Or with plain Maven:
```bash
mvn clean package -DskipTests
```

### Step 2 — Start all modules

```bash
./myapp.sh run all
```

This starts modules in the correct order with delays between them
(`authserver` → `resserver` → `webapp`) and writes logs to `.logs/`.

### Step 3 — Open the web app

```
http://localhost:8080
```

Log in with one of the pre-configured users:

| Username | Password | Roles |
|---|---|---|
| `user` | `password` | USER |
| `admin` | `admin` | USER, ADMIN |

---

## Running Modules Individually

### Foreground (recommended for development)

Open **three terminals**, one per module:

```bash
# Terminal 1 — Auth Server (start this first!)
./myapp.sh run authserver

# Terminal 2 — Resource Server
./myapp.sh run resserver

# Terminal 3 — Web Application
./myapp.sh run webapp
```

### Background

```bash
./myapp.sh run all        # start all in background
./myapp.sh logs authserver  # tail a module's log
./myapp.sh stop           # stop all background modules
```

---

## Building Individual Modules

```bash
./myapp.sh build authserver
./myapp.sh build resserver
./myapp.sh build webapp
```

Or with Maven:
```bash
mvn -pl authserver package -DskipTests
mvn -pl resserver package -DskipTests
mvn -pl webapp    package -DskipTests
```

---

## Cleaning

```bash
./myapp.sh clean            # clean all
./myapp.sh clean authserver # clean one module
```

---

## Key Endpoints

### Auth Server (port 9000)

| Endpoint | Description |
|---|---|
| `GET  /.well-known/openid-configuration` | OIDC discovery document |
| `GET  /oauth2/jwks` | Public JWK Set (used by resserver to verify JWTs) |
| `POST /oauth2/token` | Token endpoint |
| `GET  /oauth2/authorize` | Authorization endpoint |
| `GET  /userinfo` | OIDC UserInfo endpoint |
| `POST /oauth2/revoke` | Token revocation |
| `GET  /connect/logout` | RP-Initiated Logout |

### Resource Server (port 8081)

| Endpoint | Required Scope | Description |
|---|---|---|
| `GET /api/hello` | `openid` | Returns subject & issuer from JWT |
| `GET /api/data`  | `api.read` | Returns protected data |
| `GET /api/admin` | `api.write` | Admin action |

### Web App (port 8080)

| Endpoint | Description |
|---|---|
| `GET /` | Public home page |
| `GET /login` | Triggers redirect to Auth Server |
| `GET /dashboard` | Authenticated dashboard (calls Resource Server) |
| `GET /logout` | Logs out and redirects to Auth Server end_session |

---

## Configuration Reference

### authserver — `src/main/resources/application.yml`

```yaml
server.port: 9000
```

Key beans in `AuthServerSecurityConfig`:
- **Registered Client** — `webapp-client` / `webapp-secret` (in-memory; swap for `JdbcRegisteredClientRepository` in prod)
- **Users** — `user`/`password`, `admin`/`admin` (in-memory; swap for DB-backed `UserDetailsService` in prod)
- **RSA key pair** — generated at startup (ephemeral; use a keystore or Vault in prod)
- **Issuer URI** — `http://localhost:9000`

### resserver — `src/main/resources/application.yml`

```yaml
spring.security.oauth2.resourceserver.jwt.issuer-uri: http://localhost:9000
```

Spring auto-discovers the JWKS URI from the issuer's OIDC discovery document.

### webapp — `src/main/resources/application.yml`

```yaml
spring.security.oauth2.client.registration.myapp:
  client-id: webapp-client
  client-secret: webapp-secret
  scope: openid, profile, api.read, api.write
spring.security.oauth2.client.provider.myapp:
  issuer-uri: http://localhost:9000
```

---

## Production Checklist

- [ ] Replace in-memory `RegisteredClientRepository` with `JdbcRegisteredClientRepository`
- [ ] Replace in-memory `UserDetailsService` with a database-backed implementation
- [ ] Replace ephemeral RSA key generation with a persistent keystore (`KeyStore` / HashiCorp Vault)
- [ ] Use BCrypt-encoded client secrets (remove `{noop}` prefix)
- [ ] Enable HTTPS on all three services
- [ ] Configure `issuer-uri` to match the public domain of the Auth Server
- [ ] Set `redirect-uri` in the registered client to the production webapp URL
- [ ] Add token introspection or opaque token support if needed
- [ ] Add rate limiting and CORS policies on the Resource Server

---

## Troubleshooting

**`Connection refused` on startup of resserver or webapp**
The Auth Server must be fully started before the other modules, because they
fetch the OIDC discovery document on startup. Wait for the Auth Server to print
`Started AuthServerApplication` before starting the others.

**`401 Unauthorized` calling `/api/*`**
The access token is missing or expired. Check that the webapp successfully
completed the Authorization Code flow (check the `/dashboard` page or the
`webapp` log).

**Scope denied (`403 Forbidden`) on `/api/data` or `/api/admin`**
The token was issued without the required scope. Confirm the registered client
in `AuthServerSecurityConfig` includes `api.read` / `api.write` and that the
user approved the consent screen.

**Port already in use**
```bash
# Find and kill the process using the port (example: 9000)
lsof -ti tcp:9000 | xargs kill -9
```
