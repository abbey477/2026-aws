"""
TriggerEcsJob Lambda Handler.

Triggers an ECS Fargate task using the RunTask API.
Called by the state machine when job_config.job_runner.type is ECS_Fargate.

Input:  Full merged payload from GetConfig (job_run + job_config).
Output: Same payload + trigger_result with task_arn and trigger_status.

job_param is passed to the container as a JSON-encoded JOB_PARAM
environment variable. The ECS RunTask overrides block is capped at
8 KB, so job_param must stay below that size.
"""

from datetime import datetime, timezone
from typing import Any

import boto3

from trigger_ecs_job.ecs_trigger import trigger_ecs_task
from trigger_ecs_job.log_to_dynamo import write_log
from trigger_ecs_job.logger import get_logger, log_info

logger = get_logger(__name__)


def lambda_handler(event: dict[str, Any], context: Any) -> dict[str, Any]:
    """
    Lambda entry point. Input: merged payload from GetConfig.
    Output: same payload + trigger_result.
    """
    timestamp: str = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    run_id: str = event.get("run_id", "UNKNOWN")
    job_config: dict[str, Any] = event.get("job_config", {})
    job_param: dict[str, Any] = job_config.get("job_param", {})
    job_runner: dict[str, Any] = job_config.get("job_runner", {})
    runner_name: str = job_runner.get("name", "")

    log_info(logger, "HANDLER_START", {
        "timestamp": timestamp,
        "run_id": run_id,
        "runner_name": runner_name,
    })

    ecs_client: Any = boto3.client("ecs")
    trigger_result: dict[str, Any] = trigger_ecs_task(
        ecs_client=ecs_client,
        job_config=job_config,
        job_param=job_param,
        run_id=run_id,
    )

    trigger_result["runner_name"] = runner_name
    trigger_result["runner_type"] = "ECS"
    event["trigger_result"] = trigger_result

    write_log(
        run_id=run_id,
        job_id=event.get("job_id", ""),
        stage="TriggerEcsJob",
        status=trigger_result.get("trigger_status", "UNKNOWN"),
    )

    log_info(logger, "HANDLER_COMPLETE", {
        "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "run_id": run_id,
        "trigger_status": trigger_result.get("trigger_status"),
        "task_arn": trigger_result.get("task_arn", ""),
    })

    return event
