package com.example.batch.core;

import com.example.batch.common.exception.BusinessException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Finds the right BatchJob bean by name and runs it.
 * One try/catch turns exceptions into exit codes.
 */
@Component
public class JobDispatcher {

    private static final Logger log = LoggerFactory.getLogger(JobDispatcher.class);

    private final Map<String, BatchJob> jobs;

    public JobDispatcher(List<BatchJob> allJobs) {
        this.jobs = allJobs.stream()
                .collect(Collectors.toMap(BatchJob::getName, Function.identity()));
    }

    public JobResult dispatch(JobContext ctx) {
        BatchJob job = jobs.get(ctx.getJobName());
        if (job == null) {
            return JobResult.failure(2, "Unknown job: " + ctx.getJobName());
        }

        try {
            job.execute(ctx);
            return JobResult.success();
        } catch (BusinessException ex) {
            return JobResult.failure(ex.getExitCode(), ex.getMessage());
        } catch (Exception ex) {
            log.error("Unexpected error", ex);
            return JobResult.failure(1, ex.getMessage());
        }
    }
}
