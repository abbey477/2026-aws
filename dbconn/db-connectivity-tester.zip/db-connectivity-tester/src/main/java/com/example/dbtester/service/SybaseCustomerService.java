package com.example.dbtester.service;

import com.example.dbtester.dto.CustomerRequest;
import com.example.dbtester.entity.Customer;
import com.example.dbtester.exception.ResourceNotFoundException;
import com.example.dbtester.repository.sybase.CustomerRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class SybaseCustomerService {

    private final CustomerRepository repository;

    public SybaseCustomerService(CustomerRepository repository) {
        this.repository = repository;
    }

    @Transactional(transactionManager = "sybaseTxManager", readOnly = true)
    public List<Customer> findAll() {
        return repository.findAll();
    }

    @Transactional(transactionManager = "sybaseTxManager", readOnly = true)
    public Customer findById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found: " + id));
    }

    @Transactional(transactionManager = "sybaseTxManager")
    public Customer create(CustomerRequest request) {
        Customer toCreate = new Customer(null, request.firstName(), request.lastName(), request.email(), null);
        return repository.insert(toCreate);
    }

    @Transactional(transactionManager = "sybaseTxManager")
    public Customer update(Long id, CustomerRequest request) {
        Customer existing = findById(id);
        Customer updated = new Customer(
                existing.id(),
                request.firstName(),
                request.lastName(),
                request.email(),
                existing.createdAt()
        );
        int rows = repository.update(id, updated);
        if (rows == 0) {
            throw new ResourceNotFoundException("Customer not found: " + id);
        }
        return updated;
    }

    @Transactional(transactionManager = "sybaseTxManager")
    public void delete(Long id) {
        int rows = repository.delete(id);
        if (rows == 0) {
            throw new ResourceNotFoundException("Customer not found: " + id);
        }
    }
}
