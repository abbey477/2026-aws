"""
config.py
Config extraction helpers for TriggerDbrJob.

Centralises all job_config key lookups and emits WARNING logs
when expected keys are absent so failures are easy to trace.
"""

from trigger_dbr_job.log_utils import log_warning


def get_runner_config(job_config: dict) -> dict:
    """Extract the job_runner config block."""
    runner = job_config.get("job_runner", {})
    config = runner.get("config", {})
    if not runner:
        log_warning("CONFIG_MISSING_RUNNER", {"job_config_keys": list(job_config.keys())})
    return config


def get_runner_name(job_config: dict) -> str:
    """Extract the runner name (e.g. 'DBR')."""
    name = job_config.get("job_runner", {}).get("name", "")
    if not name:
        log_warning("CONFIG_MISSING_RUNNER_NAME", {"job_config_keys": list(job_config.keys())})
    return name


def get_dbr_connection(runner_config: dict) -> tuple[str, str, str]:
    """
    Extract Databricks connection details from runner config.

    Returns:
        (host, token, job_id) — any missing value is an empty string
        and a WARNING is emitted for each absent key.
    """
    host = runner_config.get("host", "")
    token = runner_config.get("token", "")
    job_id = runner_config.get("job_id", "")

    missing = [k for k, v in {"host": host, "token": token, "job_id": job_id}.items() if not v]
    if missing:
        log_warning("CONFIG_MISSING_DBR_KEYS", {"missing_keys": missing})

    return host, token, job_id
