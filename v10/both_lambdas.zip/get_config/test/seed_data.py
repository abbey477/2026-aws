"""
Shared seed data builders and test helpers — importable as a regular
Python module from any test file.

(conftest.py is only auto-discovered by pytest, not importable as a
normal module, so shared data functions live here instead.)
"""

from botocore.exceptions import ClientError


def make_job_run_item(**overrides) -> dict:
    """
    Build a job_run item with sensible defaults; override any field.

    last_updated_time is the composite-key SK and required on every row.
    Defaults to 2024-01-01 so a single-row test is predictable; tests that
    care about ordering override it explicitly.
    """
    base = {
        "run_id": "run-001",
        "last_updated_time": "2024-01-01T00:00:00Z",
        "job_id": "client",
        "job_type": "sourcing",
        "trigger_type": "SCHEDULER",
        "status": "WAITING",
        "start_time": "",
        "end_time": "",
        "next_scheduled_run_time": "",
        "last_heartbeat_time": "",
        "expiry_time": "",
        "mark_for_delete": False,
        "custom_attributes": {},
        "error": "",
        "delete_at": 0,
    }
    base.update(overrides)
    return base


def make_job_config_item(**overrides) -> dict:
    """Build a job_config item matching the current authoritative shape."""
    base = {
        "job_id": "client",
        "job_type": "sourcing",
        "enabled": True,
        "trigger_type": "SCHEDULER",
        "run_frequency_in_mins": 60,
        "concurrent_runs_enabled": False,
        "job_runner": {
            "type": "ECS_Fargate",
            "name": "S2S3",
            "config": {
                "cluster": "my-ecs-cluster",
                "subnets": ["subnet-aaa111", "subnet-bbb222"],
                "security_groups": ["sg-abc123"],
                "task_definition": "default-task-def",
                "container_name": "default-container",
                "instance_size": "small",
                "image": "",
            },
        },
        "pre_steps": [
            {"pre_step_type": "change_since_append"},
            {
                "pre_step_type": "ddb_config_pull",
                "tables": ["service_config", "table_config"],
            },
        ],
        "job_param": {
            "source": {"type": "API", "name": "RDI"},
            "batch_size": 1000,
            "thread_count": 10,
        },
        "next_jobs": [
            {"type": "silver_load", "id": "dbr_client"},
        ],
        "created_at": "2024-01-01T00:00:00Z",
        "updated_at": "2024-01-01T00:00:00Z",
    }
    base.update(overrides)
    return base


def raise_access_denied(*args, **kwargs):
    """Reusable stub that raises a DynamoDB AccessDeniedException."""
    raise ClientError(
        {"Error": {"Code": "AccessDeniedException", "Message": "Denied"}},
        "GetItem",
    )
