package com.example.dbtester.entity;

import java.math.BigDecimal;

/** Maps to Oracle PRODUCT. id is null for un-persisted instances. */
public record Product(
        Long id,
        String sku,
        String name,
        BigDecimal price,
        boolean inStock
) {}
