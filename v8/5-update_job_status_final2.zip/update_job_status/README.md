# update_job_status

AWS Lambda that updates a job status in DynamoDB based on how a job finished.

---

## What this Lambda does, in plain English

A job runs somewhere (in ECS, Fargate, etc.). When it finishes — successfully,
with an error, or is still running — this Lambda records what happened in a
DynamoDB table called `job_run`. That's it.

The four outcomes it handles:

| Outcome | What the Lambda does |
|---|---|
| **SUCCESS** | Mark the job as SUCCESS, record the end time |
| **RUNNING** | Update the heartbeat, extend the expiry by 5 minutes |
| **FAILED** | Mark the job as FAILED, save the error message |
| **TRIGGER_FAILED** | Reset the job to WAITING so it can be tried again |

---

## Project structure

```
update_job_status/
├── requirements.txt         ← runtime dependencies (ship with Lambda)
├── requirements-dev.txt     ← dev/test dependencies (your machine only)
├── pytest.ini               ← pytest configuration
├── pyproject.toml           ← Poetry config (optional alternative)
├── poetry.toml              ← Poetry settings (optional)
├── Makefile                 ← shortcuts: make install / test / build
├── .gitignore
├── README.md
├── src/
│   └── update_job_status/   ← the Python package that gets deployed
│       ├── __init__.py
│       ├── handler.py           Lambda entry point
│       ├── constants.py         JobStatus enum, env config
│       ├── logger.py            structured logging + LOG_LEVEL support
│       ├── time_utils.py        ISO 8601 timestamp helpers
│       ├── dynamo_client.py     boto3 DynamoDB resource factory
│       ├── job_updater.py       DynamoDB update operations
│       └── log_to_dynamo.py     shared audit log writer
└── test/
    ├── __init__.py
    ├── conftest.py              shared pytest fixtures
    ├── test_success.py
    ├── test_trigger_failed.py
    ├── test_running.py
    ├── test_failed.py
    └── test_edge_cases.py
```

---

## Getting started (pick one path)

Two ways to set up. **If you're new to Python, use Option A** — it uses only
Python's built-in tools and nothing extra.

### Option A — pip + venv (recommended for beginners)

#### 1. Make sure you have Python 3.11 or newer

```bash
python3 --version
```

If you see `Python 3.11.x` or higher, you're good. If not, install Python from
[python.org](https://www.python.org/downloads/).

#### 2. Create a virtual environment

A **virtual environment** is a folder that contains its own copy of Python
and its own installed packages. This keeps this project's dependencies
separate from other Python projects on your machine.

```bash
cd update_job_status
python3 -m venv .venv
```

This creates a `.venv/` folder. You only do this once.

#### 3. Activate the virtual environment

Activating makes your terminal use this project's Python instead of the
system-wide one. You do this every time you open a new terminal.

**macOS / Linux:**
```bash
source .venv/bin/activate
```

**Windows (PowerShell):**
```powershell
.venv\Scripts\Activate.ps1
```

**Windows (Command Prompt):**
```cmd
.venv\Scripts\activate.bat
```

Your prompt should now show `(.venv)` at the start — that means it worked.

#### 4. Install dependencies

```bash
pip install -r requirements-dev.txt
```

This installs `boto3` (for AWS) plus `pytest` and `moto` (for testing).

#### 5. Run the tests

```bash
pytest
```

You should see **17 tests all passing**. 🎉

You're done — that's the whole setup.

---

### Option B — Poetry (alternative)

Poetry is a more advanced tool that handles dependencies + packaging + virtual
environments in one. Use it if you're already familiar with it or working on a
team that uses it.

#### 1. Install Poetry

```bash
curl -sSL https://install.python-poetry.org | python3 -
```

#### 2. Install the project

```bash
cd update_job_status
poetry install
```

Poetry creates a virtual environment in `.venv/` automatically and installs
everything.

#### 3. Run tests

```bash
poetry run pytest
```

---

## Everyday commands (pip + venv)

Remember: activate your venv first with `source .venv/bin/activate` when
opening a new terminal.

| Command | What it does |
|---|---|
| `pytest` | Run all tests |
| `pytest test/test_success.py` | Run just one test file |
| `pytest -k "success"` | Run only tests with "success" in the name |
| `pip install <package>` | Install a new package |
| `deactivate` | Exit the virtual environment |
| `make test` | Run tests (Makefile shortcut) |
| `make build` | Build a Lambda deployment zip |
| `make clean` | Remove build artifacts |

---

## Building the Lambda deployment zip

```bash
make build
```

This produces `dist/update_job_status.zip` — upload that to AWS Lambda.

The zip contains:
- Your source code from `src/update_job_status/`
- Runtime dependencies from `requirements.txt`

(It does NOT include test dependencies like `pytest` and `moto` — those would
just make the zip larger and aren't needed at runtime.)

---

## Environment variables

Set these on the Lambda configuration in AWS:

| Variable | Default | Purpose |
|---|---|---|
| `JOB_RUN_TABLE` | `job_run` | Main DynamoDB table to update |
| `LOGS_TABLE` | `logs` | Audit log table |
| `LOG_LEVEL` | `INFO` | `DEBUG` / `INFO` / `WARNING` / `ERROR` / `CRITICAL` |

---

## How the handler decides what to do

```
trigger_status == "TRIGGER_FAILED"  →  mark WAITING, set next_scheduled_run_time
job_status     == "SUCCESS"         →  mark SUCCESS, record end_time
job_status     == "RUNNING"         →  update heartbeat, extend expiry +5min
job_status     == "FAILED"          →  mark FAILED, save error message
anything else                       →  treat as FAILED with a diagnostic message
```

---

## Troubleshooting

**`python3: command not found`**
Python isn't installed or isn't on your PATH. Try `python --version` instead,
or install Python from [python.org](https://www.python.org/downloads/).

**`pip: command not found` after activating the venv**
Very rare — try `python -m pip install -r requirements-dev.txt` instead.

**Tests fail with `ModuleNotFoundError: No module named 'update_job_status'`**
Your venv isn't activated, OR dependencies aren't installed.
Run `source .venv/bin/activate && pip install -r requirements-dev.txt`.

**Tests fail with `ModuleNotFoundError: No module named 'moto'`**
You installed only runtime deps. Run `pip install -r requirements-dev.txt`
(the `-dev` version includes everything).

**I activated the venv but it's still using system Python**
Close the terminal and reopen it, then activate again. Sometimes shell state
gets confused.

**What does `(.venv)` mean in my prompt?**
It means your virtual environment is active. Everything you `pip install`
now goes into this project, not your system.
