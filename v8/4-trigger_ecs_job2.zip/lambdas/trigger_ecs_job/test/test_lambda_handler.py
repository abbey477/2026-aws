"""
Lambda handler integration tests.

Coverage:
  - Handler adds runner_name and runner_type to trigger_result on success
  - Handler adds trigger_result with TRIGGER_FAILED on error
  - Handler preserves all original event fields
  - Handler calls write_log with correct stage and status on success
  - write_log called even on failure path
  - Handler handles missing run_id gracefully (defaults to "UNKNOWN")
  - Handler handles completely empty event gracefully
  - Handler returns the SAME event object (not a new dict)
"""

from trigger_ecs_job.handler import lambda_handler
from conftest import (
    make_event,
    mock_ecs_client_success,
    mock_ecs_client_no_tasks,
    mock_ecs_client_with_error,
)


class TestLambdaHandler:

    def test_handler_success_adds_trigger_result(self, monkeypatch):
        """Handler should add trigger_result with runner metadata on success."""
        mock_ecs = mock_ecs_client_success()
        monkeypatch.setattr("trigger_ecs_job.handler.boto3.client", lambda svc: mock_ecs)

        result = lambda_handler(make_event(), None)

        assert "trigger_result" in result
        tr = result["trigger_result"]
        assert tr["trigger_status"] == "TRIGGERED"
        assert tr["runner_name"] == "S2S3"
        assert tr["runner_type"] == "ECS"
        assert "abc123def456" in tr["task_arn"]

    def test_handler_failure_adds_trigger_result(self, monkeypatch):
        """Handler should add trigger_result with TRIGGER_FAILED on error."""
        mock_ecs = mock_ecs_client_no_tasks()
        monkeypatch.setattr("trigger_ecs_job.handler.boto3.client", lambda svc: mock_ecs)

        result = lambda_handler(make_event(), None)

        tr = result["trigger_result"]
        assert tr["trigger_status"] == "TRIGGER_FAILED"
        assert tr["runner_name"] == "S2S3"
        assert tr["runner_type"] == "ECS"

    def test_handler_preserves_original_event_fields(self, monkeypatch):
        """Handler should return the original event fields plus trigger_result."""
        mock_ecs = mock_ecs_client_success()
        monkeypatch.setattr("trigger_ecs_job.handler.boto3.client", lambda svc: mock_ecs)

        result = lambda_handler(make_event(), None)

        assert result["run_id"] == "run-001"
        assert result["job_id"] == "client"
        assert result["job_type"] == "sourcing"
        assert result["status"] == "WAITING"
        assert result["job_config"]["job_runner"]["type"] == "ECS_Fargate"

    def test_handler_calls_write_log_on_success(self, monkeypatch, _mock_write_log):
        """write_log should be called with the correct stage and status."""
        mock_ecs = mock_ecs_client_success()
        monkeypatch.setattr("trigger_ecs_job.handler.boto3.client", lambda svc: mock_ecs)

        lambda_handler(make_event(), None)

        _mock_write_log.assert_called_once()
        kw = _mock_write_log.call_args.kwargs
        assert kw["run_id"] == "run-001"
        assert kw["job_id"] == "client"
        assert kw["stage"] == "TriggerEcsJob"
        assert kw["status"] == "TRIGGERED"

    def test_handler_calls_write_log_on_failure(self, monkeypatch, _mock_write_log):
        """write_log should be called even when the trigger fails."""
        mock_ecs = mock_ecs_client_no_tasks()
        monkeypatch.setattr("trigger_ecs_job.handler.boto3.client", lambda svc: mock_ecs)

        lambda_handler(make_event(), None)

        _mock_write_log.assert_called_once()
        assert _mock_write_log.call_args.kwargs["status"] == "TRIGGER_FAILED"

    def test_handler_missing_run_id_defaults_to_unknown(self, monkeypatch):
        """Handler should default run_id to 'UNKNOWN' when missing."""
        mock_ecs = mock_ecs_client_success()
        monkeypatch.setattr("trigger_ecs_job.handler.boto3.client", lambda svc: mock_ecs)

        event = make_event()
        del event["run_id"]
        result = lambda_handler(event, None)

        assert result["trigger_result"]["trigger_status"] == "TRIGGERED"

    def test_handler_handles_empty_event(self, monkeypatch):
        """Handler should not crash on a minimal / empty-ish event."""
        mock_ecs = mock_ecs_client_with_error(
            code="InvalidParameterException",
            message="taskDefinition cannot be empty",
        )
        monkeypatch.setattr("trigger_ecs_job.handler.boto3.client", lambda svc: mock_ecs)

        result = lambda_handler({}, None)

        assert "trigger_result" in result
        assert result["trigger_result"]["trigger_status"] == "TRIGGER_FAILED"

    def test_handler_returns_modified_event_not_new_dict(self, monkeypatch):
        """Handler must return the SAME event object, with trigger_result added."""
        mock_ecs = mock_ecs_client_success()
        monkeypatch.setattr("trigger_ecs_job.handler.boto3.client", lambda svc: mock_ecs)

        event = make_event()
        result = lambda_handler(event, None)
        assert result is event
