"""
handler.py
UpdateJobStatus Lambda Handler – entry point only.

Delegates all business logic to specialised modules:
  • constants    – environment-driven config & status enums
  • logger       – structured step logging with configurable log level
  • time_utils   – ISO 8601 timestamp helpers
  • dynamo_client – boto3 DynamoDB resource factory
  • job_updater  – per-status DynamoDB update operations

Status Outcomes:
  SUCCESS        → Mark status as SUCCESS, update all time attributes.
  TRIGGER_FAILED → Mark status back to WAITING,
                   set next_scheduled_run_time to next minute.
  RUNNING        → Update last_heartbeat_time,
                   extend expiry_time by 5 minutes.
  FAILED         → Mark status as FAILED, persist error message.

Input:  Full payload with trigger_result containing job_status.
Output: Updated payload with update_confirmation.
"""

from datetime import datetime, timezone

from constants import JOB_RUN_TABLE, JobStatus
from dynamo_client import get_dynamodb_resource
from job_updater import (
    update_job_run_failed,
    update_job_run_still_running,
    update_job_run_success,
    update_job_run_trigger_failed,
)
from lambdas.log_to_dynamo import write_log          # unchanged external dep
from logger import get_logger, log_step

logger = get_logger(__name__)


def lambda_handler(event: dict, context) -> dict:
    """Lambda entry point."""

    # ------------------------------------------------------------------
    # 1. Extract and validate inputs
    # ------------------------------------------------------------------
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    run_id: str = event.get("run_id")

    if not run_id:
        log_step(
            "VALIDATION_ERROR",
            {"error": "Missing required field: run_id"},
            level="ERROR",
        )
        raise ValueError("Missing required field: 'run_id'")

    trigger_result: dict = event.get("trigger_result", {})
    trigger_status: str = trigger_result.get("trigger_status", "")
    job_status: str = trigger_result.get("job_status", "")
    job_config: dict = event.get("job_config", {})

    # ------------------------------------------------------------------
    # 2. Determine effective status
    # ------------------------------------------------------------------
    effective_status = (
        JobStatus.TRIGGER_FAILED
        if trigger_status == JobStatus.TRIGGER_FAILED
        else job_status
    )

    log_step(
        "HANDLER_START",
        {
            "timestamp": timestamp,
            "run_id": run_id,
            "trigger_status": trigger_status,
            "job_status": job_status,
            "effective_status": effective_status,
        },
    )

    # ------------------------------------------------------------------
    # 3. Connect to DynamoDB
    # ------------------------------------------------------------------
    dynamodb = get_dynamodb_resource()
    table = dynamodb.Table(JOB_RUN_TABLE)

    # ------------------------------------------------------------------
    # 4. Dispatch to the appropriate update function
    # ------------------------------------------------------------------
    update_result: dict = {"effective_status": effective_status}

    if effective_status == JobStatus.SUCCESS:
        log_step("STATUS_BRANCH", {"branch": "SUCCESS", "run_id": run_id})
        updated = update_job_run_success(table, run_id)
        update_result["updated_attributes"] = updated

    elif effective_status == JobStatus.TRIGGER_FAILED:
        log_step(
            "STATUS_BRANCH",
            {"branch": "TRIGGER_FAILED", "run_id": run_id},
        )
        updated = update_job_run_trigger_failed(table, run_id)
        update_result["updated_attributes"] = updated

    elif effective_status == JobStatus.RUNNING:
        log_step(
            "STATUS_BRANCH",
            {"branch": "RUNNING (heartbeat update)", "run_id": run_id},
        )
        updated = update_job_run_still_running(table, run_id)
        update_result["updated_attributes"] = updated

    elif effective_status == JobStatus.FAILED:
        log_step(
            "STATUS_BRANCH",
            {"branch": "FAILED", "run_id": run_id},
            level="ERROR",
        )
        error_message: str = trigger_result.get("error", "")
        updated = update_job_run_failed(table, run_id, error_message)
        update_result["updated_attributes"] = updated

    else:
        # Unknown status – treat as FAILED and surface the original value
        unknown_msg = f"Unknown status treated as FAILED: {effective_status}"
        log_step(
            "STATUS_BRANCH",
            {"branch": f"UNKNOWN ({effective_status}) → treating as FAILED", "run_id": run_id},
            level="ERROR",
        )
        updated = update_job_run_failed(table, run_id, unknown_msg)
        update_result["updated_attributes"] = updated
        update_result["error"] = unknown_msg

    # ------------------------------------------------------------------
    # 5. Persist audit log and return
    # ------------------------------------------------------------------
    event["update_result"] = update_result

    write_log(
        run_id=run_id,
        job_id=event.get("job_id", ""),
        stage="UpdateJobStatus",
        status=effective_status,
    )

    log_step(
        "HANDLER_COMPLETE",
        {
            "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "run_id": run_id,
            "effective_status": effective_status,
        },
    )

    return event
