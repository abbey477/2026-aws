"""
Happy path tests for trigger_ecs_task.

Coverage:
  - Successful trigger returns TRIGGERED with task_arn
  - JOB_PARAM env var contains JSON-encoded job_param
  - Nested objects and arrays survive JSON round-trip
  - Unicode characters survive JSON serialization
  - Empty job_param ({}) still serializes and passes
"""

import json

from trigger_ecs_job.ecs_trigger import trigger_ecs_task
from conftest import make_event, mock_ecs_client_success, get_job_param_env


class TestHappyPath:

    def test_successful_trigger_returns_task_arn(self):
        """RunTask returns a task with an ARN."""
        mock_ecs = mock_ecs_client_success()
        event = make_event()
        job_config = event["job_config"]
        job_param = job_config["job_param"]

        result = trigger_ecs_task(mock_ecs, job_config, job_param, "run-001")

        assert result["trigger_status"] == "TRIGGERED"
        assert "abc123def456" in result["task_arn"]
        assert "error" not in result

    def test_job_param_passed_as_json_in_env(self):
        """JOB_PARAM env var contains JSON-encoded job_param."""
        mock_ecs = mock_ecs_client_success()
        event = make_event()
        job_config = event["job_config"]
        job_param = job_config["job_param"]

        trigger_ecs_task(mock_ecs, job_config, job_param, "run-001")

        job_param_env = get_job_param_env(mock_ecs)
        assert job_param_env["name"] == "JOB_PARAM"
        parsed = json.loads(job_param_env["value"])
        assert parsed == job_param

    def test_nested_structures_round_trip(self):
        """Nested objects and arrays survive JSON round-trip."""
        mock_ecs = mock_ecs_client_success()
        job_param = {
            "source": {"type": "API", "name": "RDI", "config": {"timeout": 30}},
            "filters": [
                {"field": "status", "op": "eq", "value": "active"},
                {"field": "region", "op": "in", "value": ["us", "eu"]},
            ],
            "batch_size": 1000,
            "dry_run": False,
        }
        event = make_event(job_param=job_param)
        job_config = event["job_config"]

        trigger_ecs_task(mock_ecs, job_config, job_param, "run-001")

        parsed = json.loads(get_job_param_env(mock_ecs)["value"])
        assert parsed == job_param
        assert parsed["source"]["config"]["timeout"] == 30
        assert parsed["filters"][1]["value"] == ["us", "eu"]
        assert parsed["dry_run"] is False

    def test_unicode_survives_serialization(self):
        """Non-ASCII characters in job_param survive JSON serialization."""
        mock_ecs = mock_ecs_client_success()
        job_param = {
            "customer_name": "Zürich Café",
            "description": "データ処理",
            "emoji_tag": "🚀",
        }
        event = make_event(job_param=job_param)
        job_config = event["job_config"]

        trigger_ecs_task(mock_ecs, job_config, job_param, "run-001")

        parsed = json.loads(get_job_param_env(mock_ecs)["value"])
        assert parsed == job_param

    def test_empty_job_param_still_works(self):
        """Empty dict as job_param should serialize to '{}' and succeed."""
        mock_ecs = mock_ecs_client_success()
        event = make_event(job_param={})
        job_config = event["job_config"]

        result = trigger_ecs_task(mock_ecs, job_config, {}, "run-001")

        assert result["trigger_status"] == "TRIGGERED"
        assert get_job_param_env(mock_ecs)["value"] == "{}"
