import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;

import com.sybase.jdbc4.jdbc.SybDriver;

public class SybaseKerberosTest {

    public static void main(String[] args) {
        // ===== UPDATE THESE VALUES FOR YOUR ENVIRONMENT =====
        String host = "your-sybase-host.example.com";
        int    port = 5000;
        String database = "your_database";
        // SPN registered for the Sybase server in your KDC, e.g.
        //   sybase/your-sybase-host.example.com@YOUR.REALM.COM
        String servicePrincipal = "sybase/your-sybase-host.example.com@YOUR.REALM.COM";
        // Path to the Kerberos config file someone gave you
        String krb5ConfPath = "/etc/krb5.conf";
        // ====================================================

        // Tell Java where the Kerberos config file is
        System.setProperty("java.security.krb5.conf", krb5ConfPath);
        // Useful first time - prints what Kerberos is doing. Remove once it works.
        System.setProperty("sun.security.krb5.debug", "true");

        // jConnect URL
        String url = "jdbc:sybase:Tds:" + host + ":" + port + "/" + database;

        Properties props = new Properties();
        props.put("REQUEST_KERBEROS_SESSION", "true");
        props.put("SERVICE_PRINCIPAL_NAME", servicePrincipal);
        props.put("JCONNECT_VERSION", "7");

        System.out.println("=== Sybase jConnect Kerberos Test ===");
        System.out.println("URL       : " + url);
        System.out.println("SPN       : " + servicePrincipal);
        System.out.println("krb5.conf : " + krb5ConfPath);
        System.out.println();

        try {
            DriverManager.registerDriver(new SybDriver());

            System.out.println("Connecting...");
            try (Connection conn = DriverManager.getConnection(url, props)) {
                System.out.println("SUCCESS: Connected to Sybase via Kerberos!");
                System.out.println("Catalog    : " + conn.getCatalog());
                System.out.println("AutoCommit : " + conn.getAutoCommit());

                try (Statement st = conn.createStatement();
                     ResultSet rs = st.executeQuery("SELECT @@version")) {
                    if (rs.next()) {
                        System.out.println("Server version:");
                        System.out.println("  " + rs.getString(1));
                    }
                }
            }
            System.out.println("Connection closed cleanly.");
        } catch (Exception e) {
            System.err.println("FAIL: " + e.getClass().getName() + " - " + e.getMessage());
            e.printStackTrace();
        }
    }
}
