package com.example.dbtester.repository.sybase;

import com.example.dbtester.entity.Customer;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * JDBC CRUD for Sybase CUSTOMER.
 * IDENTITY column assigns ids server-side. Single insert uses SimpleJdbcInsert
 * to retrieve the generated key; batch insert returns row count only.
 */
@Repository
public class CustomerRepository {

    private static final int BATCH_SIZE = 500;

    private static final String TABLE = "CUSTOMER";
    private static final String SQL_FIND_ALL = "SELECT id, first_name, last_name, email, created_at FROM CUSTOMER";
    private static final String SQL_FIND_BY_ID = "SELECT id, first_name, last_name, email, created_at FROM CUSTOMER WHERE id = ?";
    private static final String SQL_INSERT_BATCH = "INSERT INTO CUSTOMER (first_name, last_name, email, created_at) VALUES (?, ?, ?, ?)";
    private static final String SQL_UPDATE = "UPDATE CUSTOMER SET first_name = ?, last_name = ?, email = ? WHERE id = ?";
    private static final String SQL_DELETE = "DELETE FROM CUSTOMER WHERE id = ?";

    private final JdbcTemplate jdbc;
    private final SimpleJdbcInsert insert;
    private final CustomerRowMapper rowMapper = new CustomerRowMapper();

    public CustomerRepository(@Qualifier("sybaseJdbcTemplate") JdbcTemplate jdbc,
                              @Qualifier("sybaseDataSource") DataSource ds) {
        this.jdbc = jdbc;
        this.insert = new SimpleJdbcInsert(ds)
                .withTableName(TABLE)
                .usingGeneratedKeyColumns("id");
    }

    // ---- Read ----

    public List<Customer> findAll() {
        return jdbc.query(SQL_FIND_ALL, rowMapper);
    }

    public Optional<Customer> findById(Long id) {
        return jdbc.query(SQL_FIND_BY_ID, rowMapper, id).stream().findFirst();
    }

    // ---- Write (single row) ----

    public Customer insert(Customer c) {
        Map<String, Object> params = Map.of(
                "first_name", c.firstName(),
                "last_name",  c.lastName(),
                "email",      c.email(),
                "created_at", Timestamp.valueOf(LocalDateTime.now())
        );
        Number key = insert.executeAndReturnKey(params);
        return findById(key.longValue()).orElseThrow();
    }

    public int update(Long id, Customer c) {
        return jdbc.update(SQL_UPDATE, c.firstName(), c.lastName(), c.email(), id);
    }

    public int delete(Long id) {
        return jdbc.update(SQL_DELETE, id);
    }

    // ---- Write (batch) ----
    // Each batch method chunks by BATCH_SIZE to keep memory bounded.

    public int insertAll(List<Customer> customers) {
        Timestamp now = Timestamp.valueOf(LocalDateTime.now());
        List<Object[]> rows = new ArrayList<>(customers.size());
        for (Customer c : customers) {
            Timestamp created = c.createdAt() != null ? Timestamp.valueOf(c.createdAt()) : now;
            rows.add(new Object[]{c.firstName(), c.lastName(), c.email(), created});
        }
        return batchInChunks(SQL_INSERT_BATCH, rows);
    }

    public int updateAll(List<Customer> customers) {
        List<Object[]> rows = new ArrayList<>(customers.size());
        for (Customer c : customers) {
            rows.add(new Object[]{c.firstName(), c.lastName(), c.email(), c.id()});
        }
        return batchInChunks(SQL_UPDATE, rows);
    }

    public int deleteAll(List<Long> ids) {
        List<Object[]> rows = new ArrayList<>(ids.size());
        for (Long id : ids) {
            rows.add(new Object[]{id});
        }
        return batchInChunks(SQL_DELETE, rows);
    }

    /** Run a batchUpdate in BATCH_SIZE chunks; return total rows affected. */
    private int batchInChunks(String sql, List<Object[]> rows) {
        int total = 0;
        for (int i = 0; i < rows.size(); i += BATCH_SIZE) {
            List<Object[]> chunk = rows.subList(i, Math.min(i + BATCH_SIZE, rows.size()));
            int[] counts = jdbc.batchUpdate(sql, chunk);
            for (int c : counts) {
                total += (c >= 0) ? c : 1;
            }
        }
        return total;
    }
}
