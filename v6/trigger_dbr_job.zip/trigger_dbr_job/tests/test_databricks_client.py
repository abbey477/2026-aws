"""
test_databricks_client.py
Unit tests for databricks_client.trigger_databricks_job.

Tests:
  1. Successful trigger — returns TRIGGERED with dbr_run_id
  2. HTTPError         — returns TRIGGER_FAILED with error
  3. URLError          — returns TRIGGER_FAILED with error
  4. Unexpected error  — returns TRIGGER_FAILED with error
  5. Correct API URL and auth headers are constructed
  6. Request payload contains job_id and notebook_params
  7. Empty run_id in response emits a warning (non-fatal)
"""

import json
import urllib.error
import pytest
from unittest.mock import patch, MagicMock

from databricks_client import trigger_databricks_job

_MODULE = "databricks_client.urllib.request.urlopen"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _job_config(event):
    return event["job_config"]

def _job_param(event):
    return event["job_config"]["job_param"]


# ---------------------------------------------------------------------------
# Success path
# ---------------------------------------------------------------------------

class TestTriggerDatabricksJobSuccess:

    @patch(_MODULE)
    def test_returns_triggered_with_run_id(self, mock_urlopen, make_event, mock_urlopen_success):
        """Happy path: Databricks API returns a run_id."""
        mock_urlopen.return_value = mock_urlopen_success("67890")
        event = make_event()

        result = trigger_databricks_job(_job_config(event), _job_param(event))

        assert result["trigger_status"] == "TRIGGERED"
        assert result["dbr_run_id"] == "67890"
        assert "error" not in result

    @patch(_MODULE)
    def test_empty_run_id_still_returns_triggered(self, mock_urlopen, make_event, mock_urlopen_success):
        """Edge: API returns empty run_id — still TRIGGERED but warning emitted."""
        mock_urlopen.return_value = mock_urlopen_success("")
        event = make_event()

        result = trigger_databricks_job(_job_config(event), _job_param(event))

        assert result["trigger_status"] == "TRIGGERED"
        assert result["dbr_run_id"] == ""


# ---------------------------------------------------------------------------
# Failure paths
# ---------------------------------------------------------------------------

class TestTriggerDatabricksJobFailures:

    @patch(_MODULE)
    def test_http_error_returns_trigger_failed(self, mock_urlopen, make_event):
        """HTTPError from Databricks API → TRIGGER_FAILED."""
        mock_urlopen.side_effect = urllib.error.HTTPError(
            url="https://example.com", code=403, msg="Forbidden", hdrs={}, fp=None
        )
        event = make_event()

        result = trigger_databricks_job(_job_config(event), _job_param(event))

        assert result["trigger_status"] == "TRIGGER_FAILED"
        assert result["dbr_run_id"] == ""
        assert "error" in result

    @patch(_MODULE)
    def test_url_error_returns_trigger_failed(self, mock_urlopen, make_event):
        """URLError (network failure) → TRIGGER_FAILED."""
        mock_urlopen.side_effect = urllib.error.URLError("Connection refused")
        event = make_event()

        result = trigger_databricks_job(_job_config(event), _job_param(event))

        assert result["trigger_status"] == "TRIGGER_FAILED"
        assert result["dbr_run_id"] == ""
        assert "Connection refused" in result["error"]

    @patch(_MODULE)
    def test_unexpected_error_returns_trigger_failed(self, mock_urlopen, make_event):
        """Unexpected Exception → TRIGGER_FAILED."""
        mock_urlopen.side_effect = RuntimeError("something went wrong")
        event = make_event()

        result = trigger_databricks_job(_job_config(event), _job_param(event))

        assert result["trigger_status"] == "TRIGGER_FAILED"
        assert result["dbr_run_id"] == ""
        assert "something went wrong" in result["error"]


# ---------------------------------------------------------------------------
# Request construction
# ---------------------------------------------------------------------------

class TestTriggerDatabricksJobRequestConstruction:

    @patch(_MODULE)
    def test_correct_api_url_and_headers(self, mock_urlopen, make_event, mock_urlopen_success):
        """Correct Databricks API URL and auth headers are used."""
        mock_urlopen.return_value = mock_urlopen_success()
        event = make_event()

        trigger_databricks_job(_job_config(event), _job_param(event))

        request_obj = mock_urlopen.call_args[0][0]
        assert "my-databricks-instance.cloud.databricks.com" in request_obj.full_url
        assert "/api/2.1/jobs/run-now" in request_obj.full_url
        assert request_obj.get_header("Authorization") == "Bearer dapi-mock-token-12345"
        assert request_obj.get_header("Content-type") == "application/json"

    @patch(_MODULE)
    def test_request_payload_contains_job_id_and_params(self, mock_urlopen, make_event, mock_urlopen_success):
        """Request body includes job_id and notebook_params."""
        mock_urlopen.return_value = mock_urlopen_success()
        event = make_event()

        trigger_databricks_job(_job_config(event), _job_param(event))

        request_obj = mock_urlopen.call_args[0][0]
        body = json.loads(request_obj.data.decode("utf-8"))
        assert body["job_id"] == "12345"
        assert body["notebook_params"]["entity_id"] == "client"
        assert body["notebook_params"]["job_type"] == "silver_load"
