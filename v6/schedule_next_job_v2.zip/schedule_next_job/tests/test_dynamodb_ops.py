"""
Tests for dynamodb_ops.py
"""
import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import re
import pytest
from botocore.exceptions import ClientError
from dynamodb_ops import get_current_time_iso, get_next_minute_iso, get_next_job_config, put_job_run

ISO_8601_REGEX = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$")


class TestGetNextJobConfig:

    def test_get_next_job_config_found(self, dynamodb_setup):
        _, _, job_config_table = dynamodb_setup
        result = get_next_job_config(job_config_table, "dbr_client", "silver_load")
        assert result["job_id"] == "dbr_client"
        assert result["trigger_type"] == "PIPELINE"
        assert result["job_runner"]["name"] == "DBR"

    def test_get_next_job_config_not_found(self, dynamodb_setup):
        _, _, job_config_table = dynamodb_setup
        assert get_next_job_config(job_config_table, "nonexistent", "missing") == {}

    def test_get_next_job_config_calls_correct_key(self, dynamodb_setup):
        _, _, job_config_table = dynamodb_setup
        assert get_next_job_config(job_config_table, "dbr_client", "wrong_type") == {}
        assert get_next_job_config(job_config_table, "dbr_client", "silver_load") != {}


class TestPutJobRun:

    def test_put_job_run_inserts_item(self, dynamodb_setup):
        _, job_run_table, _ = dynamodb_setup
        item = {
            "run_id": "test-run-999", "job_id": "dbr_client", "job_type": "silver_load",
            "trigger_type": "PIPELINE", "status": "WAITING", "start_time": "",
            "end_time": "", "next_scheduled_run_time": "2024-04-01T00:01:00Z",
            "last_heartbeat_time": "", "expiry_time": "", "mark_for_delete": False,
            "custom_attributes": {"s3_path": "s3://bucket/data"}, "error": "", "delete_at": 0,
        }
        put_job_run(job_run_table, item)
        stored = job_run_table.get_item(Key={"run_id": "test-run-999"})["Item"]
        assert stored["job_id"] == "dbr_client"
        assert stored["status"] == "WAITING"
        assert stored["custom_attributes"] == {"s3_path": "s3://bucket/data"}


class TestTimeHelpers:

    def test_current_time_iso_format(self):
        assert ISO_8601_REGEX.match(get_current_time_iso())

    def test_next_minute_iso_format(self):
        assert ISO_8601_REGEX.match(get_next_minute_iso())

    def test_next_minute_is_after_current(self):
        assert get_next_minute_iso() > get_current_time_iso()
