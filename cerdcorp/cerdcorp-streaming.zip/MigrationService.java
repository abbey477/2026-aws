import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.stereotype.Service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Orchestrates the migration from Sybase to Oracle.
 * Delegates streaming to SybaseReaderService and writing to OracleWriterService.
 * All per-run state lives in MigrationRowHandler so run() can be called
 * multiple times safely.
 */
@Service
public class MigrationService {

    private static final Logger log = LoggerFactory.getLogger(MigrationService.class);

    private static final int CHUNK_SIZE = 1_000;
    private static final int LOG_EVERY  = 100_000;

    private final SybaseReaderService sybaseReader;
    private final OracleWriterService oracleWriter;

    public MigrationService(SybaseReaderService sybaseReader,
                            OracleWriterService oracleWriter) {
        this.sybaseReader = sybaseReader;
        this.oracleWriter = oracleWriter;
    }

    // -------------------------------------------------------------------------
    // Entry point — fresh handler every call, so state is always clean.
    // -------------------------------------------------------------------------

    public void run() {
        log.info("Migration started");

        MigrationRowHandler handler = new MigrationRowHandler();
        sybaseReader.streamAll(handler);
        handler.flushRemainingRows();

        log.info("Migration complete — {} total rows written", handler.getTotalWritten());
    }

    // -------------------------------------------------------------------------
    // Spring calls processRow() once per row from Sybase.
    // Accumulates rows into a chunk, flushes to Oracle when full.
    // Holds all per-run state internally.
    // -------------------------------------------------------------------------

    private class MigrationRowHandler implements RowCallbackHandler {

        private final List<MyRecord> chunk = new ArrayList<>(CHUNK_SIZE);
        private long totalWritten = 0;
        private long lastLoggedAt = 0;

        @Override
        public void processRow(ResultSet rs) throws SQLException {
            MyRecord record = mapRow(rs);
            chunk.add(record);

            boolean chunkIsFull = chunk.size() == CHUNK_SIZE;
            if (chunkIsFull) {
                writeChunk();
            }
        }

        // Flush the last partial chunk after streaming ends
        public void flushRemainingRows() {
            boolean hasLeftovers = !chunk.isEmpty();
            if (hasLeftovers) {
                writeChunk();
            }
        }

        public long getTotalWritten() {
            return totalWritten;
        }

        // Map one ResultSet row to a domain object
        private MyRecord mapRow(ResultSet rs) throws SQLException {
            return new MyRecord(
                rs.getLong("col1"),
                rs.getString("col2"),
                rs.getTimestamp("col3")
            );
        }

        // Single place that does the write + bookkeeping
        private void writeChunk() {
            oracleWriter.writeChunk(chunk);
            totalWritten += chunk.size();
            chunk.clear();
            logProgressIfDue();
        }

        // Difference-based check — works regardless of chunk size
        private void logProgressIfDue() {
            boolean isDue = totalWritten - lastLoggedAt >= LOG_EVERY;
            if (isDue) {
                log.info("Progress: {} rows written", totalWritten);
                lastLoggedAt = totalWritten;
            }
        }
    }
}
