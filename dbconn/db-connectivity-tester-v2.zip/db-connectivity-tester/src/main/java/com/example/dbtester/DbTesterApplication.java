package com.example.dbtester;

import com.example.dbtester.config.DataSourceProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

/**
 * Application entry point.
 *
 * <p>Two things worth calling out here:
 *
 * <ol>
 *   <li>{@code exclude = DataSourceAutoConfiguration.class} — Spring Boot's
 *       auto-config would otherwise try to build a single default DataSource
 *       from {@code spring.datasource.*} properties and fail (we don't set
 *       those). We build both DataSources manually in the {@code config}
 *       package.</li>
 *   <li>{@code @EnableConfigurationProperties(DataSourceProperties.class)} —
 *       registers our record-based {@link DataSourceProperties} for
 *       automatic property binding. Without this, {@code @ConfigurationProperties}
 *       on a record has no effect.</li>
 * </ol>
 */
@SpringBootApplication(exclude = { DataSourceAutoConfiguration.class })
@EnableConfigurationProperties(DataSourceProperties.class)
public class DbTesterApplication {

    public static void main(String[] args) {
        SpringApplication.run(DbTesterApplication.class, args);
    }
}
