"""
Structured logging helper for GetConfig Lambda.

Four log levels — info / warn / error / debug — map to Python's stdlib
logging levels so CloudWatch Insights can filter by @logLevel.

Every log line carries a step tag + key-value pairs for easy filtering.

Usage:
    from get_config.logging_utils import info, warn, error, debug

    info("HANDLER_START", {"run_id": run_id})
    warn("FETCH_JOB_RUN_FAILED", {"run_id": run_id, "reason": "..."})
    error("VALIDATION_ERROR", {"error": "..."})
    debug("STEP_DETAIL", {"state": "..."})
"""

import logging

logger = logging.getLogger(__name__)

_LAMBDA_TAG = "[GetConfig]"


def _fmt(details: dict) -> str:
    """Format a details dict as 'k=v, k=v' for log readability."""
    return ", ".join(f"{k}={v}" for k, v in details.items())


def info(step: str, details: dict) -> None:
    """Informational event — normal operation, not actionable."""
    logger.info(f"{_LAMBDA_TAG} [{step}] {_fmt(details)}")


def warn(step: str, details: dict) -> None:
    """
    Warning — something unusual happened but the lambda can continue.
    Examples: row not found (may be expected), fallback used.
    """
    logger.warning(f"{_LAMBDA_TAG} [{step}] {_fmt(details)}")


def error(step: str, details: dict) -> None:
    """
    Error — something went wrong; the lambda is likely raising or failing.
    Examples: ClientError from DynamoDB, validation failure.
    """
    logger.error(f"{_LAMBDA_TAG} [{step}] {_fmt(details)}")


def debug(step: str, details: dict) -> None:
    """Debug detail — only visible when root log level is DEBUG."""
    logger.debug(f"{_LAMBDA_TAG} [{step}] {_fmt(details)}")
