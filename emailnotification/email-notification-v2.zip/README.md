# Email Notification Service — v2

Same features as v1, ~40% less code.

---

## What changed from v1

| v1 | v2 | Reduction |
|---|---|---|
| 3 service classes | 1 `EmailService` | -2 files |
| 3 model files + 3 enum files | 1 `EmailModel.java` (nested records + enums) | -5 files |
| 2 exception classes | 1 `AppException` | -1 file |
| 2 cache classes | Cache logic inlined into `EmailService` | -2 files |
| 1 idempotency guard class | Guard inlined into `EmailService.send()` | -1 file |
| 4 test classes | 1 `EmailServiceTest` | -3 files |
| **20 Java files** | **8 Java files** | **-60%** |

All features preserved: idempotency guard, per-environment yml, enums, record DTOs, plain HTML templates, priority headers, CC/BCC/replyTo.

---

## Project Structure

```
src/main/java/com/example/notification/
├── config/
│   ├── MailProperties.java     Record bound to app.mail.* yml
│   └── MailConfig.java         JavaMailSender + Caffeine cache beans
│
├── model/
│   └── EmailModel.java         All in one: Type/Priority/Status enums + Request/Response/Info records
│
├── template/
│   ├── EmailTemplate.java      Maps Type → template file + default subject
│   └── TemplateService.java    Loads HTML file, injects {{variables}}
│
├── service/
│   └── EmailService.java       Everything: guard + render + compose + send
│
└── exception/
    └── AppException.java       Single unified exception

src/main/resources/
├── application.yml             Shared config
├── application-dev.yml         Dev SMTP — Mailtrap (TTL: 5 min)
├── application-uat.yml         UAT SMTP (TTL: 30 min)
├── application-prod.yml        Prod SMTP — AWS SES (TTL: 60 min)
└── templates/
    ├── welcome.html
    ├── password-reset.html
    └── order-confirm.html
```

---

## How It Works

```
Your existing service
        │
        │  EmailModel.Request.welcome(...)
        ↓
EmailService.send()
        │
        ├── build cache key (to + type + variablesHash)
        ├── cache HIT  → return Response.skipped()
        └── cache MISS
                │
                ├── EmailTemplate.from(type)  → template file
                ├── TemplateService.render()  → HTML string
                ├── compose()                 → MimeMessage
                ├── mailSender.send()         → SMTP
                └── cache.put(key)            → mark sent
                        │
                        └── return Response.sent() | Response.failed()
```

---

## Setup

### Environment Variables

**Dev**
```bash
export MAIL_DEV_USER=your_mailtrap_user
export MAIL_DEV_PASS=your_mailtrap_pass
```

**UAT**
```bash
export MAIL_UAT_USER=your_uat_user
export MAIL_UAT_PASS=your_uat_pass
```

**Prod**
```bash
export MAIL_PROD_USER=your_ses_access_key
export MAIL_PROD_PASS=your_ses_secret_key
```

### Build & Run

```bash
# build
mvn clean install

# dev (default)
mvn spring-boot:run

# uat
mvn spring-boot:run -Dspring.profiles.active=uat

# prod
SPRING_PROFILES_ACTIVE=prod java -jar target/email-notification-v2-2.0.0-SNAPSHOT.jar
```

### Run Tests

```bash
mvn test
```

---

## How to Call From an Existing Service

```java
@Service
@RequiredArgsConstructor
public class UserService {

    private final EmailService emailService;

    public void onUserRegistered(User user) {
        var response = emailService.send(
            EmailModel.Request.welcome(
                user.getEmail(),
                user.getName(),
                "https://app.example.com/dashboard",
                "support@example.com"
            )
        );

        if (response.isSkipped()) {
            log.info("Already sent to {}", user.getEmail());
        }
    }

    public void onPasswordReset(User user, String resetLink) {
        emailService.send(
            EmailModel.Request.passwordReset(
                user.getEmail(), user.getName(), resetLink, 30, "support@example.com"
            )
        );
    }
}
```

---

## Adding a New Email Type

1. Add to `EmailModel.Type` enum
2. Add to `EmailTemplate` enum (file + subject)
3. Create HTML file in `src/main/resources/templates/`
4. Optionally add a factory method on `EmailModel.Request`

---

## Idempotency

Cache key = `to :: type :: variablesHash`

| Environment | TTL |
|---|---|
| dev | 5 min |
| uat | 30 min |
| prod | 60 min |

Failed sends are **not** cached — the next call will retry.
To swap Caffeine for Redis, replace the `Cache<>` bean in `MailConfig` — `EmailService` is unaffected.
