"""
CheckJobStatus Lambda Handler

Unified status poller that checks the status of a running job regardless of
runner type (ECS Fargate or Databricks). Routes to the correct status-check
logic based on ``trigger_result.runner_type``.

Called every 60 seconds in the Step Functions poll loop.

Input:  Full payload with trigger_result containing either task_arn (ECS)
            or dbr_run_id (Databricks). Runner infra config is in
            job_config.job_runner.config.
Output: Same payload with job_status updated in trigger_result.

Possible job_status values:
    - RUNNING  : Job is still executing
    - SUCCESS  : Job completed successfully
    - FAILED   : Job failed or could not be checked
"""

import logging
from datetime import datetime, timezone

from check_job_status.ecs_status import get_ecs_client, check_ecs_task_status
from check_job_status.databricks_status import check_databricks_job_status
from check_job_status.log_to_dynamo import (
    write_log_info,
    write_log_warn,
    write_log_error,
)

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


def _log(step: str, details: dict):
    """Structured info log – every line has a step tag + key-value pairs."""
    detail_str = ", ".join(f"{k}={v}" for k, v in details.items())
    logger.info(f"[CheckJobStatus] [{step}] {detail_str}")


def lambda_handler(event, context):
    """
    Lambda entry point -- checks job status based on runner_type.

    Routes to ECS or Databricks status check logic based on
    ``trigger_result.runner_type``. Runner infra config comes from
    ``job_config.job_runner.config``.

    Input:  Full payload with trigger_result containing task_arn or dbr_run_id.
    Output: Same payload with job_status updated in trigger_result.
    """
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    run_id = event.get("run_id", "UNKNOWN")
    trigger_result = event.get("trigger_result", {})
    job_config = event.get("job_config", {})
    runner_config = job_config.get("job_runner", {}).get("config", {})
    runner_type = trigger_result.get("runner_type", "")
    job_id = event.get("job_id", "")

    _log("HANDLER_START", {
        "timestamp": timestamp,
        "run_id": run_id,
        "runner_type": runner_type,
    })

    # --- Log that we started checking ---
    write_log_info(run_id=run_id, job_id=job_id, stage="CheckJobStatus", status="STARTED")

    if runner_type == "ECS":
        task_arn = trigger_result.get("task_arn", "")

        if not task_arn:
            _log("VALIDATION_ERROR", {"error": "Missing task_arn", "run_id": run_id})
            trigger_result["job_status"] = "FAILED"
            trigger_result["error"] = "Missing task_arn"
            write_log_error(run_id=run_id, job_id=job_id, stage="CheckJobStatus", status="FAILED")
        else:
            ecs_client = get_ecs_client()
            status_result = check_ecs_task_status(ecs_client, task_arn, runner_config)
            trigger_result.update(status_result)

    elif runner_type == "DBR":
        dbr_run_id = trigger_result.get("dbr_run_id", "")

        if not dbr_run_id:
            _log("VALIDATION_ERROR", {"error": "Missing dbr_run_id", "run_id": run_id})
            trigger_result["job_status"] = "FAILED"
            trigger_result["error"] = "Missing dbr_run_id"
            write_log_error(run_id=run_id, job_id=job_id, stage="CheckJobStatus", status="FAILED")
        else:
            status_result = check_databricks_job_status(dbr_run_id, runner_config)
            trigger_result.update(status_result)

    else:
        _log("VALIDATION_ERROR", {"error": f"Unsupported runner_type: {runner_type}", "run_id": run_id})
        trigger_result["job_status"] = "FAILED"
        trigger_result["error"] = f"Unsupported runner_type: {runner_type}"
        write_log_error(run_id=run_id, job_id=job_id, stage="CheckJobStatus", status="FAILED")

    event["trigger_result"] = trigger_result

    # --- Log final status using the right level ---
    final_status = trigger_result.get("job_status", "UNKNOWN")

    if final_status == "SUCCESS":
        write_log_info(run_id=run_id, job_id=job_id, stage="CheckJobStatus", status="SUCCESS")
    elif final_status == "FAILED":
        write_log_error(run_id=run_id, job_id=job_id, stage="CheckJobStatus", status="FAILED")
    elif final_status == "RUNNING":
        write_log_info(run_id=run_id, job_id=job_id, stage="CheckJobStatus", status="RUNNING")
    else:
        write_log_warn(run_id=run_id, job_id=job_id, stage="CheckJobStatus", status=final_status)

    _log("HANDLER_COMPLETE", {
        "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "run_id": run_id,
        "runner_type": runner_type,
        "job_status": trigger_result.get("job_status", "UNKNOWN"),
    })

    return event
