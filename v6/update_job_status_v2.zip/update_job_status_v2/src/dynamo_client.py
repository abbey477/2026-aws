"""
dynamo_client.py
DynamoDB resource factory for the UpdateJobStatus Lambda.

Keeping this in its own module makes it trivial to mock in unit tests.
"""

import boto3
from botocore.exceptions import ClientError  # re-exported for convenience

__all__ = ["get_dynamodb_resource", "ClientError"]


def get_dynamodb_resource():
    """Return a boto3 DynamoDB service resource."""
    return boto3.resource("dynamodb")
