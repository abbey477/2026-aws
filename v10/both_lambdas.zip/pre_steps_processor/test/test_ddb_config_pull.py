"""
ddb_config_pull — direct query helper tests + end-to-end.

Results now appear directly in the return dict under "ddb_config_pull"
(no longer merged into job_param — Step Functions handles the payload).
"""

import pytest
from botocore.exceptions import ClientError

from pre_steps_processor.dynamodb_ops import pull_config_from_table
from pre_steps_processor.handler import lambda_handler
from seed_data import make_event, raise_access_denied


class TestPullConfigFromTable:
    """Direct tests for the get_item helper."""

    def test_returns_row_when_found(self, config_tables):
        _, tables = config_tables
        service = tables["service_config"]
        service.put_item(Item={
            "job_id": "client", "job_type": "sourcing",
            "some_setting": "value_x", "other": 42,
        })

        result = pull_config_from_table(
            table=service, table_name="service_config",
            job_id="client", job_type="sourcing",
        )

        assert result is not None
        assert result["some_setting"] == "value_x"
        assert result["other"] == 42

    def test_returns_none_when_not_found(self, config_tables):
        _, tables = config_tables
        result = pull_config_from_table(
            table=tables["service_config"], table_name="service_config",
            job_id="unknown", job_type="sourcing",
        )
        assert result is None

    def test_client_error_propagates(self, monkeypatch, config_tables):
        _, tables = config_tables
        service = tables["service_config"]
        monkeypatch.setattr(service, "get_item", raise_access_denied)

        with pytest.raises(ClientError):
            pull_config_from_table(
                table=service, table_name="service_config",
                job_id="client", job_type="sourcing",
            )


class TestDdbConfigPullEndToEnd:
    """
    Full lambda_handler runs with real step_handlers + moto DynamoDB.
    Results now appear under the return dict keyed as "ddb_config_pull".
    """

    def test_pulled_rows_in_return_dict(self, config_tables, monkeypatch):
        dynamodb, tables = config_tables

        tables["service_config"].put_item(Item={
            "job_id": "client", "job_type": "sourcing",
            "feature_flag": True, "region": "us-east-1",
        })

        monkeypatch.setattr(
            "pre_steps_processor.step_handlers.get_dynamodb_resource",
            lambda: dynamodb,
        )

        event = make_event(pre_steps=[{
            "pre_step_type": "ddb_config_pull",
            "tables": ["service_config", "table_config"],
        }])

        result = lambda_handler(event, None)

        # Results live under "ddb_config_pull" in the return dict
        assert "ddb_config_pull" in result
        ddb_results = result["ddb_config_pull"]

        assert ddb_results["service_config"] == {
            "job_id": "client", "job_type": "sourcing",
            "feature_flag": True, "region": "us-east-1",
        }
        # Missing row → None
        assert ddb_results["table_config"] is None

        # No event fields in the return — Step Functions handles those
        assert "run_id" not in result
        assert "job_config" not in result

    def test_empty_tables_list_returns_empty(self, config_tables, monkeypatch):
        dynamodb, _ = config_tables
        monkeypatch.setattr(
            "pre_steps_processor.step_handlers.get_dynamodb_resource",
            lambda: dynamodb,
        )

        event = make_event(pre_steps=[{
            "pre_step_type": "ddb_config_pull",
            "tables": [],
        }])

        result = lambda_handler(event, None)
        # Empty handler result → key not present
        assert "ddb_config_pull" not in result

    def test_missing_tables_key_returns_empty(self, config_tables, monkeypatch):
        dynamodb, _ = config_tables
        monkeypatch.setattr(
            "pre_steps_processor.step_handlers.get_dynamodb_resource",
            lambda: dynamodb,
        )

        event = make_event(pre_steps=[{"pre_step_type": "ddb_config_pull"}])
        result = lambda_handler(event, None)
        assert "ddb_config_pull" not in result
