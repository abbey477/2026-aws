package com.example.batch.core;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Marker annotation for service classes that should be advised by
 * {@link com.example.batch.common.aspect.ServiceErrorAspect}.
 *
 * <p>Place this on any class whose method-level exceptions should be
 * logged/audited automatically. The aspect uses {@code @within(BusinessService)}
 * to find these classes.
 *
 * <p>Example:
 * <pre>
 * &#64;Service
 * &#64;BusinessService
 * public class CustomerService { ... }
 * </pre>
 *
 * <p>{@code @Retention(RUNTIME)} is REQUIRED — without it, the aspect can't see
 * the annotation at runtime.
 */
@Target(ElementType.TYPE)              // applied to classes/interfaces
@Retention(RetentionPolicy.RUNTIME)    // must be visible to Spring AOP at runtime
public @interface BusinessService {
}
