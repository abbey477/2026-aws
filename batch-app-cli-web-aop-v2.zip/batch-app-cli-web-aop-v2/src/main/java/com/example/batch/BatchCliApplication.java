package com.example.batch;

import com.example.batch.core.JobContext;
import com.example.batch.core.JobDispatcher;
import com.example.batch.core.JobResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import java.time.LocalDate;

/**
 * CLI entry point for Autosys. Runs one job and exits with a status code.
 *
 * Usage: --job=jobA [--runDate=YYYY-MM-DD]
 */
@SpringBootApplication
public class BatchCliApplication {

    private static final Logger log = LoggerFactory.getLogger(BatchCliApplication.class);

    public static void main(String[] args) {
        JobContext ctx;
        try {
            ctx = parseArgs(args);
        } catch (IllegalArgumentException e) {
            System.err.println("ERROR: " + e.getMessage());
            System.err.println("Usage: --job=<jobName> [--runDate=YYYY-MM-DD]");
            System.exit(2);
            return;
        }

        SpringApplication app = new SpringApplication(BatchCliApplication.class);
        app.setWebApplicationType(WebApplicationType.NONE);

        int exitCode;
        try (ConfigurableApplicationContext context = app.run(args)) {
            JobResult result = context.getBean(JobDispatcher.class).dispatch(ctx);
            log.info("Job '{}' finished with exitCode={} ({})",
                    ctx.getJobName(), result.getExitCode(), result.getMessage());
            exitCode = result.getExitCode();
        }

        System.exit(exitCode);
    }

    private static JobContext parseArgs(String[] args) {
        String jobName = null;
        String runDate = LocalDate.now().toString();
        for (String arg : args) {
            if (arg.startsWith("--job=")) jobName = arg.substring(6);
            else if (arg.startsWith("--runDate=")) runDate = arg.substring(10);
        }
        if (jobName == null) throw new IllegalArgumentException("Missing --job=<name>");
        return new JobContext(jobName, runDate);
    }
}
