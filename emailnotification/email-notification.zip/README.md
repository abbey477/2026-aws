# Email Notification Service

A focused, standalone Spring Boot email notification module.
Designed to plug into any existing backend — no web layer, no queue, no database required.

---

## Features

- Plain HTML templates with `{{placeholder}}` variable injection (no Thymeleaf)
- Per-environment SMTP configuration (`dev` / `uat` / `prod`)
- Idempotency guard — prevents the same email being sent multiple times within a TTL window
- Immutable record-based DTOs throughout
- Full unit test coverage

---

## Project Structure

```
src/main/java/com/example/notification/
│
├── config/
│   ├── MailConfig.java                  Bean wiring: JavaMailSender + Caffeine cache
│   └── MailProperties.java              Record bound to app.mail.* in yml
│
├── model/
│   ├── request/EmailRequest.java        Inbound DTO — what the caller passes in
│   ├── response/EmailResponse.java      Outbound DTO — what the caller gets back
│   ├── dto/EmailInfo.java               Internal DTO — resolved content between layers
│   └── enums/
│       ├── EmailType.java               WELCOME | PASSWORD_RESET | ORDER_CONFIRM
│       ├── EmailPriority.java           HIGH | NORMAL | LOW
│       └── EmailStatus.java             SENT | FAILED | PENDING | SKIPPED
│
├── template/
│   ├── EmailTemplate.java               Maps EmailType → template file + default subject
│   └── TemplateService.java             Loads HTML file, injects {{variables}}
│
├── service/
│   ├── EmailNotificationService.java    Orchestrates: template → compose → send
│   ├── MailComposerService.java         Builds MimeMessage from EmailInfo
│   └── MailSenderService.java           Hands MimeMessage to JavaMailSender
│
├── cache/
│   ├── EmailCacheKey.java               Record: to + emailType + variablesHash
│   └── EmailCacheService.java           Check / mark / evict cache entries
│
├── idempotency/
│   └── EmailIdempotencyGuard.java       Entry point — deduplication gatekeeper
│
└── exception/
    ├── EmailSendException.java          Thrown on SMTP or composition failure
    └── TemplateNotFoundException.java   Thrown when template file is missing

src/main/resources/
├── application.yml                      Shared config (TTL, from-name, support-email)
├── application-dev.yml                  Dev SMTP (Mailtrap sandbox)
├── application-uat.yml                  UAT SMTP
├── application-prod.yml                 Prod SMTP (AWS SES)
└── templates/
    ├── welcome.html
    ├── password-reset.html
    └── order-confirm.html
```

---

## How It Works

```
Your existing service
        │
        │  EmailRequest.welcome("user@example.com", "John", ...)
        ↓
EmailIdempotencyGuard.sendOnce()
        │
        ├── build EmailCacheKey (to + emailType + variablesHash)
        ├── HIT  → return EmailResponse(SKIPPED) — no send
        └── MISS → continue
                │
                ↓
        EmailNotificationService.send()
                │
                ├── EmailTemplate     → resolves template file + default subject
                ├── TemplateService   → loads HTML, injects {{variables}}
                ├── EmailInfo         → internal resolved DTO
                ├── MailComposerService → builds MimeMessage
                └── MailSenderService  → sends via JavaMailSender → SMTP
                        │
                        └── on success: cache key marked → future duplicates skipped
                        │
                        └── return EmailResponse(SENT | FAILED)
```

---

## Setup

### 1. Prerequisites

- Java 21
- Maven 3.8+
- A Mailtrap account for dev/uat (free): https://mailtrap.io
- AWS SES or SendGrid for prod

### 2. Environment Variables

Set these before running. Never hardcode credentials in yml.

**Dev**
```bash
export MAIL_DEV_USER=your_mailtrap_user
export MAIL_DEV_PASS=your_mailtrap_pass
```

**UAT**
```bash
export MAIL_UAT_USER=your_uat_user
export MAIL_UAT_PASS=your_uat_pass
```

**Prod**
```bash
export MAIL_PROD_USER=your_ses_access_key
export MAIL_PROD_PASS=your_ses_secret_key
```

### 3. Build

```bash
mvn clean install
```

---

## Running by Environment

**Dev** (default)
```bash
mvn spring-boot:run
```

**UAT**
```bash
mvn spring-boot:run -Dspring.profiles.active=uat
```

**Prod**
```bash
SPRING_PROFILES_ACTIVE=prod java -jar target/email-notification-1.0.0-SNAPSHOT.jar
```

---

## Running Tests

```bash
# all tests
mvn test

# specific test class
mvn test -Dtest=EmailIdempotencyGuardTest

# skip tests
mvn install -DskipTests
```

---

## How to Call From an Existing Service

Inject `EmailIdempotencyGuard` — not `EmailNotificationService` directly.
The guard handles deduplication transparently.

```java
@Service
@RequiredArgsConstructor
public class UserService {

    private final EmailIdempotencyGuard emailGuard;

    public void onUserRegistered(User user) {
        EmailResponse response = emailGuard.sendOnce(
            EmailRequest.welcome(
                user.getEmail(),
                user.getName(),
                "https://app.example.com/dashboard",
                "support@example.com"
            )
        );

        if (response.isSkipped()) {
            log.info("Welcome email already sent to {}", user.getEmail());
        }
    }

    public void onPasswordResetRequested(User user, String resetLink) {
        emailGuard.sendOnce(
            EmailRequest.passwordReset(
                user.getEmail(),
                user.getName(),
                resetLink,
                30,                         // expiry in minutes
                "support@example.com"
            )
        );
    }
}
```

---

## Idempotency / Deduplication

The guard prevents sending the same email more than once within the cache TTL window.

Two requests are considered duplicates if they share:
- Same `to` address
- Same `EmailType`
- Same variable content (hash of the variables map)

**TTL per environment** (configured in yml):

| Environment | Cache TTL |
|---|---|
| dev | 5 minutes |
| uat | 30 minutes |
| prod | 60 minutes |

On a cache hit the guard returns `EmailResponse(SKIPPED)` immediately without touching SMTP.
On failure the key is **not** cached — the next call will retry.

---

## Adding a New Email Type

1. Add entry to `EmailType` enum
2. Add entry to `EmailTemplate` enum (maps type → file + subject)
3. Create the HTML template in `src/main/resources/templates/`
4. Add a factory method to `EmailRequest` (optional but recommended)

---

## Switching to Redis (Multi-node Deployments)

Caffeine is in-memory and per-node. For distributed deployments:

1. Uncomment the Redis dependency in `pom.xml`
2. Replace the `Cache<String, Boolean>` bean in `MailConfig` with a `RedisTemplate`-backed implementation
3. Update `EmailCacheService` to use the Redis bean

`EmailIdempotencyGuard` and all callers are unaffected — they depend on `EmailCacheService`, not the cache implementation.

---

## Key Design Decisions

| Decision | Reason |
|---|---|
| Records for all DTOs | Immutable, no boilerplate, no accidental mutation |
| Guard separate from service | Service stays pure and independently testable |
| Plain `{{placeholder}}` templates | No Thymeleaf dependency — this is not a web app |
| Cache only on SENT | Failed sends remain retryable |
| Factory methods on EmailRequest | Callers don't construct raw maps — type-safe and readable |
| Profile-driven yml | Dev/UAT/prod credentials never mixed, CI/CD friendly |
