# =============================================================================
# Load seed data into DynamoDB tables
# Usage:
#   .\load_all.ps1             # load data
#   .\load_all.ps1 -DryRun     # preview commands without running
# =============================================================================

param(
    [switch]$DryRun
)

if ($DryRun) {
    Write-Host "=== DRY RUN - no data will be loaded ===" -ForegroundColor Yellow
    Write-Host ""
}

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$Files = @("app-jobConfig.json", "app-jobRun.json", "app-jobLog.json")

foreach ($File in $Files) {
    $FilePath = Join-Path $ScriptDir $File
    if (-not (Test-Path $FilePath)) {
        Write-Host "ERROR: File not found: $FilePath" -ForegroundColor Red
        exit 1
    }

    Write-Host "Loading: $File"
    if ($DryRun) {
        Write-Host "  aws dynamodb batch-write-item --request-items file://$FilePath"
    } else {
        aws dynamodb batch-write-item --request-items "file://$FilePath"
        if ($LASTEXITCODE -ne 0) {
            Write-Host "ERROR: Failed to load $File" -ForegroundColor Red
            exit 1
        }
        Write-Host "  Done." -ForegroundColor Green
    }
}

Write-Host ""
Write-Host "=== Load complete ===" -ForegroundColor Green
Write-Host ""
Write-Host "Verify with:"
Write-Host "  aws dynamodb scan --table-name app-jobConfig --select COUNT"
Write-Host "  aws dynamodb scan --table-name app-jobRun    --select COUNT"
Write-Host "  aws dynamodb scan --table-name app-jobLog    --select COUNT"
Write-Host "Expected: 1, 18, 20"
