package com.example.batch.common.service;

import com.example.batch.common.exception.BusinessException;
import com.example.batch.core.BusinessService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * Pretend processing service.
 *
 * @BusinessService → ServiceErrorAspect will catch any exception thrown here.
 * Throws BusinessException when runDate is "FAIL" so we can demo the failure path.
 */
@Service
@BusinessService
public class SimulatedProcessingService {

    private static final Logger log = LoggerFactory.getLogger(SimulatedProcessingService.class);

    public void process(String jobName, String runDate) {
        log.info("  [Service] processing job={}, date={}", jobName, runDate);

        if ("FAIL".equals(runDate)) {
            throw new BusinessException("Simulated failure in " + jobName, 3);
        }

        log.info("  [Service] done");
    }
}
