package com.myapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * Verifies the Spring application context starts successfully.
 *
 * <p>Because all datasource beans are lazy, the context loads without any
 * MySQL/PostgreSQL server being reachable — a connection is only attempted
 * when a datasource is actually used.
 */
@SpringBootTest
class MultiDatasourceApplicationTests {

    @Test
    void contextLoads() {
        // Intentionally empty: success means the context started and the
        // ApplicationProperties record bound without error.
    }
}
