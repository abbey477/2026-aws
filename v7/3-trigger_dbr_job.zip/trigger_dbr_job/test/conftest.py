"""
conftest.py
Shared pytest fixtures for TriggerDbrJob tests.

Fixtures:
  mock_write_log          — auto-use; prevents DynamoDB writes in all tests
  make_event              — factory returning a complete sample Lambda event
  mock_urlopen_success    — factory returning a successful urllib mock response
"""

import json
import pytest
from unittest.mock import MagicMock, patch


# ---------------------------------------------------------------------------
# Auto-mock write_log — no real DynamoDB in any test
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def mock_write_log():
    """Prevent write_log from hitting real DynamoDB in all tests."""
    with patch("trigger_dbr_job.handler.write_log"):
        yield


# ---------------------------------------------------------------------------
# Event factory
# ---------------------------------------------------------------------------

@pytest.fixture
def make_event():
    """
    Factory: returns a complete sample merged payload from GetConfig
    for a Databricks job. Pass keyword overrides to customise per test.
    """
    def _factory(**overrides):
        base = {
            "run_id": "run-002",
            "job_id": "dbr-client",
            "job_type": "silver_load",
            "status": "WAITING",
            "job_config": {
                "job_runner": {
                    "type": "Databricks",
                    "name": "DBR",
                    "config": {
                        "job_id": "12345",
                        "host": "my-databricks-instance.cloud.databricks.com",
                        "token": "dapi-mock-token-12345",
                    },
                },
                "job_param": {
                    "entity_id": "client",
                    "job_type": "silver_load",
                    "output": ["record_count"],
                },
                "next_jobs": [],
            },
        }
        base.update(overrides)
        return base

    return _factory


# ---------------------------------------------------------------------------
# urllib mock helpers
# ---------------------------------------------------------------------------

@pytest.fixture
def mock_urlopen_success():
    """
    Factory: returns a mock context manager for urllib.request.urlopen
    that simulates a successful Databricks API response with the given run_id.
    """
    def _factory(run_id: str = "67890"):
        mock_resp = MagicMock()
        mock_resp.read.return_value = json.dumps({"run_id": run_id}).encode("utf-8")
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        return mock_resp

    return _factory
