package com.example.dbtester.service;

import com.example.dbtester.dto.ProductRequest;
import com.example.dbtester.entity.Product;
import com.example.dbtester.exception.ResourceNotFoundException;
import com.example.dbtester.repository.oracle.ProductRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Product CRUD orchestration. Owns Oracle transaction boundaries and
 * translates "no rows" into a 404.
 */
@Service
public class OracleProductService {

    private final ProductRepository repository;

    public OracleProductService(ProductRepository repository) {
        this.repository = repository;
    }

    // ---- Single row ----

    @Transactional(transactionManager = "oracleTxManager", readOnly = true)
    public List<Product> findAll() {
        return repository.findAll();
    }

    @Transactional(transactionManager = "oracleTxManager", readOnly = true)
    public Product findById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found: " + id));
    }

    @Transactional(transactionManager = "oracleTxManager")
    public Product create(ProductRequest request) {
        Product toCreate = new Product(null, request.sku(), request.name(), request.price(), request.inStock());
        return repository.insert(toCreate);
    }

    @Transactional(transactionManager = "oracleTxManager")
    public Product update(Long id, ProductRequest request) {
        Product existing = findById(id);
        Product updated = new Product(existing.id(), request.sku(), request.name(), request.price(), request.inStock());
        if (repository.update(id, updated) == 0) {
            throw new ResourceNotFoundException("Product not found: " + id);
        }
        return updated;
    }

    @Transactional(transactionManager = "oracleTxManager")
    public void delete(Long id) {
        if (repository.delete(id) == 0) {
            throw new ResourceNotFoundException("Product not found: " + id);
        }
    }

    // ---- Bulk ----

    @Transactional(transactionManager = "oracleTxManager")
    public List<Long> createAll(List<ProductRequest> requests) {
        List<Product> toInsert = requests.stream()
                .map(r -> new Product(null, r.sku(), r.name(), r.price(), r.inStock()))
                .toList();
        return repository.insertAll(toInsert);
    }

    @Transactional(transactionManager = "oracleTxManager")
    public int updateAll(List<Product> products) {
        return repository.updateAll(products);
    }

    @Transactional(transactionManager = "oracleTxManager")
    public int deleteAll(List<Long> ids) {
        return repository.deleteAll(ids);
    }
}
