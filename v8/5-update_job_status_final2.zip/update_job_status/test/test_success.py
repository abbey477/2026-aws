"""
test_success.py
Tests for the SUCCESS status path of the UpdateJobStatus Lambda.
"""

from test.conftest import make_event
from update_job_status.handler import lambda_handler


class TestUpdateSuccess:
    """Tests for SUCCESS outcome."""

    def test_success_updates_status(self, dynamodb_setup, monkeypatch):
        """SUCCESS marks job_run as SUCCESS and populates all time attributes."""
        dynamodb, table = dynamodb_setup
        monkeypatch.setattr(
            "update_job_status.handler.get_dynamodb_resource",
            lambda: dynamodb,
        )

        event = make_event(
            job_status="SUCCESS",
            job_output={"s3_path": "s3://bucket/output"},
        )
        result = lambda_handler(event, None)

        assert result["update_result"]["effective_status"] == "SUCCESS"

        item = table.get_item(Key={"run_id": "run-001"})["Item"]
        assert item["status"] == "SUCCESS"
        assert item["end_time"] != ""
        assert item["last_heartbeat_time"] != ""

    def test_success_returns_updated_attributes(self, dynamodb_setup, monkeypatch):
        """SUCCESS result payload contains 'updated_attributes' key."""
        dynamodb, _ = dynamodb_setup
        monkeypatch.setattr(
            "update_job_status.handler.get_dynamodb_resource",
            lambda: dynamodb,
        )

        event = make_event(job_status="SUCCESS")
        result = lambda_handler(event, None)

        assert "updated_attributes" in result["update_result"]

    def test_success_end_time_is_iso_format(self, dynamodb_setup, monkeypatch):
        """end_time written on SUCCESS is a valid ISO 8601 string."""
        from datetime import datetime

        dynamodb, table = dynamodb_setup
        monkeypatch.setattr(
            "update_job_status.handler.get_dynamodb_resource",
            lambda: dynamodb,
        )

        event = make_event(job_status="SUCCESS")
        lambda_handler(event, None)

        item = table.get_item(Key={"run_id": "run-001"})["Item"]
        # Should not raise
        datetime.strptime(item["end_time"], "%Y-%m-%dT%H:%M:%SZ")
