import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Row mappers for {@link CodeValue}.
 *
 * <p>Two static methods so the migration class can A/B them on identical data:
 * <ul>
 *   <li>{@link #mapByIndex(ResultSet)} — positional reads, fastest, fragile
 *       to SELECT column reordering.</li>
 *   <li>{@link #mapByName(ResultSet)} — name-based reads, robust to column
 *       reordering, slight per-cell overhead.</li>
 * </ul>
 *
 * <p>Type-handling notes (consistent across all migrations):
 * <ul>
 *   <li>{@code Integer} fields use {@code (Integer) rs.getObject(...)} — null-safe;
 *       jconn4 doesn't support the two-arg {@code getObject(idx, Class)} overload.</li>
 *   <li>{@code Date} field uses {@code rs.getTimestamp(...)} assuming
 *       {@code java.util.Date}. If it's {@code java.sql.Date}, swap to
 *       {@code rs.getDate}.</li>
 * </ul>
 */
public final class CodeValueRowMapper {

    private CodeValueRowMapper() {
        // utility class
    }

    /** Positional read — column index MUST match SELECT order. */
    public static CodeValue mapByIndex(ResultSet rs) throws SQLException {
        CodeValue row = new CodeValue();
        row.setID_CODE(                  rs.getString(1));
        row.setTX_CODE(                  rs.getString(2));
        row.setID_TYP_CODE(              rs.getString(3));
        row.setID_TYP_CODE_GBL(          rs.getString(4));
        row.setID_CODE_MAX(              rs.getString(5));
        row.setID_CODE_VAL(    (Integer) rs.getObject(6));
        row.setDT_CHG_GRD(               rs.getTimestamp(7));
        row.setID_DEL_GRD(               rs.getString(8));
        row.setID_OWN_GRD(     (Integer) rs.getObject(9));
        return row;
    }

    /** Name-based read — robust to SELECT column reordering. */
    public static CodeValue mapByName(ResultSet rs) throws SQLException {
        CodeValue row = new CodeValue();
        row.setID_CODE(                  rs.getString("ID_CODE"));
        row.setTX_CODE(                  rs.getString("TX_CODE"));
        row.setID_TYP_CODE(              rs.getString("ID_TYP_CODE"));
        row.setID_TYP_CODE_GBL(          rs.getString("ID_TYP_CODE_GBL"));
        row.setID_CODE_MAX(              rs.getString("ID_CODE_MAX"));
        row.setID_CODE_VAL(    (Integer) rs.getObject("ID_CODE_VAL"));
        row.setDT_CHG_GRD(               rs.getTimestamp("DT_CHG_GRD"));
        row.setID_DEL_GRD(               rs.getString("ID_DEL_GRD"));
        row.setID_OWN_GRD(     (Integer) rs.getObject("ID_OWN_GRD"));
        return row;
    }
}
