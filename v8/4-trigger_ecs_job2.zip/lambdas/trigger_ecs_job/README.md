# trigger_ecs_job

Lambda function that triggers an ECS Fargate task via the `RunTask` API.

It is called by the Step Functions state machine when a job's runner
type is `ECS_Fargate`. It takes the merged payload from `GetConfig`,
launches a Fargate task with the right config and parameters, and
returns the task ARN (or an error) to the state machine.

---

## 🚀 Quick start (for beginners)

If you just want to get the tests running — no special tools required.
You only need **Python 3.12+**.

```bash
# 1. Unzip and enter the project
cd lambdas/trigger_ecs_job

# 2. Install everything into a local virtual environment
make install-pip

# 3. Run the tests
make test
```

That's it. You should see `26 passed`.

**What just happened:**
- `make install-pip` created a folder called `.venv/` next to the code.
  This is a "virtual environment" — an isolated copy of Python where
  project dependencies live, so they don't pollute your system Python.
- Inside `.venv/` it installed the packages listed in `requirements-dev.txt`
  (`boto3`, `botocore`, `pytest`).
- `make test` ran the test suite using the `pytest` installed inside `.venv/`.

**If `make install-pip` fails** with `python3-venv missing`, install it first:

```bash
sudo apt install python3 python3-venv    # Ubuntu / Debian
brew install python@3.12                 # macOS
```

---

## Project layout

```
trigger_ecs_job/
├── Makefile                # make install / make test / make clean
├── README.md               # this file
├── pytest.ini              # test runner config (works without Poetry)
├── pyproject.toml          # Poetry config + package metadata
├── poetry.toml             # tells Poetry to create .venv inside project
├── requirements.txt        # runtime deps (boto3)
├── requirements-dev.txt    # runtime + test deps (pytest, botocore)
│
├── src/
│   └── trigger_ecs_job/
│       ├── __init__.py
│       ├── handler.py          # lambda_handler() entry point
│       ├── ecs_trigger.py      # trigger_ecs_task() core RunTask logic
│       ├── logger.py           # shared structured logger
│       └── log_to_dynamo.py    # DynamoDB audit log writer
│
└── test/
    ├── __init__.py
    ├── conftest.py                # shared fixtures, ECS client mocks, event factory
    ├── test_happy_path.py         # TestHappyPath         — 5 tests
    ├── test_failure_modes.py      # TestFailureModes      — 5 tests
    ├── test_configuration.py      # TestConfiguration     — 5 tests
    ├── test_payload_size.py       # TestPayloadSizeLogging — 3 tests
    └── test_lambda_handler.py     # TestLambdaHandler     — 8 tests
                                                            ──────────
                                                            26 tests
```

---

## Setup options

There are **three ways** to install the project. Pick whichever suits you.

### Option 1: Plain pip + venv ⭐ (simplest, recommended for beginners)

**Use this if:** you're new to Python projects, or you just want tests to run.

```bash
make install-pip
make test
```

**How it works:**
1. Creates `.venv/` using `python3 -m venv .venv`
2. Runs `.venv/bin/pip install -r requirements-dev.txt`
3. `make test` runs `.venv/bin/pytest`

Everything lives inside the project folder. To remove it, run `make clean`.

**To run anything inside the venv manually** (e.g. a Python shell with the
deps loaded), activate it:

```bash
source .venv/bin/activate
pytest                    # now pytest is on your PATH
python                    # Python with boto3 / pytest available
deactivate                # exit the venv
```

### Option 2: Poetry (recommended for active development)

**Use this if:** you want dependency locking, cleaner dev workflows, or
you're working across multiple projects.

**First install Poetry** (one-time, if you don't have it):

```bash
make install-poetry
export PATH="$HOME/.local/bin:$PATH"
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc   # make it permanent
```

Or the official way: https://python-poetry.org/docs/#installation

**Then install the project:**

```bash
make install    # auto-detects Poetry and runs `poetry install`
make test       # runs `poetry run pytest`
```

Poetry also creates `.venv/` inside the project folder (configured via
`poetry.toml`). You can still activate it the same way:

```bash
source .venv/bin/activate
```

### Option 3: Direct pip (system-wide, not recommended)

If you know what you're doing and want to install without a venv:

```bash
pip install -r requirements-dev.txt
pytest
```

On modern Debian/Ubuntu this will fail with PEP 668 — use Option 1 instead.

---

## Running tests

After any of the install options above:

```bash
make test                           # full suite
make test ARGS="test/test_happy_path.py"   # single file (with Poetry/venv)
```

Or run `pytest` directly. Useful flags:

```bash
pytest                              # full suite
pytest test/test_happy_path.py      # single file
pytest -k "empty_event"             # filter by test name
pytest --tb=long                    # longer tracebacks
pytest -x                           # stop on first failure
```

Pytest config lives in `pytest.ini`. The suite runs with live log streaming
at INFO level, so you'll see the structured log lines
(`[TriggerEcsJob] [STEP] key=value, ...`) as tests execute. This is what
the logger emits in production, so tests double as documentation of the
log format.

---

## Other make targets

```bash
make check        # show what tooling was detected (python3, poetry, venv)
make help         # list all targets with descriptions
make lint         # run ruff (install it first: pip install ruff)
make clean        # remove .venv/, __pycache__/, .pytest_cache/
```

---

## How the Lambda is called

### Input event shape

The handler expects the merged payload from `GetConfig`:

```json
{
  "run_id": "run-001",
  "job_id": "client",
  "job_type": "sourcing",
  "status": "WAITING",
  "job_config": {
    "job_runner": {
      "type": "ECS_Fargate",
      "name": "S2S3",
      "config": {
        "cluster": "my-ecs-cluster",
        "subnets": ["subnet-aaa111", "subnet-bbb222"],
        "security_groups": ["sg-abc123"],
        "task_definition": "default-task-def",
        "container_name": "default-container",
        "image": "optional-image-tag"
      }
    },
    "job_param": {
      "source": {"type": "API", "name": "RDI"},
      "batch_size": 1000,
      "output": ["s3_path"]
    },
    "next_jobs": []
  }
}
```

### Output

The same event with a `trigger_result` block appended:

```json
{
  "...": "all original fields preserved",
  "trigger_result": {
    "trigger_status": "TRIGGERED",
    "task_arn": "arn:aws:ecs:us-east-1:123456789012:task/my-ecs-cluster/abc123",
    "runner_name": "S2S3",
    "runner_type": "ECS"
  }
}
```

On failure, `trigger_status` is `TRIGGER_FAILED`, `task_arn` is `""`, and
an `error` field describes what went wrong.

### Invoking locally (for debugging)

Save an event to `event.json`, then:

```bash
source .venv/bin/activate         # if using pip + venv
python -c "
from trigger_ecs_job.handler import lambda_handler
import json
event = json.load(open('event.json'))
result = lambda_handler(event, None)
print(json.dumps(result, indent=2))
"
```

⚠️ This uses your real AWS credentials and hits DynamoDB + ECS. For safe
dry runs, use the test suite — it mocks everything.

### Invoking the deployed Lambda

```bash
aws lambda invoke \
  --function-name trigger_ecs_job \
  --cli-binary-format raw-in-base64-out \
  --payload file://event.json \
  response.json

cat response.json | jq .trigger_result
```

### Invoking from Step Functions

The state machine passes the full merged payload as input. A typical task
state looks like:

```json
{
  "Type": "Task",
  "Resource": "arn:aws:lambda:us-east-1:123456789012:function:trigger_ecs_job",
  "Next": "CheckJobStatus",
  "ResultPath": "$"
}
```

`ResultPath: "$"` replaces the state input with the handler's return
value, so downstream states see the original fields plus `trigger_result`.

---

## Environment variables

| Variable     | Default | Purpose                                            |
|--------------|---------|----------------------------------------------------|
| `LOGS_TABLE` | `logs`  | DynamoDB table that `log_to_dynamo.write_log` writes to |

AWS credentials are resolved from the standard chain (IAM role in Lambda,
`~/.aws/credentials` or env vars locally).

---

## Payload size limit

ECS `RunTask` caps the `overrides` block at 8 KB. `job_param` is
JSON-encoded and passed as the `JOB_PARAM` env var inside that block,
so anything over ~8000 bytes of serialized JSON will fail with
`InvalidParameterException`.

Every invocation logs the payload size **before** calling `RunTask`:

```
[TriggerEcsJob] [JOB_PARAM_SIZE] run_id=run-001, job_param_bytes=85
```

Watch CloudWatch for this metric to catch payloads approaching the limit
before they start failing.

---

## Trigger statuses

| Status           | Meaning                                                       |
|------------------|---------------------------------------------------------------|
| `TRIGGERED`      | ECS accepted the task; `task_arn` is populated                |
| `TRIGGER_FAILED` | `RunTask` returned no tasks OR raised a `ClientError`         |
| `UNKNOWN`        | Only appears if the trigger function didn't return a status   |

Failures recorded as `TRIGGER_FAILED` include placement failures (no
capacity, bad subnets), `InvalidParameterException` (payload too large),
`ClusterNotFoundException`, `AccessDeniedException`, throttling, and any
other `ClientError` boto3 raises.

---

## Troubleshooting

**`make: poetry: No such file or directory`** — Poetry isn't installed.
Either install it (`make install-poetry`) or just use `make install-pip`.

**`make: pip: No such file or directory`** — pip isn't on your PATH.
Use `make install-pip`, which uses `python3 -m venv` directly.

**`python3-venv missing`** — run `sudo apt install python3-venv`.

**`externally-managed-environment` (PEP 668)** — your system blocks
`pip install` on system Python. Use `make install-pip` to get a venv.

**Tests can't import `trigger_ecs_job`** — make sure you're running tests
via `make test` or from the project root. `pythonpath` in `pytest.ini`
adds `src/` automatically.
