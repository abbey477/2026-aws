"""
constants.py
Shared constants for the UpdateJobStatus Lambda.
"""

import os

# DynamoDB table name from environment
JOB_RUN_TABLE = os.environ.get("JOB_RUN_TABLE", "job_run")

# Job status values
class JobStatus:
    SUCCESS = "SUCCESS"
    TRIGGER_FAILED = "TRIGGER_FAILED"
    RUNNING = "RUNNING"
    FAILED = "FAILED"
    WAITING = "WAITING"
    UNKNOWN = "UNKNOWN"

# Heartbeat extension window in minutes
HEARTBEAT_EXTENSION_MINUTES = 5
