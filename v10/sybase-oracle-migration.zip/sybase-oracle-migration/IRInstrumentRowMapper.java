import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Row mappers for {@link IRInstrument}, extracted from the migration class
 * for readability — IRInstrument has 47 columns and inlining two copies of
 * the mapping logic would dominate the migration file.
 *
 * <p>Two static methods are provided so the migration class can A/B them
 * on identical data:
 * <ul>
 *   <li>{@link #mapByIndex(ResultSet)} — positional reads, fastest, fragile
 *       to SELECT column reordering.</li>
 *   <li>{@link #mapByName(ResultSet)} — name-based reads, robust to column
 *       reordering, slight per-cell overhead.</li>
 * </ul>
 *
 * <p>Type-handling notes (consistent across all migrations):
 * <ul>
 *   <li>{@code Integer}/{@code Float} fields use the cast pattern
 *       {@code (T) rs.getObject(...)} because jconn4 doesn't support the
 *       two-arg {@code getObject(idx, Class)} overload. Casting null is safe.</li>
 *   <li>{@code Date} fields use {@code rs.getTimestamp(...)} assuming
 *       {@code java.util.Date}. If any field is {@code java.sql.Date},
 *       swap that specific call to {@code rs.getDate}.</li>
 * </ul>
 */
public final class IRInstrumentRowMapper {

    private IRInstrumentRowMapper() {
        // utility class
    }

    /** Positional read — column index MUST match SELECT order. */
    public static IRInstrument mapByIndex(ResultSet rs) throws SQLException {
        IRInstrument row = new IRInstrument();
        row.setID_IMNT(             (Integer) rs.getObject(1));
        row.setID_CLEAN_DIRTY(                rs.getString(2));
        row.setAM_FACT_TIME(          (Float) rs.getObject(3));
        row.setID_ACCR_TRD(                   rs.getString(4));
        row.setID_RULE_TRUNC_ACCR(            rs.getString(5));
        row.setID_ACT_PCT(                    rs.getString(6));
        row.setID_CV_DYBU(                    rs.getString(7));
        row.setID_FREQ_CPN(                   rs.getString(8));
        row.setRT_CPN(                (Float) rs.getObject(9));
        row.setID_CPN_EOM(                    rs.getString(10));
        row.setID_EOM_LEAP(                   rs.getString(11));
        row.setDT_CPN_FRT(                    rs.getTimestamp(12));
        row.setDT_CPN_LST(                    rs.getTimestamp(13));
        row.setAM_VAL_PAR(            (Float) rs.getObject(14));
        row.setPR_EXPY(               (Float) rs.getObject(15));
        row.setID_TYP_CPN(                    rs.getString(16));
        row.setDT_START_ACCR(                 rs.getTimestamp(17));
        row.setRT_TAX_CPN(            (Float) rs.getObject(18));
        row.setID_RANK_DEBT(                  rs.getString(19));
        row.setCT_EXDIV_MAX(        (Integer) rs.getObject(20));
        row.setID_RULE_EXDIV(                 rs.getString(21));
        row.setID_ODD_LAST(                   rs.getString(22));
        row.setID_ACCR_MAX(                   rs.getString(23));
        row.setCT_RECORD(           (Integer) rs.getObject(24));
        row.setID_RECORD_BUS_DAYS(            rs.getString(25));
        row.setDT_END_ACCR(                   rs.getTimestamp(26));
        row.setID_ADJ_ACCR(                   rs.getString(27));
        row.setID_CPN_CREEP(                  rs.getString(28));
        row.setID_ACCR_CALL(                  rs.getString(29));
        row.setID_ACCR_PUT(                   rs.getString(30));
        row.setRT_RECOVERY(           (Float) rs.getObject(31));
        row.setID_DEFAULT(                    rs.getString(32));
        row.setDT_DEFAULT(                    rs.getTimestamp(33));
        row.setID_LE_DEF(                     rs.getString(34));
        row.setID_CALC_TYP(         (Integer) rs.getObject(35));
        row.setAM_CALLABLE_DAYS(    (Integer) rs.getObject(36));
        row.setID_CONT_CALLABLE(              rs.getString(37));
        row.setAM_SETTLE_DAYS(      (Integer) rs.getObject(38));
        row.setID_SERIES(                     rs.getString(39));
        row.setNM_REF_INDEX(                  rs.getString(40));
        row.setID_TYP_COUPON(       (Integer) rs.getObject(41));
        row.setNM_GMX_OWNER(                  rs.getString(42));
        row.setID_VARS_BCHMRK(                rs.getString(43));
        row.setID_GEM_CUSTOM_CLASS(           rs.getString(44));
        row.setDT_CHG_GRD(                    rs.getTimestamp(45));
        row.setID_DEL_GRD(                    rs.getString(46));
        row.setID_OWN_GRD(          (Integer) rs.getObject(47));
        return row;
    }

    /** Name-based read — robust to SELECT column reordering. */
    public static IRInstrument mapByName(ResultSet rs) throws SQLException {
        IRInstrument row = new IRInstrument();
        row.setID_IMNT(             (Integer) rs.getObject("ID_IMNT"));
        row.setID_CLEAN_DIRTY(                rs.getString("ID_CLEAN_DIRTY"));
        row.setAM_FACT_TIME(          (Float) rs.getObject("AM_FACT_TIME"));
        row.setID_ACCR_TRD(                   rs.getString("ID_ACCR_TRD"));
        row.setID_RULE_TRUNC_ACCR(            rs.getString("ID_RULE_TRUNC_ACCR"));
        row.setID_ACT_PCT(                    rs.getString("ID_ACT_PCT"));
        row.setID_CV_DYBU(                    rs.getString("ID_CV_DYBU"));
        row.setID_FREQ_CPN(                   rs.getString("ID_FREQ_CPN"));
        row.setRT_CPN(                (Float) rs.getObject("RT_CPN"));
        row.setID_CPN_EOM(                    rs.getString("ID_CPN_EOM"));
        row.setID_EOM_LEAP(                   rs.getString("ID_EOM_LEAP"));
        row.setDT_CPN_FRT(                    rs.getTimestamp("DT_CPN_FRT"));
        row.setDT_CPN_LST(                    rs.getTimestamp("DT_CPN_LST"));
        row.setAM_VAL_PAR(            (Float) rs.getObject("AM_VAL_PAR"));
        row.setPR_EXPY(               (Float) rs.getObject("PR_EXPY"));
        row.setID_TYP_CPN(                    rs.getString("ID_TYP_CPN"));
        row.setDT_START_ACCR(                 rs.getTimestamp("DT_START_ACCR"));
        row.setRT_TAX_CPN(            (Float) rs.getObject("RT_TAX_CPN"));
        row.setID_RANK_DEBT(                  rs.getString("ID_RANK_DEBT"));
        row.setCT_EXDIV_MAX(        (Integer) rs.getObject("CT_EXDIV_MAX"));
        row.setID_RULE_EXDIV(                 rs.getString("ID_RULE_EXDIV"));
        row.setID_ODD_LAST(                   rs.getString("ID_ODD_LAST"));
        row.setID_ACCR_MAX(                   rs.getString("ID_ACCR_MAX"));
        row.setCT_RECORD(           (Integer) rs.getObject("CT_RECORD"));
        row.setID_RECORD_BUS_DAYS(            rs.getString("ID_RECORD_BUS_DAYS"));
        row.setDT_END_ACCR(                   rs.getTimestamp("DT_END_ACCR"));
        row.setID_ADJ_ACCR(                   rs.getString("ID_ADJ_ACCR"));
        row.setID_CPN_CREEP(                  rs.getString("ID_CPN_CREEP"));
        row.setID_ACCR_CALL(                  rs.getString("ID_ACCR_CALL"));
        row.setID_ACCR_PUT(                   rs.getString("ID_ACCR_PUT"));
        row.setRT_RECOVERY(           (Float) rs.getObject("RT_RECOVERY"));
        row.setID_DEFAULT(                    rs.getString("ID_DEFAULT"));
        row.setDT_DEFAULT(                    rs.getTimestamp("DT_DEFAULT"));
        row.setID_LE_DEF(                     rs.getString("ID_LE_DEF"));
        row.setID_CALC_TYP(         (Integer) rs.getObject("ID_CALC_TYP"));
        row.setAM_CALLABLE_DAYS(    (Integer) rs.getObject("AM_CALLABLE_DAYS"));
        row.setID_CONT_CALLABLE(              rs.getString("ID_CONT_CALLABLE"));
        row.setAM_SETTLE_DAYS(      (Integer) rs.getObject("AM_SETTLE_DAYS"));
        row.setID_SERIES(                     rs.getString("ID_SERIES"));
        row.setNM_REF_INDEX(                  rs.getString("NM_REF_INDEX"));
        row.setID_TYP_COUPON(       (Integer) rs.getObject("ID_TYP_COUPON"));
        row.setNM_GMX_OWNER(                  rs.getString("NM_GMX_OWNER"));
        row.setID_VARS_BCHMRK(                rs.getString("ID_VARS_BCHMRK"));
        row.setID_GEM_CUSTOM_CLASS(           rs.getString("ID_GEM_CUSTOM_CLASS"));
        row.setDT_CHG_GRD(                    rs.getTimestamp("DT_CHG_GRD"));
        row.setID_DEL_GRD(                    rs.getString("ID_DEL_GRD"));
        row.setID_OWN_GRD(          (Integer) rs.getObject("ID_OWN_GRD"));
        return row;
    }
}
