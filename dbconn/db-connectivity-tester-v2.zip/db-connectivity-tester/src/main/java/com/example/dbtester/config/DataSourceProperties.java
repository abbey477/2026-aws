package com.example.dbtester.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.List;
import java.util.Map;

/**
 * Strongly-typed binding of all datasource configuration, rooted at the
 * {@code app} prefix in {@code application.properties}.
 *
 * <p>The hierarchy demonstrates three things:
 * <ul>
 *   <li>{@code Map<String, DbConfig>} — keyed by a logical datasource name
 *       ("oracle", "sybase"), so adding a third DB later is just a matter
 *       of adding config + wiring, with no record changes.</li>
 *   <li>Nested records ({@code DbConfig} → {@code HikariConfig}) — groups
 *       related settings without flat-namespace collisions.</li>
 *   <li>{@code List<String>} / {@code Map<String, String>} — for arbitrary
 *       validation queries and pass-through driver properties.</li>
 * </ul>
 *
 * <p>Property layout:
 * <pre>
 *   app.datasources.{name}.url
 *   app.datasources.{name}.username
 *   app.datasources.{name}.password
 *   app.datasources.{name}.driver-class-name
 *   app.datasources.{name}.hikari.maximum-pool-size          (and other hikari.* keys)
 *   app.datasources.{name}.properties.{driverKey}={value}    (Map entries)
 *   app.datasources.{name}.validation-queries[0]=SELECT 1    (List entries)
 * </pre>
 *
 * <p>Registered for binding via
 * {@code @EnableConfigurationProperties(DataSourceProperties.class)} on the
 * application class — no need to annotate the record with {@code @Component}.
 */
@ConfigurationProperties(prefix = "app")
public record DataSourceProperties(
        /** Keyed by logical datasource name: "oracle", "sybase", etc. */
        Map<String, DbConfig> datasources
) {

    /**
     * Per-datasource settings.
     *
     * @param url              JDBC URL, including protocol-specific format
     *                         ({@code jdbc:oracle:thin:@...},
     *                         {@code jdbc:sybase:Tds:...})
     * @param username         DB user
     * @param password         DB password
     * @param driverClassName  Fully-qualified driver class, used for explicit
     *                         Class.forName-style loading. Required when the
     *                         driver jar isn't auto-registered.
     * @param hikari           Pool settings (nullable — sensible Hikari
     *                         defaults apply if omitted)
     * @param properties       Pass-through JDBC driver properties. Keys are
     *                         driver-specific (e.g. {@code oracle.net.CONNECT_TIMEOUT},
     *                         {@code DYNAMIC_PREPARE} for jConnect).
     * @param validationQueries Queries the pool runs to test a connection.
     *                         First entry is used as Hikari's connection-test
     *                         query.
     */
    public record DbConfig(
            String url,
            String username,
            String password,
            String driverClassName,
            HikariConfig hikari,
            Map<String, String> properties,
            List<String> validationQueries
    ) {}

    /**
     * HikariCP pool settings. All fields optional — if null/zero, Hikari's
     * defaults apply (10 max pool size, 30s connection timeout, etc).
     *
     * @param maximumPoolSize     Max total connections (idle + in-use)
     * @param minimumIdle         Min idle connections kept warm. Keep equal
     *                            to max for a fixed-size pool (recommended
     *                            for stable workloads).
     * @param connectionTimeoutMs How long getConnection() waits before giving up
     * @param idleTimeoutMs       How long an idle connection sits before Hikari closes it
     * @param maxLifetimeMs       Hard upper bound on a connection's age, to
     *                            sidestep DB-side idle-connection killers.
     *                            Should be slightly less than your DB's
     *                            idle timeout.
     * @param poolName            Appears in thread names and metrics — set
     *                            it so oracle-pool and sybase-pool are
     *                            distinguishable in stack traces.
     */
    public record HikariConfig(
            int maximumPoolSize,
            int minimumIdle,
            long connectionTimeoutMs,
            long idleTimeoutMs,
            long maxLifetimeMs,
            String poolName
    ) {}
}
