"""Input validation + malformed-row handling."""
import pytest
from get_config.handler import lambda_handler
from seed_data import make_job_run_item


class TestHandlerValidation:

    @pytest.mark.parametrize("bad_event", [{}, {"run_id": ""}, {"run_id": None}])
    def test_invalid_run_id(self, patched_handler, mock_write_log, bad_event):
        with pytest.raises(ValueError, match="Missing required input"):
            lambda_handler(bad_event, None)
        mock_write_log.assert_called_once_with(
            run_id="<missing>", job_id="<unknown>", stage="GetConfig", status="FAILED",
        )

    def test_run_id_not_found(self, patched_handler, mock_write_log):
        with pytest.raises(ValueError, match="No job_run found"):
            lambda_handler({"run_id": "nonexistent"}, None)
        mock_write_log.assert_called_once_with(
            run_id="nonexistent", job_id="<unknown>", stage="GetConfig", status="FAILED",
        )

    def test_job_config_not_found(self, patched_handler, mock_write_log):
        patched_handler.Table("app-jobRun").put_item(Item=make_job_run_item(
            run_id="run-orphan", job_type="nonexistent_type",
        ))
        with pytest.raises(ValueError, match="No job_config found"):
            lambda_handler({"run_id": "run-orphan"}, None)
        mock_write_log.assert_called_once_with(
            run_id="run-orphan", job_id="client", stage="GetConfig", status="FAILED",
        )

    def test_missing_job_id(self, patched_handler, mock_write_log):
        patched_handler.Table("app-jobRun").put_item(Item={
            "run_id": "run-bad", "last_updated_time": "2024-01-01T00:00:00Z",
            "job_type": "sourcing", "status": "WAITING",
        })
        with pytest.raises(ValueError, match="missing 'job_id' or 'job_type'"):
            lambda_handler({"run_id": "run-bad"}, None)

    def test_missing_job_type(self, patched_handler, mock_write_log):
        patched_handler.Table("app-jobRun").put_item(Item={
            "run_id": "run-bad-2", "last_updated_time": "2024-01-01T00:00:00Z",
            "job_id": "client", "status": "WAITING",
        })
        with pytest.raises(ValueError, match="missing 'job_id' or 'job_type'"):
            lambda_handler({"run_id": "run-bad-2"}, None)
