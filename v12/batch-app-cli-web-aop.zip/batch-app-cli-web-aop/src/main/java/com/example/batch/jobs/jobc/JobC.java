package com.example.batch.jobs.jobc;

import com.example.batch.common.service.SimulatedProcessingService;
import com.example.batch.core.BatchJob;
import com.example.batch.core.JobContext;
import com.example.batch.core.JobResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class JobC implements BatchJob {

    private static final Logger log = LoggerFactory.getLogger(JobC.class);

    private final SimulatedProcessingService service;

    public JobC(SimulatedProcessingService service) {
        this.service = service;
    }

    @Override
    public String getName() {
        return "jobC";
    }

    @Override
    public JobResult execute(JobContext context) {
        log.info(">>> JobC starting for runDate={}", context.getRunDate());
        int count = service.process("jobC", context.getRunDate());
        log.info("<<< JobC done. {} records.", count);
        return JobResult.success(count);
    }
}
