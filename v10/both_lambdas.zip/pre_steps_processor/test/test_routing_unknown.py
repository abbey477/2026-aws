"""
Routing: unknown pre_step_type handling.

Unknown types route to handle_unknown_pre_step, not a known handler.
Invalid items (no valid pre_step_type) are skipped silently.
"""

from pre_steps_processor.handler import lambda_handler
from seed_data import make_event


class TestRoutingUnknown:

    def test_unknown_type_routes_to_unknown_handler(self, mocks):
        step = {"pre_step_type": "something_new"}
        lambda_handler(make_event(pre_steps=[step]), None)

        mocks["unknown"].assert_called_once_with(step)
        mocks["change_since"].assert_not_called()
        mocks["ddb_pull"].assert_not_called()
        mocks["no_data"].assert_not_called()

    def test_mixed_known_and_unknown(self, mocks):
        steps = [
            {"pre_step_type": "change_since_append"},
            {"pre_step_type": "mystery_type"},
            {"pre_step_type": "ddb_config_pull", "tables": []},
        ]
        event = make_event(pre_steps=steps)
        lambda_handler(event, None)

        mocks["change_since"].assert_called_once_with(steps[0], event)
        mocks["unknown"].assert_called_once_with(steps[1])
        mocks["ddb_pull"].assert_called_once_with(steps[2], event)
        mocks["no_data"].assert_not_called()

    def test_mixed_valid_and_invalid_items(self, mocks):
        """Invalid items skipped; valid ones still route correctly."""
        steps = [
            {"pre_step_type": "change_since_append"},
            {},
            {"pre_step_type": ""},
            "not-a-dict",
            {"pre_step_type": "ddb_config_pull"},
        ]
        event = make_event(pre_steps=steps)
        lambda_handler(event, None)

        mocks["change_since"].assert_called_once_with(steps[0], event)
        mocks["ddb_pull"].assert_called_once_with(steps[4], event)
        mocks["unknown"].assert_not_called()
        mocks["no_data"].assert_not_called()
