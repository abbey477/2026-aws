"""Step handler functions for PreStepsProcessor."""

from typing import Any
from pre_steps_processor import logging_utils as log
from pre_steps_processor.dynamodb_ops import (
    JOB_RUN_TABLE, get_dynamodb_resource,
    get_last_successful_run_start_time, pull_config_from_table,
)


def handle_no_pre_steps() -> dict:
    """Called when there's nothing to process."""
    log.info("HANDLE_NO_PRE_STEPS", {"status": "stub_called"})
    return {}


def handle_change_since_append(step: dict, event: dict) -> dict:
    """Find start_time of the last COMPLETED run for this (job_id, job_type)."""
    job_id = event.get("job_id")
    job_type = event.get("job_type")

    log.info("HANDLE_CHANGE_SINCE_APPEND_START", {"job_id": job_id, "job_type": job_type})

    dynamodb = get_dynamodb_resource()
    table = dynamodb.Table(JOB_RUN_TABLE)

    start_time = get_last_successful_run_start_time(table=table, job_id=job_id, job_type=job_type)

    result = {"last_successful_start_time": start_time}

    log.info("HANDLE_CHANGE_SINCE_APPEND_COMPLETE", {
        "job_id": job_id, "has_start_time": start_time is not None,
    })
    return result


def handle_ddb_config_pull(step: dict, event: dict) -> dict:
    """Pull config rows from each table listed in step['tables']."""
    job_id = event.get("job_id")
    job_type = event.get("job_type")
    tables = step.get("tables")

    log.info("HANDLE_DDB_CONFIG_PULL_START", {
        "job_id": job_id, "tables_count": len(tables) if isinstance(tables, list) else 0,
    })

    if not isinstance(tables, list) or len(tables) == 0:
        log.warn("HANDLE_DDB_CONFIG_PULL_NO_TABLES", {"reason": "tables missing or empty"})
        return {}

    dynamodb = get_dynamodb_resource()
    results: dict = {}

    for table_name in tables:
        if not isinstance(table_name, str) or table_name == "":
            log.warn("HANDLE_DDB_CONFIG_PULL_SKIP", {"table_value": repr(table_name)})
            continue
        table = dynamodb.Table(table_name)
        row = pull_config_from_table(table=table, table_name=table_name, job_id=job_id, job_type=job_type)
        results[table_name] = row

    log.info("HANDLE_DDB_CONFIG_PULL_COMPLETE", {"pulled_count": len(results)})
    return results


def handle_unknown_pre_step(step: Any) -> dict:
    """Catch-all for unrecognised pre_step_type values."""
    unknown_type = step.get("pre_step_type", "<missing>") if isinstance(step, dict) else "<not-a-dict>"
    log.warn("HANDLE_UNKNOWN_PRE_STEP", {"pre_step_type": unknown_type})
    return {}
