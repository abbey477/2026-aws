"""
DynamoDB data access for GetConfig Lambda.

Contains:
- Resource factory (separated for easy mocking in tests)
- Table name constants (env-driven)
- Repository functions for job_run and job_config tables
- Helper to compute last_updated_time when writing job_run rows

job_run table schema:
  PK: run_id            (string)
  SK: last_updated_time (string, ISO-8601)

The table is append-only — each state change creates a NEW row for the same
run_id with a newer last_updated_time. This supports restarts (re-run from
a specific historical state by passing that last_updated_time) and audit.
"""

import os
from datetime import datetime, timezone

import boto3
from botocore.exceptions import ClientError
from boto3.dynamodb.conditions import Key

from get_config import logging_utils as log


# Table names — env-driven with sensible defaults
JOB_RUN_TABLE = os.environ.get("JOB_RUN_TABLE", "job_run")
JOB_CONFIG_TABLE = os.environ.get("JOB_CONFIG_TABLE", "job_config")


def get_dynamodb_resource():
    """Return a DynamoDB resource. Separated for easy mocking in tests."""
    return boto3.resource("dynamodb")


def get_last_updated_time(provided: str | None = None) -> str:
    """
    Return a value suitable for the job_run SK `last_updated_time`.

    If the caller passes a non-empty value, we use it as-is (they know what
    timestamp they want to write). Otherwise we auto-set to the current UTC
    time in ISO-8601 format — same format as other timestamps in the system
    so lexicographic sort on the SK matches chronological order.

    Args:
        provided: Caller-supplied timestamp, or None/empty to auto-set.

    Returns:
        An ISO-8601 UTC timestamp string, e.g. "2024-03-15T10:00:00Z".
    """
    if isinstance(provided, str) and provided != "":
        return provided
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def get_job_run(
    table,
    run_id: str,
    last_updated_time: str | None = None,
) -> dict:
    """
    Fetch a job_run record from DynamoDB.

    Composite key (PK=run_id, SK=last_updated_time) means multiple rows
    can exist for the same run_id — one per state change. Two lookup modes:

    1. **Exact fetch** (last_updated_time provided):
       Use get_item with the full composite key. Used for restarts — the
       caller wants a specific historical snapshot.

    2. **Latest fetch** (last_updated_time None/omitted):
       Use query with ScanIndexForward=False + Limit=1 to return the most
       recently written row for this run_id. This is the normal case —
       "give me the current state of this run."

    Args:
        table: DynamoDB Table resource for job_run.
        run_id: The unique run identifier (partition key).
        last_updated_time: Optional sort key value. When None/empty, returns
                           the latest row for run_id.

    Returns:
        dict: The job run item from DynamoDB.

    Raises:
        ValueError: If no record found for the given lookup.
        ClientError: If DynamoDB call fails (throttling, permissions, etc.).
    """
    log.info("FETCH_JOB_RUN_START", {
        "run_id": run_id,
        "table": JOB_RUN_TABLE,
        "mode": "exact" if last_updated_time else "latest",
        "last_updated_time": last_updated_time or "<not provided>",
    })

    # --- Branch 1: exact fetch via full composite key ---
    if last_updated_time:
        try:
            response = table.get_item(Key={
                "run_id": run_id,
                "last_updated_time": last_updated_time,
            })
        except ClientError as e:
            log.error("FETCH_JOB_RUN_ERROR", {
                "run_id": run_id,
                "last_updated_time": last_updated_time,
                "error_code": e.response.get("Error", {}).get("Code", "Unknown"),
                "error_message": str(e),
            })
            raise

        if "Item" not in response:
            log.warn("FETCH_JOB_RUN_FAILED", {
                "run_id": run_id,
                "last_updated_time": last_updated_time,
                "reason": "No item found at exact composite key",
            })
            raise ValueError(
                f"No job_run found for run_id: {run_id}, "
                f"last_updated_time: {last_updated_time}"
            )

        item = response["Item"]

    # --- Branch 2: latest fetch via query (newest SK first) ---
    else:
        try:
            response = table.query(
                KeyConditionExpression=Key("run_id").eq(run_id),
                ScanIndexForward=False,
                Limit=1,
            )
        except ClientError as e:
            log.error("FETCH_JOB_RUN_ERROR", {
                "run_id": run_id,
                "error_code": e.response.get("Error", {}).get("Code", "Unknown"),
                "error_message": str(e),
            })
            raise

        items = response.get("Items", [])
        if not items:
            log.warn("FETCH_JOB_RUN_FAILED", {
                "run_id": run_id,
                "reason": "No items found for run_id (latest lookup)",
            })
            raise ValueError(f"No job_run found for run_id: {run_id}")

        item = items[0]

    log.info("FETCH_JOB_RUN_SUCCESS", {
        "run_id": run_id,
        "last_updated_time": item.get("last_updated_time", "N/A"),
        "job_id": item.get("job_id", "N/A"),
        "job_type": item.get("job_type", "N/A"),
        "status": item.get("status", "N/A"),
        "trigger_type": item.get("trigger_type", "N/A"),
    })
    return item


def get_job_config(table, job_id: str, job_type: str) -> dict:
    """
    Fetch job configuration from the job_config DynamoDB table.

    Schema-agnostic by design: any new fields added to the job_config row
    (e.g. pre_steps) automatically flow through to the caller.

    Args:
        table: DynamoDB Table resource for job_config.
        job_id: Partition key.
        job_type: Sort key.

    Returns:
        dict: The job config item (full row, no filtering).

    Raises:
        ValueError: If no config found.
        ClientError: If DynamoDB call fails.
    """
    log.info("FETCH_JOB_CONFIG_START", {
        "job_id": job_id,
        "job_type": job_type,
        "table": JOB_CONFIG_TABLE,
    })

    try:
        response = table.get_item(Key={"job_id": job_id, "job_type": job_type})
    except ClientError as e:
        log.error("FETCH_JOB_CONFIG_ERROR", {
            "job_id": job_id,
            "job_type": job_type,
            "error_code": e.response.get("Error", {}).get("Code", "Unknown"),
            "error_message": str(e),
        })
        raise

    if "Item" not in response:
        log.warn("FETCH_JOB_CONFIG_FAILED", {
            "job_id": job_id,
            "job_type": job_type,
            "reason": "No item found in job_config table",
        })
        raise ValueError(
            f"No job_config found for job_id: {job_id}, job_type: {job_type}"
        )

    item = response["Item"]
    runner = item.get("job_runner", {})
    log.info("FETCH_JOB_CONFIG_SUCCESS", {
        "job_id": job_id,
        "job_type": job_type,
        "enabled": item.get("enabled", "N/A"),
        "runner_type": runner.get("type", "N/A"),
        "runner_name": runner.get("name", "N/A"),
        "has_next_jobs": bool(item.get("next_jobs")),
        "next_jobs_count": len(item.get("next_jobs", [])),
        "has_pre_steps": bool(item.get("pre_steps")),
        "pre_steps_count": len(item.get("pre_steps", [])),
    })
    return item
