"""
Tests for handler.py

Tests:
1. Happy path - next_jobs creates new job_run entries using child config.
2. No next_jobs - handler skips gracefully.
3. Child config not found - still creates entry with defaults.
4. Multiple next_jobs - creates multiple entries.
5. Handler failure - write_log called with FAILURE, exception re-raised.
"""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
sys.path.insert(0, os.path.dirname(__file__))

import pytest
from conftest import _make_event


def _load_handler(dynamodb_setup, monkeypatch):
    """Reload handler and patch module-scope tables to the moto-backed ones."""
    dynamodb, job_run_table, job_config_table, _ = dynamodb_setup
    sys.modules.pop("schedule_next_job.handler", None)

    from schedule_next_job import dynamodb_ops
    monkeypatch.setattr(dynamodb_ops, "get_dynamodb_resource", lambda: dynamodb)

    from schedule_next_job import handler
    monkeypatch.setattr(handler, "_DYNAMODB", dynamodb)
    monkeypatch.setattr(handler, "_JOB_RUN_TABLE", job_run_table)
    monkeypatch.setattr(handler, "_JOB_CONFIG_TABLE", job_config_table)
    return handler, job_run_table


class TestScheduleNextJobLambda:

    def test_schedule_with_next_jobs(self, dynamodb_setup, monkeypatch):
        """Happy path: next_jobs creates new job_run entries using child config."""
        handler, job_run_table = _load_handler(dynamodb_setup, monkeypatch)

        result = handler.lambda_handler(
            _make_event(
                next_jobs=[{"type": "silver_load", "id": "dbr_client"}],
                job_output={"s3_path": "s3://bucket/output"},
            ), None
        )

        assert result["schedule_result"]["skipped"] is False
        next_ids = result["schedule_result"]["next_job_run_ids"]
        assert len(next_ids) == 1

        item = job_run_table.get_item(Key={"run_id": next_ids[0]})["Item"]
        assert item["job_id"] == "dbr_client"
        assert item["job_type"] == "silver_load"
        assert item["trigger_type"] == "PIPELINE"
        assert item["status"] == "WAITING"
        assert item["custom_attributes"] == {"s3_path": "s3://bucket/output"}
        assert item["error"] == ""
        assert item["delete_at"] == 0

    def test_schedule_no_next_jobs(self, dynamodb_setup, monkeypatch):
        """Handler skips gracefully when no next_jobs."""
        handler, _ = _load_handler(dynamodb_setup, monkeypatch)
        result = handler.lambda_handler(_make_event(next_jobs=[]), None)
        assert result["schedule_result"]["skipped"] is True
        assert result["schedule_result"]["next_job_run_ids"] == []

    def test_schedule_multiple_next_jobs(self, dynamodb_setup, monkeypatch):
        """Multiple next_jobs creates multiple entries."""
        handler, job_run_table = _load_handler(dynamodb_setup, monkeypatch)

        result = handler.lambda_handler(
            _make_event(
                next_jobs=[
                    {"type": "silver_load", "id": "dbr_client"},
                    {"type": "gold_load",   "id": "dbr_gold"},
                ],
                job_output={"s3_path": "s3://bucket/data"},
            ), None
        )

        next_ids = result["schedule_result"]["next_job_run_ids"]
        assert len(next_ids) == 2
        item1 = job_run_table.get_item(Key={"run_id": next_ids[0]})["Item"]
        item2 = job_run_table.get_item(Key={"run_id": next_ids[1]})["Item"]
        assert {item1["job_id"], item2["job_id"]} == {"dbr_client", "dbr_gold"}

    def test_schedule_child_config_not_found(self, dynamodb_setup, monkeypatch):
        """Missing child config still creates entry with defaults."""
        handler, job_run_table = _load_handler(dynamodb_setup, monkeypatch)

        result = handler.lambda_handler(
            _make_event(next_jobs=[{"type": "nonexistent_type", "id": "nonexistent_job"}]),
            None
        )
        next_ids = result["schedule_result"]["next_job_run_ids"]
        assert len(next_ids) == 1
        item = job_run_table.get_item(Key={"run_id": next_ids[0]})["Item"]
        assert item["job_id"] == "nonexistent_job"
        assert item["status"] == "WAITING"

    def test_handler_failure_writes_failure_log(self, dynamodb_setup, monkeypatch):
        """Unexpected scheduler error writes FAILURE log and re-raises."""
        handler, _ = _load_handler(dynamodb_setup, monkeypatch)

        calls = []
        monkeypatch.setattr(handler, "write_log", lambda **kw: calls.append(kw))
        monkeypatch.setattr(
            handler, "schedule_next_jobs",
            lambda *a, **kw: (_ for _ in ()).throw(RuntimeError("boom")),
        )

        with pytest.raises(RuntimeError, match="boom"):
            handler.lambda_handler(
                _make_event(next_jobs=[{"type": "silver_load", "id": "dbr_client"}]), None
            )

        assert calls[0]["status"] == "FAILURE"
        assert calls[0]["stage"] == "ScheduleNextJob"
