package com.example.dbtester.controller;

import com.example.dbtester.dto.BulkResult;
import com.example.dbtester.dto.ProductRequest;
import com.example.dbtester.entity.Product;
import com.example.dbtester.service.OracleProductService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/oracle/products")
@Validated
public class OracleProductController {

    private final OracleProductService service;

    public OracleProductController(OracleProductService service) {
        this.service = service;
    }

    // ---- Single row ----

    @GetMapping
    public List<Product> findAll() {
        return service.findAll();
    }

    @GetMapping("/{id}")
    public Product findById(@PathVariable Long id) {
        return service.findById(id);
    }

    @PostMapping
    public ResponseEntity<Product> create(@Valid @RequestBody ProductRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.create(request));
    }

    @PutMapping("/{id}")
    public Product update(@PathVariable Long id, @Valid @RequestBody ProductRequest request) {
        return service.update(id, request);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    // ---- Bulk ----

    @PostMapping("/bulk")
    public ResponseEntity<BulkResult> createAll(
            @RequestBody @NotEmpty @Valid List<ProductRequest> requests) {
        return ResponseEntity.status(HttpStatus.CREATED).body(BulkResult.of(service.createAll(requests)));
    }

    @PutMapping("/bulk")
    public BulkResult updateAll(@RequestBody @NotEmpty List<Product> products) {
        return BulkResult.of(service.updateAll(products));
    }

    @DeleteMapping("/bulk")
    public BulkResult deleteAll(@RequestBody @NotEmpty List<Long> ids) {
        return BulkResult.of(service.deleteAll(ids));
    }
}
