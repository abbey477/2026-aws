# DynamoDB Seed Data — v2

Test data for three tables: **`app-jobConfig`**, **`app-jobRun`**, **`app-jobLog`**.

**Totals:** 15 configs, 50 runs, 100 logs.
**Run status mix:** 25 SUCCESS, 10 FAILED, 8 RUNNING, 7 WAITING.

Two ways to load the same data are included — pick whichever works for your environment.

## Plan A — AWS CLI (preferred)

Folder: `cli_plan_a/`

Uses `aws dynamodb batch-write-item`. Fastest way to load all 165 items.

```bash
cd cli_plan_a
chmod +x load_all.sh
./load_all.sh --dry-run   # preview
./load_all.sh             # load
```

Windows:
```powershell
cd cli_plan_a
.\load_all.ps1 -DryRun
.\load_all.ps1
```

See `cli_plan_a/README.md` for details.

## Plan B — PartiQL editor in AWS Console

Folder: `partiql_plan_b/`

Use this if the CLI isn't available or is blocked by IAM/network. Open each `.sql` file, paste statements one at a time into the DynamoDB PartiQL editor, run.

- `app-jobConfig.partiql.sql` — 15 INSERTs
- `app-jobRun.partiql.sql` — 50 INSERTs
- `app-jobLog.partiql.sql` — 100 INSERTs

See `partiql_plan_b/README.md` for details.

## Prerequisites (both plans)

Tables must already exist with these keys:
- `app-jobConfig`: PK `job_id` (S), SK `job_type` (S)
- `app-jobRun`: PK `run_id` (S), SK `last_updated_time` (S)
- `app-jobLog`: PK `run_id` (S), SK `time` (S)

## Verify after loading

```sql
SELECT COUNT(*) FROM "app-jobConfig";   -- expect 15
SELECT COUNT(*) FROM "app-jobRun";      -- expect 50
SELECT COUNT(*) FROM "app-jobLog";      -- expect 100
```

Or with the CLI:
```bash
aws dynamodb scan --table-name app-jobConfig --select COUNT
aws dynamodb scan --table-name app-jobRun    --select COUNT
aws dynamodb scan --table-name app-jobLog    --select COUNT
```

## What's in the data

**15 configs** form three parallel three-stage pipelines (sourcing → silver_load → gold_load) for `client`, `country`, `currency`, and `product` subjects, plus three standalone jobs: `trade_ref` (ADHOC), `dq_check` (scheduled validation), and `legacy_feed` (disabled — tests dispatcher skip behavior).

**50 runs** include 5 complete end-to-end chains (15 runs, linked via `custom_attributes.parent_run_id`), 10 FAILED runs with realistic error messages, 8 RUNNING runs with fresh heartbeats, and 7 WAITING runs with `next_scheduled_run_time` set.

**100 logs** — 2 per run, covering START/END for completed runs and START/HEARTBEAT or QUEUED/DISPATCH for in-flight ones.

Data integrity is verified end-to-end: every `jobRun.job_id` references a real `jobConfig`, every `jobLog.run_id` references a real `jobRun`, all PK+SK pairs are unique per table.
