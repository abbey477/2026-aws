aws_region   = "us-east-1"
env          = "dev"
project_name = "terraform-hello"

tags = {
  # <<< PLACEHOLDER: firm-required tags >>>
  Project     = "terraform-hello"
  Environment = "dev"
  Owner       = "REPLACE-your-name"
  CostCenter  = "REPLACE-if-needed"
}
