# load_all.ps1 — load all jobConfig / jobRun / jobLog batches into DynamoDB (Windows)
#
# Usage:
#   .\load_all.ps1
#   .\load_all.ps1 -Prefix "app-"
#   .\load_all.ps1 -DryRun

param(
    [string]$Prefix = "",
    [switch]$DryRun
)

$ErrorActionPreference = "Stop"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ScriptDir

$Files = @(
    "jobConfig_part1_of_1.json",
    "jobRun_part1_of_2.json",
    "jobRun_part2_of_2.json",
    "jobLog_part1_of_4.json",
    "jobLog_part2_of_4.json",
    "jobLog_part3_of_4.json",
    "jobLog_part4_of_4.json"
)

Write-Host "=== DynamoDB seed loader ===" -ForegroundColor Cyan
Write-Host "Prefix: '$Prefix'"
Write-Host "Files:  $($Files.Count)"
Write-Host ""

$TmpDir = Join-Path $env:TEMP ("ddb_seed_" + [Guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Path $TmpDir | Out-Null

try {
    foreach ($f in $Files) {
        if (-not (Test-Path $f)) {
            Write-Error "MISSING: $f"
            exit 1
        }

        if ($Prefix -ne "") {
            $raw = Get-Content $f -Raw | ConvertFrom-Json
            $origKey = ($raw.PSObject.Properties | Select-Object -First 1).Name
            $newKey = "$Prefix$origKey"
            $newObj = [ordered]@{ $newKey = $raw.$origKey }
            $target = Join-Path $TmpDir $f
            ($newObj | ConvertTo-Json -Depth 100) | Set-Content -Path $target -Encoding UTF8
        } else {
            $target = Join-Path $ScriptDir $f
        }

        $fileUri = "file://$target"
        Write-Host ">>> aws dynamodb batch-write-item --request-items $fileUri"

        if ($DryRun) { continue }

        $resp = aws dynamodb batch-write-item --request-items $fileUri | ConvertFrom-Json
        $unprocessedCount = 0
        if ($resp.UnprocessedItems) {
            foreach ($prop in $resp.UnprocessedItems.PSObject.Properties) {
                $unprocessedCount += $prop.Value.Count
            }
        }
        if ($unprocessedCount -gt 0) {
            Write-Host "    WARN: $unprocessedCount unprocessed items" -ForegroundColor Yellow
            $resp | ConvertTo-Json -Depth 10
        } else {
            Write-Host "    OK" -ForegroundColor Green
        }
    }
} finally {
    Remove-Item -Recurse -Force $TmpDir -ErrorAction SilentlyContinue
}

Write-Host ""
Write-Host "Done. Verify with:"
Write-Host "  aws dynamodb scan --table-name ${Prefix}jobConfig --select COUNT"
Write-Host "  aws dynamodb scan --table-name ${Prefix}jobRun --select COUNT"
Write-Host "  aws dynamodb scan --table-name ${Prefix}jobLog --select COUNT"
Write-Host "Expected: 15, 50, 100"
