"""
Core scheduling logic for ScheduleNextJob.

For each next_job declared in the parent job_config, fetch the child's
full config from job_config and insert a new job_run record.
"""
import uuid

from logger import log_info, log_error
from config import DEFAULT_TRIGGER_TYPE, DEFAULT_RUN_FREQUENCY_MINS
from dynamodb_ops import (
    get_next_job_config,
    get_next_minute_iso,
    put_job_run,
)


def _build_job_run_item(
    new_run_id: str,
    next_job_id: str,
    next_job_type: str,
    trigger_type: str,
    run_frequency: int,
    next_min: str,
    job_output: dict,
) -> dict:
    """Build the item dict that will be written to the job_run table."""
    return {
        "run_id": new_run_id,
        "job_id": next_job_id,
        "job_type": next_job_type,
        "trigger_type": "PIPELINE",
        "status": "WAITING",
        "start_time": "",
        "end_time": "",
        "next_scheduled_run_time": next_min,
        "last_heartbeat_time": "",
        "expiry_time": "",
        "mark_for_delete": False,
        "custom_attributes": job_output if job_output else {},
        "error": "",
        "delete_at": 0,
    }


def schedule_next_jobs(
    job_run_table,
    job_config_table,
    next_jobs: list,
    job_output: dict,
) -> list:
    """
    For each next_job entry, fetch its full config from job_config table
    and insert a new job_run record into the job_run table.

    Args:
        job_run_table: DynamoDB Table resource for job_run.
        job_config_table: DynamoDB Table resource for job_config.
        next_jobs: List of next_job dicts, each with 'id' and 'type'.
        job_output: Output from the completed parent job (passed via custom_attributes).

    Returns:
        list: List of created run_id strings.
    """
    if not next_jobs:
        log_info("SCHEDULE_SKIP", {"reason": "No next_jobs defined in job_config"})
        return []

    log_info("SCHEDULE_START", {
        "count": len(next_jobs),
        "output_keys": list(job_output.keys()) if job_output else [],
    })

    created_run_ids = []
    next_min = get_next_minute_iso()

    for next_job in next_jobs:
        next_job_id = next_job.get("id", "")
        next_job_type = next_job.get("type", "")

        # Fetch the child's full config from job_config table.
        try:
            child_config = get_next_job_config(
                job_config_table, next_job_id, next_job_type
            )
        except Exception:
            # get_next_job_config already logged the error with exc_info.
            # Skip this child and continue with the rest — one bad lookup
            # shouldn't block all downstream jobs.
            log_error("SCHEDULE_CHILD_SKIPPED", {
                "job_id": next_job_id,
                "job_type": next_job_type,
                "reason": "Failed to fetch child config",
            })
            continue

        # Use child config values for the new job_run record.
        trigger_type = child_config.get("trigger_type", DEFAULT_TRIGGER_TYPE)
        run_frequency = child_config.get(
            "run_frequency_in_mins", DEFAULT_RUN_FREQUENCY_MINS
        )

        new_run_id = str(uuid.uuid4())

        log_info("SCHEDULE_INSERT", {
            "new_run_id": new_run_id,
            "job_id": next_job_id,
            "job_type": next_job_type,
            "trigger_type": trigger_type,
            "run_frequency_in_mins": run_frequency,
            "has_child_config": bool(child_config),
            "next_scheduled_run_time": next_min,
        })

        item = _build_job_run_item(
            new_run_id=new_run_id,
            next_job_id=next_job_id,
            next_job_type=next_job_type,
            trigger_type=trigger_type,
            run_frequency=run_frequency,
            next_min=next_min,
            job_output=job_output,
        )

        try:
            put_job_run(job_run_table, item)
        except Exception:
            # put_job_run already logged with exc_info. Keep going so one
            # failed insert doesn't block the rest of the batch.
            log_error("SCHEDULE_INSERT_SKIPPED", {
                "new_run_id": new_run_id,
                "job_id": next_job_id,
                "reason": "put_item failed",
            })
            continue

        created_run_ids.append(new_run_id)

    log_info("SCHEDULE_DONE", {
        "created_count": len(created_run_ids),
        "requested_count": len(next_jobs),
        "run_ids": created_run_ids,
    })
    return created_run_ids
