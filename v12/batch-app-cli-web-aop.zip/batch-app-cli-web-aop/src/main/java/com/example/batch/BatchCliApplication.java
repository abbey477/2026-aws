package com.example.batch;

import com.example.batch.core.JobContext;
import com.example.batch.core.JobDispatcher;
import com.example.batch.core.JobResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import java.time.LocalDate;

/**
 * Entry point #2 — STANDALONE / CLI MODE.
 *
 * <p>For Autosys. Boots Spring with web disabled, runs one job, exits with status code.
 *
 * <p>Run with:
 * <pre>java -cp batch-app.jar -Dloader.main=com.example.batch.BatchCliApplication \
 *      org.springframework.boot.loader.launch.PropertiesLauncher --job=jobA</pre>
 *
 * <p>Or, simpler, with the un-shaded classpath approach (used in the demo):
 * <pre>java -cp "lib/*:batch-app.jar" com.example.batch.BatchCliApplication --job=jobA</pre>
 *
 * <p>Coexists with {@link BatchWebApplication}. Same beans, same business logic,
 * different entry point.
 */
@SpringBootApplication
public class BatchCliApplication {

    private static final Logger log = LoggerFactory.getLogger(BatchCliApplication.class);

    private static final int EXIT_SUCCESS = 0;
    private static final int EXIT_FAILURE = 1;
    private static final int EXIT_BAD_ARGS = 2;

    public static void main(String[] args) {
        int exitCode = EXIT_FAILURE;
        long startTime = System.currentTimeMillis();

        try {
            JobContext context = parseArgs(args);
            log.info("CLI mode — starting job '{}' for runDate={}",
                    context.getJobName(), context.getRunDate());

            SpringApplication app = new SpringApplication(BatchCliApplication.class);
            app.setWebApplicationType(WebApplicationType.NONE);  // critical: no Tomcat

            try (ConfigurableApplicationContext ctx = app.run(args)) {
                JobDispatcher dispatcher = ctx.getBean(JobDispatcher.class);
                JobResult result = dispatcher.dispatch(context);

                long elapsed = System.currentTimeMillis() - startTime;
                log.info("Job '{}' finished: success={}, recordsProcessed={}, exitCode={}, elapsedMs={}",
                        context.getJobName(), result.isSuccess(),
                        result.getRecordsProcessed(), result.getExitCode(), elapsed);

                // Use the exit code the dispatcher determined from the exception type
                // (0 on success, 1 generic failure, 3+ for specific business errors).
                exitCode = result.getExitCode();
            }
        } catch (IllegalArgumentException e) {
            log.error("Invalid arguments: {}", e.getMessage());
            printUsage();
            exitCode = EXIT_BAD_ARGS;
        } catch (Exception e) {
            log.error("Job failed with unhandled exception", e);
            exitCode = EXIT_FAILURE;
        }

        System.exit(exitCode);
    }

    private static JobContext parseArgs(String[] args) {
        String jobName = null;
        String runDate = LocalDate.now().toString();

        for (String arg : args) {
            if (arg.startsWith("--job=")) {
                jobName = arg.substring("--job=".length());
            } else if (arg.startsWith("--runDate=")) {
                runDate = arg.substring("--runDate=".length());
            }
        }
        if (jobName == null || jobName.isBlank()) {
            throw new IllegalArgumentException("Missing required argument: --job=<jobName>");
        }
        return new JobContext(jobName, runDate);
    }

    private static void printUsage() {
        System.err.println("Usage: --job=<jobName> [--runDate=YYYY-MM-DD]");
        System.err.println("  --job       Required. One of: jobA, jobB, jobC");
        System.err.println("  --runDate   Optional. Defaults to today.");
    }
}
