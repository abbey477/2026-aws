package com.example.dbtester.repository.oracle;

import com.example.dbtester.entity.Product;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * JDBC repository for the Oracle PRODUCT table.
 *
 * <p>Uses a dedicated {@link JdbcTemplate} qualified as "oracleJdbcTemplate"
 * so we hit the Oracle DataSource and not the Sybase one. Rows are mapped
 * to the immutable {@link Product} record via {@link ProductRowMapper}.
 *
 * <p>Primary keys come from {@code PRODUCT_SEQ} (see {@code oracle-schema.sql})
 * — we fetch {@code NEXTVAL} explicitly rather than letting the DB auto-assign,
 * because that's how you get the generated ID back through plain JDBC without
 * relying on {@code RETURN_GENERATED_KEYS}, which Oracle's driver handles
 * awkwardly compared to MySQL/Postgres.
 */
@Repository
public class ProductRepository {

    /**
     * Max rows sent to the driver in one {@code executeBatch()} round-trip.
     *
     * <p>Why chunk at all? The JDBC driver buffers every row of a batch in
     * client memory before sending, and some databases have packet-size or
     * statement-length limits. Chunking keeps memory bounded and means a
     * late failure only rolls back the current chunk's row set, not all
     * million rows you queued.
     *
     * <p>500 is a typical sweet spot for Oracle. Tune based on row width.
     */
    private static final int BATCH_SIZE = 500;

    /** Oracle sequence read. Pattern: {@code SEQUENCE.NEXTVAL FROM DUAL}. */
    private static final String SQL_NEXT_ID =
            "SELECT PRODUCT_SEQ.NEXTVAL FROM DUAL";

    /** Full-table scan. Fine for a demo; add LIMIT/pagination in production. */
    private static final String SQL_FIND_ALL =
            "SELECT id, sku, name, price, in_stock FROM PRODUCT";

    /** Single-row lookup by primary key. Uses positional {@code ?} binding. */
    private static final String SQL_FIND_BY_ID =
            "SELECT id, sku, name, price, in_stock FROM PRODUCT WHERE id = ?";

    /** INSERT statement reused by both single and batch insert paths. */
    private static final String SQL_INSERT =
            "INSERT INTO PRODUCT (id, sku, name, price, in_stock) VALUES (?, ?, ?, ?, ?)";

    /** UPDATE does not touch the id — the id is the WHERE predicate. */
    private static final String SQL_UPDATE =
            "UPDATE PRODUCT SET sku = ?, name = ?, price = ?, in_stock = ? WHERE id = ?";

    private static final String SQL_DELETE =
            "DELETE FROM PRODUCT WHERE id = ?";

    private final JdbcTemplate jdbc;

    // RowMapper is stateless and thread-safe, so one instance for the repo is fine.
    private final ProductRowMapper rowMapper = new ProductRowMapper();

    /**
     * @param jdbc the Oracle-scoped JdbcTemplate (qualifier distinguishes it
     *             from the Sybase one — Spring would otherwise not know which
     *             bean to inject).
     */
    public ProductRepository(@Qualifier("oracleJdbcTemplate") JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    // =========================================================================
    //  Read
    // =========================================================================

    /**
     * Returns every row. JdbcTemplate drives the ResultSet loop and calls
     * {@link ProductRowMapper#mapRow} for each row.
     */
    public List<Product> findAll() {
        return jdbc.query(SQL_FIND_ALL, rowMapper);
    }

    /**
     * Lookup by primary key.
     *
     * <p>Uses {@code query(..).stream().findFirst()} instead of
     * {@code queryForObject(..)} because the latter throws
     * {@code EmptyResultDataAccessException} on a miss — wrapping in
     * Optional keeps the "maybe absent" case out of the exception channel.
     */
    public Optional<Product> findById(Long id) {
        return jdbc.query(SQL_FIND_BY_ID, rowMapper, id).stream().findFirst();
    }

    // =========================================================================
    //  Write (single row)
    // =========================================================================

    /**
     * Single-row insert.
     *
     * <p>Steps:
     * <ol>
     *   <li>Ask Oracle for the next sequence value — one round trip.</li>
     *   <li>INSERT with that id — second round trip.</li>
     *   <li>Re-read the row so the caller gets the exact stored state
     *       (defaults, trimming, any DB-side coercion).</li>
     * </ol>
     *
     * <p>Three round-trips is fine for individual creates. For bulk loads,
     * use {@link #insertAll(List)} instead.
     */
    public Product insert(Product product) {
        Long id = jdbc.queryForObject(SQL_NEXT_ID, Long.class);
        jdbc.update(SQL_INSERT,
                id,
                product.sku(),
                product.name(),
                product.price(),
                product.inStock() ? 1 : 0);  // Oracle has no boolean; we store 0/1
        return findById(id).orElseThrow();
    }

    /**
     * Update by id. Returns rows affected — caller can use 0 to detect
     * "no such id" and throw a not-found.
     */
    public int update(Long id, Product product) {
        return jdbc.update(SQL_UPDATE,
                product.sku(),
                product.name(),
                product.price(),
                product.inStock() ? 1 : 0,
                id);
    }

    /**
     * Delete by id. Returns rows affected (0 or 1).
     */
    public int delete(Long id) {
        return jdbc.update(SQL_DELETE, id);
    }

    // =========================================================================
    //  Write (batch / bulk)
    // =========================================================================

    /**
     * Batch insert with sequence-generated IDs. Returns the ids in the same
     * order as the input list so the caller can correlate inputs to outputs.
     *
     * <p>Strategy:
     * <ol>
     *   <li>Pre-allocate N sequence values (see {@link #nextIds(int)}).</li>
     *   <li>Build a parallel list of Products with those ids attached.</li>
     *   <li>INSERT in chunks of BATCH_SIZE via {@code executeBatch()}.</li>
     * </ol>
     *
     * <p>Why pre-allocate IDs instead of fetching generated keys? Because
     * JDBC's {@code getGeneratedKeys()} with batch inserts is driver-specific
     * and unreliable across Oracle/Sybase. Pre-allocating from a sequence is
     * portable and lets us give the caller deterministic ids back.
     *
     * <p>Thread-safety of sequences: Oracle guarantees unique NEXTVAL across
     * concurrent sessions, so this is safe under concurrency.
     */
    public List<Long> insertAll(List<Product> products) {
        if (products == null || products.isEmpty()) {
            return List.of();
        }

        // Step 1: grab all the ids we need upfront.
        List<Long> ids = nextIds(products.size());

        // Step 2: rebuild the product list with ids filled in.
        List<Product> withIds = new ArrayList<>(products.size());
        for (int i = 0; i < products.size(); i++) {
            Product p = products.get(i);
            withIds.add(new Product(ids.get(i), p.sku(), p.name(), p.price(), p.inStock()));
        }

        // Step 3: chunked INSERTs.
        batchInsertInChunks(withIds);
        return ids;
    }

    /**
     * Batch update by id. Returns total rows affected across all chunks.
     *
     * <p>Some drivers return {@link java.sql.Statement#SUCCESS_NO_INFO} (-2)
     * instead of a real count in batch mode — we count those as 1 since
     * the statement did execute. If your driver returns accurate counts,
     * the total will be exact.
     */
    public int updateAll(List<Product> products) {
        if (products == null || products.isEmpty()) {
            return 0;
        }

        int total = 0;
        for (int i = 0; i < products.size(); i += BATCH_SIZE) {
            // subList is a view, not a copy — cheap.
            List<Product> chunk = products.subList(i, Math.min(i + BATCH_SIZE, products.size()));

            int[] counts = jdbc.batchUpdate(SQL_UPDATE, new BatchPreparedStatementSetter() {
                // setValues is called once per row within the current batch.
                // idx is the row index within `chunk`, not the full list.
                @Override
                public void setValues(PreparedStatement ps, int idx) throws SQLException {
                    Product p = chunk.get(idx);
                    ps.setString(1, p.sku());
                    ps.setString(2, p.name());
                    ps.setBigDecimal(3, p.price());
                    ps.setInt(4, p.inStock() ? 1 : 0);
                    ps.setLong(5, p.id());
                }

                // Tells JdbcTemplate how many rows are in this batch.
                @Override
                public int getBatchSize() {
                    return chunk.size();
                }
            });

            for (int c : counts) {
                total += (c >= 0) ? c : 1; // -2 = SUCCESS_NO_INFO; count as 1
            }
        }
        return total;
    }

    /**
     * Batch delete by id. Same chunking pattern as {@link #updateAll}.
     */
    public int deleteAll(List<Long> ids) {
        if (ids == null || ids.isEmpty()) {
            return 0;
        }

        int total = 0;
        for (int i = 0; i < ids.size(); i += BATCH_SIZE) {
            List<Long> chunk = ids.subList(i, Math.min(i + BATCH_SIZE, ids.size()));
            int[] counts = jdbc.batchUpdate(SQL_DELETE, new BatchPreparedStatementSetter() {
                @Override
                public void setValues(PreparedStatement ps, int idx) throws SQLException {
                    ps.setLong(1, chunk.get(idx));
                }

                @Override
                public int getBatchSize() {
                    return chunk.size();
                }
            });
            for (int c : counts) {
                total += (c >= 0) ? c : 1;
            }
        }
        return total;
    }

    // =========================================================================
    //  Internal helpers
    // =========================================================================

    /**
     * Pre-allocate N sequence values.
     *
     * <p>On real Oracle you could optimize this into a single round-trip:
     * <pre>{@code
     *   SELECT PRODUCT_SEQ.NEXTVAL FROM DUAL CONNECT BY LEVEL <= ?
     * }</pre>
     * but {@code CONNECT BY} is Oracle-only syntax (H2 doesn't support it
     * even in Oracle mode), so we use a portable loop here. Within a single
     * transaction over a pooled connection, the per-iteration overhead is
     * negligible for reasonable batch sizes.
     *
     * <p>If you need to squeeze extra throughput on production Oracle for
     * very large loads, swap the body for the CONNECT BY version — the
     * behavior is identical, only the round-trip count changes.
     */
    private List<Long> nextIds(int count) {
        List<Long> ids = new ArrayList<>(count);
        for (int i = 0; i < count; i++) {
            ids.add(jdbc.queryForObject(SQL_NEXT_ID, Long.class));
        }
        return ids;
    }

    /**
     * Chunked batch-insert. Kept private so the public API
     * ({@link #insertAll(List)}) owns the full transactional semantics.
     */
    private void batchInsertInChunks(List<Product> products) {
        for (int i = 0; i < products.size(); i += BATCH_SIZE) {
            List<Product> chunk = products.subList(i, Math.min(i + BATCH_SIZE, products.size()));
            jdbc.batchUpdate(SQL_INSERT, new BatchPreparedStatementSetter() {
                @Override
                public void setValues(PreparedStatement ps, int idx) throws SQLException {
                    Product p = chunk.get(idx);
                    ps.setLong(1, p.id());
                    ps.setString(2, p.sku());
                    ps.setString(3, p.name());
                    ps.setBigDecimal(4, p.price());
                    ps.setInt(5, p.inStock() ? 1 : 0);
                }

                @Override
                public int getBatchSize() {
                    return chunk.size();
                }
            });
        }
    }
}
