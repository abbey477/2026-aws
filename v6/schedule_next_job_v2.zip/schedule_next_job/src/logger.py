"""
Structured logger for ScheduleNextJob Lambda.

Emits single-line key=value logs tagged with a component name.
Supports INFO (default operational events) and ERROR (failures, exceptions).
"""
import logging

# Module-level logger configured once on import.
_logger = logging.getLogger("ScheduleNextJob")
_logger.setLevel(logging.INFO)


def _format_details(details: dict) -> str:
    """Turn a details dict into ', '-joined key=value pairs."""
    if not details:
        return ""
    return ", ".join(f"{k}={v}" for k, v in details.items())


def log_info(step: str, details: dict = None) -> None:
    """
    Structured INFO log.

    Args:
        step: Short tag identifying the pipeline step (e.g. 'SCHEDULE_START').
        details: Optional key/value context dict.
    """
    detail_str = _format_details(details or {})
    _logger.info(f"[ScheduleNextJob] [{step}] {detail_str}")


def log_error(step: str, details: dict = None, exc_info: bool = False) -> None:
    """
    Structured ERROR log.

    Args:
        step: Short tag identifying where the failure occurred.
        details: Optional key/value context dict (error messages, IDs, etc.).
        exc_info: When True, append the current exception traceback.
                  Set this to True inside an `except` block.
    """
    detail_str = _format_details(details or {})
    _logger.error(f"[ScheduleNextJob] [{step}] {detail_str}", exc_info=exc_info)
