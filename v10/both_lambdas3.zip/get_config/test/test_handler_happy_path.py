"""Happy-path tests."""
from get_config.handler import lambda_handler


class TestHandlerHappyPath:

    def test_successful_config_retrieval(self, patched_handler, mock_write_log):
        result = lambda_handler({"run_id": "run-001"}, None)
        assert result["run_id"] == "run-001"
        assert result["job_id"] == "client"
        assert result["job_type"] == "sourcing"
        assert result["status"] == "WAITING"
        assert result["last_updated_time"] == "2024-01-01T00:00:00Z"
        assert "job_config" in result
        assert result["job_config"]["enabled"] is True
        assert result["job_config"]["job_runner"]["type"] == "ECS_Fargate"

    def test_job_runner_config_fields_preserved(self, patched_handler):
        result = lambda_handler({"run_id": "run-001"}, None)
        cfg = result["job_config"]["job_runner"]["config"]
        assert cfg["cluster"] == "my-ecs-cluster"
        assert cfg["subnets"] == ["subnet-aaa111", "subnet-bbb222"]
        assert cfg["security_groups"] == ["sg-abc123"]
        assert cfg["instance_size"] == "small"

    def test_pre_steps_and_next_jobs_flow_through(self, patched_handler):
        result = lambda_handler({"run_id": "run-001"}, None)
        assert len(result["job_config"]["next_jobs"]) == 1
        assert result["job_config"]["next_jobs"][0]["id"] == "dbr_client"
        assert len(result["job_config"]["pre_steps"]) == 2

    def test_write_log_called_with_success(self, patched_handler, mock_write_log):
        lambda_handler({"run_id": "run-001"}, None)
        mock_write_log.assert_called_once_with(
            run_id="run-001", job_id="client", stage="GetConfig", status="SUCCESS",
        )
