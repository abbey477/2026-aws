#!/bin/bash
# =============================================================================
# Load seed data into DynamoDB tables
# Usage:
#   ./load_all.sh             # load data
#   ./load_all.sh --dry-run   # preview commands without running
# =============================================================================

DRY_RUN=false
if [[ "$1" == "--dry-run" ]]; then
    DRY_RUN=true
    echo "=== DRY RUN — no data will be loaded ==="
    echo ""
fi

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
FILES=("app-jobConfig.json" "app-jobRun.json" "app-jobLog.json")

for FILE in "${FILES[@]}"; do
    FILEPATH="${SCRIPT_DIR}/${FILE}"
    if [[ ! -f "$FILEPATH" ]]; then
        echo "ERROR: File not found: $FILEPATH"
        exit 1
    fi

    echo "Loading: $FILE"
    if $DRY_RUN; then
        echo "  aws dynamodb batch-write-item --request-items file://$FILEPATH"
    else
        aws dynamodb batch-write-item --request-items "file://$FILEPATH"
        if [[ $? -ne 0 ]]; then
            echo "ERROR: Failed to load $FILE"
            exit 1
        fi
        echo "  Done."
    fi
done

echo ""
echo "=== Load complete ==="
echo ""
echo "Verify with:"
echo "  aws dynamodb scan --table-name app-jobConfig --select COUNT"
echo "  aws dynamodb scan --table-name app-jobRun    --select COUNT"
echo "  aws dynamodb scan --table-name app-jobLog    --select COUNT"
echo "Expected: 1, 18, 20"
