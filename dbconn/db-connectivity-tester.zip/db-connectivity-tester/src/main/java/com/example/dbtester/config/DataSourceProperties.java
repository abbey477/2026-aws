package com.example.dbtester.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.List;
import java.util.Map;

/**
 * Root configuration bound to properties with prefix "app".
 *
 * Hierarchy:
 *   app.datasources.{name}.url
 *   app.datasources.{name}.username
 *   app.datasources.{name}.password
 *   app.datasources.{name}.driver-class-name
 *   app.datasources.{name}.hikari.*
 *   app.datasources.{name}.properties.{key}={value}
 *   app.datasources.{name}.validation-queries[0]=SELECT 1
 */
@ConfigurationProperties(prefix = "app")
public record DataSourceProperties(
        Map<String, DbConfig> datasources
) {

    public record DbConfig(
            String url,
            String username,
            String password,
            String driverClassName,
            HikariConfig hikari,
            Map<String, String> properties,
            List<String> validationQueries
    ) {}

    public record HikariConfig(
            int maximumPoolSize,
            int minimumIdle,
            long connectionTimeoutMs,
            long idleTimeoutMs,
            long maxLifetimeMs,
            String poolName
    ) {}
}
