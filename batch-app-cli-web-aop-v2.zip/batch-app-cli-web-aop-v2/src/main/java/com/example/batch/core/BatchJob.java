package com.example.batch.core;

/**
 * Every job implements this. Throw an exception on failure;
 * the dispatcher converts exceptions to exit codes.
 */
public interface BatchJob {

    String getName();

    void execute(JobContext context);
}
