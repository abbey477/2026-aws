# DynamoDB Seed Data — Simple Test Set

Minimal, realistic test data for the job orchestrator.
One job (`client/sourcing`), five runs across five days, realistic lifecycles.

## Contents

| File | Items | Target table |
|---|---|---|
| `app-jobConfig.json` | 1 | `app-jobConfig` |
| `app-jobRun.json` | 18 | `app-jobRun` |
| `app-jobLog.json` | 20 | `app-jobLog` |
| `load_all.sh` | — | Bash loader |
| `load_all.ps1` | — | PowerShell loader |

**Totals: 1 config + 18 run rows + 20 log rows = 39 items**

## The five runs

All runs use `job_id=client`, `job_type=sourcing`.

### run-001 — Jan 1 — Clean success (3 rows)

| last_updated_time | status | Notes |
|---|---|---|
| 2024-01-01T00:00:00Z | WAITING | Created |
| 2024-01-01T08:00:00Z | RUNNING | Started |
| 2024-01-01T08:45:00Z | COMPLETED | Finished cleanly |

### run-002 — Jan 2 — Failed twice, succeeded on 3rd attempt (7 rows)

| last_updated_time | status | Notes |
|---|---|---|
| 2024-01-02T00:00:00Z | WAITING | Created |
| 2024-01-02T08:00:00Z | RUNNING | 1st attempt |
| 2024-01-02T08:30:00Z | FAILED | Connection timeout |
| 2024-01-02T09:00:00Z | RUNNING | 2nd attempt |
| 2024-01-02T09:20:00Z | FAILED | Out of memory |
| 2024-01-02T10:00:00Z | RUNNING | 3rd attempt |
| 2024-01-02T10:45:00Z | COMPLETED | Finally succeeded |

### run-003 — Jan 3 — Failed, never recovered (3 rows)

| last_updated_time | status | Notes |
|---|---|---|
| 2024-01-03T00:00:00Z | WAITING | Created |
| 2024-01-03T08:00:00Z | RUNNING | Started |
| 2024-01-03T08:30:00Z | FAILED | Source API 503 — gave up |

### run-004 — Jan 4 — Clean success (3 rows)

| last_updated_time | status | Notes |
|---|---|---|
| 2024-01-04T00:00:00Z | WAITING | Created |
| 2024-01-04T08:00:00Z | RUNNING | Started |
| 2024-01-04T08:50:00Z | COMPLETED | Finished cleanly |

### run-005 — Jan 5 — Still running (2 rows)

| last_updated_time | status | Notes |
|---|---|---|
| 2024-01-05T00:00:00Z | WAITING | Created |
| 2024-01-05T08:00:00Z | RUNNING | Currently executing |

## Log entries (app-jobLog)

| run_id | Attempt | GetConfig | PreStepsProcessor | TriggerEcsJob |
|---|---|---|---|---|
| run-001 | 1st | ✅ SUCCESS | ✅ SUCCESS | ✅ SUCCESS |
| run-002 | 1st | ✅ SUCCESS | ✅ SUCCESS | ❌ FAILED |
| run-002 | 2nd | ✅ SUCCESS | ✅ SUCCESS | ❌ FAILED |
| run-002 | 3rd | ✅ SUCCESS | ✅ SUCCESS | ✅ SUCCESS |
| run-003 | 1st | ✅ SUCCESS | ✅ SUCCESS | ❌ FAILED |
| run-004 | 1st | ✅ SUCCESS | ✅ SUCCESS | ✅ SUCCESS |
| run-005 | 1st | ✅ SUCCESS | ✅ SUCCESS | (still running) |

## Prerequisites

1. AWS CLI installed and configured (`aws configure`)
2. Tables must already exist:
   - `app-jobConfig` — PK: `job_id` (S), SK: `job_type` (S)
   - `app-jobRun` — PK: `run_id` (S), SK: `last_updated_time` (S)
   - `app-jobLog` — PK: `run_id` (S), SK: `time` (S)

## Usage

### macOS / Linux / WSL

```bash
chmod +x load_all.sh
./load_all.sh --dry-run   # preview commands
./load_all.sh             # load data
```

### Windows PowerShell

```powershell
.\load_all.ps1 -DryRun    # preview commands
.\load_all.ps1             # load data
```

### Manual

```bash
aws dynamodb batch-write-item --request-items file://app-jobConfig.json
aws dynamodb batch-write-item --request-items file://app-jobRun.json
aws dynamodb batch-write-item --request-items file://app-jobLog.json
```

## Verify

```bash
aws dynamodb scan --table-name app-jobConfig --select COUNT   # Expected: 1
aws dynamodb scan --table-name app-jobRun    --select COUNT   # Expected: 18
aws dynamodb scan --table-name app-jobLog    --select COUNT   # Expected: 20
```

## Test scenarios this data enables

### GetConfig Lambda

| Scenario | Input | Expected result |
|---|---|---|
| Latest — completed | `{"run_id": "run-001"}` | COMPLETED row |
| Latest — failed | `{"run_id": "run-003"}` | FAILED row |
| Latest — running | `{"run_id": "run-005"}` | RUNNING row |
| Latest — retry success | `{"run_id": "run-002"}` | COMPLETED row (after 3 attempts) |
| Restart (exact) | `{"run_id": "run-002", "last_updated_time": "2024-01-02T08:30:00Z"}` | FAILED row (1st failure) |
| Not found | `{"run_id": "run-999"}` | ValueError — FAILED logged |

### PreStepsProcessor Lambda

| Scenario | What happens |
|---|---|
| change_since_append | Finds run-004 COMPLETED (Jan 4) — newest COMPLETED start_time |
| ddb_config_pull | Config tables don't exist yet — returns null per table |

### change_since_append — which COMPLETED run does it find?

Three runs have COMPLETED status: run-001 (Jan 1), run-002 (Jan 2), run-004 (Jan 4).
The query returns the **newest** start_time, which is run-004: `2024-01-04T08:00:00Z`.
