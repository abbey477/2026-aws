"""
GetConfig Lambda Handler

Fetches job run metadata and configuration from DynamoDB.
AWS Lambda handler entry point: get_config.handler.lambda_handler
"""

import json
from datetime import datetime, timezone

from get_config import logging_utils as log
from get_config.dynamodb_ops import (
    JOB_RUN_TABLE, JOB_CONFIG_TABLE,
    get_dynamodb_resource, get_job_run, get_job_config,
)
from get_config.log_to_dynamo import write_log


def lambda_handler(event, context):
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    log.info("HANDLER_START", {"timestamp": timestamp, "input_event": json.dumps(event)})

    run_id = event.get("run_id") or "<missing>"
    job_id = "<unknown>"

    try:
        if run_id == "<missing>":
            raise ValueError("Missing required input: 'run_id'")

        last_updated_time = event.get("last_updated_time")
        log.info("INPUT_VALIDATED", {
            "run_id": run_id,
            "last_updated_time": last_updated_time or "<not provided - will fetch latest>",
        })

        dynamodb = get_dynamodb_resource()

        log.info("STEP_1", {"action": "Fetching job_run row", "run_id": run_id})
        job_run_table = dynamodb.Table(JOB_RUN_TABLE)
        job_run = get_job_run(job_run_table, run_id, last_updated_time)

        job_id = job_run.get("job_id") or "<unknown>"
        job_type = job_run.get("job_type")

        if job_id == "<unknown>" or not job_type:
            raise ValueError(
                f"job_run record is missing 'job_id' or 'job_type'. "
                f"Got job_id={job_id}, job_type={job_type}"
            )

        log.info("STEP_2", {"action": "Querying job_config table", "job_id": job_id, "job_type": job_type})
        job_config_table = dynamodb.Table(JOB_CONFIG_TABLE)
        job_config = get_job_config(job_config_table, job_id, job_type)

        output = {**job_run, "job_config": job_config}

        log.info("HANDLER_COMPLETE", {
            "run_id": run_id, "job_id": job_id, "job_type": job_type,
            "runner_name": job_config.get("job_runner", {}).get("name", "N/A"),
        })
        write_log(run_id=run_id, job_id=job_id, stage="GetConfig", status="SUCCESS")
        return output

    except Exception as e:
        log.error("HANDLER_FAILED", {
            "run_id": run_id, "job_id": job_id,
            "error_type": type(e).__name__, "error_message": str(e),
        })
        write_log(run_id=run_id, job_id=job_id, stage="GetConfig", status="FAILED")
        raise
