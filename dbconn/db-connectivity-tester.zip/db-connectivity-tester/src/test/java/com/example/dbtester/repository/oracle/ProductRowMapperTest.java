package com.example.dbtester.repository.oracle;

import com.example.dbtester.entity.Product;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.sql.ResultSet;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class ProductRowMapperTest {

    private final ProductRowMapper mapper = new ProductRowMapper();

    @Test
    void mapsInStockOneToTrue() throws Exception {
        ResultSet rs = mock(ResultSet.class);
        when(rs.getLong("id")).thenReturn(7L);
        when(rs.getString("sku")).thenReturn("SKU-7");
        when(rs.getString("name")).thenReturn("Widget");
        when(rs.getBigDecimal("price")).thenReturn(new BigDecimal("9.99"));
        when(rs.getInt("in_stock")).thenReturn(1);

        Product p = mapper.mapRow(rs, 0);

        assertThat(p.id()).isEqualTo(7L);
        assertThat(p.sku()).isEqualTo("SKU-7");
        assertThat(p.name()).isEqualTo("Widget");
        assertThat(p.price()).isEqualByComparingTo("9.99");
        assertThat(p.inStock()).isTrue();
    }

    @Test
    void mapsInStockZeroToFalse() throws Exception {
        ResultSet rs = mock(ResultSet.class);
        when(rs.getLong("id")).thenReturn(1L);
        when(rs.getString("sku")).thenReturn("X");
        when(rs.getString("name")).thenReturn("Y");
        when(rs.getBigDecimal("price")).thenReturn(BigDecimal.ZERO);
        when(rs.getInt("in_stock")).thenReturn(0);

        Product p = mapper.mapRow(rs, 0);

        assertThat(p.inStock()).isFalse();
    }
}
