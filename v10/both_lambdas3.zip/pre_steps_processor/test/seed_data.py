"""Shared seed-data builders and test helpers."""

from botocore.exceptions import ClientError

_DEFAULT_JOB_PARAM = {
    "source": {
        "type": "API", "name": "RDI",
        "url": "https://refdata-common.jpmchase.net/common/v2/countrygroup?data.schemaVersion=1",
        "file_type": "XML",
    },
    "batch_size": 1000,
    "thread_count": 10,
}


def make_event(pre_steps=..., job_param=...) -> dict:
    """
    Build a GetConfig-shaped event.

    pre_steps=... means "do not set pre_steps"
    job_param=... means "use the default realistic job_param"
    job_param={} means "set job_param to empty dict"
    """
    event = {
        "run_id": "run-001",
        "job_id": "client",
        "job_type": "sourcing",
        "status": "WAITING",
        "trigger_type": "SCHEDULER",
        "custom_attributes": {},
        "job_config": {
            "enabled": True,
            "job_runner": {"type": "ECS_Fargate", "name": "S2S3", "config": {}},
            "job_param": dict(_DEFAULT_JOB_PARAM) if job_param is ... else job_param,
            "next_jobs": [],
        },
    }
    if pre_steps is not ...:
        event["job_config"]["pre_steps"] = pre_steps
    return event


def raise_access_denied(*args, **kwargs):
    raise ClientError(
        {"Error": {"Code": "AccessDeniedException", "Message": "Denied"}}, "Query",
    )
