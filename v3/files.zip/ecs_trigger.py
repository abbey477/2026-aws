"""
ECS Fargate task trigger.

Launches a Fargate task and passes job_param to the container as a
JSON-encoded JOB_PARAM environment variable via containerOverrides.

Note on size limits: ECS RunTask caps the total overrides block at
8 KB (8192 characters of JSON). If job_param is too large, the
run_task call will raise a ClientError which is caught and returned
as TRIGGER_FAILED. The payload size is logged before each call so
operators can see when payloads approach the limit.
"""

import json
import logging
from typing import Any

from botocore.exceptions import ClientError

logger: logging.Logger = logging.getLogger(__name__)


def _log(step: str, details: dict[str, Any]) -> None:
    """Structured info log — every line has a step tag + key-value pairs."""
    detail_str: str = ", ".join(f"{k}={v}" for k, v in details.items())
    logger.info(f"[TriggerEcsJob] [{step}] {detail_str}")


def trigger_ecs_task(
    ecs_client: Any,
    job_config: dict[str, Any],
    job_param: dict[str, Any],
    run_id: str,
) -> dict[str, Any]:
    """
    Trigger an ECS Fargate task. Returns a dict with trigger_status,
    task_arn, and optionally error.
    """
    runner_config: dict[str, Any] = (
        job_config.get("job_runner", {}).get("config", {})
    )

    ecs_cluster: str = runner_config.get("cluster", "")
    ecs_subnets: list[str] = runner_config.get("subnets", [])
    ecs_security_groups: list[str] = runner_config.get("security_groups", [])
    task_definition: str = runner_config.get("task_definition", "")
    container_name: str = runner_config.get("container_name", "")
    image: str = runner_config.get("image", "")

    # Serialize job_param once. We use this same string for both the
    # size log and the env var value so they're guaranteed consistent.
    job_param_json: str = json.dumps(job_param)

    _log("ECS_TRIGGER_START", {
        "cluster": ecs_cluster,
        "task_definition": task_definition,
        "container_name": container_name,
        "image": image or "N/A",
        "job_param_keys": list(job_param.keys()),
        "run_id": run_id,
    })

    # Record payload size for every run — this log line gives us
    # historical visibility into how big payloads get in production,
    # and an early warning if we start approaching the 8 KB limit.
    _log("JOB_PARAM_SIZE", {
        "run_id": run_id,
        "job_param_bytes": len(job_param_json),
    })

    try:
        response: dict[str, Any] = ecs_client.run_task(
            cluster=ecs_cluster,
            taskDefinition=task_definition,
            launchType="FARGATE",
            networkConfiguration={
                "awsvpcConfiguration": {
                    "subnets": ecs_subnets,
                    "securityGroups": ecs_security_groups,
                    "assignPublicIp": "DISABLED",
                }
            },
            overrides={
                "containerOverrides": [
                    {
                        "name": container_name,
                        "environment": [
                            {"name": "JOB_PARAM", "value": job_param_json},
                        ],
                    }
                ]
            },
        )

        # RunTask can return 200 with empty `tasks` if placement fails
        # (no capacity, bad subnets, etc.) — always check.
        tasks: list[dict[str, Any]] = response.get("tasks", [])
        if not tasks:
            failures: list[dict[str, Any]] = response.get("failures", [])
            _log("ECS_TRIGGER_FAILED", {
                "reason": "RunTask returned no tasks",
                "failures": str(failures),
            })
            return {
                "trigger_status": "TRIGGER_FAILED",
                "task_arn": "",
                "error": str(failures),
            }

        task_arn: str = tasks[0]["taskArn"]
        _log("ECS_TRIGGER_SUCCESS", {"task_arn": task_arn})
        return {
            "trigger_status": "TRIGGERED",
            "task_arn": task_arn,
        }

    except ClientError as e:
        # Covers all AWS-side failures including:
        #   - InvalidParameterException (overrides > 8 KB)
        #   - ClusterNotFoundException
        #   - AccessDeniedException
        #   - ThrottlingException
        #   - Anything else boto3 raises on RunTask
        _log("ECS_CLIENT_ERROR", {
            "run_id": run_id,
            "error_code": e.response["Error"]["Code"],
            "error_message": e.response["Error"]["Message"],
        })
        return {
            "trigger_status": "TRIGGER_FAILED",
            "task_arn": "",
            "error": str(e),
        }
