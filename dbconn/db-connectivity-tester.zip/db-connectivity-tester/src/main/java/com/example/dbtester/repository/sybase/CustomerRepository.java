package com.example.dbtester.repository.sybase;

import com.example.dbtester.entity.Customer;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Repository
public class CustomerRepository {

    private static final String TABLE = "CUSTOMER";

    private static final String SQL_FIND_ALL =
            "SELECT id, first_name, last_name, email, created_at FROM CUSTOMER";

    private static final String SQL_FIND_BY_ID =
            "SELECT id, first_name, last_name, email, created_at FROM CUSTOMER WHERE id = ?";

    private static final String SQL_UPDATE =
            "UPDATE CUSTOMER SET first_name = ?, last_name = ?, email = ? WHERE id = ?";

    private static final String SQL_DELETE =
            "DELETE FROM CUSTOMER WHERE id = ?";

    private final JdbcTemplate jdbc;
    private final SimpleJdbcInsert insert;
    private final CustomerRowMapper rowMapper = new CustomerRowMapper();

    public CustomerRepository(@Qualifier("sybaseJdbcTemplate") JdbcTemplate jdbc,
                              @Qualifier("sybaseDataSource") DataSource ds) {
        this.jdbc = jdbc;
        this.insert = new SimpleJdbcInsert(ds)
                .withTableName(TABLE)
                .usingGeneratedKeyColumns("id");
    }

    public List<Customer> findAll() {
        return jdbc.query(SQL_FIND_ALL, rowMapper);
    }

    public Optional<Customer> findById(Long id) {
        return jdbc.query(SQL_FIND_BY_ID, rowMapper, id).stream().findFirst();
    }

    public Customer insert(Customer customer) {
        Map<String, Object> params = Map.of(
                "first_name", customer.firstName(),
                "last_name",  customer.lastName(),
                "email",      customer.email(),
                "created_at", Timestamp.valueOf(LocalDateTime.now())
        );
        Number key = insert.executeAndReturnKey(params);
        return findById(key.longValue()).orElseThrow();
    }

    public int update(Long id, Customer customer) {
        return jdbc.update(SQL_UPDATE,
                customer.firstName(),
                customer.lastName(),
                customer.email(),
                id);
    }

    public int delete(Long id) {
        return jdbc.update(SQL_DELETE, id);
    }
}
