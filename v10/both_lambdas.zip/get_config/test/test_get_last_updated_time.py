"""Unit tests for the get_last_updated_time helper."""

from datetime import datetime

from get_config.dynamodb_ops import get_last_updated_time


class TestGetLastUpdatedTime:

    def test_returns_provided_value_when_given(self):
        assert get_last_updated_time("2024-03-15T10:00:00Z") == "2024-03-15T10:00:00Z"

    def test_auto_sets_when_none(self):
        """None input → returns a valid ISO-8601 UTC timestamp."""
        result = get_last_updated_time(None)
        assert isinstance(result, str)
        assert result.endswith("Z")
        # Sanity-check the format
        datetime.strptime(result, "%Y-%m-%dT%H:%M:%SZ")

    def test_auto_sets_when_empty_string(self):
        """Empty string → also auto-sets (treated as 'not provided')."""
        result = get_last_updated_time("")
        assert result != ""
        assert result.endswith("Z")

    def test_auto_sets_when_omitted(self):
        """No argument → auto-sets."""
        result = get_last_updated_time()
        assert result.endswith("Z")
