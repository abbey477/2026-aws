import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Row mappers for {@link InstrumentLink}.
 *
 * <p>Two static methods so the migration class can A/B them on identical data:
 * <ul>
 *   <li>{@link #mapByIndex(ResultSet)} — positional reads, fastest, fragile
 *       to SELECT column reordering.</li>
 *   <li>{@link #mapByName(ResultSet)} — name-based reads, robust to column
 *       reordering, slight per-cell overhead.</li>
 * </ul>
 *
 * <p>Type-handling notes (consistent across all migrations):
 * <ul>
 *   <li>{@code Integer}/{@code Float} fields use the cast pattern
 *       {@code (T) rs.getObject(...)} because jconn4 doesn't support the
 *       two-arg {@code getObject(idx, Class)} overload. Casting null is safe.</li>
 *   <li>{@code Date} fields use {@code rs.getTimestamp(...)} assuming
 *       {@code java.util.Date}. If any field is {@code java.sql.Date},
 *       swap that specific call to {@code rs.getDate}.</li>
 * </ul>
 */
public final class InstrumentLinkRowMapper {

    private InstrumentLinkRowMapper() {
        // utility class
    }

    /** Positional read — column index MUST match SELECT order. */
    public static InstrumentLink mapByIndex(ResultSet rs) throws SQLException {
        InstrumentLink row = new InstrumentLink();
        row.setID_IMNT_1(    (Integer) rs.getObject(1));
        row.setID_IMNT_2(    (Integer) rs.getObject(2));
        row.setID_PURP_LINK(           rs.getString(3));
        row.setAM_RATIO(       (Float) rs.getObject(4));
        row.setDT_EFF(                 rs.getTimestamp(5));
        row.setID_USER(                rs.getString(6));
        row.setDT_CHG_GRD(             rs.getTimestamp(7));
        row.setID_DEL_GRD(   (Integer) rs.getObject(8));
        row.setID_OWN_GRD(   (Integer) rs.getObject(9));
        return row;
    }

    /** Name-based read — robust to SELECT column reordering. */
    public static InstrumentLink mapByName(ResultSet rs) throws SQLException {
        InstrumentLink row = new InstrumentLink();
        row.setID_IMNT_1(    (Integer) rs.getObject("ID_IMNT_1"));
        row.setID_IMNT_2(    (Integer) rs.getObject("ID_IMNT_2"));
        row.setID_PURP_LINK(           rs.getString("ID_PURP_LINK"));
        row.setAM_RATIO(       (Float) rs.getObject("AM_RATIO"));
        row.setDT_EFF(                 rs.getTimestamp("DT_EFF"));
        row.setID_USER(                rs.getString("ID_USER"));
        row.setDT_CHG_GRD(             rs.getTimestamp("DT_CHG_GRD"));
        row.setID_DEL_GRD(   (Integer) rs.getObject("ID_DEL_GRD"));
        row.setID_OWN_GRD(   (Integer) rs.getObject("ID_OWN_GRD"));
        return row;
    }
}
