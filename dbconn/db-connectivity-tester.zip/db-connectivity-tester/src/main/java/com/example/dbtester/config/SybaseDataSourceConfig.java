package com.example.dbtester.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;

@Configuration
public class SybaseDataSourceConfig {

    private static final String DS_KEY = "sybase";

    private final DataSourceProperties.DbConfig config;

    public SybaseDataSourceConfig(DataSourceProperties properties) {
        this.config = properties.datasources().get(DS_KEY);
        if (this.config == null) {
            throw new IllegalStateException("Missing configuration for datasource: " + DS_KEY);
        }
    }

    @Bean(name = "sybaseDataSource", destroyMethod = "close")
    public DataSource sybaseDataSource() {
        return HikariDataSourceFactory.build(DS_KEY, config);
    }

    @Bean(name = "sybaseJdbcTemplate")
    public JdbcTemplate sybaseJdbcTemplate(DataSource sybaseDataSource) {
        return new JdbcTemplate(sybaseDataSource);
    }

    @Bean(name = "sybaseTxManager")
    public PlatformTransactionManager sybaseTxManager(DataSource sybaseDataSource) {
        return new DataSourceTransactionManager(sybaseDataSource);
    }
}
