package com.example.myapp;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.test.context.ActiveProfiles;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("test")
class MyAppRestApplicationTests {

    @LocalServerPort
    int port;

    @Autowired
    TestRestTemplate rest;

    @Test
    void getConfigReturnsBoundProperties() {
        String body = rest.getForObject("http://localhost:" + port + "/api/config", String.class);
        assertThat(body).contains("\"name\":\"myapp-rest\"");
        assertThat(body).contains("\"environment\":\"test\"");
    }

    @Test
    void getConfigDbReturnsNestedRecord() {
        String body = rest.getForObject("http://localhost:" + port + "/api/config/db", String.class);
        assertThat(body).contains("\"username\":\"test\"");
        assertThat(body).contains("\"poolSize\":2");
    }
}
