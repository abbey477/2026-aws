package com.example.dbtester.config;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;

/**
 * Sybase datasource + JdbcTemplate + transaction manager.
 * Not @Primary - Oracle wins any ambiguous injection.
 * Use @Qualifier("sybaseJdbcTemplate") etc. to inject these.
 */
@Configuration
public class SybaseDataSourceConfig {

    @Bean(name = "sybaseDataSource", destroyMethod = "close")
    public DataSource sybaseDataSource(AppProperties props) {
        AppProperties.Sybase cfg = props.sybase();
        AppProperties.SybaseHikari h = cfg.hikari();

        HikariConfig hikari = new HikariConfig();
        hikari.setJdbcUrl(cfg.url());
        hikari.setUsername(cfg.username());
        hikari.setPassword(cfg.password());
        hikari.setDriverClassName(cfg.driverClassName());

        hikari.setMaximumPoolSize(h.maximumPoolSize());
        hikari.setMinimumIdle(h.minimumIdle());
        hikari.setConnectionTimeout(h.connectionTimeoutMs());
        hikari.setIdleTimeout(h.idleTimeoutMs());
        hikari.setMaxLifetime(h.maxLifetimeMs());
        hikari.setPoolName(h.poolName());

        cfg.properties().forEach(hikari::addDataSourceProperty);
        hikari.setConnectionTestQuery(cfg.validationQueries().get(0));

        return new HikariDataSource(hikari);
    }

    @Bean(name = "sybaseJdbcTemplate")
    public JdbcTemplate sybaseJdbcTemplate(DataSource sybaseDataSource) {
        return new JdbcTemplate(sybaseDataSource);
    }

    @Bean(name = "sybaseTxManager")
    public PlatformTransactionManager sybaseTxManager(DataSource sybaseDataSource) {
        return new DataSourceTransactionManager(sybaseDataSource);
    }
}
