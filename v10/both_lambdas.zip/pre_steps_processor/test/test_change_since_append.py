"""
change_since_append — direct query helper tests + end-to-end.

Exercises get_last_successful_run_start_time against a moto-backed job_run
table with GSI-2, plus the full lambda path with real step_handlers wired in.
"""

import pytest
from botocore.exceptions import ClientError

from pre_steps_processor.dynamodb_ops import get_last_successful_run_start_time
from seed_data import raise_access_denied


class TestGetLastSuccessfulRunStartTime:
    """Direct tests for the GSI-2 query helper."""

    def test_returns_start_time_of_most_recent_success(self, job_run_table):
        """
        Seed three runs for job_id=client, job_type=sourcing:
          old success / newer failed / newest success
        Query should return the NEWEST COMPLETED start_time.
        """
        job_run_table.put_item(Item={
            "run_id": "r1", "last_updated_time": "2024-01-01T00:00:00Z",
            "job_id": "client", "job_type": "sourcing",
            "status": "COMPLETED", "start_time": "2024-01-01T00:00:00Z",
        })
        job_run_table.put_item(Item={
            "run_id": "r2", "last_updated_time": "2024-02-01T00:00:00Z",
            "job_id": "client", "job_type": "sourcing",
            "status": "FAILED", "start_time": "2024-02-01T00:00:00Z",
        })
        job_run_table.put_item(Item={
            "run_id": "r3", "last_updated_time": "2024-03-01T00:00:00Z",
            "job_id": "client", "job_type": "sourcing",
            "status": "COMPLETED", "start_time": "2024-03-01T00:00:00Z",
        })

        result = get_last_successful_run_start_time(
            table=job_run_table, job_id="client", job_type="sourcing",
        )
        assert result == "2024-03-01T00:00:00Z"

    def test_ignores_other_job_types(self, job_run_table):
        """Rows with same job_id but different job_type shouldn't match."""
        job_run_table.put_item(Item={
            "run_id": "r1", "last_updated_time": "2024-01-01T00:00:00Z",
            "job_id": "client", "job_type": "sourcing",
            "status": "COMPLETED", "start_time": "2024-01-01T00:00:00Z",
        })
        job_run_table.put_item(Item={
            "run_id": "r2", "last_updated_time": "2024-06-01T00:00:00Z",
            "job_id": "client", "job_type": "other_type",
            "status": "COMPLETED", "start_time": "2024-06-01T00:00:00Z",
        })

        result = get_last_successful_run_start_time(
            table=job_run_table, job_id="client", job_type="sourcing",
        )
        assert result == "2024-01-01T00:00:00Z"

    def test_ignores_non_success_statuses(self, job_run_table):
        """Only COMPLETED should be returned."""
        job_run_table.put_item(Item={
            "run_id": "r1", "last_updated_time": "2024-05-01T00:00:00Z",
            "job_id": "client", "job_type": "sourcing",
            "status": "FAILED", "start_time": "2024-05-01T00:00:00Z",
        })
        job_run_table.put_item(Item={
            "run_id": "r2", "last_updated_time": "2024-06-01T00:00:00Z",
            "job_id": "client", "job_type": "sourcing",
            "status": "RUNNING", "start_time": "2024-06-01T00:00:00Z",
        })

        result = get_last_successful_run_start_time(
            table=job_run_table, job_id="client", job_type="sourcing",
        )
        assert result is None

    def test_returns_none_when_no_rows(self, job_run_table):
        """Brand-new job with no runs — placeholder None returned."""
        result = get_last_successful_run_start_time(
            table=job_run_table, job_id="never-ran", job_type="sourcing",
        )
        assert result is None

    def test_client_error_propagates(self, monkeypatch, job_run_table):
        """ClientError from DynamoDB surfaces to caller, not swallowed."""
        monkeypatch.setattr(job_run_table, "query", raise_access_denied)

        with pytest.raises(ClientError):
            get_last_successful_run_start_time(
                table=job_run_table, job_id="client", job_type="sourcing",
            )
