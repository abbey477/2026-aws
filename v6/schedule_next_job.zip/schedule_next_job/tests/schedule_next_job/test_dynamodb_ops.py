"""
Tests for dynamodb_ops.py — using moto-backed real DynamoDB tables.

Tests:
1. get_next_job_config returns item when found.
2. get_next_job_config returns empty dict when not found.
3. get_current_time_iso / get_next_minute_iso return valid ISO 8601.
4. put_job_run inserts item correctly.
"""
import re

import pytest
from botocore.exceptions import ClientError

from dynamodb_ops import (
    get_current_time_iso,
    get_next_minute_iso,
    get_next_job_config,
    put_job_run,
)

ISO_8601_REGEX = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$")


class TestGetNextJobConfig:
    """Tests for the get_next_job_config helper function."""

    def test_get_next_job_config_found(self, dynamodb_setup):
        """Test that existing child config is returned."""
        _, _, job_config_table = dynamodb_setup

        result = get_next_job_config(job_config_table, "dbr_client", "silver_load")

        assert result["job_id"] == "dbr_client"
        assert result["trigger_type"] == "PIPELINE"
        assert result["job_runner"]["name"] == "DBR"

    def test_get_next_job_config_not_found(self, dynamodb_setup):
        """Test that missing child config returns empty dict."""
        _, _, job_config_table = dynamodb_setup

        result = get_next_job_config(job_config_table, "nonexistent", "missing")

        assert result == {}

    def test_get_next_job_config_calls_correct_key(self, dynamodb_setup):
        """Test that both job_id and job_type are used as the lookup key."""
        _, _, job_config_table = dynamodb_setup

        # Same job_id, wrong job_type — must not match.
        result = get_next_job_config(job_config_table, "dbr_client", "wrong_type")
        assert result == {}

        # Correct composite key — must match.
        result = get_next_job_config(job_config_table, "dbr_client", "silver_load")
        assert result != {}


class TestPutJobRun:
    """Tests for the put_job_run helper."""

    def test_put_job_run_inserts_item(self, dynamodb_setup):
        """Test that put_job_run writes the item to DynamoDB."""
        _, job_run_table, _ = dynamodb_setup

        item = {
            "run_id": "test-run-999",
            "job_id": "dbr_client",
            "job_type": "silver_load",
            "trigger_type": "PIPELINE",
            "status": "WAITING",
            "start_time": "",
            "end_time": "",
            "next_scheduled_run_time": "2024-04-01T00:01:00Z",
            "last_heartbeat_time": "",
            "expiry_time": "",
            "mark_for_delete": False,
            "custom_attributes": {"s3_path": "s3://bucket/data"},
            "error": "",
            "delete_at": 0,
        }

        put_job_run(job_run_table, item)

        stored = job_run_table.get_item(Key={"run_id": "test-run-999"})["Item"]
        assert stored["job_id"] == "dbr_client"
        assert stored["status"] == "WAITING"
        assert stored["custom_attributes"] == {"s3_path": "s3://bucket/data"}


class TestTimeHelpers:
    """Tests for get_current_time_iso and get_next_minute_iso."""

    def test_current_time_iso_format(self):
        result = get_current_time_iso()
        assert ISO_8601_REGEX.match(result), f"Bad format: {result}"

    def test_next_minute_iso_format(self):
        result = get_next_minute_iso()
        assert ISO_8601_REGEX.match(result), f"Bad format: {result}"

    def test_next_minute_is_after_current(self):
        current = get_current_time_iso()
        next_min = get_next_minute_iso()
        assert next_min > current
