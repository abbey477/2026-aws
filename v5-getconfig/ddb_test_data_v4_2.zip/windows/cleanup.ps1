# cleanup.ps1 — delete ALL items from app-jobConfig, app-jobRun, app-jobLog
# (Tables themselves are preserved.)
$ErrorActionPreference = "Stop"
Set-Location -Path $PSScriptRoot

# Table -> @(pk_name, sk_name)
$Tables = [ordered]@{
    "app-jobConfig" = @("job_id", "job_type")
    "app-jobRun"    = @("run_id", "last_updated_time")
    "app-jobLog"    = @("run_id", "time")
}

Write-Host "=== Cleanup ===" -ForegroundColor Yellow
Write-Host "This will DELETE every item from:"
foreach ($t in $Tables.Keys) { Write-Host "  - $t" }
Write-Host "(The tables themselves will remain.)"
$confirm = Read-Host "Type 'yes' to confirm"
if ($confirm -ne "yes") {
    Write-Host "Aborted."
    exit 1
}

foreach ($table in $Tables.Keys) {
    $pk = $Tables[$table][0]
    $sk = $Tables[$table][1]
    Write-Host ""
    Write-Host ">>> $table (keys: $pk, $sk)"

    # Paginate through scan to collect all key tuples
    $allKeys = @()
    $nextToken = $null
    do {
        $attrNames = '{\"#pk\":\"' + $pk + '\",\"#sk\":\"' + $sk + '\"}'
        if ($nextToken) {
            $respJson = aws dynamodb scan `
                --table-name $table `
                --projection-expression "#pk, #sk" `
                --expression-attribute-names $attrNames `
                --starting-token $nextToken `
                --output json
        } else {
            $respJson = aws dynamodb scan `
                --table-name $table `
                --projection-expression "#pk, #sk" `
                --expression-attribute-names $attrNames `
                --output json
        }
        if ($LASTEXITCODE -ne 0) { Write-Error "Scan failed on $table"; exit 1 }

        $resp = $respJson | ConvertFrom-Json
        if ($resp.Items) { $allKeys += $resp.Items }
        $nextToken = $resp.NextToken
    } while ($nextToken)

    if ($allKeys.Count -eq 0) {
        Write-Host "    (already empty)" -ForegroundColor DarkGray
        continue
    }

    # Delete in batches of 25
    $deleted = 0
    $tmp = Join-Path $env:TEMP "_ddb_del_batch.json"
    for ($i = 0; $i -lt $allKeys.Count; $i += 25) {
        $chunk = $allKeys[$i..([Math]::Min($i + 24, $allKeys.Count - 1))]
        $requests = @()
        foreach ($k in $chunk) {
            $key = [ordered]@{}
            $key[$pk] = $k.$pk
            $key[$sk] = $k.$sk
            $requests += @{ DeleteRequest = @{ Key = $key } }
        }
        $payload = [ordered]@{ $table = $requests }
        $json = $payload | ConvertTo-Json -Depth 10 -Compress
        # Write UTF-8 without BOM — Windows PS 5.1 adds a BOM with Set-Content -Encoding UTF8,
        # which can break `aws ... file://...`. Use .NET directly to be safe.
        [System.IO.File]::WriteAllText($tmp, $json, (New-Object System.Text.UTF8Encoding($false)))

        aws dynamodb batch-write-item --request-items "file://$tmp" | Out-Null
        if ($LASTEXITCODE -ne 0) { Write-Error "batch-write-item failed on $table"; exit 1 }
        $deleted += $chunk.Count
    }
    Remove-Item $tmp -ErrorAction SilentlyContinue
    Write-Host "    deleted $deleted items" -ForegroundColor Green
}

Write-Host ""
Write-Host "Counts after cleanup:"
foreach ($t in $Tables.Keys) {
    $c = aws dynamodb scan --table-name $t --select COUNT --query Count --output text
    Write-Host "  ${t}: $c"
}
