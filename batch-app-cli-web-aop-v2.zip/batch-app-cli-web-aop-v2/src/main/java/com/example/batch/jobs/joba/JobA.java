package com.example.batch.jobs.joba;

import com.example.batch.common.service.SimulatedProcessingService;
import com.example.batch.core.BatchJob;
import com.example.batch.core.JobContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class JobA implements BatchJob {

    private static final Logger log = LoggerFactory.getLogger(JobA.class);
    private final SimulatedProcessingService service;

    public JobA(SimulatedProcessingService service) {
        this.service = service;
    }

    @Override
    public String getName() { return "jobA"; }

    @Override
    public void execute(JobContext ctx) {
        log.info(">>> JobA running for runDate={}", ctx.getRunDate());
        service.process("jobA", ctx.getRunDate());
        log.info("<<< JobA done");
    }
}
