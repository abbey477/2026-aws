package com.example.myapp.jobs;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class JobC implements Job {

    private static final Logger log = LoggerFactory.getLogger(JobC.class);

    @Override
    public String name() {
        return "jobC";
    }

    @Override
    public void run() {
        log.info("==> JobC starting");
        log.info("    JobC doing yet another thing...");
        log.info("==> JobC finished");
    }
}
