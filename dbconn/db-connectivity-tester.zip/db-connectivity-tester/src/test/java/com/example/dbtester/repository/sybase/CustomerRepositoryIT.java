package com.example.dbtester.repository.sybase;

import com.example.dbtester.entity.Customer;
import com.zaxxer.hikari.HikariDataSource;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
import org.springframework.jdbc.datasource.init.ScriptUtils;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Exercises CustomerRepository SQL against H2 in MSSQLServer compatibility mode.
 *
 * NOTE: H2 has no Sybase mode. MSSQLServer mode is the closest proxy — IDENTITY
 * columns behave the same way SimpleJdbcInsert (and jConnect-driven code) expect.
 * This validates the CRUD logic; driver-specific behavior must still be tested
 * against a real Sybase instance.
 */
class CustomerRepositoryIT {

    private HikariDataSource ds;
    private CustomerRepository repository;

    @BeforeEach
    void setUp() {
        ds = new HikariDataSource();
        ds.setJdbcUrl("jdbc:h2:mem:customerRepoIT;MODE=MSSQLServer;DB_CLOSE_DELAY=-1");
        ds.setDriverClassName("org.h2.Driver");
        ds.setUsername("sa");
        ds.setPassword("");

        new ResourceDatabasePopulator(new ClassPathResource("sql/customer-h2-schema.sql"))
                .execute(ds);

        JdbcTemplate template = new JdbcTemplate(ds);
        repository = new CustomerRepository(template, ds);
    }

    @AfterEach
    void tearDown() {
        try (var c = ds.getConnection()) {
            ScriptUtils.executeSqlScript(c,
                    new ByteArrayResource("DROP TABLE CUSTOMER;".getBytes()));
        } catch (Exception ignored) {}
        ds.close();
    }

    @Test
    void insertAssignsIdentityId() {
        Customer created = repository.insert(
                new Customer(null, "Ada", "Lovelace", "ada@example.com", null));

        assertThat(created.id()).isNotNull();
        assertThat(created.firstName()).isEqualTo("Ada");
        assertThat(created.createdAt()).isNotNull();
    }

    @Test
    void findByIdReturnsInsertedCustomer() {
        Customer created = repository.insert(
                new Customer(null, "Grace", "Hopper", "g@h.com", null));

        Optional<Customer> loaded = repository.findById(created.id());

        assertThat(loaded).isPresent();
        assertThat(loaded.get().email()).isEqualTo("g@h.com");
    }

    @Test
    void findByIdReturnsEmptyWhenMissing() {
        assertThat(repository.findById(9999L)).isEmpty();
    }

    @Test
    void findAllReturnsAllRows() {
        repository.insert(new Customer(null, "A", "One", "a@x.com", null));
        repository.insert(new Customer(null, "B", "Two", "b@x.com", null));

        List<Customer> all = repository.findAll();

        assertThat(all).hasSize(2);
        assertThat(all).extracting(Customer::email).containsExactlyInAnyOrder("a@x.com", "b@x.com");
    }

    @Test
    void updateChangesValues() {
        Customer created = repository.insert(
                new Customer(null, "Old", "Name", "old@x.com", null));

        int rows = repository.update(created.id(),
                new Customer(created.id(), "New", "Name", "new@x.com", created.createdAt()));

        assertThat(rows).isEqualTo(1);
        Customer reloaded = repository.findById(created.id()).orElseThrow();
        assertThat(reloaded.firstName()).isEqualTo("New");
        assertThat(reloaded.email()).isEqualTo("new@x.com");
    }

    @Test
    void updateReturnsZeroWhenIdMissing() {
        int rows = repository.update(9999L,
                new Customer(9999L, "X", "Y", "z@x.com", null));

        assertThat(rows).isZero();
    }

    @Test
    void deleteRemovesRow() {
        Customer created = repository.insert(
                new Customer(null, "Del", "Me", "del@x.com", null));

        assertThat(repository.delete(created.id())).isEqualTo(1);
        assertThat(repository.findById(created.id())).isEmpty();
    }

    @Test
    void deleteReturnsZeroWhenIdMissing() {
        assertThat(repository.delete(9999L)).isZero();
    }
}
