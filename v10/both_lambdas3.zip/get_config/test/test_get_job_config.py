"""Repository-level tests for get_job_config."""
import pytest
from botocore.exceptions import ClientError
from get_config.dynamodb_ops import get_job_config
from seed_data import raise_access_denied


class TestGetJobConfig:

    def test_returns_item(self, dynamodb_tables):
        result = get_job_config(dynamodb_tables.Table("app-jobConfig"), "client", "sourcing")
        assert result["job_id"] == "client"
        assert result["job_runner"]["name"] == "S2S3"

    def test_pre_steps_present(self, dynamodb_tables):
        result = get_job_config(dynamodb_tables.Table("app-jobConfig"), "client", "sourcing")
        assert len(result["pre_steps"]) == 2

    def test_raises_when_not_found(self, dynamodb_tables):
        with pytest.raises(ValueError, match="No job_config found"):
            get_job_config(dynamodb_tables.Table("app-jobConfig"), "client", "nonexistent")

    def test_raises_on_client_error(self, dynamodb_tables, monkeypatch):
        table = dynamodb_tables.Table("app-jobConfig")
        monkeypatch.setattr(table, "get_item", raise_access_denied)
        with pytest.raises(ClientError):
            get_job_config(table, "client", "sourcing")
