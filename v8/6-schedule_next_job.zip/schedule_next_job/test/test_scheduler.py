"""Tests for scheduler.py"""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from schedule_next_job.scheduler import schedule_next_jobs


class TestScheduleNextJobsHelper:

    def test_creates_entries(self, dynamodb_setup):
        _, job_run_table, job_config_table, _ = dynamodb_setup
        ids = schedule_next_jobs(job_run_table, job_config_table,
                                 [{"type": "silver_load", "id": "dbr_client"}],
                                 {"s3_path": "s3://bucket/data"})
        assert len(ids) == 1
        item = job_run_table.get_item(Key={"run_id": ids[0]})["Item"]
        assert item["job_id"] == "dbr_client"
        assert item["status"] == "WAITING"
        assert item["custom_attributes"] == {"s3_path": "s3://bucket/data"}

    def test_empty_returns_empty_list(self, dynamodb_setup):
        _, job_run_table, job_config_table, _ = dynamodb_setup
        assert schedule_next_jobs(job_run_table, job_config_table, [], {}) == []

    def test_item_fields(self, dynamodb_setup):
        _, job_run_table, job_config_table, _ = dynamodb_setup
        ids = schedule_next_jobs(job_run_table, job_config_table,
                                 [{"type": "silver_load", "id": "dbr_client"}], {})
        item = job_run_table.get_item(Key={"run_id": ids[0]})["Item"]
        assert item["trigger_type"] == "PIPELINE"
        assert item["mark_for_delete"] is False
        assert item["error"] == ""
        assert item["delete_at"] == 0

    def test_multiple_next_jobs(self, dynamodb_setup):
        _, job_run_table, job_config_table, _ = dynamodb_setup
        ids = schedule_next_jobs(job_run_table, job_config_table,
                                 [{"type": "silver_load", "id": "dbr_client"},
                                  {"type": "gold_load",   "id": "dbr_gold"}], {})
        assert len(ids) == 2
        job_ids = {job_run_table.get_item(Key={"run_id": i})["Item"]["job_id"] for i in ids}
        assert job_ids == {"dbr_client", "dbr_gold"}

    def test_missing_config_uses_defaults(self, dynamodb_setup):
        _, job_run_table, job_config_table, _ = dynamodb_setup
        ids = schedule_next_jobs(job_run_table, job_config_table,
                                 [{"type": "no_type", "id": "no_job"}], {})
        assert len(ids) == 1
        assert job_run_table.get_item(Key={"run_id": ids[0]})["Item"]["status"] == "WAITING"

    def test_run_ids_are_unique(self, dynamodb_setup):
        _, job_run_table, job_config_table, _ = dynamodb_setup
        ids = schedule_next_jobs(job_run_table, job_config_table,
                                 [{"type": "silver_load", "id": "dbr_client"},
                                  {"type": "gold_load",   "id": "dbr_gold"}], {})
        assert len(set(ids)) == len(ids)
