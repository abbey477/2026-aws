"""
conftest.py
Shared pytest fixtures for the UpdateJobStatus Lambda test suite.
"""

import boto3
import pytest
from moto import mock_aws
from unittest.mock import patch


# ---------------------------------------------------------------------------
# Auto-mock write_log so no real DynamoDB audit writes happen in any test
# ---------------------------------------------------------------------------
@pytest.fixture(autouse=True)
def _mock_write_log():
    """Prevent write_log from hitting real DynamoDB in all tests."""
    with patch("lambdas.update_job_status.handler.write_log"):
        yield


# ---------------------------------------------------------------------------
# DynamoDB mock table
# ---------------------------------------------------------------------------
@pytest.fixture
def dynamodb_setup():
    """Create a mock DynamoDB table for job_run and seed a record."""
    with mock_aws():
        dynamodb = boto3.resource("dynamodb", region_name="us-east-1")

        table = dynamodb.create_table(
            TableName="job_run",
            KeySchema=[{"AttributeName": "run_id", "KeyType": "HASH"}],
            AttributeDefinitions=[
                {"AttributeName": "run_id", "AttributeType": "S"}
            ],
            BillingMode="PAY_PER_REQUEST",
        )

        # Seed a baseline job_run record
        table.put_item(
            Item={
                "run_id": "run-001",
                "job_id": "client",
                "job_type": "sourcing",
                "trigger_type": "SCHEDULER",
                "status": "WAITING",
                "start_time": "",
                "end_time": "",
                "next_scheduled_run_time": "",
                "last_heartbeat_time": "",
                "expiry_time": "",
                "mark_for_delete": False,
                "custom_attributes": {},
                "error": "",
                "delete_at": 0,
            }
        )

        yield dynamodb, table


# ---------------------------------------------------------------------------
# Event builder helper
# ---------------------------------------------------------------------------
def make_event(
    job_status: str = "SUCCESS",
    trigger_status: str = "TRIGGERED",
    job_output=None,
    next_jobs=None,
) -> dict:
    """Build a sample Lambda event payload."""
    return {
        "run_id": "run-001",
        "job_id": "client",
        "job_type": "sourcing",
        "status": "WAITING",
        "job_config": {
            "job_runner": {"name": "S2S3", "type": "ECS_FARGATE"},
            "job_param": {"output": ["s3_path"]},
            "next_jobs": next_jobs or [],
        },
        "trigger_result": {
            "trigger_status": trigger_status,
            "runner_type": "ECS",
            "runner_name": "S2S3",
            "task_arn": "arn:aws:ecs:us-east-1:123:task/cluster/abc123",
            "job_status": job_status,
            "output": job_output or {},
        },
    }
