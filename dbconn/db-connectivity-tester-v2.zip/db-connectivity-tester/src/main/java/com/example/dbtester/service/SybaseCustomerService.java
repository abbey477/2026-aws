package com.example.dbtester.service;

import com.example.dbtester.dto.CustomerRequest;
import com.example.dbtester.entity.Customer;
import com.example.dbtester.exception.ResourceNotFoundException;
import com.example.dbtester.repository.sybase.CustomerRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Orchestrates Customer CRUD against Sybase.
 *
 * <p>Mirrors {@link OracleProductService} in shape. The critical difference
 * is the {@code transactionManager = "sybaseTxManager"} qualifier on every
 * {@code @Transactional} — without it, Spring would grab the @Primary
 * (Oracle) manager and your "Sybase transaction" would be a no-op
 * against the wrong database.
 */
@Service
public class SybaseCustomerService {

    private final CustomerRepository repository;

    public SybaseCustomerService(CustomerRepository repository) {
        this.repository = repository;
    }

    @Transactional(transactionManager = "sybaseTxManager", readOnly = true)
    public List<Customer> findAll() {
        return repository.findAll();
    }

    @Transactional(transactionManager = "sybaseTxManager", readOnly = true)
    public Customer findById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found: " + id));
    }

    /**
     * Create. The DB assigns the identity id, the repo re-reads the row so
     * we also get the server-side {@code created_at} timestamp back.
     */
    @Transactional(transactionManager = "sybaseTxManager")
    public Customer create(CustomerRequest request) {
        Customer toCreate = new Customer(null, request.firstName(), request.lastName(), request.email(), null);
        return repository.insert(toCreate);
    }

    /**
     * Update-or-404. Preserves the original {@code createdAt} — update is
     * about mutable fields only, not re-stamping creation time.
     */
    @Transactional(transactionManager = "sybaseTxManager")
    public Customer update(Long id, CustomerRequest request) {
        Customer existing = findById(id);
        Customer updated = new Customer(
                existing.id(),
                request.firstName(),
                request.lastName(),
                request.email(),
                existing.createdAt()
        );
        int rows = repository.update(id, updated);
        if (rows == 0) {
            throw new ResourceNotFoundException("Customer not found: " + id);
        }
        return updated;
    }

    @Transactional(transactionManager = "sybaseTxManager")
    public void delete(Long id) {
        int rows = repository.delete(id);
        if (rows == 0) {
            throw new ResourceNotFoundException("Customer not found: " + id);
        }
    }

    // =========================================================================
    //  Bulk operations
    // =========================================================================

    /**
     * Bulk insert wrapped in a single transaction.
     *
     * <p>Returns row count, not ids — Sybase IDENTITY + JDBC batch doesn't
     * surface generated keys reliably. See {@link CustomerRepository#insertAll}
     * for options if you need the ids back.
     */
    @Transactional(transactionManager = "sybaseTxManager")
    public int createAll(List<CustomerRequest> requests) {
        List<Customer> toInsert = requests.stream()
                .map(r -> new Customer(null, r.firstName(), r.lastName(), r.email(), null))
                .toList();
        return repository.insertAll(toInsert);
    }

    /**
     * Bulk update by id.
     */
    @Transactional(transactionManager = "sybaseTxManager")
    public int updateAll(List<Customer> customers) {
        return repository.updateAll(customers);
    }

    /**
     * Bulk delete by id list.
     */
    @Transactional(transactionManager = "sybaseTxManager")
    public int deleteAll(List<Long> ids) {
        return repository.deleteAll(ids);
    }
}
