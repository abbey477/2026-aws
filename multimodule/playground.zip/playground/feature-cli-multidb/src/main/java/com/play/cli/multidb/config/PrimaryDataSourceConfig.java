package com.play.cli.multidb.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.sql.DataSource;

/**
 * Beans for the "primary" datasource. Marked {@link Primary} so a plain
 * {@code @Autowired DataSource} (no qualifier) resolves to this one.
 */
@Configuration
public class PrimaryDataSourceConfig {

    private static final String KEY = "primary";

    private final DataSourceProperties.DbConfig cfg;

    public PrimaryDataSourceConfig(DataSourceProperties props) {
        this.cfg = props.datasources().get(KEY);
    }

    @Primary
    @Bean(name = "primaryDataSource", destroyMethod = "close")
    public DataSource primaryDataSource() {
        return DataSourceFactory.build(KEY, cfg);
    }

    @Primary
    @Bean(name = "primaryJdbcTemplate")
    public JdbcTemplate primaryJdbcTemplate(DataSource primaryDataSource) {
        return new JdbcTemplate(primaryDataSource);
    }
}
