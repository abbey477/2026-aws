"""Shared pytest fixtures for PreStepsProcessor tests."""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

import pytest
import boto3
from moto import mock_aws
from unittest.mock import patch

HANDLER_PATH = "pre_steps_processor.handler"


@pytest.fixture(autouse=True)
def mock_write_log():
    with patch(f"{HANDLER_PATH}.write_log") as m:
        yield m


@pytest.fixture
def mocks(mock_write_log):
    with patch(f"{HANDLER_PATH}.handle_no_pre_steps", return_value={}) as no_data, \
         patch(f"{HANDLER_PATH}.handle_change_since_append", return_value={}) as change_since, \
         patch(f"{HANDLER_PATH}.handle_ddb_config_pull", return_value={}) as ddb_pull, \
         patch(f"{HANDLER_PATH}.handle_unknown_pre_step", return_value={}) as unknown:
        yield {
            "no_data": no_data, "change_since": change_since,
            "ddb_pull": ddb_pull, "unknown": unknown,
        }


@pytest.fixture
def job_run_table():
    with mock_aws():
        dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
        table = dynamodb.create_table(
            TableName="app-jobRun",
            KeySchema=[
                {"AttributeName": "run_id", "KeyType": "HASH"},
                {"AttributeName": "last_updated_time", "KeyType": "RANGE"},
            ],
            AttributeDefinitions=[
                {"AttributeName": "run_id", "AttributeType": "S"},
                {"AttributeName": "last_updated_time", "AttributeType": "S"},
                {"AttributeName": "job_id", "AttributeType": "S"},
                {"AttributeName": "start_time", "AttributeType": "S"},
            ],
            GlobalSecondaryIndexes=[{
                "IndexName": "jobIdQuery",
                "KeySchema": [
                    {"AttributeName": "job_id", "KeyType": "HASH"},
                    {"AttributeName": "start_time", "KeyType": "RANGE"},
                ],
                "Projection": {"ProjectionType": "ALL"},
            }],
            BillingMode="PAY_PER_REQUEST",
        )
        yield table


@pytest.fixture
def config_tables():
    with mock_aws():
        dynamodb = boto3.resource("dynamodb", region_name="us-east-1")
        created = {}
        for name in ("service_config", "table_config"):
            t = dynamodb.create_table(
                TableName=name,
                KeySchema=[
                    {"AttributeName": "job_id", "KeyType": "HASH"},
                    {"AttributeName": "job_type", "KeyType": "RANGE"},
                ],
                AttributeDefinitions=[
                    {"AttributeName": "job_id", "AttributeType": "S"},
                    {"AttributeName": "job_type", "AttributeType": "S"},
                ],
                BillingMode="PAY_PER_REQUEST",
            )
            created[name] = t
        yield dynamodb, created
