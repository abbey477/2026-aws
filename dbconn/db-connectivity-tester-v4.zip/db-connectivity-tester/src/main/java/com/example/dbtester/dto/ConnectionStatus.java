package com.example.dbtester.dto;

public record ConnectionStatus(
        String datasource,
        String status,   // UP / DOWN / UNKNOWN
        long latencyMs,
        String message
) {}
