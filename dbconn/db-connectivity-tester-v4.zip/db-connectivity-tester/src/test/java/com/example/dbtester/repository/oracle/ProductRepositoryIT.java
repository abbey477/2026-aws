package com.example.dbtester.repository.oracle;

import com.example.dbtester.entity.Product;
import com.zaxxer.hikari.HikariDataSource;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
import org.springframework.jdbc.datasource.init.ScriptUtils;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.ClassPathResource;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Exercises the real ProductRepository SQL against H2 in Oracle compatibility mode.
 * Oracle features we depend on (sequences + NEXTVAL from DUAL-like SELECT) are supported.
 */
class ProductRepositoryIT {

    private HikariDataSource ds;
    private ProductRepository repository;

    @BeforeEach
    void setUp() {
        ds = new HikariDataSource();
        ds.setJdbcUrl("jdbc:h2:mem:productRepoIT;MODE=Oracle;DB_CLOSE_DELAY=-1");
        ds.setDriverClassName("org.h2.Driver");
        ds.setUsername("sa");
        ds.setPassword("");

        ResourceDatabasePopulator populator = new ResourceDatabasePopulator(
                new ClassPathResource("sql/product-h2-schema.sql"));
        populator.execute(ds);

        JdbcTemplate template = new JdbcTemplate(ds);
        repository = new ProductRepository(template);
    }

    @AfterEach
    void tearDown() {
        // Drop tables between tests to keep isolation
        try (var c = ds.getConnection()) {
            ScriptUtils.executeSqlScript(c,
                    new ByteArrayResource(
                            "DROP TABLE PRODUCT; DROP SEQUENCE PRODUCT_SEQ;".getBytes()));
        } catch (Exception ignored) {}
        ds.close();
    }

    @Test
    void insertAssignsIdFromSequence() {
        Product created = repository.insert(
                new Product(null, "SKU-A", "Alpha", new BigDecimal("10.00"), true));

        assertThat(created.id()).isNotNull();
        assertThat(created.sku()).isEqualTo("SKU-A");
        assertThat(created.inStock()).isTrue();
    }

    @Test
    void findByIdReturnsInsertedProduct() {
        Product created = repository.insert(
                new Product(null, "SKU-B", "Bravo", new BigDecimal("25.50"), false));

        Optional<Product> loaded = repository.findById(created.id());

        assertThat(loaded).isPresent();
        assertThat(loaded.get().name()).isEqualTo("Bravo");
        assertThat(loaded.get().price()).isEqualByComparingTo("25.50");
        assertThat(loaded.get().inStock()).isFalse();
    }

    @Test
    void findByIdReturnsEmptyWhenMissing() {
        assertThat(repository.findById(9999L)).isEmpty();
    }

    @Test
    void findAllReturnsAllRows() {
        repository.insert(new Product(null, "SKU-1", "One", BigDecimal.ONE, true));
        repository.insert(new Product(null, "SKU-2", "Two", BigDecimal.TEN, false));

        List<Product> all = repository.findAll();

        assertThat(all).hasSize(2);
        assertThat(all).extracting(Product::sku).containsExactlyInAnyOrder("SKU-1", "SKU-2");
    }

    @Test
    void updateChangesValues() {
        Product created = repository.insert(
                new Product(null, "SKU-U", "Original", new BigDecimal("1.00"), true));

        int rows = repository.update(created.id(),
                new Product(created.id(), "SKU-U", "Updated", new BigDecimal("2.00"), false));

        assertThat(rows).isEqualTo(1);
        Product reloaded = repository.findById(created.id()).orElseThrow();
        assertThat(reloaded.name()).isEqualTo("Updated");
        assertThat(reloaded.inStock()).isFalse();
    }

    @Test
    void updateReturnsZeroWhenIdMissing() {
        int rows = repository.update(9999L,
                new Product(9999L, "X", "X", BigDecimal.ONE, true));

        assertThat(rows).isZero();
    }

    @Test
    void deleteRemovesRow() {
        Product created = repository.insert(
                new Product(null, "SKU-D", "Doomed", BigDecimal.ONE, true));

        int rows = repository.delete(created.id());

        assertThat(rows).isEqualTo(1);
        assertThat(repository.findById(created.id())).isEmpty();
    }

    @Test
    void deleteReturnsZeroWhenIdMissing() {
        assertThat(repository.delete(9999L)).isZero();
    }

    // ---- Batch ----

    @Test
    void insertAllAssignsIdsInOrder() {
        List<Long> ids = repository.insertAll(List.of(
                new Product(null, "B1", "One",   BigDecimal.ONE, true),
                new Product(null, "B2", "Two",   BigDecimal.TEN, false),
                new Product(null, "B3", "Three", new BigDecimal("3.33"), true)
        ));

        assertThat(ids).hasSize(3);
        assertThat(ids).doesNotContainNull();
        // Oracle sequence values are monotonically increasing
        assertThat(ids).isSorted();

        Product second = repository.findById(ids.get(1)).orElseThrow();
        assertThat(second.sku()).isEqualTo("B2");
    }

    @Test
    void insertAllHandlesEmptyList() {
        assertThat(repository.insertAll(List.of())).isEmpty();
    }

    @Test
    void updateAllAffectsAllRows() {
        List<Long> ids = repository.insertAll(List.of(
                new Product(null, "U1", "Old1", BigDecimal.ONE, true),
                new Product(null, "U2", "Old2", BigDecimal.ONE, true)
        ));

        List<Product> updates = List.of(
                new Product(ids.get(0), "U1", "New1", new BigDecimal("9.99"), false),
                new Product(ids.get(1), "U2", "New2", new BigDecimal("9.99"), false)
        );

        int affected = repository.updateAll(updates);

        assertThat(affected).isEqualTo(2);
        assertThat(repository.findById(ids.get(0)).orElseThrow().name()).isEqualTo("New1");
        assertThat(repository.findById(ids.get(1)).orElseThrow().inStock()).isFalse();
    }

    @Test
    void deleteAllRemovesAllRows() {
        List<Long> ids = repository.insertAll(List.of(
                new Product(null, "D1", "X", BigDecimal.ONE, true),
                new Product(null, "D2", "Y", BigDecimal.ONE, true),
                new Product(null, "D3", "Z", BigDecimal.ONE, true)
        ));

        int deleted = repository.deleteAll(ids);

        assertThat(deleted).isEqualTo(3);
        assertThat(repository.findAll()).isEmpty();
    }

    @Test
    void insertAllHandlesLargeBatchCrossingChunkBoundary() {
        // BATCH_SIZE is 500 — insert 1200 to force multiple chunks
        List<Product> many = new java.util.ArrayList<>(1200);
        for (int i = 0; i < 1200; i++) {
            many.add(new Product(null, "BIG-" + i, "n" + i, BigDecimal.ONE, true));
        }

        List<Long> ids = repository.insertAll(many);

        assertThat(ids).hasSize(1200);
        assertThat(repository.findAll()).hasSize(1200);
    }
}
