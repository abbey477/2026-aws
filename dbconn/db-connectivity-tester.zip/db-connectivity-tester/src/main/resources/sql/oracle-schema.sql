-- Oracle PRODUCT table + sequence
-- Run once against the target Oracle schema before using the CRUD endpoints.

CREATE TABLE PRODUCT (
    id        NUMBER(19)    NOT NULL,
    sku       VARCHAR2(50)  NOT NULL,
    name      VARCHAR2(200) NOT NULL,
    price     NUMBER(12,2)  NOT NULL,
    in_stock  NUMBER(1)     DEFAULT 1 NOT NULL,
    CONSTRAINT pk_product     PRIMARY KEY (id),
    CONSTRAINT uk_product_sku UNIQUE (sku),
    CONSTRAINT ck_product_in_stock CHECK (in_stock IN (0, 1))
);

CREATE SEQUENCE PRODUCT_SEQ
    START WITH 1
    INCREMENT BY 1
    NOCACHE
    NOCYCLE;
