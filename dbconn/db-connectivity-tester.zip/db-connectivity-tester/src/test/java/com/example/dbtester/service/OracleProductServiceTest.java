package com.example.dbtester.service;

import com.example.dbtester.dto.ProductRequest;
import com.example.dbtester.entity.Product;
import com.example.dbtester.exception.ResourceNotFoundException;
import com.example.dbtester.repository.oracle.ProductRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class OracleProductServiceTest {

    @Mock ProductRepository repository;
    @InjectMocks OracleProductService service;

    private Product existing;

    @BeforeEach
    void setUp() {
        existing = new Product(5L, "SKU-5", "Widget", new BigDecimal("19.99"), true);
    }

    @Test
    void findAllDelegates() {
        when(repository.findAll()).thenReturn(List.of(existing));

        assertThat(service.findAll()).containsExactly(existing);
    }

    @Test
    void findByIdThrowsWhenMissing() {
        when(repository.findById(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.findById(99L))
                .isInstanceOf(ResourceNotFoundException.class)
                .hasMessageContaining("99");
    }

    @Test
    void createPassesThroughToRepository() {
        Product saved = new Product(1L, "NEW", "New Item", new BigDecimal("1.00"), false);
        when(repository.insert(any(Product.class))).thenReturn(saved);

        Product result = service.create(
                new ProductRequest("NEW", "New Item", new BigDecimal("1.00"), false));

        assertThat(result).isEqualTo(saved);
    }

    @Test
    void updatePreservesId() {
        when(repository.findById(5L)).thenReturn(Optional.of(existing));
        when(repository.update(eq(5L), any(Product.class))).thenReturn(1);

        Product result = service.update(5L,
                new ProductRequest("SKU-5", "Updated", new BigDecimal("29.99"), false));

        assertThat(result.id()).isEqualTo(5L);
        assertThat(result.name()).isEqualTo("Updated");
        assertThat(result.inStock()).isFalse();
    }

    @Test
    void updateThrowsWhenRowNotUpdated() {
        when(repository.findById(5L)).thenReturn(Optional.of(existing));
        when(repository.update(anyLong(), any(Product.class))).thenReturn(0);

        assertThatThrownBy(() -> service.update(5L,
                new ProductRequest("SKU-5", "X", BigDecimal.ONE, true)))
                .isInstanceOf(ResourceNotFoundException.class);
    }

    @Test
    void deleteThrowsWhenMissing() {
        when(repository.delete(99L)).thenReturn(0);

        assertThatThrownBy(() -> service.delete(99L))
                .isInstanceOf(ResourceNotFoundException.class);
    }

    @Test
    void deleteSucceedsWhenRowAffected() {
        when(repository.delete(5L)).thenReturn(1);

        service.delete(5L);

        verify(repository).delete(5L);
    }
}
