import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;

import java.util.ArrayList;
import java.util.List;

/**
 * Streaming migration for GRDInstrumentEvent (Sybase -> Oracle).
 *
 * <p>Streams rows from Sybase via {@link RowCallbackHandler}, buffers them, and
 * flushes batches to Oracle through {@link GRDInstrumentEventOracleRepository}.
 * Memory is bounded at ~BATCH_SIZE rows.
 *
 * <p>Row mapping is delegated to {@link GRDInstrumentEventRowMapper};
 * see that class for type-handling notes.
 *
 * <p>Two variants for A/B comparison: {@link #migrateByIndex()} (positional,
 * fastest) and {@link #migrateByName()} (by name, robust to SELECT reordering).
 */
@Slf4j
public class GRDInstrumentEventMigration {

    private static final int FETCH_SIZE = 2000;
    private static final int BATCH_SIZE = 5000;

    /**
     * SELECT column order MUST match the order used by
     * {@link GRDInstrumentEventRowMapper#mapByIndex} when reading positionally.
     */
    private static final String SELECT_SQL =
            "SELECT ID_IMNT, DT_CHG_GRD FROM GRD_INSTRUMENT_EVENT";

    private static final String TABLE_LABEL = "GRD_INSTRUMENT_EVENT";

    private final JdbcTemplate sybaseJdbcTemplate;
    private final GRDInstrumentEventOracleRepository oracleRepo;

    public GRDInstrumentEventMigration(
            @Qualifier("sybaseJdbcTemplate") JdbcTemplate sybaseJdbcTemplate,
            GRDInstrumentEventOracleRepository oracleRepo) {
        this.sybaseJdbcTemplate = sybaseJdbcTemplate;
        this.oracleRepo = oracleRepo;

        // CRITICAL: without this jconn4 uses a tiny default fetch size.
        this.sybaseJdbcTemplate.setFetchSize(FETCH_SIZE);
    }

    /** Variant A — positional read. */
    public void migrateByIndex() {
        run("byIndex", GRDInstrumentEventRowMapper::mapByIndex);
    }

    /** Variant B — by-name read. */
    public void migrateByName() {
        run("byName", GRDInstrumentEventRowMapper::mapByName);
    }

    /**
     * Shared streaming pipeline. The variants only differ in which mapper they pass in,
     * so the orchestration is parameterized to avoid code duplication.
     */
    private void run(String variant, RowMapperFn mapper) {
        log.info("[{}] Starting migration (variant={}, fetchSize={}, batchSize={})",
                TABLE_LABEL, variant, FETCH_SIZE, BATCH_SIZE);
        final long startNanos = System.nanoTime();

        oracleRepo.truncate();

        final List<GRDInstrumentEvent> buffer = new ArrayList<>(BATCH_SIZE);
        final MigrationStats stats = new MigrationStats();

        sybaseJdbcTemplate.query(SELECT_SQL, (RowCallbackHandler) rs -> {
            buffer.add(mapper.apply(rs));
            if (buffer.size() >= BATCH_SIZE) {
                flush(stats, buffer);
            }
        });

        if (!buffer.isEmpty()) {
            flush(stats, buffer);
        }

        logCompletion(variant, stats, startNanos);
    }

    private void flush(MigrationStats stats, List<GRDInstrumentEvent> buffer) {
        final int rowsInThisBatch = buffer.size();
        final long batchStartNanos = System.nanoTime();

        oracleRepo.batchInsert(buffer);

        final long batchElapsedMs = (System.nanoTime() - batchStartNanos) / 1_000_000;
        stats.batchCount++;
        stats.totalRows += rowsInThisBatch;

        log.debug("[{}] Batch {} complete — rows={}, elapsedMs={}, totalRowsSoFar={}",
                TABLE_LABEL, stats.batchCount, rowsInThisBatch, batchElapsedMs, stats.totalRows);

        buffer.clear();
    }

    private void logCompletion(String variant, MigrationStats stats, long startNanos) {
        final long totalElapsedMs = (System.nanoTime() - startNanos) / 1_000_000;
        final double seconds = Math.max(totalElapsedMs / 1000.0, 0.001);
        final long rowsPerSec = (long) (stats.totalRows / seconds);

        log.info("[{}] Migration complete (variant={}) — totalRows={}, batches={}, elapsedMs={}, throughput={} rows/sec",
                TABLE_LABEL, variant, stats.totalRows, stats.batchCount, totalElapsedMs, rowsPerSec);
    }

    /** Functional interface so we can pass a checked-exception-throwing mapper as a method reference. */
    @FunctionalInterface
    private interface RowMapperFn {
        GRDInstrumentEvent apply(java.sql.ResultSet rs) throws java.sql.SQLException;
    }

    private static final class MigrationStats {
        long totalRows = 0;
        int batchCount = 0;
    }
}
