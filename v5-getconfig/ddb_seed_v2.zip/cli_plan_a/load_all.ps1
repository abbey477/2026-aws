# load_all.ps1 — load all app-jobConfig / app-jobRun / app-jobLog batches into DynamoDB (Windows)
#
# Usage:
#   .\load_all.ps1
#   .\load_all.ps1 -DryRun

param(
    [switch]$DryRun
)

$ErrorActionPreference = "Stop"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ScriptDir

$Files = @(
    "app-jobConfig_part1_of_1.json",
    "app-jobRun_part1_of_2.json",
    "app-jobRun_part2_of_2.json",
    "app-jobLog_part1_of_4.json",
    "app-jobLog_part2_of_4.json",
    "app-jobLog_part3_of_4.json",
    "app-jobLog_part4_of_4.json"
)

Write-Host "=== DynamoDB seed loader ===" -ForegroundColor Cyan
Write-Host "Target tables: app-jobConfig, app-jobRun, app-jobLog"
Write-Host "Files: $($Files.Count)"
Write-Host ""

foreach ($f in $Files) {
    if (-not (Test-Path $f)) {
        Write-Error "MISSING: $f"
        exit 1
    }

    $target = Join-Path $ScriptDir $f
    $fileUri = "file://$target"
    Write-Host ">>> aws dynamodb batch-write-item --request-items $fileUri"

    if ($DryRun) { continue }

    $resp = aws dynamodb batch-write-item --request-items $fileUri | ConvertFrom-Json
    $unprocessedCount = 0
    if ($resp.UnprocessedItems) {
        foreach ($prop in $resp.UnprocessedItems.PSObject.Properties) {
            $unprocessedCount += $prop.Value.Count
        }
    }
    if ($unprocessedCount -gt 0) {
        Write-Host "    WARN: $unprocessedCount unprocessed items" -ForegroundColor Yellow
        $resp | ConvertTo-Json -Depth 10
    } else {
        Write-Host "    OK" -ForegroundColor Green
    }
}

Write-Host ""
Write-Host "Done. Verify with:"
Write-Host "  aws dynamodb scan --table-name app-jobConfig --select COUNT"
Write-Host "  aws dynamodb scan --table-name app-jobRun    --select COUNT"
Write-Host "  aws dynamodb scan --table-name app-jobLog    --select COUNT"
Write-Host "Expected: 15, 50, 100"
