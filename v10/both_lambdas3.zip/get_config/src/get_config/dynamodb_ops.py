"""
DynamoDB data access for GetConfig Lambda.

job_run table schema:
  PK: run_id (string), SK: last_updated_time (string, ISO-8601)
  Append-only — each state change creates a NEW row.

job_config table schema:
  PK: job_id (string), SK: job_type (string)
"""

import os
from datetime import datetime, timezone

import boto3
from botocore.exceptions import ClientError
from boto3.dynamodb.conditions import Key

from get_config import logging_utils as log

JOB_RUN_TABLE = os.environ.get("JOB_RUN_TABLE", "app-jobRun")
JOB_CONFIG_TABLE = os.environ.get("JOB_CONFIG_TABLE", "app-jobConfig")


def get_dynamodb_resource():
    """Return a DynamoDB resource. Separated for easy mocking in tests."""
    return boto3.resource("dynamodb")


def get_last_updated_time(provided: str | None = None) -> str:
    """Return provided timestamp or auto-set to current UTC."""
    if isinstance(provided, str) and provided != "":
        return provided
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def get_job_run(table, run_id: str, last_updated_time: str | None = None) -> dict:
    """
    Fetch a job_run record. Two modes:
    1. Exact fetch (last_updated_time provided) — get_item with full composite key.
    2. Latest fetch (last_updated_time None) — query newest row for run_id.
    """
    log.info("FETCH_JOB_RUN_START", {
        "run_id": run_id, "table": JOB_RUN_TABLE,
        "mode": "exact" if last_updated_time else "latest",
        "last_updated_time": last_updated_time or "<not provided>",
    })

    if last_updated_time:
        try:
            response = table.get_item(Key={
                "run_id": run_id, "last_updated_time": last_updated_time,
            })
        except ClientError as e:
            log.error("FETCH_JOB_RUN_ERROR", {
                "run_id": run_id, "error_message": str(e),
            })
            raise

        if "Item" not in response:
            log.warn("FETCH_JOB_RUN_FAILED", {
                "run_id": run_id, "last_updated_time": last_updated_time,
                "reason": "No item found at exact composite key",
            })
            raise ValueError(
                f"No job_run found for run_id: {run_id}, "
                f"last_updated_time: {last_updated_time}"
            )
        item = response["Item"]
    else:
        try:
            response = table.query(
                KeyConditionExpression=Key("run_id").eq(run_id),
                ScanIndexForward=False, Limit=1,
            )
        except ClientError as e:
            log.error("FETCH_JOB_RUN_ERROR", {
                "run_id": run_id, "error_message": str(e),
            })
            raise

        items = response.get("Items", [])
        if not items:
            log.warn("FETCH_JOB_RUN_FAILED", {
                "run_id": run_id, "reason": "No items found (latest lookup)",
            })
            raise ValueError(f"No job_run found for run_id: {run_id}")
        item = items[0]

    log.info("FETCH_JOB_RUN_SUCCESS", {
        "run_id": run_id,
        "last_updated_time": item.get("last_updated_time", "N/A"),
        "job_id": item.get("job_id", "N/A"),
        "job_type": item.get("job_type", "N/A"),
        "status": item.get("status", "N/A"),
    })
    return item


def get_job_config(table, job_id: str, job_type: str) -> dict:
    """Fetch job configuration. Schema-agnostic — all fields pass through."""
    log.info("FETCH_JOB_CONFIG_START", {
        "job_id": job_id, "job_type": job_type, "table": JOB_CONFIG_TABLE,
    })

    try:
        response = table.get_item(Key={"job_id": job_id, "job_type": job_type})
    except ClientError as e:
        log.error("FETCH_JOB_CONFIG_ERROR", {
            "job_id": job_id, "job_type": job_type, "error_message": str(e),
        })
        raise

    if "Item" not in response:
        log.warn("FETCH_JOB_CONFIG_FAILED", {
            "job_id": job_id, "job_type": job_type,
            "reason": "No item found in job_config table",
        })
        raise ValueError(f"No job_config found for job_id: {job_id}, job_type: {job_type}")

    item = response["Item"]
    runner = item.get("job_runner", {})
    log.info("FETCH_JOB_CONFIG_SUCCESS", {
        "job_id": job_id, "job_type": job_type,
        "runner_type": runner.get("type", "N/A"),
        "has_pre_steps": bool(item.get("pre_steps")),
        "pre_steps_count": len(item.get("pre_steps", [])),
    })
    return item
