# myapp-rest

A minimal Spring Boot **REST** starter that:
- Exposes 3 `GET` endpoints reading from `@ConfigurationProperties` (a record with a nested record).
- Supports 3 profiles (`dev`, `test`, `prod`), each with its own port and DB settings.
- Externalizes all config (`application*.properties` + `logback.xml`) — nothing baked into the JAR.
- Writes logs to `output/logs/application-<HOST_IP>.log` (sibling of `myapp/`, survives redeploys).
- Ships as a `tar.gz` distribution with foreground (`run.*`) and daemon (`start/stop/status.*`) scripts.

---

## Table of contents
- [Requirements](#requirements)
- [Build](#build)
- [The 3 endpoints](#the-3-endpoints)
- [Run](#run)
  - [Foreground (dev)](#foreground-dev)
  - [Daemon (prod-style)](#daemon-prod-style)
  - [Directly from the JAR](#directly-from-the-jar)
- [Test the endpoints](#test-the-endpoints)
- [Configuration](#configuration)
- [Runtime layout](#runtime-layout)
- [Deploy](#deploy)
- [Troubleshooting](#troubleshooting)

---

## Requirements
- Java 21
- Maven 3.9+
- `curl` (for the endpoint examples)

## Build

```bash
mvn clean package
```

Produces:
- `target/myapp-rest-1.0.0.jar` — the Spring Boot fat JAR (no configs inside)
- `target/myapp-rest-1.0.0-dist.tar.gz` — full distribution (JAR + config + scripts)

To skip tests: `mvn clean package -DskipTests`.

## The 3 endpoints

All return JSON. Bound from the active profile's `application-<env>.properties`.

| Method | Path                | Returns                                            |
|--------|---------------------|----------------------------------------------------|
| GET    | `/api/config`       | The full `AppProperties` record (incl. nested DB)  |
| GET    | `/api/config/app`   | `{ "name": "...", "environment": "..." }`          |
| GET    | `/api/config/db`    | The nested `Database` record (url/username/poolSize) |

**Ports per profile:** dev=8080, test=8081, prod=8082.

## Run

### Foreground (dev)

Blocks the terminal; Ctrl-C stops it.

**Linux / macOS:**
```bash
tar -xzf target/myapp-rest-1.0.0-dist.tar.gz -C output
output/myapp/bin/run.sh dev
```

**Windows:**
```cmd
mkdir output
tar -xzf target\myapp-rest-1.0.0-dist.tar.gz -C output
output\myapp\bin\run.bat dev
```

### Daemon (prod-style)

Runs in the background, writes the PID to `myapp/tmp/app.pid`, redirects stdout/stderr to `output/logs/console-<IP>.out`.

**Linux:**
```bash
output/myapp/bin/start.sh prod
output/myapp/bin/status.sh             # RUNNING (pid 12345)
output/myapp/bin/stop.sh               # graceful, 30s timeout, then SIGKILL
output/myapp/bin/stop.sh 60            # custom timeout
```

**Windows:**
```cmd
output\myapp\bin\start.bat prod
output\myapp\bin\status.bat
output\myapp\bin\stop.bat
```

### Directly from the JAR

For the fastest dev loop without the assembly step:

```bash
java \
  -Dapp.host.ip=127.0.0.1 \
  -Dapp.log.dir=./logs \
  -Dlogging.config=file:src/main/resources/logback.xml \
  -jar target/myapp-rest-1.0.0.jar \
  --spring.config.additional-location=file:src/main/resources/ \
  --spring.profiles.active=dev
```

## Test the endpoints

Once running on `dev` (port 8080):

```bash
curl http://localhost:8080/api/config
# {"name":"myapp-rest","environment":"dev","db":{"url":"jdbc:postgresql://localhost:5432/myapp_dev","username":"dev_user","poolSize":5}}

curl http://localhost:8080/api/config/app
# {"name":"myapp-rest","environment":"dev"}

curl http://localhost:8080/api/config/db
# {"url":"jdbc:postgresql://localhost:5432/myapp_dev","username":"dev_user","poolSize":5}
```

For `test` use port 8081; for `prod` use port 8082.

Pipe to `jq` for readable output: `curl -s http://localhost:8080/api/config | jq`.

## Configuration

All configuration lives in the externalized `config/` directory (single source of truth — none of these files are inside the JAR).

| File                                  | Purpose                              |
|---------------------------------------|--------------------------------------|
| `config/application.properties`       | base (always loaded)                 |
| `config/application-dev.properties`   | dev profile (port 8080)              |
| `config/application-test.properties`  | test profile (port 8081)             |
| `config/application-prod.properties`  | prod profile (port 8082)             |
| `config/logback.xml`                  | logging appenders & patterns         |

### How to change a setting

Edit the relevant file under `myapp/config/` on the server, then restart. No rebuild.

**Example — bump prod log level to DEBUG:**
```properties
# myapp/config/application-prod.properties
logging.level.com.example.myapp=DEBUG
```
Then `./stop.sh && ./start.sh prod`.

### Spring Boot load order (lowest → highest priority)
1. `config/application.properties` (base)
2. `config/application-<profile>.properties` (active profile)
3. CLI args / system properties / env vars

## Runtime layout

After extracting the tarball and starting the app:

```
output/
├── dist/                              ← CI/CD drops the tarball here
│   └── myapp-rest-1.0.0-dist.tar.gz
├── backup/                            ← deploy script populates
│   └── myapp-<version>-<timestamp>/
├── logs/                              ← persistent, sibling of myapp/
│   ├── application-<HOST_IP>.log
│   └── console-<HOST_IP>.out          ← from daemon scripts only
└── myapp/                             ← replaced on every deploy
    ├── bin/
    │   ├── run.sh, run.bat            (foreground)
    │   ├── start.sh, start.bat        (daemon)
    │   ├── stop.sh, stop.bat
    │   └── status.sh, status.bat
    ├── lib/
    │   └── myapp-rest-1.0.0.jar
    ├── config/
    │   ├── application.properties
    │   ├── application-dev.properties
    │   ├── application-test.properties
    │   ├── application-prod.properties
    │   └── logback.xml
    └── tmp/
        └── app.pid                    (only when daemon is running)
```

**Key invariant:** `output/logs/` is never touched by a deploy. The deploy only ever wipes and recreates `myapp/`. Logs survive forever (subject to `<maxHistory>30</maxHistory>` in logback.xml).

## Deploy

Typical CI/CD flow on each server:

1. Drop new tarball at `output/dist/myapp-rest-<version>-dist.tar.gz`.
2. `output/myapp/bin/stop.sh` (graceful shutdown).
3. `mv output/myapp output/backup/myapp-<oldversion>-$(date +%Y%m%d-%H%M%S)`.
4. `tar -xzf output/dist/myapp-rest-<version>-dist.tar.gz -C output` (recreates `output/myapp/`).
5. `output/myapp/bin/start.sh prod`.
6. `curl -fsS http://localhost:8082/api/config > /dev/null` as a health check; rollback on failure.
7. Optionally prune old backups (keep the most recent N).

A full deploy script with rollback is left as a CI/CD concern (we'd typically write it once and reuse it across services).

## Troubleshooting

**"Address already in use" on startup**
Something else is on the profile's port (dev=8080, test=8081, prod=8082). Find it:
```bash
lsof -i :8080      # Linux/macOS
netstat -ano | findstr 8080   # Windows
```

**"Already running (pid X). Use stop.sh first."**
`start.sh` refuses to start over an existing process. Run `stop.sh` first, or delete `myapp/tmp/app.pid` if you're sure nothing is actually running.

**Log file shows host IP `unknown`**
The script couldn't detect the host's IP. On Linux that means `hostname -I` and `ip route get` both failed. The app still works; only the log filename is affected. You can override:
```bash
java -Dapp.host.ip=10.0.0.42 -jar ...
```

**Properties bind to `null`**
You ran the JAR without `--spring.config.additional-location=file:.../config/`. The JAR is empty of config on purpose; configs ship in `myapp/config/`. The launch scripts handle this automatically — use them.

**Endpoints return 404**
You're hitting the wrong port for your active profile. `/api/config` is on dev=8080, test=8081, prod=8082.

**Daemon log files keep growing**
By default Logback rotates daily and keeps 30 days (`<maxHistory>30</maxHistory>` in `config/logback.xml`). Adjust there.

**Where are the logs?**
`output/logs/application-<HOST_IP>.log` (regular app logs) and `output/logs/console-<HOST_IP>.out` (stdout/stderr from the daemon — only from `start.sh`/`start.bat`, not from `run.sh`/`run.bat`).
