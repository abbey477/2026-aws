package com.example.myapp.jobs;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class JobB implements Job {

    private static final Logger log = LoggerFactory.getLogger(JobB.class);

    @Override
    public String name() {
        return "jobB";
    }

    @Override
    public void run() {
        log.info("==> JobB starting");
        log.info("    JobB doing different work...");
        log.info("==> JobB finished");
    }
}
