package com.example.dbtester.config;

import com.zaxxer.hikari.HikariDataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;

/**
 * Builds the Oracle-scoped triad of beans that every repository/service needs:
 * DataSource, JdbcTemplate, and PlatformTransactionManager.
 *
 * <p>All three are marked {@link Primary}. When Spring encounters a bean
 * injection point with multiple matching candidates (because Sybase provides
 * the same three bean types), it prefers the primary. This lets generic
 * {@code @Autowired DataSource} work without qualifiers — though we still
 * use qualifiers explicitly in repositories for clarity.
 *
 * <p>The DataSource bean is registered with {@code destroyMethod = "close"}
 * so Hikari's pool shuts down cleanly when the Spring context closes.
 */
@Configuration
public class OracleDataSourceConfig {

    /** Key in {@code app.datasources.*}. Must match application.properties. */
    private static final String DS_KEY = "oracle";

    private final DataSourceProperties.DbConfig config;

    /**
     * Constructor-injected properties. We pull out just the "oracle" entry
     * and fail fast if it's missing — missing config is a programming error,
     * not a runtime state to recover from.
     */
    public OracleDataSourceConfig(DataSourceProperties properties) {
        this.config = properties.datasources().get(DS_KEY);
        if (this.config == null) {
            throw new IllegalStateException("Missing configuration for datasource: " + DS_KEY);
        }
    }

    @Primary
    @Bean(name = "oracleDataSource", destroyMethod = "close")
    public DataSource oracleDataSource() {
        return HikariDataSourceFactory.build(DS_KEY, config);
    }

    /**
     * JdbcTemplate is the main collaborator for repositories. It's thread-safe
     * and stateless once constructed, so a single instance is shared across
     * all callers.
     */
    @Primary
    @Bean(name = "oracleJdbcTemplate")
    public JdbcTemplate oracleJdbcTemplate(DataSource oracleDataSource) {
        return new JdbcTemplate(oracleDataSource);
    }

    /**
     * Transaction manager for {@code @Transactional("oracleTxManager")}. Each
     * datasource needs its own because transactions in Spring are bound to a
     * specific DataSource — a single manager can't span Oracle and Sybase
     * (that would require XA / two-phase commit, out of scope here).
     */
    @Primary
    @Bean(name = "oracleTxManager")
    public PlatformTransactionManager oracleTxManager(DataSource oracleDataSource) {
        return new DataSourceTransactionManager(oracleDataSource);
    }
}
