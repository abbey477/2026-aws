"""
Routing: all flavours of 'no data to iterate' should call handle_no_pre_steps.
"""

import pytest

from pre_steps_processor.handler import lambda_handler
from seed_data import make_event


class TestRoutingNoData:

    def test_pre_steps_key_missing(self, mocks):
        lambda_handler(make_event(), None)
        mocks["no_data"].assert_called_once()
        mocks["change_since"].assert_not_called()
        mocks["ddb_pull"].assert_not_called()
        mocks["unknown"].assert_not_called()

    def test_pre_steps_is_none(self, mocks):
        lambda_handler(make_event(pre_steps=None), None)
        mocks["no_data"].assert_called_once()

    def test_pre_steps_is_empty_list(self, mocks):
        lambda_handler(make_event(pre_steps=[]), None)
        mocks["no_data"].assert_called_once()

    def test_pre_steps_is_not_a_list(self, mocks):
        """String, dict, number etc. should be treated as no-data."""
        lambda_handler(make_event(pre_steps="not-a-list"), None)
        mocks["no_data"].assert_called_once()

    def test_job_config_key_missing(self, mocks):
        """Even if job_config is missing entirely, we don't crash."""
        event = {"run_id": "run-001", "job_id": "client", "job_type": "sourcing"}
        lambda_handler(event, None)
        mocks["no_data"].assert_called_once()

    @pytest.mark.parametrize("invalid_step", [
        {},
        {"pre_step_type": None},
        {"pre_step_type": ""},
        {"pre_step_type": 123},
        {"other_field": "value"},
        "just-a-string",
        None,
    ])
    def test_items_without_valid_pre_step_type_treated_as_no_data(
        self, mocks, invalid_step,
    ):
        lambda_handler(make_event(pre_steps=[invalid_step]), None)
        mocks["no_data"].assert_called_once()
        mocks["change_since"].assert_not_called()
        mocks["ddb_pull"].assert_not_called()
        mocks["unknown"].assert_not_called()
