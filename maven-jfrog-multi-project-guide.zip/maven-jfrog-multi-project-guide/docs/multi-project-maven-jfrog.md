# Multi-Project Maven Repo → JFrog Artifactory

A guide to keeping several **independent** Maven projects in one Git repo, each building its own JAR, released at its own pace, tagged in Git, and deployed to JFrog Artifactory. Shared libraries (JUnit, Mockito) are managed in one place.

The sample repo `acme-libs` follows this guide, so you can try each step on it.

---

## Contents

0. [The idea](#0-the-idea)
1. [Repo layout](#1-repo-layout)
2. [One-time setup](#2-one-time-setup)
3. [The parent POM](#3-the-parent-pom)
4. [A project POM](#4-a-project-pom)
5. [Build locally](#5-build-locally)
6. [Deploy the parent](#6-deploy-the-parent)
7. [Release one project](#7-release-one-project)
8. [Update a shared library (JUnit / Mockito)](#8-update-a-shared-library-junit--mockito)
9. [Add a new project](#9-add-a-new-project)
10. [Rebuild an old release from a tag](#10-rebuild-an-old-release-from-a-tag)
11. [Finding which `settings.xml` you're using](#11-finding-which-settingsxml-youre-using)
12. [Troubleshooting](#12-troubleshooting)
13. [Quick reference](#13-quick-reference)

---

## 0. The idea

| Need | How it's solved |
|---|---|
| Shared library versions in one place | A **parent POM** at the repo root with `<dependencyManagement>` |
| Projects stay independent | The parent has **no `<modules>`**, so nothing gets built together |
| Each JAR changes at its own pace | Each project has **its own `<version>`** |
| A Git record of every release | Tags in the form **`<project>-<version>`**, for example `string-utils-1.0.0` |
| Deploy to JFrog | `<distributionManagement>` in the parent, credentials in `~/.m2/settings.xml` |

> **Note:** The parent is just a shared settings file. Changing it does **not** change any project until that project chooses to use the new parent version.

---

## 1. Repo layout

```
acme-libs/
├── pom.xml                  ← parent POM (acme-parent 1.0.0)
├── settings.xml.example     ← template for ~/.m2/settings.xml (never commit the real one)
├── .gitignore
├── README.md
├── string-utils/            ← project 1, version 1.0.0-SNAPSHOT
│   ├── pom.xml
│   └── src/
│       ├── main/java/com/acme/strings/StringUtils.java
│       └── test/java/com/acme/strings/StringUtilsTest.java    (JUnit)
└── date-utils/              ← project 2, version 2.3.0-SNAPSHOT
    ├── pom.xml
    └── src/
        ├── main/java/com/acme/dates/DateUtils.java
        └── test/java/com/acme/dates/DateUtilsTest.java        (JUnit + Mockito)
```

Git tags will look like this:

```
acme-parent-1.0.0
string-utils-1.0.0
string-utils-1.1.0
date-utils-2.3.0
```

---

## 2. One-time setup

### 2.1 Check Java and Maven

```bash
java -version
mvn -v
```

> **Note:** `mvn -v` shows the Java version Maven runs on. The version in the parent POM (`maven.compiler.release`, set to 17 in the sample) can't be higher than that.

### 2.2 Add your JFrog credentials

Copy `settings.xml.example` to `~/.m2/settings.xml` (Windows: `C:\Users\YOU\.m2\settings.xml`) and fill it in:

```xml
<settings>
  <servers>
    <server>
      <id>artifactory</id>
      <username>YOUR_USERNAME</username>
      <password>YOUR_ACCESS_TOKEN</password>
    </server>
  </servers>
</settings>
```

> **Notes:**
> - The `<id>` must match the `<id>` in the parent POM's `<distributionManagement>`.
> - Use an **access token**, not your password. In JFrog, open your profile → **Generate Token**.
> - Never commit this file. It contains your credentials.

### 2.3 Set your JFrog URL and repo names

In the parent `pom.xml`, replace `YOURCOMPANY` and check the repo names:

```xml
<url>https://YOURCOMPANY.jfrog.io/artifactory/libs-release-local</url>
<url>https://YOURCOMPANY.jfrog.io/artifactory/libs-snapshot-local</url>
```

> **Note:** Repo names vary by company. Check **Artifacts** in the JFrog UI. Use the **`-local`** repos: remote and virtual repos don't accept uploads.

---

## 3. The parent POM

File: `acme-libs/pom.xml`. What each part does:

| Section | Purpose |
|---|---|
| `<packaging>pom</packaging>` | It's a settings file, not a JAR |
| `<version>1.0.0</version>` | The parent's own version. Increase it when you change the file |
| `<properties>` | Java version (`maven.compiler.release`) and shared library versions |
| `<dependencyManagement>` | Sets **versions only**. Nothing is added to projects automatically |
| `<pluginManagement>` | Pins Maven plugin versions so builds are repeatable |
| `<distributionManagement>` | Where to deploy (release and snapshot repos) |
| **No `<modules>`** | Keeps projects independent |

The key part:

```xml
<properties>
  <maven.compiler.release>17</maven.compiler.release>
  <junit.version>5.11.3</junit.version>
  <mockito.version>5.14.2</mockito.version>
</properties>

<dependencyManagement>
  <dependencies>
    <dependency>
      <groupId>org.junit</groupId>
      <artifactId>junit-bom</artifactId>
      <version>${junit.version}</version>
      <type>pom</type>
      <scope>import</scope>
    </dependency>
    <dependency>
      <groupId>org.mockito</groupId>
      <artifactId>mockito-core</artifactId>
      <version>${mockito.version}</version>
      <scope>test</scope>
    </dependency>
    <dependency>
      <groupId>org.mockito</groupId>
      <artifactId>mockito-junit-jupiter</artifactId>
      <version>${mockito.version}</version>
      <scope>test</scope>
    </dependency>
  </dependencies>
</dependencyManagement>
```

> **Notes:**
> - `junit-bom` with `<scope>import</scope>` sets versions for **all** JUnit 5 libraries at once.
> - To share another library (for example, Jackson or SLF4J), add it to `<dependencyManagement>` the same way.
> - The version numbers here were current at the time of writing. Check Maven Central for newer ones.

---

## 4. A project POM

File: `string-utils/pom.xml`

```xml
<parent>
  <groupId>com.acme</groupId>
  <artifactId>acme-parent</artifactId>
  <version>1.0.0</version>
</parent>

<artifactId>string-utils</artifactId>
<version>1.0.0-SNAPSHOT</version>
<packaging>jar</packaging>

<dependencies>
  <dependency>
    <groupId>org.junit.jupiter</groupId>
    <artifactId>junit-jupiter</artifactId>
    <scope>test</scope>
  </dependency>
</dependencies>
```

> **Notes:**
> - **No `<version>` on dependencies.** It comes from the parent.
> - **No `<groupId>` for the project.** It's inherited (`com.acme`).
> - The `<parent>` block needs no `<relativePath>`: Maven looks in `../pom.xml` by default, which is the repo root.
> - `date-utils` is the same, but also uses `mockito-junit-jupiter` and has its own version, `2.3.0-SNAPSHOT`.

---

## 5. Build locally

Run builds **from inside a project folder**:

```bash
cd string-utils
mvn clean package
```

Result: `string-utils/target/string-utils-1.0.0-SNAPSHOT.jar`

```bash
cd ../date-utils
mvn clean package
```

Result: `date-utils/target/date-utils-2.3.0-SNAPSHOT.jar`

> **Note:** Running `mvn package` at the repo root builds **only the parent**, because it has no modules. That's by design.

---

## 6. Deploy the parent

Deploy the parent **first**, and again whenever it changes. Every deployed JAR's POM points to the parent, so anyone using your JARs needs the parent in JFrog too.

```bash
# from the repo root
mvn clean deploy -N

git tag acme-parent-1.0.0
git push origin acme-parent-1.0.0
```

> **Notes:**
> - `-N` means "this POM only, don't go into subfolders."
> - The parent version has no `-SNAPSHOT`, so it goes to the **release** repo.
> - A release version can only be deployed **once** (you'll get 409 Conflict the second time). If you change the parent, increase its version.

---

## 7. Release one project

Example: release `string-utils` **1.0.0**. The other projects aren't affected.

```bash
cd string-utils

# 1. Remove -SNAPSHOT: 1.0.0-SNAPSHOT → 1.0.0
mvn versions:set -DnewVersion=1.0.0 -DgenerateBackupPoms=false

# 2. Build and test before tagging
mvn clean verify

# 3. Commit and tag
git commit -am "Release string-utils 1.0.0"
git tag string-utils-1.0.0

# 4. Deploy to JFrog (goes to libs-release-local)
mvn clean deploy

# 5. Start the next development version
mvn versions:set -DnewVersion=1.1.0-SNAPSHOT -DgenerateBackupPoms=false
git commit -am "string-utils: next version 1.1.0-SNAPSHOT"

# 6. Push commits and the tag
git push
git push origin string-utils-1.0.0
```

> **Notes:**
> - **Release vs snapshot:** a version ending in `-SNAPSHOT` goes to `libs-snapshot-local` and can be redeployed any time. A version without it goes to `libs-release-local` and is permanent.
> - You can deploy snapshots during development with just `mvn clean deploy`, with no tag needed.
> - **Tag before deploying**, so the tag always matches what's in JFrog. If the deploy fails, fix it, delete the tag (`git tag -d string-utils-1.0.0`), and redo steps 3–4.
> - **Choosing the next version:** increase the first number for breaking changes (`2.0.0`), the middle one for new features (`1.1.0`), and the last for bug fixes (`1.0.1`).
> - If `versions:set` isn't available, you can edit `<version>` in the project's `pom.xml` by hand.

---

## 8. Update a shared library (JUnit / Mockito)

Example: move Mockito to a newer version.

**Step 1: update and release the parent**

```bash
# from the repo root
mvn versions:set -DnewVersion=1.1.0 -DgenerateBackupPoms=false
# edit pom.xml: <mockito.version>NEW_VERSION</mockito.version>

git commit -am "acme-parent 1.1.0: update Mockito"
git tag acme-parent-1.1.0
mvn clean deploy -N
git push && git push origin acme-parent-1.1.0
```

**Step 2: move each project over when it's ready**

In that project's `pom.xml`:

```xml
<parent>
  <groupId>com.acme</groupId>
  <artifactId>acme-parent</artifactId>
  <version>1.1.0</version>   <!-- was 1.0.0 -->
</parent>
```

Then run `mvn clean verify`, commit, and release it as usual ([section 7](#7-release-one-project)).

> **Notes:**
> - Projects **don't have to update together.** `date-utils` can stay on parent `1.0.0` while `string-utils` moves to `1.1.0`.
> - **Watch out:** when building locally, Maven checks `../pom.xml` first. If the root POM is at `1.1.0` but a project still asks for `1.0.0`, Maven gets `1.0.0` from your local repository (`~/.m2/repository`) or from JFrog instead. Building still works, because `1.0.0` was deployed in [section 6](#6-deploy-the-parent).

---

## 9. Add a new project

```bash
# from the repo root
mkdir -p new-lib/src/main/java/com/acme/newlib new-lib/src/test/java/com/acme/newlib
```

Create `new-lib/pom.xml`:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
  <modelVersion>4.0.0</modelVersion>

  <parent>
    <groupId>com.acme</groupId>
    <artifactId>acme-parent</artifactId>
    <version>1.0.0</version>
  </parent>

  <artifactId>new-lib</artifactId>
  <version>0.1.0-SNAPSHOT</version>
  <packaging>jar</packaging>

  <dependencies>
    <dependency>
      <groupId>org.junit.jupiter</groupId>
      <artifactId>junit-jupiter</artifactId>
      <scope>test</scope>
    </dependency>
  </dependencies>
</project>
```

Then add your code and build with `cd new-lib && mvn clean package`.

> **Note:** You can also generate a project with `mvn archetype:generate` (see below), then replace the generated `pom.xml` with the one above so it uses the parent.

```bash
mvn archetype:generate \
  -DgroupId=com.acme \
  -DartifactId=new-lib \
  -DarchetypeArtifactId=maven-archetype-quickstart \
  -DarchetypeVersion=1.5 \
  -DjavaCompilerVersion=17 \
  -DinteractiveMode=false
```

> On Windows Command Prompt, put it all on one line or use `^` instead of `\` at the line ends.

---

## 10. Rebuild an old release from a tag

```bash
git tag -l "string-utils-*"          # list releases of one project
git checkout string-utils-1.0.0
cd string-utils
mvn clean package
git checkout main                    # go back when done
```

> **Note:** The build is the same as the original because the tag fixes both the project's code **and** the parent version it used.

---

## 11. Finding which `settings.xml` you're using

Maven reads two settings files. If a setting is in both, the user file wins.

| Type | Location |
|---|---|
| **User** | `~/.m2/settings.xml` (Windows: `C:\Users\YOU\.m2\settings.xml`) |
| **Global** | `<maven home>/conf/settings.xml` (run `mvn -v` and check the `Maven home:` line) |

Show the exact paths:

```bash
mvn -X help:help | grep -i settings          # Linux / macOS
mvn -X help:help | findstr /i settings       # Windows
```

Output looks like:

```
[DEBUG] Reading global settings from /opt/maven/conf/settings.xml
[DEBUG] Reading user settings from /home/you/.m2/settings.xml
```

Check that your credentials are picked up:

```bash
mvn help:effective-settings
```

Look for the `<server>` with `id` `artifactory`. The password is masked.

> **Notes:**
> - If Maven runs with `-s` (user settings) or `-gs` (global settings), it uses the file given there.
> - IntelliJ and Eclipse may use their own settings file. Check the IDE's Maven preferences.

---

## 12. Troubleshooting

| Error | Cause / Fix |
|---|---|
| **401 Unauthorized** | Wrong username or token, or the `<id>` in `settings.xml` doesn't match the parent POM |
| **403 Forbidden** | Your user lacks deploy permission on that repo. Ask your JFrog admin |
| **405 Method Not Allowed** | The URL points to a virtual or remote repo. Use the `-local` one |
| **409 Conflict** | That release version already exists. Increase the version number |
| **Non-resolvable parent POM** | The parent version isn't in `../pom.xml`, `~/.m2/repository` or JFrog. Deploy it ([section 6](#6-deploy-the-parent)) or run `mvn install -N` at the root |
| **`dependencies.dependency.version` is missing** | The library isn't in the parent's `<dependencyManagement>`. Add it there, or give the version in the project |
| **Tests not running** | Check that `maven-surefire-plugin` is version 3.x (pinned in the parent) |
| **`release version 17 not supported`** | Maven runs on an older JDK. Check `mvn -v` and set `JAVA_HOME` to a newer JDK |

---

## 13. Quick reference

| Task | Where | Command |
|---|---|---|
| Build a project | project folder | `mvn clean package` |
| Run tests | project folder | `mvn clean verify` |
| Deploy a snapshot | project folder | `mvn clean deploy` |
| Set a version | project folder | `mvn versions:set -DnewVersion=X.Y.Z -DgenerateBackupPoms=false` |
| Deploy the parent | repo root | `mvn clean deploy -N` |
| Install the parent locally only | repo root | `mvn install -N` |
| Tag a release | anywhere | `git tag <project>-<version>` |
| Push a tag | anywhere | `git push origin <project>-<version>` |
| List a project's releases | anywhere | `git tag -l "<project>-*"` |
| Show settings file paths | anywhere | `mvn -X help:help \| grep -i settings` |
| Show effective settings | anywhere | `mvn help:effective-settings` |
