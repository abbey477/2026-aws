package com.example.dbtester.exception;

/**
 * Thrown by services when a requested entity doesn't exist. Mapped to
 * HTTP 404 by {@link GlobalExceptionHandler}.
 *
 * <p>Unchecked (extends RuntimeException) so we don't have to declare it
 * on every service method's signature — consistent with how Spring treats
 * {@code DataAccessException} and friends.
 */
public class ResourceNotFoundException extends RuntimeException {

    public ResourceNotFoundException(String message) {
        super(message);
    }
}
