"""
Tests for logger.py
"""
import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import logging
from logger import log_info, log_error, _format_details


class TestFormatDetails:
    def test_empty_dict(self):        assert _format_details({}) == ""
    def test_none(self):              assert _format_details(None) == ""
    def test_single_kv(self):         assert _format_details({"key": "value"}) == "key=value"
    def test_multiple_kv(self):       assert _format_details({"a": 1, "b": 2}) == "a=1, b=2"
    def test_non_string_values(self):
        result = _format_details({"count": 5, "flag": True})
        assert "count=5" in result and "flag=True" in result


class TestLogInfo:
    def test_emits_info_level(self, caplog):
        with caplog.at_level(logging.INFO, logger="ScheduleNextJob"):
            log_info("TEST_STEP", {"k": "v"})
        assert caplog.records[0].levelname == "INFO"

    def test_message_format(self, caplog):
        with caplog.at_level(logging.INFO, logger="ScheduleNextJob"):
            log_info("TEST_STEP", {"k": "v"})
        assert caplog.records[0].message == "[ScheduleNextJob] [TEST_STEP] k=v"

    def test_empty_details(self, caplog):
        with caplog.at_level(logging.INFO, logger="ScheduleNextJob"):
            log_info("TEST_STEP")
        assert "[TEST_STEP]" in caplog.records[0].message


class TestLogError:
    def test_emits_error_level(self, caplog):
        with caplog.at_level(logging.ERROR, logger="ScheduleNextJob"):
            log_error("FAIL_STEP", {"error": "boom"})
        assert caplog.records[0].levelname == "ERROR"

    def test_message_format(self, caplog):
        with caplog.at_level(logging.ERROR, logger="ScheduleNextJob"):
            log_error("FAIL_STEP", {"error": "boom"})
        assert "[FAIL_STEP]" in caplog.records[0].message
        assert "error=boom" in caplog.records[0].message

    def test_exc_info_captures_traceback(self, caplog):
        with caplog.at_level(logging.ERROR, logger="ScheduleNextJob"):
            try:
                raise ValueError("test exception")
            except ValueError:
                log_error("FAIL_STEP", {}, exc_info=True)
        assert caplog.records[0].exc_info[0] is ValueError
