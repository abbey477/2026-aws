package com.myapp;

import com.myapp.config.ApplicationProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

/**
 * Entry point for the multi-datasource starter.
 *
 * <p>The application builds, starts, and prints the bound configuration
 * properties to the console. Datasource beans are lazy, so the app starts
 * cleanly even when MySQL/PostgreSQL servers are not reachable.
 */
@SpringBootApplication
@EnableConfigurationProperties(ApplicationProperties.class)
public class MultiDatasourceApplication {

    public static void main(String[] args) {
        SpringApplication.run(MultiDatasourceApplication.class, args);
    }
}
