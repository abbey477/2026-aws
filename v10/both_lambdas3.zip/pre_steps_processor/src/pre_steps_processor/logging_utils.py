"""Structured logging helper for PreStepsProcessor Lambda."""

import logging

logger = logging.getLogger(__name__)
_LAMBDA_TAG = "[PreStepsProcessor]"


def _fmt(details: dict) -> str:
    return ", ".join(f"{k}={v}" for k, v in details.items())


def info(step: str, details: dict) -> None:
    logger.info(f"{_LAMBDA_TAG} [{step}] {_fmt(details)}")


def warn(step: str, details: dict) -> None:
    logger.warning(f"{_LAMBDA_TAG} [{step}] {_fmt(details)}")


def error(step: str, details: dict) -> None:
    logger.error(f"{_LAMBDA_TAG} [{step}] {_fmt(details)}")


def debug(step: str, details: dict) -> None:
    logger.debug(f"{_LAMBDA_TAG} [{step}] {_fmt(details)}")
