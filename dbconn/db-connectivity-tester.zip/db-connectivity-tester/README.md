# db-connectivity-tester

Simple Spring Boot (3.2, JDK 17, Maven) REST app that opens HikariCP-pooled JDBC
connections to **Oracle** (primary) and **Sybase** (via jConnect `jconn4`),
exposes health-check endpoints, and provides minimal CRUD against a sample
table in each database.

---

## Prerequisites

- JDK 17
- Maven 3.9+
- Running Oracle instance (reachable from your machine)
- Running Sybase ASE instance (reachable from your machine)
- `jconn4.jar` from your SAP/Sybase installation

## 1. Install `jconn4.jar` to your local Maven repo

jConnect is not on Maven Central. Install the jar once:

```bash
mvn install:install-file \
  -Dfile=/path/to/jconn4.jar \
  -DgroupId=com.sybase.jdbc4 \
  -DartifactId=jconn4 \
  -Dversion=16.0 \
  -Dpackaging=jar
```

If your `jconn4.jar` is a different version, update `sybase.jconn4.version`
in `pom.xml` accordingly.

## 2. Create the sample tables

- `src/main/resources/sql/oracle-schema.sql` - creates `PRODUCT` + `PRODUCT_SEQ`
- `src/main/resources/sql/sybase-schema.sql` - creates `CUSTOMER`

Run each against its target database.

## 3. Configure connection details

Edit `src/main/resources/application.properties` and set URL, username,
and password for both datasources.

## 4. Build and run

```bash
mvn clean package
mvn spring-boot:run
```

---

## Endpoints

### Health

| Method | Path                        | Description                    |
|--------|-----------------------------|--------------------------------|
| GET    | `/api/db/health/all`        | Ping both datasources          |
| GET    | `/api/db/health/{name}`     | Ping one (`oracle` or `sybase`)|

### Oracle CRUD - Products

| Method | Path                          |
|--------|-------------------------------|
| GET    | `/api/oracle/products`        |
| GET    | `/api/oracle/products/{id}`   |
| POST   | `/api/oracle/products`        |
| PUT    | `/api/oracle/products/{id}`   |
| DELETE | `/api/oracle/products/{id}`   |

### Sybase CRUD - Customers

| Method | Path                            |
|--------|---------------------------------|
| GET    | `/api/sybase/customers`         |
| GET    | `/api/sybase/customers/{id}`    |
| POST   | `/api/sybase/customers`         |
| PUT    | `/api/sybase/customers/{id}`    |
| DELETE | `/api/sybase/customers/{id}`    |

---

## Sample payloads

Create a product:
```json
POST /api/oracle/products
{
  "sku": "WIDGET-001",
  "name": "Deluxe Widget",
  "price": 19.99,
  "inStock": true
}
```

Create a customer:
```json
POST /api/sybase/customers
{
  "firstName": "Ada",
  "lastName": "Lovelace",
  "email": "ada@example.com"
}
```

## Testing

Run all tests:

```bash
mvn test
```

The test suite is layered so it runs without needing live Oracle or Sybase
instances:

| Layer                | Tests                                                                 | Approach                             |
|----------------------|-----------------------------------------------------------------------|--------------------------------------|
| Row mappers          | `CustomerRowMapperTest`, `ProductRowMapperTest`                       | JUnit + Mockito (mock `ResultSet`)   |
| Exception handler    | `GlobalExceptionHandlerTest`                                          | Plain JUnit                          |
| Services             | `SybaseCustomerServiceTest`, `OracleProductServiceTest`               | Mockito (`@Mock` repository)         |
| Health service       | `DatabaseHealthServiceTest`                                           | Real H2 Hikari pools                 |
| Controllers          | `HealthControllerTest`, `SybaseCustomerControllerTest`, `OracleProductControllerTest` | `@WebMvcTest` + MockMvc + `@MockBean` |
| Repositories         | `ProductRepositoryIT`, `CustomerRepositoryIT`                         | H2 (Oracle mode / MSSQLServer mode)  |

### Caveat on Sybase tests

H2 has no Sybase compatibility mode. `CustomerRepositoryIT` runs against H2 in
**MSSQLServer** mode as the closest proxy — Sybase ASE and SQL Server share
T-SQL heritage and `IDENTITY` column semantics compatible with
`SimpleJdbcInsert`. This validates the CRUD logic but **cannot** validate
jConnect-specific behavior. For full confidence, run the same repository tests
against a real Sybase instance (via Testcontainers or a shared dev DB) before
shipping.

---

## Project layout

```
src/main/java/com/example/dbtester/
├── DbTesterApplication.java
├── config/
│   ├── DataSourceProperties.java      # root record (Map / List / nested)
│   ├── HikariDataSourceFactory.java
│   ├── OracleDataSourceConfig.java    # @Primary
│   └── SybaseDataSourceConfig.java
├── controller/
│   ├── HealthController.java
│   ├── OracleProductController.java
│   └── SybaseCustomerController.java
├── service/
│   ├── DatabaseHealthService.java
│   ├── OracleProductService.java
│   └── SybaseCustomerService.java
├── repository/
│   ├── oracle/{ProductRepository, ProductRowMapper}.java
│   └── sybase/{CustomerRepository, CustomerRowMapper}.java
├── entity/
│   ├── Customer.java                  # record
│   └── Product.java                   # record
├── dto/
│   ├── ConnectionStatus.java          # record
│   ├── CustomerRequest.java           # record
│   └── ProductRequest.java            # record
└── exception/
    ├── ResourceNotFoundException.java
    └── GlobalExceptionHandler.java
```
