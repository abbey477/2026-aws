package com.example.myapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest(args = {"--job=jobA"})
@ActiveProfiles("test")
class MyAppApplicationTests {

    @Test
    void contextLoads() {
    }
}
