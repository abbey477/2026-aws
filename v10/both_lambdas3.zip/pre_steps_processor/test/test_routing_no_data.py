"""Routing: all flavours of 'no data to iterate'."""
import pytest
from pre_steps_processor.handler import lambda_handler
from seed_data import make_event


class TestRoutingNoData:

    def test_pre_steps_key_missing(self, mocks):
        lambda_handler(make_event(), None)
        mocks["no_data"].assert_called_once()

    def test_pre_steps_is_none(self, mocks):
        lambda_handler(make_event(pre_steps=None), None)
        mocks["no_data"].assert_called_once()

    def test_pre_steps_is_empty_list(self, mocks):
        lambda_handler(make_event(pre_steps=[]), None)
        mocks["no_data"].assert_called_once()

    def test_pre_steps_is_not_a_list(self, mocks):
        lambda_handler(make_event(pre_steps="not-a-list"), None)
        mocks["no_data"].assert_called_once()

    def test_job_config_key_missing(self, mocks):
        lambda_handler({"run_id": "run-001", "job_id": "client"}, None)
        mocks["no_data"].assert_called_once()

    @pytest.mark.parametrize("invalid_step", [
        {}, {"pre_step_type": None}, {"pre_step_type": ""},
        {"pre_step_type": 123}, "just-a-string", None,
    ])
    def test_invalid_items_treated_as_no_data(self, mocks, invalid_step):
        lambda_handler(make_event(pre_steps=[invalid_step]), None)
        mocks["no_data"].assert_called_once()
        mocks["change_since"].assert_not_called()
        mocks["ddb_pull"].assert_not_called()
