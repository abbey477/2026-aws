import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.stereotype.Service;

/**
 * Responsible for ONE thing: reading from Sybase temp table.
 * Knows nothing about Oracle or chunking logic.
 *
 * The caller provides a RowCallbackHandler (Spring's built-in interface)
 * and this service streams rows into it.
 */
@Service
public class SybaseReaderService {

    private static final Logger log = LoggerFactory.getLogger(SybaseReaderService.class);

    private static final int FETCH_SIZE    = 1_000;
    private static final int QUERY_TIMEOUT = 7200;  // 2 hours — safety net if query hangs

    private static final String SELECT_SQL = "SELECT col1, col2, col3 FROM temp_table";

    private final JdbcTemplate sybaseJdbc;

    public SybaseReaderService(@Qualifier("sybaseJdbc") JdbcTemplate sybaseJdbc) {
        this.sybaseJdbc = sybaseJdbc;
        this.sybaseJdbc.setFetchSize(FETCH_SIZE);
        this.sybaseJdbc.setQueryTimeout(QUERY_TIMEOUT);
    }

    // -------------------------------------------------------------------------
    // Public API — called by MigrationService.
    // Caller provides a RowCallbackHandler; this service streams rows into it.
    // -------------------------------------------------------------------------

    public void streamAll(RowCallbackHandler handler) {
        log.info("Starting Sybase stream");
        sybaseJdbc.query(SELECT_SQL, handler);
        log.info("Sybase stream complete");
    }
}
