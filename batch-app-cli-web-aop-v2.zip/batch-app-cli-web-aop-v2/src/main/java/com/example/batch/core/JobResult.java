package com.example.batch.core;

/**
 * Result of a job execution. Carries the exit code for Autosys.
 *   0 = success
 *   1 = generic failure
 *   3+ = specific business errors
 */
public class JobResult {

    private final int exitCode;
    private final String message;

    private JobResult(int exitCode, String message) {
        this.exitCode = exitCode;
        this.message = message;
    }

    public static JobResult success() {
        return new JobResult(0, "OK");
    }

    public static JobResult failure(int exitCode, String message) {
        return new JobResult(exitCode, message);
    }

    public int getExitCode() { return exitCode; }
    public String getMessage() { return message; }
    public boolean isSuccess() { return exitCode == 0; }
}
