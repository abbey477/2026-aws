"""
Shared pytest fixtures for all test files.
"""

import pytest
from unittest.mock import patch


@pytest.fixture(autouse=True)
def _mock_write_log():
    """Prevent log writes from hitting real DynamoDB in all tests."""
    with patch("check_job_status.log_to_dynamo._write_log"):
        yield
