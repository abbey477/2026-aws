"""Shared pytest fixtures for GetConfig tests."""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

import pytest
import boto3
from moto import mock_aws
from unittest.mock import patch
from seed_data import make_job_run_item, make_job_config_item


@pytest.fixture(autouse=True)
def mock_write_log():
    with patch("get_config.handler.write_log") as m:
        yield m


@pytest.fixture
def _mock_write_log(mock_write_log):
    return mock_write_log


@pytest.fixture
def dynamodb_tables():
    with mock_aws():
        dynamodb = boto3.resource("dynamodb", region_name="us-east-1")

        dynamodb.create_table(
            TableName="app-jobRun",
            KeySchema=[
                {"AttributeName": "run_id", "KeyType": "HASH"},
                {"AttributeName": "last_updated_time", "KeyType": "RANGE"},
            ],
            AttributeDefinitions=[
                {"AttributeName": "run_id", "AttributeType": "S"},
                {"AttributeName": "last_updated_time", "AttributeType": "S"},
            ],
            BillingMode="PAY_PER_REQUEST",
        )

        dynamodb.create_table(
            TableName="app-jobConfig",
            KeySchema=[
                {"AttributeName": "job_id", "KeyType": "HASH"},
                {"AttributeName": "job_type", "KeyType": "RANGE"},
            ],
            AttributeDefinitions=[
                {"AttributeName": "job_id", "AttributeType": "S"},
                {"AttributeName": "job_type", "AttributeType": "S"},
            ],
            BillingMode="PAY_PER_REQUEST",
        )

        dynamodb.Table("app-jobRun").put_item(Item=make_job_run_item())
        dynamodb.Table("app-jobConfig").put_item(Item=make_job_config_item())

        yield dynamodb


@pytest.fixture
def patched_handler(dynamodb_tables, monkeypatch):
    monkeypatch.setattr("get_config.handler.get_dynamodb_resource", lambda: dynamodb_tables)
    return dynamodb_tables
