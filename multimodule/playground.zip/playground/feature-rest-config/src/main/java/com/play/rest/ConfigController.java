package com.play.rest;

import com.play.rest.config.AppProperties;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * Exposes the bound {@link AppProperties} so you can hit the running app
 * with a browser/curl and see the config values.
 */
@RestController
@RequestMapping("/api/config")
public class ConfigController {

    private final AppProperties props;

    public ConfigController(AppProperties props) {
        this.props = props;
    }

    /** GET /api/config — the whole bound record. */
    @GetMapping
    public AppProperties full() {
        return props;
    }

    /** GET /api/config/owner — just the nested record. */
    @GetMapping("/owner")
    public AppProperties.Owner owner() {
        return props.owner();
    }

    /** GET /api/config/ping — liveness check. */
    @GetMapping("/ping")
    public Map<String, String> ping() {
        return Map.of("status", "up", "feature", "rest-config");
    }
}
