package com.example.dbtester;

import com.example.dbtester.config.DataSourceProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

@SpringBootApplication(exclude = { DataSourceAutoConfiguration.class })
@EnableConfigurationProperties(DataSourceProperties.class)
public class DbTesterApplication {

    public static void main(String[] args) {
        SpringApplication.run(DbTesterApplication.class, args);
    }
}
