package com.example.batch.web;

import com.example.batch.common.exception.BusinessException;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.Map;

/**
 * REST-side exception handler — the parallel of {@link com.example.batch.core.JobDispatcher}'s
 * catch blocks.
 *
 * <p>Both handlers do the same thing logically: take an exception and turn it into a
 * transport-specific response. REST: HTTP status + JSON body. CLI: exit code.
 *
 * <p>By the time we reach here, ServiceErrorAspect has already done the heavy lifting
 * (logging, auditing, metrics). We just shape the HTTP response.
 *
 * <p>{@code @ConditionalOnWebApplication} ensures this class doesn't load in CLI mode.
 */
@RestControllerAdvice
@ConditionalOnWebApplication
public class GlobalExceptionHandler {

    @ExceptionHandler(BusinessException.class)
    public ResponseEntity<Map<String, Object>> handleBusiness(BusinessException ex) {
        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(Map.of(
                        "error", "BUSINESS_ERROR",
                        "message", ex.getMessage(),
                        "exitCode", ex.getExitCode()    // for parity with CLI response
                ));
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, Object>> handleAny(Exception ex) {
        return ResponseEntity
                .status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(Map.of(
                        "error", "UNEXPECTED_ERROR",
                        "message", ex.getMessage() != null ? ex.getMessage() : "unknown"
                ));
    }
}
