package com.myapp.config;

import com.myapp.config.ApplicationProperties.DatasourceEntry;
import com.myapp.config.ApplicationProperties.Hikari;
import com.myapp.config.ApplicationProperties.KerberosAuth;
import com.zaxxer.hikari.HikariDataSource;
import javax.sql.DataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 * MySQL datasource configuration — fully self-contained.
 *
 * <p>This class owns its own {@code switch} on {@code auth-type} and builds the
 * MySQL {@link DataSource} directly, so changing MySQL behaviour means editing
 * only this file.
 *
 * <p>Marked {@link Primary} so unqualified injection resolves to MySQL. Beans
 * are {@link Lazy} so the app boots even when no MySQL server is reachable.
 */
@Configuration
public class MySqlConfig {

    private static final Logger log = LoggerFactory.getLogger(MySqlConfig.class);

    @Primary
    @Lazy
    @Bean(name = "mysqlDataSource", destroyMethod = "close")
    public DataSource mysqlDataSource(ApplicationProperties props) {
        DatasourceEntry entry = props.datasource().mysql();

        HikariDataSource ds = new HikariDataSource();
        ds.setJdbcUrl(entry.url());
        ds.setDriverClassName(entry.driverClassName());
        applyHikari(ds, entry.hikari());

        switch (entry.authType()) {
            case BASIC -> {
                log.info("[mysql] configuring BASIC auth (username/credential)");
                ds.setUsername(entry.username());
                ds.setPassword(entry.credential());
            }
            case KERBEROS -> {
                log.info("[mysql] configuring KERBEROS auth (GSSAPI)");
                KerberosAuth k = entry.kerberos();
                if (k == null) {
                    throw new IllegalStateException(
                            "[mysql] auth-type=kerberos but no kerberos properties provided");
                }
                // Identity comes from the principal + keytab, not username/credential.
                log.info("[mysql] kerberos principal={}, keytab={}", k.principal(), k.keytab());
                ds.addDataSourceProperty("gsslib", "gssapi");
                // TODO (infra): perform a JAAS LoginContext login with the keytab
                // and principal above, ensure java.security.krb5.conf points at a
                // valid krb5.conf, and validate the KDC ({@code k.kdc()}) is reachable.
                log.warn("[mysql] KERBEROS branch is a scaffold — complete JAAS/GSSAPI "
                        + "wiring with real infra before connecting");
            }
            default -> throw new IllegalStateException(
                    "[mysql] unsupported auth-type: " + entry.authType());
        }
        return ds;
    }

    @Primary
    @Lazy
    @Bean("mysqlJdbcTemplate")
    public JdbcTemplate mysqlJdbcTemplate(DataSource mysqlDataSource) {
        return new JdbcTemplate(mysqlDataSource);
    }

    private static void applyHikari(HikariDataSource ds, Hikari hikari) {
        if (hikari == null) {
            return;
        }
        if (hikari.maximumPoolSize() != null) {
            ds.setMaximumPoolSize(hikari.maximumPoolSize());
        }
        if (hikari.minimumIdle() != null) {
            ds.setMinimumIdle(hikari.minimumIdle());
        }
        ds.setPoolName(hikari.poolName() != null ? hikari.poolName() : "mysql-pool");
    }
}
