"""
Payload size logging tests for trigger_ecs_task.

Coverage:
  - JOB_PARAM_SIZE log emitted with correct byte count
  - Size log emitted BEFORE RunTask (so size is known even on failure)
  - Byte count matches len(json.dumps(job_param))
  - Empty {} payload logs as 2 bytes
"""

import json
import logging

from trigger_ecs_job.ecs_trigger import trigger_ecs_task
from conftest import make_event, mock_ecs_client_success, mock_ecs_client_with_error


class TestPayloadSizeLogging:

    def test_size_log_emitted_with_correct_bytes(self, caplog):
        """JOB_PARAM_SIZE log line should contain the correct byte count."""
        mock_ecs = mock_ecs_client_success()
        job_param = {"foo": "bar", "nums": [1, 2, 3]}
        expected_bytes = len(json.dumps(job_param))
        event = make_event(job_param=job_param)
        job_config = event["job_config"]

        with caplog.at_level(logging.INFO):
            trigger_ecs_task(mock_ecs, job_config, job_param, "run-001")

        size_logs = [
            rec for rec in caplog.records if "JOB_PARAM_SIZE" in rec.message
        ]
        assert len(size_logs) == 1
        assert f"job_param_bytes={expected_bytes}" in size_logs[0].message
        assert "run_id=run-001" in size_logs[0].message

    def test_size_logged_before_run_task_call(self, caplog):
        """Size log must be emitted BEFORE run_task so we see size on failure."""
        mock_ecs = mock_ecs_client_with_error(
            code="InvalidParameterException",
            message="Container overrides length must be at most 8192",
        )
        event = make_event()
        job_config = event["job_config"]
        job_param = job_config["job_param"]

        with caplog.at_level(logging.INFO):
            trigger_ecs_task(mock_ecs, job_config, job_param, "run-001")

        messages = [rec.message for rec in caplog.records]
        size_idx = next(
            i for i, m in enumerate(messages) if "JOB_PARAM_SIZE" in m
        )
        error_idx = next(
            i for i, m in enumerate(messages) if "ECS_CLIENT_ERROR" in m
        )
        assert size_idx < error_idx

    def test_size_log_for_empty_payload(self, caplog):
        """Empty {} payload should log as 2 bytes ('{}')."""
        mock_ecs = mock_ecs_client_success()
        event = make_event(job_param={})
        job_config = event["job_config"]

        with caplog.at_level(logging.INFO):
            trigger_ecs_task(mock_ecs, job_config, {}, "run-001")

        size_logs = [
            rec for rec in caplog.records if "JOB_PARAM_SIZE" in rec.message
        ]
        assert len(size_logs) == 1
        assert "job_param_bytes=2" in size_logs[0].message
