"""
Restart scenarios — composite-key job_run behaviour.

When last_updated_time is supplied in the event, the handler fetches
that exact historical row. When omitted, it fetches the latest row.
"""

from get_config.handler import lambda_handler
from seed_data import make_job_run_item


class TestHandlerRestart:

    def test_normal_run_returns_latest_row(self, patched_handler, mock_write_log):
        """Event without last_updated_time → latest row returned."""
        # Default seed has last_updated_time=2024-01-01, status=WAITING.
        # Add a newer row to prove latest-mode picks the newer one.
        patched_handler.Table("app-jobRun").put_item(Item=make_job_run_item(
            last_updated_time="2024-12-01T00:00:00Z",
            status="SUCCESS",
        ))

        result = lambda_handler({"run_id": "run-001"}, None)
        assert result["last_updated_time"] == "2024-12-01T00:00:00Z"
        assert result["status"] == "SUCCESS"

    def test_restart_with_last_updated_time(self, patched_handler, mock_write_log):
        """Event WITH last_updated_time → exact historical row returned."""
        patched_handler.Table("app-jobRun").put_item(Item=make_job_run_item(
            last_updated_time="2024-12-01T00:00:00Z",
            status="SUCCESS",
        ))

        # Explicitly ask for the older row — should ignore the newer one.
        result = lambda_handler({
            "run_id": "run-001",
            "last_updated_time": "2024-01-01T00:00:00Z",
        }, None)

        assert result["last_updated_time"] == "2024-01-01T00:00:00Z"
        assert result["status"] == "WAITING"

    def test_latest_mode_ignores_other_run_ids(self, patched_handler):
        """A newer row for a different run_id must NOT be returned."""
        patched_handler.Table("app-jobRun").put_item(Item=make_job_run_item(
            run_id="other-run",
            last_updated_time="2099-12-31T23:59:59Z",
            status="SUCCESS",
        ))

        result = lambda_handler({"run_id": "run-001"}, None)
        assert result["run_id"] == "run-001"
        assert result["last_updated_time"] == "2024-01-01T00:00:00Z"
