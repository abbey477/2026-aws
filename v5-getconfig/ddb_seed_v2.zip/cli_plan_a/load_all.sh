#!/usr/bin/env bash
# load_all.sh — load all app-jobConfig / app-jobRun / app-jobLog batches into DynamoDB
#
# Usage:
#   ./load_all.sh             # load everything
#   ./load_all.sh --dry-run   # print commands without executing
#
# Requires: aws CLI configured (run `aws configure` first).

set -euo pipefail

DRY_RUN=0
while [[ $# -gt 0 ]]; do
  case "$1" in
    --dry-run) DRY_RUN=1; shift ;;
    -h|--help)
      grep '^#' "$0" | sed 's/^# \{0,1\}//'
      exit 0
      ;;
    *) echo "Unknown arg: $1"; exit 1 ;;
  esac
done

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Ordered so jobConfig loads first (parent), then jobRun, then jobLog.
FILES=(
  "app-jobConfig_part1_of_1.json"
  "app-jobRun_part1_of_2.json"
  "app-jobRun_part2_of_2.json"
  "app-jobLog_part1_of_4.json"
  "app-jobLog_part2_of_4.json"
  "app-jobLog_part3_of_4.json"
  "app-jobLog_part4_of_4.json"
)

echo "=== DynamoDB seed loader ==="
echo "Target tables: app-jobConfig, app-jobRun, app-jobLog"
echo "Files: ${#FILES[@]}"
echo ""

for f in "${FILES[@]}"; do
  if [[ ! -f "$f" ]]; then
    echo "MISSING: $f" >&2
    exit 1
  fi

  CMD="aws dynamodb batch-write-item --request-items file://$f"
  echo ">>> $CMD"

  if [[ $DRY_RUN -eq 1 ]]; then
    continue
  fi

  RESP="$(eval "$CMD")"
  UNPROCESSED=$(echo "$RESP" | python3 -c "import sys,json; d=json.load(sys.stdin); u=d.get('UnprocessedItems') or {}; print(sum(len(v) for v in u.values()))" 2>/dev/null || echo 0)
  if [[ "$UNPROCESSED" != "0" ]]; then
    echo "    WARN: $UNPROCESSED unprocessed items — rerun this file or inspect response:"
    echo "$RESP"
  else
    echo "    OK"
  fi
done

echo ""
echo "Done. Verify with:"
echo "  aws dynamodb scan --table-name app-jobConfig --select COUNT"
echo "  aws dynamodb scan --table-name app-jobRun    --select COUNT"
echo "  aws dynamodb scan --table-name app-jobLog    --select COUNT"
echo "Expected: 15, 50, 100"
