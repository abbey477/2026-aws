package com.example.batch.common.service;

import com.example.batch.common.exception.BusinessException;
import com.example.batch.core.BusinessService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Simulated processing service.
 *
 * <p>Marked with {@code @BusinessService} so the {@code @within(BusinessService)}
 * pointcut in ServiceErrorAspect picks it up — any exception thrown from any
 * method here will trigger the aspect's onServiceException advice.
 *
 * <p>To demonstrate the failure path, this service throws a {@link BusinessException}
 * when the runDate is "FAIL". Otherwise it pretends to process some records.
 */
@Service
@BusinessService    // ← marker: ServiceErrorAspect will advise this class
public class SimulatedProcessingService {

    private static final Logger log = LoggerFactory.getLogger(SimulatedProcessingService.class);

    public int process(String jobName, String runDate) {
        log.info("  [Service] Processing job={}, date={}", jobName, runDate);

        // Trigger a failure path so we can demo the aspect + exit-code mapping.
        if ("FAIL".equals(runDate)) {
            throw new BusinessException("Simulated business failure for job " + jobName, 3);
        }

        // Simulate doing work
        try {
            Thread.sleep(200);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        int recordsProcessed = ThreadLocalRandom.current().nextInt(100, 1000);
        log.info("  [Service] Done. {} records.", recordsProcessed);
        return recordsProcessed;
    }
}
