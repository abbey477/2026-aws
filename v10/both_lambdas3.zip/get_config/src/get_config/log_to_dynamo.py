"""
Shared DynamoDB log writer for all Lambda functions.

Table Schema:
    PK : run_id (string), SK : time (string, ISO 8601)
    job_id, stage, status, delete_at (TTL)
"""

import os
import logging
from datetime import datetime, timedelta, timezone

import boto3

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

LOGS_TABLE = os.environ.get("LOGS_TABLE", "app-jobLog")

_dynamodb_resource = None


def _get_dynamodb_resource():
    global _dynamodb_resource
    if _dynamodb_resource is None:
        _dynamodb_resource = boto3.resource("dynamodb")
    return _dynamodb_resource


def set_dynamodb_resource(resource):
    global _dynamodb_resource
    _dynamodb_resource = resource


def write_log(run_id: str, job_id: str, stage: str, status: str) -> None:
    now = datetime.now(timezone.utc)
    time_iso = now.strftime("%Y-%m-%dT%H:%M:%S.%fZ")
    delete_at = int((now + timedelta(days=30)).timestamp())

    item = {
        "run_id": run_id, "time": time_iso,
        "job_id": job_id, "stage": stage,
        "status": status, "delete_at": delete_at,
    }

    try:
        dynamodb = _get_dynamodb_resource()
        table = dynamodb.Table(LOGS_TABLE)
        table.put_item(Item=item)
        logger.info(f"[LogToDynamo] run_id={run_id}, stage={stage}, status={status}")
    except Exception as exc:
        logger.warning(f"[LogToDynamo] FAILED to write log: {exc} | run_id={run_id}, stage={stage}")
