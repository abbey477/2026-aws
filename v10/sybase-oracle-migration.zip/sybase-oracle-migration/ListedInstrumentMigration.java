import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;

import java.util.ArrayList;
import java.util.List;

/**
 * Streaming migration for ListedInstrument (Sybase -> Oracle).
 *
 * <p>Streams rows from Sybase via {@link RowCallbackHandler}, buffers them, and
 * flushes batches to Oracle through {@link ListedInstrumentOracleRepository}.
 * Memory is bounded at ~BATCH_SIZE rows.
 *
 * <p>Row mapping is delegated to {@link ListedInstrumentRowMapper}; see that class
 * for type-handling notes.
 *
 * <p>Two variants for A/B comparison: {@link #migrateByIndex()} (positional,
 * fastest) and {@link #migrateByName()} (by name, robust to SELECT reordering).
 */
@Slf4j
public class ListedInstrumentMigration {

    private static final int FETCH_SIZE = 2000;
    private static final int BATCH_SIZE = 5000;

    /**
     * SELECT column order MUST match the order used by
     * {@link ListedInstrumentRowMapper#mapByIndex} when reading positionally.
     */
    private static final String SELECT_SQL =
            "SELECT ID_IMNT, ID_CLASS_EQ, AM_ISSUE_MIN, DT_IPO_OPN, DT_IPO_CLSE, " +
            "       DT_EXPY_LGL, AM_BID_OFFER_SPRD, AM_ISSUE, PR_ISSUE, AM_IMNT_OUTST, " +
            "       NM_UNDERWRT, ID_REG_BEAR, ID_VALID, ID_TYP_CLR, ID_TYP_PR_ISSUE, " +
            "       ID_TYP_DT_ISSUE, ID_STG_IMNT, ID_BOND_GLOBAL, ID_BOND_EURO, ID_SEAQ, " +
            "       ID_CUPID, ID_PROSPECTUS, DT_PROSP_START, ID_PASSPORT, ID_PROGRAM, " +
            "       DT_ALLOT, DT_CMDT, ID_SECAM_GOV_TYP, ID_SECAM_CATCODE, ID_NCSC, " +
            "       ID_CAPITAL_PROTECTED, ID_CW_REGION, ID_TERM_PROV, ID_PUR_CON_PLEDGE, ID_TYP_OFF_PAY, " +
            "       ID_FUNGIBLE_TRANCHE, DT_CREATE, ID_USER_CREATE, DT_CHG_LAST, ID_USER_CHG_LAST, " +
            "       DT_NOTICE_FST, DT_DELIVERY_FST, DT_DELIVERY_LST, ID_CLIENT_ROLE, AM_DENOMINATION, " +
            "       ID_SUPERSIZED, AM_STRESSED_LTV, ID_SHORT_SELL, ID_CNS, AM_CPN_DENOM, " +
            "       ID_ROUNDING, ID_TYP_PLCMT, ID_REG_SEC, DT_SUB_OPN, DT_SUB_CLSE, " +
            "       ID_BO_TYPE, ID_BO_FREQ, DT_CHG_GRD, ID_DEL_GRD, ID_OWN_GRD " +
            "FROM LISTED_INSTRUMENT";

    private static final String TABLE_LABEL = "LISTED_INSTRUMENT";

    private final JdbcTemplate sybaseJdbcTemplate;
    private final ListedInstrumentOracleRepository oracleRepo;

    public ListedInstrumentMigration(
            @Qualifier("sybaseJdbcTemplate") JdbcTemplate sybaseJdbcTemplate,
            ListedInstrumentOracleRepository oracleRepo) {
        this.sybaseJdbcTemplate = sybaseJdbcTemplate;
        this.oracleRepo = oracleRepo;

        // CRITICAL: without this jconn4 uses a tiny default fetch size.
        this.sybaseJdbcTemplate.setFetchSize(FETCH_SIZE);
    }

    /** Variant A — positional read. */
    public void migrateByIndex() {
        run("byIndex", ListedInstrumentRowMapper::mapByIndex);
    }

    /** Variant B — by-name read. */
    public void migrateByName() {
        run("byName", ListedInstrumentRowMapper::mapByName);
    }

    /**
     * Shared streaming pipeline. The variants only differ in which mapper they pass in,
     * so the orchestration is parameterized to avoid code duplication.
     */
    private void run(String variant, RowMapperFn mapper) {
        log.info("[{}] Starting migration (variant={}, fetchSize={}, batchSize={})",
                TABLE_LABEL, variant, FETCH_SIZE, BATCH_SIZE);
        final long startNanos = System.nanoTime();

        oracleRepo.truncate();

        final List<ListedInstrument> buffer = new ArrayList<>(BATCH_SIZE);
        final MigrationStats stats = new MigrationStats();

        sybaseJdbcTemplate.query(SELECT_SQL, (RowCallbackHandler) rs -> {
            buffer.add(mapper.apply(rs));
            if (buffer.size() >= BATCH_SIZE) {
                flush(stats, buffer);
            }
        });

        if (!buffer.isEmpty()) {
            flush(stats, buffer);
        }

        logCompletion(variant, stats, startNanos);
    }

    private void flush(MigrationStats stats, List<ListedInstrument> buffer) {
        final int rowsInThisBatch = buffer.size();
        final long batchStartNanos = System.nanoTime();

        oracleRepo.batchInsert(buffer);

        final long batchElapsedMs = (System.nanoTime() - batchStartNanos) / 1_000_000;
        stats.batchCount++;
        stats.totalRows += rowsInThisBatch;

        log.debug("[{}] Batch {} complete — rows={}, elapsedMs={}, totalRowsSoFar={}",
                TABLE_LABEL, stats.batchCount, rowsInThisBatch, batchElapsedMs, stats.totalRows);

        buffer.clear();
    }

    private void logCompletion(String variant, MigrationStats stats, long startNanos) {
        final long totalElapsedMs = (System.nanoTime() - startNanos) / 1_000_000;
        final double seconds = Math.max(totalElapsedMs / 1000.0, 0.001);
        final long rowsPerSec = (long) (stats.totalRows / seconds);

        log.info("[{}] Migration complete (variant={}) — totalRows={}, batches={}, elapsedMs={}, throughput={} rows/sec",
                TABLE_LABEL, variant, stats.totalRows, stats.batchCount, totalElapsedMs, rowsPerSec);
    }

    /** Functional interface so we can pass a checked-exception-throwing mapper as a method reference. */
    @FunctionalInterface
    private interface RowMapperFn {
        ListedInstrument apply(java.sql.ResultSet rs) throws java.sql.SQLException;
    }

    private static final class MigrationStats {
        long totalRows = 0;
        int batchCount = 0;
    }
}
