"""
Shared seed-data builders and test helpers — importable as a regular
Python module from any test file.
"""

from botocore.exceptions import ClientError


def make_event(pre_steps=...) -> dict:
    """
    Build a minimal but realistic GetConfig-shaped event.

    pre_steps=... (Ellipsis) means "do not set pre_steps at all"
    pre_steps=None / [] / [...items...] are set as provided.
    """
    event = {
        "run_id": "run-001",
        "job_id": "client",
        "job_type": "sourcing",
        "status": "WAITING",
        "trigger_type": "SCHEDULER",
        "custom_attributes": {},
        "job_config": {
            "enabled": True,
            "job_runner": {"type": "ECS_Fargate", "name": "S2S3", "config": {}},
            "job_param": {},
            "next_jobs": [],
        },
    }
    if pre_steps is not ...:
        event["job_config"]["pre_steps"] = pre_steps
    return event


def raise_access_denied(*args, **kwargs):
    """Reusable stub that raises a DynamoDB AccessDeniedException."""
    raise ClientError(
        {"Error": {"Code": "AccessDeniedException", "Message": "Denied"}},
        "Query",
    )
