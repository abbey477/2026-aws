# config/

`@Configuration` classes and `@ConfigurationProperties` bindings.

Examples of what goes here:
- `DataSourceConfig.java` — DataSource and connection pool tuning
- `TransactionConfig.java` — PlatformTransactionManager, TransactionTemplate
- `BatchProperties.java` — `@ConfigurationProperties("batch")` typed binding

Job-specific config (e.g., chunk size for just JobA) lives inside the job's
own folder under `jobs/joba/JobAConfig.java`, NOT here.
