"""Tests for log_to_dynamo.py"""
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import pytest
from schedule_next_job.log_to_dynamo import write_log, set_dynamodb_resource


class TestWriteLog:

    def test_writes_item_to_logs_table(self, dynamodb_setup):
        """write_log inserts a record into the logs table."""
        dynamodb, _, _, logs_table = dynamodb_setup
        set_dynamodb_resource(dynamodb)

        write_log(run_id="run-001", job_id="client", stage="ScheduleNextJob", status="SUCCESS")

        result = logs_table.scan()["Items"]
        assert len(result) == 1
        item = result[0]
        assert item["run_id"] == "run-001"
        assert item["job_id"] == "client"
        assert item["stage"] == "ScheduleNextJob"
        assert item["status"] == "SUCCESS"
        assert "time" in item
        assert "delete_at" in item

    def test_writes_failure_status(self, dynamodb_setup):
        """write_log correctly records FAILURE status."""
        dynamodb, _, _, logs_table = dynamodb_setup
        set_dynamodb_resource(dynamodb)

        write_log(run_id="run-002", job_id="client", stage="ScheduleNextJob", status="FAILURE")

        items = logs_table.scan()["Items"]
        assert items[0]["status"] == "FAILURE"

    def test_does_not_raise_on_dynamo_error(self, monkeypatch):
        """write_log swallows exceptions so it never breaks the pipeline."""
        import unittest.mock as mock
        bad_resource = mock.MagicMock()
        bad_resource.Table.return_value.put_item.side_effect = Exception("DynamoDB down")
        set_dynamodb_resource(bad_resource)

        # Should not raise
        write_log(run_id="r", job_id="j", stage="s", status="SUCCESS")

    def test_delete_at_is_set(self, dynamodb_setup):
        """delete_at TTL field is always populated."""
        dynamodb, _, _, logs_table = dynamodb_setup
        set_dynamodb_resource(dynamodb)

        write_log(run_id="run-003", job_id="j", stage="s", status="SUCCESS")

        item = logs_table.scan()["Items"][0]
        from decimal import Decimal
        assert isinstance(item["delete_at"], (int, Decimal))
        assert item["delete_at"] > 0
