#!/usr/bin/env bash
# =============================================================================
#  myapp.sh — Build & Run helper for the myapp multi-module Maven project
#
#  Usage:
#    ./myapp.sh <command> [module]
#
#  Commands:
#    build [module]   — Compile & package (all modules, or one)
#    run   <module>   — Run a specific module
#    run   all        — Run all 3 modules in the background
#    stop             — Stop all background modules started by this script
#    clean [module]   — Maven clean (all or one)
#    logs  <module>   — Tail the log file for a running background module
#    help             — Show this message
#
#  Modules:  authserver | resserver | webapp
#
#  Examples:
#    ./myapp.sh build                 # build everything
#    ./myapp.sh build authserver      # build only authserver
#    ./myapp.sh run authserver        # run authserver in foreground
#    ./myapp.sh run all               # start all 3 in background
#    ./myapp.sh logs resserver        # tail resserver log
#    ./myapp.sh stop                  # kill all background processes
# =============================================================================

set -euo pipefail

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PID_DIR="$SCRIPT_DIR/.pids"
LOG_DIR="$SCRIPT_DIR/.logs"

MODULES=(authserver resserver webapp)
PORTS=(authserver=9000 resserver=8081 webapp=8080)

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'

info()    { echo -e "${CYAN}[INFO]${NC}  $*"; }
success() { echo -e "${GREEN}[OK]${NC}    $*"; }
warn()    { echo -e "${YELLOW}[WARN]${NC}  $*"; }
error()   { echo -e "${RED}[ERROR]${NC} $*" >&2; }

require_module() {
    local m="$1"
    if [[ ! " ${MODULES[*]} " =~ " ${m} " ]]; then
        error "Unknown module: '$m'. Valid modules: ${MODULES[*]}"
        exit 1
    fi
}

mvn_cmd() {
    # Prefer ./mvnw if present, fall back to system mvn
    if [[ -f "$SCRIPT_DIR/mvnw" ]]; then
        "$SCRIPT_DIR/mvnw" "$@"
    else
        mvn "$@"
    fi
}

jar_for() {
    local module="$1"
    local jar
    jar=$(find "$SCRIPT_DIR/$module/target" -maxdepth 1 -name "*.jar" ! -name "*-sources.jar" 2>/dev/null | head -1)
    echo "$jar"
}

# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

cmd_build() {
    local module="${1:-}"
    if [[ -z "$module" ]]; then
        info "Building all modules…"
        mvn_cmd -f "$SCRIPT_DIR/pom.xml" clean package -DskipTests
        success "All modules built."
    else
        require_module "$module"
        info "Building $module…"
        mvn_cmd -f "$SCRIPT_DIR/$module/pom.xml" clean package -DskipTests
        success "$module built."
    fi
}

cmd_run_one() {
    local module="$1"
    require_module "$module"

    local jar
    jar=$(jar_for "$module")

    if [[ -z "$jar" ]]; then
        warn "No JAR found for $module — building first…"
        cmd_build "$module"
        jar=$(jar_for "$module")
    fi

    info "Starting $module from $jar"
    java -jar "$jar"
}

cmd_run_background() {
    local module="$1"
    require_module "$module"

    local jar
    jar=$(jar_for "$module")

    if [[ -z "$jar" ]]; then
        warn "No JAR found for $module — building first…"
        cmd_build "$module"
        jar=$(jar_for "$module")
    fi

    mkdir -p "$PID_DIR" "$LOG_DIR"
    local logfile="$LOG_DIR/$module.log"
    local pidfile="$PID_DIR/$module.pid"

    info "Starting $module in background → log: $logfile"
    nohup java -jar "$jar" > "$logfile" 2>&1 &
    local pid=$!
    echo "$pid" > "$pidfile"
    success "$module started (PID $pid)"
}

cmd_run_all() {
    info "Starting all modules in background…"
    info "⚠  Start order matters: authserver → resserver → webapp"
    info "   Waiting 10s between modules so Auth Server is ready…"

    cmd_run_background authserver
    sleep 10

    cmd_run_background resserver
    sleep 5

    cmd_run_background webapp

    echo ""
    success "All modules started."
    echo -e "  ${CYAN}Auth Server${NC}  → http://localhost:9000"
    echo -e "  ${CYAN}Res Server${NC}   → http://localhost:8081/api/hello"
    echo -e "  ${CYAN}Web App${NC}      → http://localhost:8080"
    echo ""
    info "Use './myapp.sh logs <module>' to tail a log."
    info "Use './myapp.sh stop' to shut everything down."
}

cmd_stop() {
    if [[ ! -d "$PID_DIR" ]]; then
        warn "No PID directory found — nothing to stop."
        return
    fi

    for pidfile in "$PID_DIR"/*.pid; do
        [[ -f "$pidfile" ]] || continue
        local module
        module=$(basename "$pidfile" .pid)
        local pid
        pid=$(cat "$pidfile")

        if kill -0 "$pid" 2>/dev/null; then
            kill "$pid"
            success "Stopped $module (PID $pid)"
        else
            warn "$module (PID $pid) was not running"
        fi
        rm -f "$pidfile"
    done
}

cmd_clean() {
    local module="${1:-}"
    if [[ -z "$module" ]]; then
        info "Cleaning all modules…"
        mvn_cmd -f "$SCRIPT_DIR/pom.xml" clean
        success "All modules cleaned."
    else
        require_module "$module"
        info "Cleaning $module…"
        mvn_cmd -f "$SCRIPT_DIR/$module/pom.xml" clean
        success "$module cleaned."
    fi
}

cmd_logs() {
    local module="${1:-}"
    [[ -z "$module" ]] && { error "Usage: ./myapp.sh logs <module>"; exit 1; }
    require_module "$module"
    local logfile="$LOG_DIR/$module.log"
    [[ -f "$logfile" ]] || { error "Log not found: $logfile  (has the module been started with 'run all'?)"; exit 1; }
    tail -f "$logfile"
}

cmd_help() {
    sed -n '3,25p' "${BASH_SOURCE[0]}" | sed 's/^#  \?//'
}

# ---------------------------------------------------------------------------
# Dispatch
# ---------------------------------------------------------------------------

COMMAND="${1:-help}"
shift || true

case "$COMMAND" in
    build) cmd_build  "${1:-}" ;;
    run)
        TARGET="${1:-}"
        if [[ "$TARGET" == "all" ]]; then
            cmd_run_all
        else
            [[ -z "$TARGET" ]] && { error "Usage: ./myapp.sh run <module|all>"; exit 1; }
            cmd_run_one "$TARGET"
        fi
        ;;
    stop)  cmd_stop ;;
    clean) cmd_clean "${1:-}" ;;
    logs)  cmd_logs  "${1:-}" ;;
    help|--help|-h) cmd_help ;;
    *)
        error "Unknown command: '$COMMAND'"
        cmd_help
        exit 1
        ;;
esac
