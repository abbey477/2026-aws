# batch-app (simplified)

Hybrid REST + standalone batch app. Single AOP pointcut, single catch location, clear exit codes.

## Exception handling flow

```
Service throws BusinessException ❌
            │
            ▼
ServiceErrorAspect (@within(@BusinessService))
   logs the error
            │ exception keeps going up
            ▼
JobDispatcher catches once
   maps to exit code
            │
            ▼
  REST: returns JSON with code
  CLI:  System.exit(code) → Autosys reads it
```

## Two simple ideas

1. **One marker annotation** — `@BusinessService`. Put it on any service class you want the aspect to watch.
2. **One catch location** — `JobDispatcher`. That's where exceptions become exit codes.

That's it. No `@RestControllerAdvice`, no multiple pointcuts, no layered handlers.

## Exit codes

| Code | Meaning |
|------|---------|
| 0 | Success |
| 1 | Unexpected error |
| 2 | Bad arguments / unknown job |
| 3 | Business error (set via `BusinessException(msg, 3)`) |

Add more codes by throwing `BusinessException` with whatever number fits.

## Build

```bash
mvn clean package
```

## Run (CLI mode)

```bash
# Happy path
java -cp target/batch-app-1.0.0.jar \
     -Dloader.main=com.example.batch.BatchCliApplication \
     org.springframework.boot.loader.launch.PropertiesLauncher \
     --job=jobA
echo "Exit: $?"   # → 0

# Failure path (triggers BusinessException)
java -cp target/batch-app-1.0.0.jar \
     -Dloader.main=com.example.batch.BatchCliApplication \
     org.springframework.boot.loader.launch.PropertiesLauncher \
     --job=jobA --runDate=FAIL
echo "Exit: $?"   # → 3
```

## Run (REST mode)

```bash
# Terminal 1
java -jar target/batch-app-1.0.0.jar

# Terminal 2
curl -X POST http://localhost:8080/api/jobs/jobA/run
curl -X POST "http://localhost:8080/api/jobs/jobA/run?runDate=FAIL"
```

## File layout

```
src/main/java/com/example/batch/
├── BatchCliApplication.java          ← CLI main (Autosys)
├── BatchWebApplication.java          ← REST main
├── core/
│   ├── BatchJob.java                 ← interface every job implements
│   ├── BusinessService.java          ← marker annotation
│   ├── JobContext.java
│   ├── JobDispatcher.java            ← ONE catch turns exceptions into exit codes
│   └── JobResult.java
├── common/
│   ├── aspect/
│   │   └── ServiceErrorAspect.java   ← single @within pointcut, just logs
│   ├── exception/
│   │   └── BusinessException.java
│   └── service/
│       └── SimulatedProcessingService.java   ← @BusinessService
├── jobs/
│   ├── joba/JobA.java
│   ├── jobb/JobB.java
│   └── jobc/JobC.java
└── web/
    └── JobController.java            ← REST controller, uses same dispatcher
```

## Adding a new job

1. Create `JobD.java` implementing `BatchJob`, marked `@Component`.
2. Add `"jobD"` to the shell script's `VALID_JOBS` array.

Dispatcher picks it up automatically.

## Adding a new service class to be advised by the aspect

Annotate with `@BusinessService`:

```java
@Service
@BusinessService
public class MyOtherService { ... }
```

Done — the aspect will catch any exception it throws.

## Adding a new business error type

```java
throw new BusinessException("Validation failed", 4);
```

Anywhere in a `@BusinessService` class. The aspect logs it; the dispatcher returns exit code 4. No other changes needed.
