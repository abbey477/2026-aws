# DynamoDB Test Data

Seed data for `app-jobConfig` (15), `app-jobRun` (50), `app-jobLog` (100).

## Three commands

```bash
chmod +x *.sh

./setup.sh     # load all test data
./cleanup.sh   # delete all items from the three tables (keeps the tables)
./reset.sh     # cleanup + setup (fresh state)
```

`cleanup.sh` asks you to type `yes` before deleting anything.

## Requirements

- AWS CLI configured (`aws configure`) with permissions to read/write the three tables
- The tables must already exist with these keys:
  - `app-jobConfig`: PK `job_id` (S), SK `job_type` (S)
  - `app-jobRun`: PK `run_id` (S), SK `last_updated_time` (S)
  - `app-jobLog`: PK `run_id` (S), SK `time` (S)
- Python 3 (used by the cleanup script for batching)

## If the local CLI is blocked

Upload this folder to AWS CloudShell (terminal icon in the console) and run the scripts there — same commands.
