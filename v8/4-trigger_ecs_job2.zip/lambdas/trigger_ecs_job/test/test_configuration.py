"""
Configuration tests for trigger_ecs_task.

Coverage:
  - Runner config overrides flow through to run_task
  - Missing cluster still calls RunTask (AWS rejects cleanly)
  - Missing image logs as "N/A"
  - Subnets and security groups passed through as-is
  - Launch type is always FARGATE
"""

import logging

from trigger_ecs_job.ecs_trigger import trigger_ecs_task
from conftest import make_event, mock_ecs_client_success


class TestConfiguration:

    def test_runner_config_overrides_defaults(self):
        """Runner config overrides should flow through to run_task."""
        mock_ecs = mock_ecs_client_success()
        event = make_event(runner_config_overrides={
            "task_definition": "custom-task-def",
            "container_name": "custom-container",
        })
        job_config = event["job_config"]
        job_param = job_config["job_param"]

        trigger_ecs_task(mock_ecs, job_config, job_param, "run-001")

        call_kwargs = mock_ecs.run_task.call_args.kwargs
        assert call_kwargs["taskDefinition"] == "custom-task-def"
        overrides = call_kwargs["overrides"]["containerOverrides"][0]
        assert overrides["name"] == "custom-container"

    def test_subnets_and_security_groups_passed_through(self):
        """Network config should be passed to run_task as-is."""
        mock_ecs = mock_ecs_client_success()
        event = make_event()
        job_config = event["job_config"]
        job_param = job_config["job_param"]

        trigger_ecs_task(mock_ecs, job_config, job_param, "run-001")

        call_kwargs = mock_ecs.run_task.call_args.kwargs
        net_config = call_kwargs["networkConfiguration"]["awsvpcConfiguration"]
        assert net_config["subnets"] == ["subnet-aaa111", "subnet-bbb222"]
        assert net_config["securityGroups"] == ["sg-abc123"]
        assert net_config["assignPublicIp"] == "DISABLED"

    def test_launch_type_is_fargate(self):
        """Launch type should always be FARGATE."""
        mock_ecs = mock_ecs_client_success()
        event = make_event()
        job_config = event["job_config"]
        job_param = job_config["job_param"]

        trigger_ecs_task(mock_ecs, job_config, job_param, "run-001")

        assert mock_ecs.run_task.call_args.kwargs["launchType"] == "FARGATE"

    def test_missing_image_logs_as_na(self, caplog):
        """When image is empty, log should show N/A."""
        mock_ecs = mock_ecs_client_success()
        event = make_event(runner_config_overrides={"image": ""})
        job_config = event["job_config"]
        job_param = job_config["job_param"]

        with caplog.at_level(logging.INFO):
            trigger_ecs_task(mock_ecs, job_config, job_param, "run-001")

        assert any("image=N/A" in rec.message for rec in caplog.records)

    def test_missing_cluster_still_calls_run_task(self):
        """Missing cluster still calls RunTask — AWS rejects cleanly."""
        mock_ecs = mock_ecs_client_success()
        event = make_event(runner_config_overrides={"cluster": ""})
        job_config = event["job_config"]
        job_param = job_config["job_param"]

        trigger_ecs_task(mock_ecs, job_config, job_param, "run-001")

        assert mock_ecs.run_task.called
        assert mock_ecs.run_task.call_args.kwargs["cluster"] == ""
