package com.example.batch.core;

/**
 * Contract every batch job implements.
 *
 * <p>One {@code BatchJob} bean per job. The dispatcher auto-discovers them via
 * Spring component scanning and routes {@code --job=<name>} to the right one.
 *
 * <p>Implementations should:
 * <ul>
 *   <li>Be annotated with {@code @Component}</li>
 *   <li>Be stateless — delegate work to injected services</li>
 *   <li>Return a {@link JobResult} indicating success/failure and counts</li>
 *   <li>Throw on fatal errors; the dispatcher will catch and mark as failed</li>
 * </ul>
 */
public interface BatchJob {

    /**
     * Unique name used to look up this job. Must match the {@code --job=<name>}
     * argument passed on the command line.
     */
    String getName();

    /**
     * Run the job with the given context.
     *
     * @param context runtime parameters (job name, run date)
     * @return result with success flag and record counts
     * @throws Exception for fatal errors; will be caught by the dispatcher
     */
    JobResult execute(JobContext context) throws Exception;
}
