"""
Routing: known pre_step_types should route to their specific handlers.
"""

from pre_steps_processor.handler import lambda_handler
from seed_data import make_event


class TestRoutingKnownTypes:

    def test_change_since_append_calls_its_handler_with_event(self, mocks):
        step = {"pre_step_type": "change_since_append"}
        event = make_event(pre_steps=[step])
        lambda_handler(event, None)

        mocks["change_since"].assert_called_once_with(step, event)
        mocks["ddb_pull"].assert_not_called()
        mocks["unknown"].assert_not_called()
        mocks["no_data"].assert_not_called()

    def test_ddb_config_pull_calls_its_handler_with_event(self, mocks):
        step = {
            "pre_step_type": "ddb_config_pull",
            "tables": ["service_config", "table_config"],
        }
        event = make_event(pre_steps=[step])
        lambda_handler(event, None)

        mocks["ddb_pull"].assert_called_once_with(step, event)
        mocks["change_since"].assert_not_called()
        mocks["unknown"].assert_not_called()
        mocks["no_data"].assert_not_called()

    def test_both_known_types_in_sequence(self, mocks):
        steps = [
            {"pre_step_type": "change_since_append"},
            {"pre_step_type": "ddb_config_pull", "tables": ["a", "b"]},
        ]
        event = make_event(pre_steps=steps)
        lambda_handler(event, None)

        mocks["change_since"].assert_called_once_with(steps[0], event)
        mocks["ddb_pull"].assert_called_once_with(steps[1], event)
        mocks["unknown"].assert_not_called()
        mocks["no_data"].assert_not_called()

    def test_same_type_multiple_times(self, mocks):
        steps = [
            {"pre_step_type": "change_since_append"},
            {"pre_step_type": "change_since_append"},
        ]
        lambda_handler(make_event(pre_steps=steps), None)
        assert mocks["change_since"].call_count == 2
