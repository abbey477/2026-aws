"""
DynamoDB data access for PreStepsProcessor Lambda.

Queries used by the step handlers:
- get_last_successful_run_start_time: GSI-2 jobIdQuery scan for
  change_since_append, returns the newest SUCCESS row's start_time.
- pull_config_from_table: get_item on a config table for ddb_config_pull.
"""

import os

import boto3
from botocore.exceptions import ClientError
from boto3.dynamodb.conditions import Key, Attr

from pre_steps_processor import logging_utils as log


JOB_RUN_TABLE = os.environ.get("JOB_RUN_TABLE", "app-jobRun")
JOB_ID_QUERY_INDEX = os.environ.get("JOB_ID_QUERY_INDEX", "jobIdQuery")


def get_dynamodb_resource():
    """Return a DynamoDB resource. Separated for easy mocking in tests."""
    return boto3.resource("dynamodb")


def get_last_successful_run_start_time(
    table,
    job_id: str,
    job_type: str,
) -> str | None:
    """
    Find the start_time of the newest COMPLETED run for (job_id, job_type).

    Uses GSI-2 jobIdQuery (PK=job_id, SK=start_time) and a FilterExpression
    on job_type + status. Does NOT use Limit=1 — DynamoDB applies Limit
    before FilterExpression, which would cause false negatives here.

    Returns None if no successful run exists (brand-new job, or all prior
    runs failed).

    Raises:
        ClientError: If DynamoDB call fails.
    """
    log.info("QUERY_LAST_SUCCESS_START", {
        "job_id": job_id,
        "job_type": job_type,
        "table": JOB_RUN_TABLE,
        "index": JOB_ID_QUERY_INDEX,
    })

    try:
        response = table.query(
            IndexName=JOB_ID_QUERY_INDEX,
            KeyConditionExpression=Key("job_id").eq(job_id),
            FilterExpression=(
                Attr("job_type").eq(job_type) & Attr("status").eq("COMPLETED")
            ),
            ScanIndexForward=False,  # newest start_time first
        )
    except ClientError as e:
        log.error("QUERY_LAST_SUCCESS_ERROR", {
            "job_id": job_id,
            "job_type": job_type,
            "error_code": e.response.get("Error", {}).get("Code", "Unknown"),
            "error_message": str(e),
        })
        raise

    items = response.get("Items", [])
    if not items:
        log.warn("QUERY_LAST_SUCCESS_NONE_FOUND", {
            "job_id": job_id,
            "job_type": job_type,
        })
        return None

    start_time = items[0].get("start_time")
    log.info("QUERY_LAST_SUCCESS_FOUND", {
        "job_id": job_id,
        "job_type": job_type,
        "start_time": start_time,
    })
    return start_time


def pull_config_from_table(
    table,
    table_name: str,
    job_id: str,
    job_type: str,
) -> dict | None:
    """
    Look up a single config row by (job_id, job_type) from a config table.

    Assumes the table uses a two-part key:  PK=job_id, SK=job_type.
    NOTE: config tables are not created yet — architect will confirm the
    key schema. If different, only this function needs to change.

    Returns the row dict if found, or None if no row exists.

    Raises:
        ClientError: If DynamoDB call fails.
    """
    log.info("PULL_CONFIG_START", {
        "table": table_name,
        "job_id": job_id,
        "job_type": job_type,
    })

    try:
        response = table.get_item(Key={"job_id": job_id, "job_type": job_type})
    except ClientError as e:
        log.error("PULL_CONFIG_ERROR", {
            "table": table_name,
            "job_id": job_id,
            "job_type": job_type,
            "error_code": e.response.get("Error", {}).get("Code", "Unknown"),
            "error_message": str(e),
        })
        raise

    item = response.get("Item")
    if item is None:
        log.warn("PULL_CONFIG_NOT_FOUND", {
            "table": table_name,
            "job_id": job_id,
            "job_type": job_type,
        })
        return None

    log.info("PULL_CONFIG_FOUND", {
        "table": table_name,
        "job_id": job_id,
        "job_type": job_type,
    })
    return item
