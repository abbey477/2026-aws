"""
GetConfig Lambda Handler — v6

Fetches job configuration from DynamoDB.
Step 1: Query `job_run` table using run_id (and optional last_updated_time
        for restarts) to get job run metadata.
Step 2: Query `job_config` table using job_id (partition key) and job_type
        (sort key) to get the full job configuration.

Input:
    Normal run:     { "run_id": "cscc66s6d78d6cc" }
    Restart a run:  { "run_id": "cscc66s6d78d6cc",
                      "last_updated_time": "2024-03-15T10:00:00Z" }

Output: Merged payload — all job_run fields at top level, full job_config
        nested under "job_config" key.

v6 change:
  - job_run table now has a composite key (PK=run_id, SK=last_updated_time).
  - When last_updated_time is NOT passed, we fetch the latest row (current
    state). When it IS passed, we fetch that exact historical snapshot —
    supports Step Function re-runs from a known point in time.
"""

import json
from datetime import datetime, timezone

from lambdas.log_to_dynamo import write_log

from .logging_utils import _log
from .dynamodb_ops import (
    JOB_RUN_TABLE,
    JOB_CONFIG_TABLE,
    get_dynamodb_resource,
    get_job_run,
    get_job_config,
)


def lambda_handler(event, context):
    """
    Lambda entry point.

    Input event:
        { "run_id": "cscc66s6d78d6cc" }
        or (for restart):
        { "run_id": "...", "last_updated_time": "2024-03-15T10:00:00Z" }

    Output:
        Merged payload — all job_run fields at top level,
        full job_config nested under `job_config` key.
    """
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    _log("HANDLER_START", {
        "timestamp": timestamp,
        "input_event": json.dumps(event),
    })

    # --- Validate input ---
    run_id = event.get("run_id")
    if not run_id:
        _log("VALIDATION_ERROR", {"error": "Missing required input: 'run_id'"})
        raise ValueError("Missing required input: 'run_id'")

    # Optional — only supplied by Step Function for restart flows.
    # Empty/None means "give me the latest row" (normal case).
    last_updated_time = event.get("last_updated_time")

    _log("INPUT_VALIDATED", {
        "run_id": run_id,
        "last_updated_time": last_updated_time or "<not provided - will fetch latest>",
    })

    dynamodb = get_dynamodb_resource()

    # --- Step 1: Get job run metadata ---
    _log("STEP_1", {
        "action": "Fetching job_run row",
        "run_id": run_id,
        "mode": "exact" if last_updated_time else "latest",
    })
    job_run_table = dynamodb.Table(JOB_RUN_TABLE)
    job_run = get_job_run(job_run_table, run_id, last_updated_time)

    # --- Extract keys for config lookup ---
    job_id = job_run.get("job_id")
    job_type = job_run.get("job_type")

    if not job_id or not job_type:
        _log("VALIDATION_ERROR", {
            "error": "job_run record missing job_id or job_type",
            "job_id": job_id,
            "job_type": job_type,
        })
        raise ValueError(
            f"job_run record is missing 'job_id' or 'job_type'. "
            f"Got job_id={job_id}, job_type={job_type}"
        )

    # --- Step 2: Get job configuration ---
    _log("STEP_2", {
        "action": "Querying job_config table",
        "job_id": job_id,
        "job_type": job_type,
    })
    job_config_table = dynamodb.Table(JOB_CONFIG_TABLE)
    job_config = get_job_config(job_config_table, job_id, job_type)

    # --- Build merged output ---
    # Spread all job_run fields at top level; nest the full job_config row.
    # Any new fields added to job_config (e.g. pre_steps) flow through as-is.
    output = {**job_run, "job_config": job_config}

    # --- Log success AFTER we know the full payload is valid ---
    _log("HANDLER_COMPLETE", {
        "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "run_id": run_id,
        "job_id": job_id,
        "job_type": job_type,
        "runner_name": job_config.get("job_runner", {}).get("name", "N/A"),
        "output_keys": list(output.keys()),
    })

    write_log(run_id=run_id, job_id=job_id, stage="GetConfig", status="SUCCESS")

    return output
