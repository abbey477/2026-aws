package com.example.dbtester.repository.sybase;

import com.example.dbtester.entity.Customer;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * JDBC repository for the Sybase CUSTOMER table.
 *
 * <p>Differs from {@link com.example.dbtester.repository.oracle.ProductRepository}
 * in one important way: Sybase's {@code IDENTITY} column auto-assigns primary
 * keys on INSERT, rather than reading from a sequence. That means:
 * <ul>
 *   <li>Single inserts use {@link SimpleJdbcInsert}, which transparently grabs
 *       the generated key via the driver's {@code @@IDENTITY} equivalent.</li>
 *   <li>Batch inserts do NOT get the generated keys back — JDBC batching with
 *       {@code IDENTITY} columns is too driver-specific to rely on. If you
 *       need the IDs, either insert row-by-row or re-query by a natural key.</li>
 * </ul>
 *
 * <p>The {@code @Qualifier("sybaseJdbcTemplate")} and
 * {@code @Qualifier("sybaseDataSource")} annotations ensure we pick up the
 * Sybase-scoped beans, not the Oracle ones (which are marked {@code @Primary}).
 */
@Repository
public class CustomerRepository {

    /**
     * Max rows per {@code executeBatch()} round-trip.
     *
     * <p>For Sybase jConnect with {@code DYNAMIC_PREPARE=true} (set in
     * application.properties), 500-1000 is the usual sweet spot. Without
     * DYNAMIC_PREPARE, batching is much less effective because every
     * statement round-trips.
     */
    private static final int BATCH_SIZE = 500;

    /** Table name used by SimpleJdbcInsert to auto-generate its INSERT SQL. */
    private static final String TABLE = "CUSTOMER";

    private static final String SQL_FIND_ALL =
            "SELECT id, first_name, last_name, email, created_at FROM CUSTOMER";

    private static final String SQL_FIND_BY_ID =
            "SELECT id, first_name, last_name, email, created_at FROM CUSTOMER WHERE id = ?";

    /**
     * Explicit INSERT for batch path. Does NOT include the id column — Sybase
     * auto-assigns it from the IDENTITY sequence. (SimpleJdbcInsert builds an
     * equivalent statement internally for the single-row path.)
     */
    private static final String SQL_INSERT_BATCH =
            "INSERT INTO CUSTOMER (first_name, last_name, email, created_at) VALUES (?, ?, ?, ?)";

    /** Update leaves created_at alone; changing creation time would be wrong. */
    private static final String SQL_UPDATE =
            "UPDATE CUSTOMER SET first_name = ?, last_name = ?, email = ? WHERE id = ?";

    private static final String SQL_DELETE =
            "DELETE FROM CUSTOMER WHERE id = ?";

    private final JdbcTemplate jdbc;

    /**
     * SimpleJdbcInsert is a Spring helper that reads the table's metadata
     * at construction time and builds the INSERT on our behalf. We use it
     * only for single-row inserts because it knows how to retrieve the
     * auto-generated IDENTITY value.
     */
    private final SimpleJdbcInsert insert;

    private final CustomerRowMapper rowMapper = new CustomerRowMapper();

    /**
     * @param jdbc Sybase-scoped JdbcTemplate
     * @param ds   Sybase DataSource — SimpleJdbcInsert needs the DataSource
     *             directly to introspect the table's metadata.
     */
    public CustomerRepository(@Qualifier("sybaseJdbcTemplate") JdbcTemplate jdbc,
                              @Qualifier("sybaseDataSource") DataSource ds) {
        this.jdbc = jdbc;
        this.insert = new SimpleJdbcInsert(ds)
                .withTableName(TABLE)
                .usingGeneratedKeyColumns("id");  // tells it which column is IDENTITY
    }

    // =========================================================================
    //  Read
    // =========================================================================

    public List<Customer> findAll() {
        return jdbc.query(SQL_FIND_ALL, rowMapper);
    }

    /**
     * Optional wrapper avoids EmptyResultDataAccessException on a miss.
     */
    public Optional<Customer> findById(Long id) {
        return jdbc.query(SQL_FIND_BY_ID, rowMapper, id).stream().findFirst();
    }

    // =========================================================================
    //  Write (single row)
    // =========================================================================

    /**
     * Single-row insert with auto-generated identity key.
     *
     * <p>Flow:
     * <ol>
     *   <li>SimpleJdbcInsert builds the INSERT and executes it.</li>
     *   <li>The driver surfaces the newly-generated identity value via
     *       {@code executeAndReturnKey}.</li>
     *   <li>We re-read the row so the caller sees the DB-generated
     *       {@code created_at} timestamp and any other defaulted columns.</li>
     * </ol>
     */
    public Customer insert(Customer customer) {
        Map<String, Object> params = Map.of(
                "first_name", customer.firstName(),
                "last_name",  customer.lastName(),
                "email",      customer.email(),
                // created_at is set client-side; could be DB default instead.
                "created_at", Timestamp.valueOf(LocalDateTime.now())
        );
        Number key = insert.executeAndReturnKey(params);
        return findById(key.longValue()).orElseThrow();
    }

    /**
     * Update by id. Returns rows affected (0 means no such id).
     */
    public int update(Long id, Customer customer) {
        return jdbc.update(SQL_UPDATE,
                customer.firstName(),
                customer.lastName(),
                customer.email(),
                id);
    }

    /**
     * Delete by id. Returns rows affected (0 or 1).
     */
    public int delete(Long id) {
        return jdbc.update(SQL_DELETE, id);
    }

    // =========================================================================
    //  Write (batch / bulk)
    // =========================================================================

    /**
     * Batch insert. The IDENTITY column assigns IDs server-side, but JDBC
     * batch mode doesn't reliably surface them back. This method therefore
     * returns just the row count.
     *
     * <p>If you need the generated IDs for a large set of customers, you
     * have two options:
     * <ul>
     *   <li>Call {@link #insert(Customer)} per row (slower, returns ID each time).</li>
     *   <li>Include a unique business key (like email) and re-query after
     *       the batch to map inputs back to IDs.</li>
     * </ul>
     */
    public int insertAll(List<Customer> customers) {
        if (customers == null || customers.isEmpty()) {
            return 0;
        }

        int total = 0;

        // Timestamp captured once so every row in the batch has the same
        // creation time — cheaper than calling now() per row, and makes
        // the batch semantically "all inserted at the same moment".
        Timestamp now = Timestamp.valueOf(LocalDateTime.now());

        for (int i = 0; i < customers.size(); i += BATCH_SIZE) {
            List<Customer> chunk = customers.subList(i, Math.min(i + BATCH_SIZE, customers.size()));

            int[] counts = jdbc.batchUpdate(SQL_INSERT_BATCH, new BatchPreparedStatementSetter() {
                @Override
                public void setValues(PreparedStatement ps, int idx) throws SQLException {
                    Customer c = chunk.get(idx);
                    ps.setString(1, c.firstName());
                    ps.setString(2, c.lastName());
                    ps.setString(3, c.email());
                    // Respect caller's timestamp if they set one, otherwise use the batch's.
                    ps.setTimestamp(4, c.createdAt() != null
                            ? Timestamp.valueOf(c.createdAt())
                            : now);
                }

                @Override
                public int getBatchSize() {
                    return chunk.size();
                }
            });

            for (int c : counts) {
                total += (c >= 0) ? c : 1; // -2 = SUCCESS_NO_INFO (jConnect may return this)
            }
        }
        return total;
    }

    /**
     * Batch update by id. Caller must populate the id field on every input.
     */
    public int updateAll(List<Customer> customers) {
        if (customers == null || customers.isEmpty()) {
            return 0;
        }

        int total = 0;
        for (int i = 0; i < customers.size(); i += BATCH_SIZE) {
            List<Customer> chunk = customers.subList(i, Math.min(i + BATCH_SIZE, customers.size()));
            int[] counts = jdbc.batchUpdate(SQL_UPDATE, new BatchPreparedStatementSetter() {
                @Override
                public void setValues(PreparedStatement ps, int idx) throws SQLException {
                    Customer c = chunk.get(idx);
                    ps.setString(1, c.firstName());
                    ps.setString(2, c.lastName());
                    ps.setString(3, c.email());
                    ps.setLong(4, c.id());
                }

                @Override
                public int getBatchSize() {
                    return chunk.size();
                }
            });
            for (int c : counts) {
                total += (c >= 0) ? c : 1;
            }
        }
        return total;
    }

    /**
     * Batch delete by id.
     */
    public int deleteAll(List<Long> ids) {
        if (ids == null || ids.isEmpty()) {
            return 0;
        }

        int total = 0;
        for (int i = 0; i < ids.size(); i += BATCH_SIZE) {
            List<Long> chunk = ids.subList(i, Math.min(i + BATCH_SIZE, ids.size()));
            int[] counts = jdbc.batchUpdate(SQL_DELETE, new BatchPreparedStatementSetter() {
                @Override
                public void setValues(PreparedStatement ps, int idx) throws SQLException {
                    ps.setLong(1, chunk.get(idx));
                }

                @Override
                public int getBatchSize() {
                    return chunk.size();
                }
            });
            for (int c : counts) {
                total += (c >= 0) ? c : 1;
            }
        }
        return total;
    }
}
