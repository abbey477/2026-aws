package com.example.dbtester.repository.oracle;

import com.example.dbtester.entity.Product;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Translates one row of the PRODUCT ResultSet into a {@link Product} record.
 *
 * <p>RowMapper is the classic JdbcTemplate extension point: JdbcTemplate
 * iterates the ResultSet, and for each row it calls {@link #mapRow} with
 * the current row. The mapper pulls typed values out by column name and
 * constructs the domain object — no reflection, no annotations.
 *
 * <p>Because Java records have a canonical constructor that takes every
 * field in declaration order, they pair cleanly with this pattern: build
 * the record in one line, return it, done.
 */
public class ProductRowMapper implements RowMapper<Product> {

    /**
     * @param rs     the current row (already positioned; do NOT call rs.next())
     * @param rowNum zero-based row index within the result set (mostly informational)
     */
    @Override
    public Product mapRow(ResultSet rs, int rowNum) throws SQLException {
        return new Product(
                rs.getLong("id"),
                rs.getString("sku"),
                rs.getString("name"),
                rs.getBigDecimal("price"),
                // Oracle NUMBER(1) comes back as an int; we translate 1→true, 0→false.
                // getBoolean() would also work on Oracle, but getInt() is unambiguous.
                rs.getInt("in_stock") == 1
        );
    }
}
