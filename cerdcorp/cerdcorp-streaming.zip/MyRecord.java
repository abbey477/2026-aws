import java.sql.Timestamp;

/**
 * One row carried between Sybase read and Oracle write.
 * Replace the fields with your actual column types.
 *
 * Java records auto-generate the constructor, getters (col1(), col2(), col3()),
 * equals, hashCode, and toString — no boilerplate needed.
 */
public record MyRecord(long col1, String col2, Timestamp col3) {}
