"""
Output shape contract.

The handler returns ONLY the results dict — no event fields spread.
Step Functions nests this under $.pre_steps_result via ResultPath
and preserves the original payload automatically.

Return shape:
{
    "change_since_append": { ... },     # if that step ran and returned data
    "ddb_config_pull": { ... },         # if that step ran and returned data
}
"""

from pre_steps_processor.handler import lambda_handler
from seed_data import make_event


class TestOutputShape:

    def test_output_does_not_contain_input_fields(self, mocks):
        """Return should NOT contain run_id, job_config, etc. — only results."""
        event = make_event(pre_steps=[{"pre_step_type": "change_since_append"}])
        result = lambda_handler(event, None)

        # Input fields should NOT be in the return (Step Functions keeps them)
        assert "run_id" not in result
        assert "job_config" not in result
        assert "job_id" not in result

    def test_empty_dict_when_no_data(self, mocks):
        """No pre_steps → empty dict returned."""
        result = lambda_handler(make_event(), None)
        assert result == {}

    def test_handler_result_keyed_by_pre_step_type(self, mocks):
        """Handler results are keyed by their pre_step_type."""
        mocks["change_since"].return_value = {
            "last_successful_start_time": "2024-01-01T00:00:00Z",
            "placeholder": True,
        }

        result = lambda_handler(
            make_event(pre_steps=[{"pre_step_type": "change_since_append"}]),
            None,
        )

        assert "change_since_append" in result
        assert result["change_since_append"] == {
            "last_successful_start_time": "2024-01-01T00:00:00Z",
            "placeholder": True,
        }

    def test_ddb_config_pull_also_keyed_by_pre_step_type(self, mocks):
        """
        ddb_config_pull results go under the same results dict — no longer
        merged into job_param (Step Functions handles payload separation).
        """
        mocks["ddb_pull"].return_value = {
            "service_config": {"feature_flag": True},
            "table_config": None,
        }

        result = lambda_handler(
            make_event(pre_steps=[{"pre_step_type": "ddb_config_pull"}]),
            None,
        )

        assert "ddb_config_pull" in result
        assert result["ddb_config_pull"]["service_config"] == {"feature_flag": True}
        assert result["ddb_config_pull"]["table_config"] is None

    def test_multiple_handlers_each_keyed_separately(self, mocks):
        mocks["change_since"].return_value = {"a": 1}
        mocks["ddb_pull"].return_value = {"service_config": {"b": 2}}

        result = lambda_handler(
            make_event(pre_steps=[
                {"pre_step_type": "change_since_append"},
                {"pre_step_type": "ddb_config_pull"},
            ]),
            None,
        )

        assert result == {
            "change_since_append": {"a": 1},
            "ddb_config_pull": {"service_config": {"b": 2}},
        }

    def test_empty_handler_result_not_added_to_output(self, mocks):
        """If a handler returns {}, its key shouldn't appear."""
        mocks["ddb_pull"].return_value = {}
        mocks["change_since"].return_value = {"something": "value"}

        result = lambda_handler(
            make_event(pre_steps=[
                {"pre_step_type": "change_since_append"},
                {"pre_step_type": "ddb_config_pull"},
            ]),
            None,
        )

        assert "change_since_append" in result
        assert "ddb_config_pull" not in result
