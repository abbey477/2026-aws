package com.example.dbtester.controller;

import com.example.dbtester.dto.BulkResult;
import com.example.dbtester.dto.CustomerRequest;
import com.example.dbtester.entity.Customer;
import com.example.dbtester.service.SybaseCustomerService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * HTTP endpoints for the Sybase-backed Customer resource.
 *
 * <p>{@code @Validated} enables method-level Bean Validation — needed for
 * the {@code @NotEmpty} check on the bulk endpoint's List body. (Request
 * bodies annotated with {@code @Valid} use the class-level validation by
 * default; {@code @Validated} is what flips on checks for direct method
 * parameter annotations.)
 */
@RestController
@RequestMapping("/api/sybase/customers")
@Validated
public class SybaseCustomerController {

    private final SybaseCustomerService service;

    public SybaseCustomerController(SybaseCustomerService service) {
        this.service = service;
    }

    // ---- Single-row CRUD ----

    @GetMapping
    public List<Customer> findAll() {
        return service.findAll();
    }

    @GetMapping("/{id}")
    public Customer findById(@PathVariable Long id) {
        return service.findById(id);
    }

    /** 201 Created with the full persisted customer in the response body. */
    @PostMapping
    public ResponseEntity<Customer> create(@Valid @RequestBody CustomerRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.create(request));
    }

    @PutMapping("/{id}")
    public Customer update(@PathVariable Long id, @Valid @RequestBody CustomerRequest request) {
        return service.update(id, request);
    }

    /** 204 No Content on successful delete — no body to return. */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    // ---- Bulk endpoints ----

    /**
     * POST /api/sybase/customers/bulk — batch create.
     * {@code @Valid} cascades into each CustomerRequest in the list.
     * {@code @NotEmpty} rejects empty arrays with 400.
     */
    @PostMapping("/bulk")
    public ResponseEntity<BulkResult> createAll(
            @RequestBody @NotEmpty @Valid List<CustomerRequest> requests) {
        int rows = service.createAll(requests);
        return ResponseEntity.status(HttpStatus.CREATED).body(BulkResult.of(rows));
    }

    /**
     * PUT /api/sybase/customers/bulk — batch update. Caller supplies full
     * Customer records with ids populated.
     */
    @PutMapping("/bulk")
    public BulkResult updateAll(@RequestBody @NotEmpty List<Customer> customers) {
        return BulkResult.of(service.updateAll(customers));
    }

    /** DELETE /api/sybase/customers/bulk — body is a JSON array of ids: [1, 2, 3]. */
    @DeleteMapping("/bulk")
    public BulkResult deleteAll(@RequestBody @NotEmpty List<Long> ids) {
        return BulkResult.of(service.deleteAll(ids));
    }
}
