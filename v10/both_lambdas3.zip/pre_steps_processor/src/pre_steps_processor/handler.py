"""
PreStepsProcessor Lambda Handler

Sits between GetConfig and RunnerTypeChoice in the Step Function.
Routes each pre_step to the appropriate handler and collects results.

Return shape (Step Functions nests this under $.pre_steps_result):
{
    "job_param": { ... },                  # copied from input as-is
    "change_since_append": { ... },        # if that step ran
    "ddb_config_pull": { ... },            # if that step ran
}

The downstream lambda (e.g. TriggerEcsJob) reads from $.pre_steps_result
and decides how to use each piece — for example, appending changedSince
to the job_param URL using the change_since_append timestamp.

AWS Lambda handler entry point: pre_steps_processor.handler.lambda_handler
"""

from typing import Any

from pre_steps_processor import logging_utils as log
from pre_steps_processor.log_to_dynamo import write_log
from pre_steps_processor.step_handlers import (
    handle_change_since_append,
    handle_ddb_config_pull,
    handle_no_pre_steps,
    handle_unknown_pre_step,
)


def _has_valid_pre_step_type(step: Any) -> bool:
    """True if step is a dict with a non-empty string pre_step_type."""
    if not isinstance(step, dict):
        return False
    value = step.get("pre_step_type")
    return isinstance(value, str) and value != ""


def _extract_pre_steps(event: dict) -> list:
    """Return pre_steps list, or [] if missing/None/not-a-list."""
    job_config = event.get("job_config") or {}
    pre_steps = job_config.get("pre_steps")
    if not isinstance(pre_steps, list):
        return []
    return pre_steps


def _extract_job_param(event: dict) -> dict:
    """
    Copy job_param from the input event so downstream consumers can
    read it from $.pre_steps_result.job_param alongside the step results.
    Returns empty dict if not present.
    """
    job_config = event.get("job_config") or {}
    return dict(job_config.get("job_param") or {})


def _process_step(step: dict, event: dict) -> dict:
    """Route a single step to its handler based on pre_step_type."""
    pre_step_type = step["pre_step_type"]

    if pre_step_type == "change_since_append":
        log.info("PROCESSING_STEP", {"pre_step_type": pre_step_type, "action": "route_to_known_handler"})
        return handle_change_since_append(step, event)

    if pre_step_type == "ddb_config_pull":
        log.info("PROCESSING_STEP", {"pre_step_type": pre_step_type, "action": "route_to_known_handler"})
        return handle_ddb_config_pull(step, event)

    log.warn("PROCESSING_STEP", {"pre_step_type": pre_step_type, "action": "route_to_unknown"})
    return handle_unknown_pre_step(step)


def lambda_handler(event: dict, context: Any) -> dict:
    """
    Lambda entry point.

    Returns a results dict that Step Functions nests under $.pre_steps_result.
    Includes job_param (copied from input) plus results from each step handler.
    """
    run_id = event.get("run_id", "<missing>")
    job_id = event.get("job_id", "<unknown>")

    log.info("HANDLER_START", {"run_id": run_id})

    try:
        pre_steps = _extract_pre_steps(event)
        valid_steps = [s for s in pre_steps if _has_valid_pre_step_type(s)]

        log.info("VALIDATION", {"raw_count": len(pre_steps), "valid_count": len(valid_steps)})

        # Start with job_param from the input — downstream reads it from
        # $.pre_steps_result.job_param alongside the step results.
        results: dict = {}

        # Include job_param as-is from the input event
        job_param = _extract_job_param(event)
        if job_param:
            results["job_param"] = job_param

        if not valid_steps:
            log.info("NO_DATA", {"reason": "no valid pre_steps to process"})
            handle_no_pre_steps()
        else:
            for step in valid_steps:
                result = _process_step(step, event)
                if result:
                    results[step["pre_step_type"]] = result

        log.info("HANDLER_COMPLETE", {
            "run_id": run_id,
            "processed_count": len(valid_steps),
            "result_keys": list(results.keys()),
        })

        write_log(run_id=run_id, job_id=job_id, stage="PreStepsProcessor", status="SUCCESS")
        return results

    except Exception as e:
        log.error("HANDLER_FAILED", {
            "run_id": run_id, "job_id": job_id,
            "error_type": type(e).__name__, "error_message": str(e),
        })
        write_log(run_id=run_id, job_id=job_id, stage="PreStepsProcessor", status="FAILED")
        raise
