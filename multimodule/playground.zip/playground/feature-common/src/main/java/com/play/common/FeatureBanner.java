package com.play.common;

/**
 * Trivial shared helper, here only to prove that feature modules can
 * depend on feature-common. Replace/extend with whatever utilities
 * your experiments end up sharing.
 */
public final class FeatureBanner {

    private FeatureBanner() {
    }

    /** Returns a boxed banner line announcing which feature is running. */
    public static String of(String featureName) {
        String label = "  RUNNING FEATURE: " + featureName + "  ";
        String rule = "=".repeat(label.length());
        return "\n" + rule + "\n" + label + "\n" + rule;
    }
}
