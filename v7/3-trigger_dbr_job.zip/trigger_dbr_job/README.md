# trigger_dbr_job

Lambda function that triggers a Databricks job via the Jobs Run Now API.

---

## Project structure

```
trigger_dbr_job/
├── src/
│   └── trigger_dbr_job/        # Source package
│       ├── handler.py           # Lambda entrypoint
│       ├── databricks_client.py # HTTP trigger logic
│       ├── config.py            # Config key extraction
│       ├── log_utils.py         # Structured logging (DEBUG/INFO/WARNING/ERROR)
│       └── log_to_dynamo.py     # DynamoDB log writer
├── test/
│   ├── conftest.py              # Shared fixtures
│   ├── test_databricks_client.py
│   └── test_handler.py
├── Makefile
├── pyproject.toml               # Project config + dependencies
└── poetry.toml                  # Local virtualenv settings
```

---

## Prerequisites

You need **Python 3.12+** and **Poetry** installed on your machine.

### Check if you have Python

```bash
python --version
# Should print: Python 3.12.x or higher
```

### Install Poetry (if you don't have it)

```bash
curl -sSL https://install.python-poetry.org | python3 -
```

After installing, restart your terminal and verify:

```bash
poetry --version
```

---

## Setup — install dependencies

Run this once when you first clone the project:

```bash
poetry install
```

This creates a `.venv` folder inside the project and installs everything listed in `pyproject.toml` (including `pytest`, `boto3`, and `moto` for testing).

---

## Running the tests

### Option A — using Make (simplest)

```bash
# Run all tests
make test

# Run all tests and show which lines are not covered
make test-cov

# Clean up cache files
make clean
```

### Option B — using Poetry directly

```bash
# Run all tests
poetry run pytest

# Run a specific test file
poetry run pytest test/test_handler.py

# Run a specific test by name
poetry run pytest test/test_handler.py::TestLambdaHandlerSuccess::test_trigger_result_added_on_success

# Run only unit tests (tagged with @pytest.mark.unit)
poetry run pytest -m unit

# Run with coverage report
poetry run pytest --cov=trigger_dbr_job --cov-report=term-missing
```

---

## Understanding the test output

When you run `make test` or `poetry run pytest` you will see output like this:

```
test/test_handler.py::TestLambdaHandlerSuccess::test_trigger_result_added_on_success PASSED  [ 57%]
test/test_handler.py::TestLambdaHandlerFailure::test_trigger_result_added_on_failure PASSED  [ 78%]
```

Each line shows:
- **File and test name** — which test ran
- **PASSED / FAILED** — result
- **Percentage** — how far through the suite you are

Log lines in between (e.g. `[INFO]`, `[ERROR]`) are the structured logs your Lambda would produce in production — this is intentional so you can see exactly what the function does during each test.

---

## Running a single test file

```bash
poetry run pytest test/test_databricks_client.py
```

---

## Troubleshooting

**`poetry: command not found`**
→ Poetry was not added to your PATH. Try closing and reopening your terminal, or follow the Poetry install instructions again.

**`ModuleNotFoundError: No module named 'trigger_dbr_job'`**
→ Run `poetry install` first to set up the virtual environment.

**`No module named 'boto3'`**
→ Run `poetry install` — boto3 is a project dependency and gets installed automatically.
