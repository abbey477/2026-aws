"""
test_failed.py
Tests for the FAILED status path of the UpdateJobStatus Lambda.
"""

import pytest
from conftest import make_event
from lambdas.update_job_status.handler import lambda_handler


class TestUpdateFailed:
    """Tests for FAILED outcome."""

    def test_failed_marks_status(self, dynamodb_setup, monkeypatch):
        """FAILED marks job_run as FAILED and persists the error message."""
        dynamodb, table = dynamodb_setup
        monkeypatch.setattr(
            "lambdas.update_job_status.handler.get_dynamodb_resource",
            lambda: dynamodb,
        )

        event = make_event(job_status="FAILED")
        event["trigger_result"]["error"] = "Out of memory"
        result = lambda_handler(event, None)

        assert result["update_result"]["effective_status"] == "FAILED"

        item = table.get_item(Key={"run_id": "run-001"})["Item"]
        assert item["status"] == "FAILED"
        assert item["end_time"] != ""
        assert item["error"] == "Out of memory"

    def test_failed_without_error_message(self, dynamodb_setup, monkeypatch):
        """FAILED with no error key should still complete without raising."""
        dynamodb, table = dynamodb_setup
        monkeypatch.setattr(
            "lambdas.update_job_status.handler.get_dynamodb_resource",
            lambda: dynamodb,
        )

        event = make_event(job_status="FAILED")
        # Intentionally no "error" key in trigger_result
        result = lambda_handler(event, None)

        assert result["update_result"]["effective_status"] == "FAILED"
        item = table.get_item(Key={"run_id": "run-001"})["Item"]
        assert item["status"] == "FAILED"

    def test_failed_end_time_is_iso_format(self, dynamodb_setup, monkeypatch):
        """end_time written on FAILED is a valid ISO 8601 string."""
        from datetime import datetime

        dynamodb, table = dynamodb_setup
        monkeypatch.setattr(
            "lambdas.update_job_status.handler.get_dynamodb_resource",
            lambda: dynamodb,
        )

        event = make_event(job_status="FAILED")
        lambda_handler(event, None)

        item = table.get_item(Key={"run_id": "run-001"})["Item"]
        # Should not raise
        datetime.strptime(item["end_time"], "%Y-%m-%dT%H:%M:%SZ")
