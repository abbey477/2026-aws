"""Repository-level tests for get_job_config."""

import pytest
from botocore.exceptions import ClientError

from get_config.dynamodb_ops import get_job_config
from seed_data import raise_access_denied


class TestGetJobConfig:

    def test_returns_item_when_found(self, dynamodb_tables):
        table = dynamodb_tables.Table("app-jobConfig")
        result = get_job_config(table, "client", "sourcing")
        assert result["job_id"] == "client"
        assert result["job_runner"]["name"] == "S2S3"

    def test_returns_pre_steps_when_present(self, dynamodb_tables):
        """Schema-agnostic — pre_steps field flows through."""
        table = dynamodb_tables.Table("app-jobConfig")
        result = get_job_config(table, "client", "sourcing")
        assert "pre_steps" in result
        assert len(result["pre_steps"]) == 2
        assert result["pre_steps"][0]["pre_step_type"] == "change_since_append"
        assert result["pre_steps"][1]["pre_step_type"] == "ddb_config_pull"

    def test_raises_when_not_found(self, dynamodb_tables):
        table = dynamodb_tables.Table("app-jobConfig")
        with pytest.raises(ValueError, match="No job_config found"):
            get_job_config(table, "client", "nonexistent")

    def test_raises_on_client_error(self, dynamodb_tables, monkeypatch):
        table = dynamodb_tables.Table("app-jobConfig")
        monkeypatch.setattr(table, "get_item", raise_access_denied)

        with pytest.raises(ClientError):
            get_job_config(table, "client", "sourcing")
