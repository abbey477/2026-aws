"""
Structured logging helper for GetConfig Lambda.

Four log levels — info / warn / error / debug — map to Python's stdlib
logging levels so CloudWatch Insights can filter by @logLevel.
"""

import logging

logger = logging.getLogger(__name__)

_LAMBDA_TAG = "[GetConfig]"


def _fmt(details: dict) -> str:
    return ", ".join(f"{k}={v}" for k, v in details.items())


def info(step: str, details: dict) -> None:
    """Informational event — normal operation."""
    logger.info(f"{_LAMBDA_TAG} [{step}] {_fmt(details)}")


def warn(step: str, details: dict) -> None:
    """Warning — recoverable/expected anomaly."""
    logger.warning(f"{_LAMBDA_TAG} [{step}] {_fmt(details)}")


def error(step: str, details: dict) -> None:
    """Error — unexpected failure."""
    logger.error(f"{_LAMBDA_TAG} [{step}] {_fmt(details)}")


def debug(step: str, details: dict) -> None:
    """Debug detail — only visible at DEBUG log level."""
    logger.debug(f"{_LAMBDA_TAG} [{step}] {_fmt(details)}")
