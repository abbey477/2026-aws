# GetConfig Lambda — v2

## What's new in v2

The `job_config` table row now includes a **`pre_steps`** field:

```json
"pre_steps": [
  { "type": "change_since_append" },
  { "type": "ddb_config_pull", "tables": ["service_config", "table_config"] }
]
```

This is a polymorphic array — each step has a `type` discriminator and may
carry additional type-specific fields (e.g. `tables` for `ddb_config_pull`).

## Handler impact

**The handler code is unchanged from v1.** It was written to be
schema-agnostic — `output = {**job_run, "job_config": job_config}` forwards
whatever fields exist in the DynamoDB row. `pre_steps` flows through
automatically with zero code changes.

Only small additions:
- Docstring updated to mention v2
- `dynamodb_ops.get_job_config` now logs `has_pre_steps` and `pre_steps_count`
  for observability

## Test changes

### Seed data updated
- `_make_job_config_item()` now includes `pre_steps` matching the
  authoritative POST /job shape
- `job_param` internals kept minimal (treated as opaque blob for now)

### New tests added
- `test_pre_steps_passes_through` — verifies the array flows through with
  both simple and polymorphic step shapes intact
- `test_pre_steps_empty_array_passes_through` — verifies `pre_steps: []`
  doesn't break anything
- `test_pre_steps_missing_field_handled_gracefully` — verifies a legacy
  job_config row without `pre_steps` still works
- `TestGetJobConfig.test_returns_pre_steps_when_present` — repository-level
  assertion

## Structure (unchanged from v1)

```
get_config_project/
├── conftest.py
├── requirements.txt
├── lambdas/
│   ├── __init__.py
│   ├── log_to_dynamo.py         ← stub; delete and use your real one
│   └── get_config/
│       ├── __init__.py
│       ├── handler.py
│       ├── dynamodb_ops.py
│       └── logging_utils.py
└── tests/
    ├── __init__.py
    └── test_get_config.py
```

## Running tests

```bash
pip install -r requirements.txt
pytest -v
```

## Coverage summary

| Scenario | Test |
|---|---|
| Happy path (all v2 fields present) | `test_successful_config_retrieval` |
| **v2: pre_steps passes through** | `test_pre_steps_passes_through` |
| **v2: empty pre_steps array** | `test_pre_steps_empty_array_passes_through` |
| **v2: missing pre_steps (legacy row)** | `test_pre_steps_missing_field_handled_gracefully` |
| Invalid run_id (missing/empty/None) | `test_invalid_run_id_raises_error` (3 params) |
| run_id not in job_run | `test_run_id_not_found_raises_error` |
| job_config missing | `test_job_config_not_found_raises_error` |
| job_run missing job_id | `test_job_run_missing_job_id_raises_error` |
| job_run missing job_type | `test_job_run_missing_job_type_raises_error` |
| DynamoDB ClientError | `test_dynamodb_client_error_propagates` |
| write_log success / not-on-failure | asserted in handler tests |
| Repository-level pre_steps read | `test_returns_pre_steps_when_present` |
| Repository isolation tests | `TestGetJobRun`, `TestGetJobConfig` |
