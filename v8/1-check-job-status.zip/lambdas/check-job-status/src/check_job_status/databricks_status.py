"""
Databricks job status check.

Checks the status of a Databricks job run by calling the
Jobs Runs Get REST API and interpreting the lifecycle state.

Returns a dict with:
    job_status    : "SUCCESS" | "RUNNING" | "FAILED"
    output        : (optional) notebook_output on success
    error         : (optional) error message on failure
    result_state  : (optional) Databricks result_state on failure
"""

import json
import logging
import urllib.request
import urllib.error

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


def _log(step: str, details: dict):
    """Structured info log – every line has a step tag + key-value pairs."""
    detail_str = ", ".join(f"{k}={v}" for k, v in details.items())
    logger.info(f"[DbrStatus] [{step}] {detail_str}")


def check_databricks_job_status(dbr_run_id: str, runner_config: dict) -> dict:
    """
    Check the status of a Databricks job run.

    Args:
        dbr_run_id: The Databricks run ID to check.
        runner_config: Runner config from job_config.job_runner.config
                       (contains host, token, etc.).

    Returns:
        dict with job_status and optional output details.
    """
    dbr_host = runner_config.get("host", "")
    dbr_token = runner_config.get("token", "")

    url = f"https://{dbr_host}/api/2.1/jobs/runs/get?run_id={dbr_run_id}"
    headers = {
        "Authorization": f"Bearer {dbr_token}",
        "Content-Type": "application/json",
    }

    _log("DBR_CHECK_START", {"dbr_run_id": dbr_run_id, "host": dbr_host})

    try:
        req = urllib.request.Request(url, headers=headers, method="GET")
        with urllib.request.urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read().decode("utf-8"))

        state = result.get("state", {})
        life_cycle_state = state.get("life_cycle_state", "UNKNOWN")
        result_state = state.get("result_state", "")

        _log("DBR_API_RESPONSE", {
            "life_cycle_state": life_cycle_state,
            "result_state": result_state,
            "dbr_run_id": dbr_run_id,
        })

        if life_cycle_state in ("PENDING", "RUNNING", "TERMINATING"):
            _log("DBR_STILL_RUNNING", {"life_cycle_state": life_cycle_state})
            return {"job_status": "RUNNING"}

        elif life_cycle_state == "TERMINATED":
            if result_state == "SUCCESS":
                output = result.get("notebook_output", {})
                _log("DBR_COMPLETED", {"result": "SUCCESS", "has_output": bool(output)})
                return {"job_status": "SUCCESS", "output": output}
            else:
                error_msg = state.get("state_message", "Unknown error")
                _log("DBR_COMPLETED", {
                    "result": "FAILED",
                    "result_state": result_state,
                    "error": error_msg,
                })
                return {
                    "job_status": "FAILED",
                    "error": error_msg,
                    "result_state": result_state,
                }
        else:
            _log("DBR_UNEXPECTED_STATE", {
                "life_cycle_state": life_cycle_state,
                "resolution": "Marking FAILED",
            })
            return {
                "job_status": "FAILED",
                "error": f"Unexpected lifecycle state: {life_cycle_state}",
            }

    except (urllib.error.URLError, urllib.error.HTTPError, Exception) as e:
        _log("DBR_API_ERROR", {"error_type": type(e).__name__, "error_message": str(e)})
        return {"job_status": "FAILED", "error": str(e)}
