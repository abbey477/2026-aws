package com.example.batch.common.exception;

/**
 * A business-level exception thrown by services when something predictable goes wrong
 * (validation failed, data missing, business rule violated, etc.).
 *
 * <p>Carries an {@code exitCode} so the CLI dispatcher can translate it to a meaningful
 * process exit code that Autosys will read. By convention:
 * <ul>
 *   <li>3 = generic business error</li>
 *   <li>4 = data validation error</li>
 *   <li>5 = required input missing</li>
 * </ul>
 * Customize these to match your operational needs.
 */
public class BusinessException extends RuntimeException {

    private final int exitCode;

    public BusinessException(String message) {
        this(message, 3);  // default business-error code
    }

    public BusinessException(String message, int exitCode) {
        super(message);
        this.exitCode = exitCode;
    }

    public int getExitCode() {
        return exitCode;
    }
}
