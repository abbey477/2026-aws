"""
databricks_client.py
Databricks Jobs Run Now HTTP client for TriggerDbrJob.

Responsible for:
  - Building the API URL, headers, and JSON payload
  - POSTing to the Databricks Jobs Run Now endpoint
  - Returning a normalised trigger_result dict
  - Emitting structured logs at the appropriate level per outcome
"""

import json
import urllib.request
import urllib.error

from config import get_runner_config, get_dbr_connection
from log_utils import log_debug, log_info, log_warning, log_error

_DBR_API_PATH = "/api/2.1/jobs/run-now"


def trigger_databricks_job(job_config: dict, job_param: dict) -> dict:
    """
    Trigger a Databricks job using the Jobs Run Now API.

    Args:
        job_config: The job_config section containing job_runner details
                    (host, token, job_id all live in job_runner.config).
        job_param:  The notebook_params payload to pass to the Databricks job.

    Returns:
        dict with keys:
          trigger_status  — "TRIGGERED" | "TRIGGER_FAILED"
          dbr_run_id      — run_id string on success, "" on failure
          error           — error message string (only present on failure)
    """
    runner_config = get_runner_config(job_config)
    host, token, dbr_job_id = get_dbr_connection(runner_config)

    url = f"https://{host}{_DBR_API_PATH}"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }
    payload = json.dumps(
        {
            "job_id": dbr_job_id,
            "notebook_params": job_param,
        }
    ).encode("utf-8")

    log_debug(
        "DBR_REQUEST_BUILT",
        {
            "host": host,
            "dbr_job_id": dbr_job_id,
            "api_url": url,
            "job_param_keys": list(job_param.keys()),
        },
    )

    try:
        req = urllib.request.Request(url, data=payload, headers=headers, method="POST")
        with urllib.request.urlopen(req, timeout=30) as resp:
            result = json.loads(resp.read().decode("utf-8"))

        dbr_run_id = result.get("run_id", "")

        if not dbr_run_id:
            log_warning(
                "DBR_EMPTY_RUN_ID",
                {"host": host, "dbr_job_id": dbr_job_id, "response_keys": list(result.keys())},
            )

        log_info("DBR_TRIGGER_SUCCESS", {"dbr_run_id": dbr_run_id})

        return {
            "trigger_status": "TRIGGERED",
            "dbr_run_id": str(dbr_run_id),
        }

    except urllib.error.HTTPError as e:
        log_error(
            "DBR_TRIGGER_FAILED_HTTP",
            {
                "error_type": type(e).__name__,
                "error_code": e.code,
                "error_message": str(e),
            },
        )
        return {
            "trigger_status": "TRIGGER_FAILED",
            "dbr_run_id": "",
            "error": str(e),
        }

    except urllib.error.URLError as e:
        log_error(
            "DBR_TRIGGER_FAILED_URL",
            {
                "error_type": type(e).__name__,
                "error_message": str(e),
            },
        )
        return {
            "trigger_status": "TRIGGER_FAILED",
            "dbr_run_id": "",
            "error": str(e),
        }

    except Exception as e:
        log_error(
            "DBR_TRIGGER_FAILED_UNEXPECTED",
            {
                "error_type": type(e).__name__,
                "error_message": str(e),
            },
        )
        return {
            "trigger_status": "TRIGGER_FAILED",
            "dbr_run_id": "",
            "error": str(e),
        }
