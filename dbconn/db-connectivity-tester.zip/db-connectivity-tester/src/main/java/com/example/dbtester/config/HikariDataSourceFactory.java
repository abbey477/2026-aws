package com.example.dbtester.config;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import java.util.List;
import java.util.Map;

/**
 * Builds HikariDataSource instances from the DbConfig record.
 * Kept package-private and static to avoid bean duplication.
 */
final class HikariDataSourceFactory {

    private HikariDataSourceFactory() {}

    static HikariDataSource build(String name, DataSourceProperties.DbConfig config) {
        HikariConfig hikari = new HikariConfig();

        hikari.setJdbcUrl(config.url());
        hikari.setUsername(config.username());
        hikari.setPassword(config.password());
        hikari.setDriverClassName(config.driverClassName());

        DataSourceProperties.HikariConfig h = config.hikari();
        if (h != null) {
            if (h.maximumPoolSize() > 0)      hikari.setMaximumPoolSize(h.maximumPoolSize());
            if (h.minimumIdle() >= 0)         hikari.setMinimumIdle(h.minimumIdle());
            if (h.connectionTimeoutMs() > 0)  hikari.setConnectionTimeout(h.connectionTimeoutMs());
            if (h.idleTimeoutMs() > 0)        hikari.setIdleTimeout(h.idleTimeoutMs());
            if (h.maxLifetimeMs() > 0)        hikari.setMaxLifetime(h.maxLifetimeMs());
            if (h.poolName() != null)         hikari.setPoolName(h.poolName());
        }

        // First validation query becomes the Hikari connection-test query
        List<String> queries = config.validationQueries();
        if (queries != null && !queries.isEmpty()) {
            hikari.setConnectionTestQuery(queries.get(0));
        }

        // Arbitrary driver-specific properties (Map<String, String>)
        Map<String, String> props = config.properties();
        if (props != null) {
            props.forEach(hikari::addDataSourceProperty);
        }

        return new HikariDataSource(hikari);
    }
}
