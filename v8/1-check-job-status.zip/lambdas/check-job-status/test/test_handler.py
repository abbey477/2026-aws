"""
Unit tests for the lambda_handler (routing layer).

Tests:
    1.  ECS handler path → SUCCESS.
    2.  ECS handler path → RUNNING.
    3.  ECS handler path → FAILED.
    4.  Missing task_arn in event → handler sets FAILED directly.
    5.  Handler preserves original event fields (ECS).
    6.  DBR handler path → SUCCESS.
    7.  DBR handler path → RUNNING.
    8.  DBR handler path → FAILED.
    9.  Missing dbr_run_id in event → handler sets FAILED directly.
    10. Handler preserves original event fields (DBR).
    11. Unsupported runner_type → FAILED.
    12. Missing runner_type → FAILED.
    13. Empty string runner_type → FAILED.
"""

from unittest.mock import patch

from check_job_status.handler import lambda_handler
from test.helpers import (
    make_ecs_event,
    make_dbr_event,
    mock_ecs_describe_stopped_success,
    mock_ecs_describe_stopped_failed,
    mock_ecs_describe_running,
    mock_urlopen_response,
)


# =============== lambda_handler – ECS Path ===============


class TestCheckJobStatusHandlerEcs:
    """Tests for the full lambda_handler – ECS path."""

    def test_handler_ecs_success(self, monkeypatch):
        """ECS handler path should update trigger_result with SUCCESS."""
        mock_client = mock_ecs_describe_stopped_success()
        monkeypatch.setattr(
            "check_job_status.handler.get_ecs_client",
            lambda: mock_client,
        )

        event = make_ecs_event()
        result = lambda_handler(event, None)

        assert result["trigger_result"]["job_status"] == "SUCCESS"
        assert result["trigger_result"]["runner_name"] == "S2S3"

    def test_handler_ecs_running(self, monkeypatch):
        """ECS handler path should update trigger_result with RUNNING."""
        mock_client = mock_ecs_describe_running()
        monkeypatch.setattr(
            "check_job_status.handler.get_ecs_client",
            lambda: mock_client,
        )

        event = make_ecs_event()
        result = lambda_handler(event, None)

        assert result["trigger_result"]["job_status"] == "RUNNING"

    def test_handler_ecs_failed(self, monkeypatch):
        """ECS handler path should update trigger_result with FAILED."""
        mock_client = mock_ecs_describe_stopped_failed()
        monkeypatch.setattr(
            "check_job_status.handler.get_ecs_client",
            lambda: mock_client,
        )

        event = make_ecs_event()
        result = lambda_handler(event, None)

        assert result["trigger_result"]["job_status"] == "FAILED"

    def test_handler_ecs_missing_task_arn(self):
        """Missing task_arn in trigger_result → handler marks FAILED directly."""
        event = make_ecs_event(task_arn="")
        result = lambda_handler(event, None)

        assert result["trigger_result"]["job_status"] == "FAILED"
        assert "Missing task_arn" in result["trigger_result"]["error"]

    def test_handler_ecs_preserves_event_fields(self, monkeypatch):
        """Handler should preserve original event fields (ECS path)."""
        mock_client = mock_ecs_describe_stopped_success()
        monkeypatch.setattr(
            "check_job_status.handler.get_ecs_client",
            lambda: mock_client,
        )

        event = make_ecs_event()
        result = lambda_handler(event, None)

        assert result["run_id"] == "run-001"
        assert result["job_id"] == "client"
        assert "trigger_result" in result


# =============== lambda_handler – DBR Path ===============


class TestCheckJobStatusHandlerDbr:
    """Tests for the full lambda_handler – Databricks path."""

    @patch("check_job_status.databricks_status.urllib.request.urlopen")
    def test_handler_dbr_success(self, mock_urlopen):
        """DBR handler path should update trigger_result with SUCCESS."""
        mock_urlopen.return_value = mock_urlopen_response({
            "state": {
                "life_cycle_state": "TERMINATED",
                "result_state": "SUCCESS",
            },
            "notebook_output": {"result": "done"},
        })

        event = make_dbr_event()
        result = lambda_handler(event, None)

        assert result["trigger_result"]["job_status"] == "SUCCESS"
        assert result["trigger_result"]["runner_name"] == "DBR"

    @patch("check_job_status.databricks_status.urllib.request.urlopen")
    def test_handler_dbr_running(self, mock_urlopen):
        """DBR handler path should update trigger_result with RUNNING."""
        mock_urlopen.return_value = mock_urlopen_response({
            "state": {"life_cycle_state": "RUNNING", "result_state": ""},
        })

        event = make_dbr_event()
        result = lambda_handler(event, None)

        assert result["trigger_result"]["job_status"] == "RUNNING"

    @patch("check_job_status.databricks_status.urllib.request.urlopen")
    def test_handler_dbr_failed(self, mock_urlopen):
        """DBR handler path should update trigger_result with FAILED."""
        mock_urlopen.return_value = mock_urlopen_response({
            "state": {
                "life_cycle_state": "TERMINATED",
                "result_state": "FAILED",
                "state_message": "Error in notebook",
            },
        })

        event = make_dbr_event()
        result = lambda_handler(event, None)

        assert result["trigger_result"]["job_status"] == "FAILED"

    def test_handler_dbr_missing_run_id(self):
        """Missing dbr_run_id in trigger_result → handler marks FAILED directly."""
        event = make_dbr_event(dbr_run_id="")
        result = lambda_handler(event, None)

        assert result["trigger_result"]["job_status"] == "FAILED"
        assert "Missing dbr_run_id" in result["trigger_result"]["error"]

    @patch("check_job_status.databricks_status.urllib.request.urlopen")
    def test_handler_dbr_preserves_event_fields(self, mock_urlopen):
        """Handler should preserve original event fields (DBR path)."""
        mock_urlopen.return_value = mock_urlopen_response({
            "state": {
                "life_cycle_state": "TERMINATED",
                "result_state": "SUCCESS",
            },
            "notebook_output": {},
        })

        event = make_dbr_event()
        result = lambda_handler(event, None)

        assert result["run_id"] == "run-002"
        assert result["job_id"] == "dbr_client"
        assert "trigger_result" in result


# =============== lambda_handler – Unsupported runner_type ===============


class TestCheckJobStatusHandlerUnsupported:
    """Tests for the handler with unsupported or missing runner_type."""

    def test_handler_unsupported_runner_type(self):
        """Unsupported runner_type → FAILED."""
        event = {
            "run_id": "run-999",
            "job_id": "unknown",
            "trigger_result": {
                "trigger_status": "TRIGGERED",
                "runner_type": "SPARK_ON_K8S",
            },
            "job_config": {"job_runner": {"config": {}}},
        }
        result = lambda_handler(event, None)

        assert result["trigger_result"]["job_status"] == "FAILED"
        assert "Unsupported runner_type" in result["trigger_result"]["error"]

    def test_handler_missing_runner_type(self):
        """Missing runner_type → FAILED."""
        event = {
            "run_id": "run-999",
            "job_id": "unknown",
            "trigger_result": {
                "trigger_status": "TRIGGERED",
            },
            "job_config": {"job_runner": {"config": {}}},
        }
        result = lambda_handler(event, None)

        assert result["trigger_result"]["job_status"] == "FAILED"
        assert "Unsupported runner_type" in result["trigger_result"]["error"]

    def test_handler_empty_runner_type(self):
        """Empty string runner_type → FAILED."""
        event = {
            "run_id": "run-999",
            "job_id": "unknown",
            "trigger_result": {
                "trigger_status": "TRIGGERED",
                "runner_type": "",
            },
            "job_config": {"job_runner": {"config": {}}},
        }
        result = lambda_handler(event, None)

        assert result["trigger_result"]["job_status"] == "FAILED"
        assert "Unsupported runner_type" in result["trigger_result"]["error"]
