-- H2 test DDL for Customer, run in MSSQLServer compatibility mode
-- (standing in for Sybase since H2 has no Sybase mode).
-- IDENTITY column behavior matches what SimpleJdbcInsert expects.

CREATE TABLE CUSTOMER (
    id         BIGINT       IDENTITY      NOT NULL PRIMARY KEY,
    first_name VARCHAR(100)               NOT NULL,
    last_name  VARCHAR(100)               NOT NULL,
    email      VARCHAR(200)               NOT NULL,
    created_at DATETIME                   NOT NULL
);
