variable "aws_region" {
  description = "AWS region to deploy to"
  type        = string
  default     = "us-east-1"
}

variable "env" {
  description = "Environment name (dev, test, prod)"
  type        = string
  default     = "dev"
}

variable "project_name" {
  description = "Project name used in resource names"
  type        = string
  default     = "terraform-hello"
}

variable "tags" {
  description = "Tags applied to all resources"
  type        = map(string)
  default = {
    # <<< PLACEHOLDER: add any firm-required tags here >>>
    Project = "terraform-hello"
    Owner   = "REPLACE-your-name"
  }
}
