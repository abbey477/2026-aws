package com.example.dbtester.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;

/**
 * Builds the Oracle-scoped triad of beans that every repository/service needs:
 * DataSource, JdbcTemplate, and PlatformTransactionManager.
 *
 * <p>All three are marked {@link Primary}. When Spring encounters a bean
 * injection point with multiple matching candidates (because Sybase provides
 * the same three bean types), it prefers the primary. This lets generic
 * {@code @Autowired DataSource} work without qualifiers — though we still
 * use qualifiers explicitly in repositories for clarity.
 */
@Configuration
public class OracleDataSourceConfig {

    private final AppProperties.DbProps config;

    /**
     * Pulls the {@code oracle} field directly off {@link AppProperties}.
     * Fails fast if it's null — missing config is a programming error.
     */
    public OracleDataSourceConfig(AppProperties properties) {
        this.config = properties.oracle();
        if (this.config == null) {
            throw new IllegalStateException("Missing 'app.oracle.*' configuration");
        }
    }

    @Primary
    @Bean(name = "oracleDataSource", destroyMethod = "close")
    public DataSource oracleDataSource() {
        return HikariDataSourceFactory.build("oracle", config);
    }

    @Primary
    @Bean(name = "oracleJdbcTemplate")
    public JdbcTemplate oracleJdbcTemplate(DataSource oracleDataSource) {
        return new JdbcTemplate(oracleDataSource);
    }

    /**
     * Transaction manager for {@code @Transactional("oracleTxManager")}.
     * Each datasource needs its own — a single manager can't span Oracle
     * and Sybase (that would require XA / two-phase commit).
     */
    @Primary
    @Bean(name = "oracleTxManager")
    public PlatformTransactionManager oracleTxManager(DataSource oracleDataSource) {
        return new DataSourceTransactionManager(oracleDataSource);
    }
}
