# DynamoDB Test Data — Windows PowerShell (v3)

Seed data for `app-jobConfig` (15), `app-jobRun` (50), `app-jobLog` (100).

## Usage

Open PowerShell in this folder, then:

```powershell
.\setup.ps1     # load all test data
.\cleanup.ps1   # delete all items from the three tables (keeps the tables)
.\reset.ps1     # cleanup + setup (fresh state)
```

`cleanup.ps1` asks you to type `yes` before deleting anything.

## If you hit an execution-policy error

PowerShell may block unsigned local scripts. Either run this once per session:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

Or invoke the script explicitly:

```powershell
powershell -ExecutionPolicy Bypass -File .\setup.ps1
```

## Requirements

- AWS CLI v2 installed and configured (`aws configure`) with read/write perms on the three tables
- Tables must already exist with these keys:
  - `app-jobConfig`: PK `job_id` (S), SK `job_type` (S)
  - `app-jobRun`: PK `run_id` (S), SK `last_updated_time` (S)
  - `app-jobLog`: PK `run_id` (S), SK `time` (S)
- PowerShell 5.1+ (built into Windows 10/11) or PowerShell 7+
