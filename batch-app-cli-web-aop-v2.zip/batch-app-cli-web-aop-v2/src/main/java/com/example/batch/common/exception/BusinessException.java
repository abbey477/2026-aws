package com.example.batch.common.exception;

/**
 * Business-level exception thrown by services.
 * Carries an exit code for Autosys to read.
 */
public class BusinessException extends RuntimeException {

    private final int exitCode;

    public BusinessException(String message, int exitCode) {
        super(message);
        this.exitCode = exitCode;
    }

    public int getExitCode() {
        return exitCode;
    }
}
