package com.example.dbtester.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;

/**
 * Builds the Sybase-scoped beans. Mirror of {@link OracleDataSourceConfig}
 * except without {@code @Primary} — Oracle wins any ambiguous injection.
 *
 * <p>To actually use Sybase, repositories/services must reference these beans
 * by their qualifier names ({@code sybaseDataSource}, {@code sybaseJdbcTemplate},
 * {@code sybaseTxManager}).
 */
@Configuration
public class SybaseDataSourceConfig {

    private final AppProperties.DbProps config;

    public SybaseDataSourceConfig(AppProperties properties) {
        this.config = properties.sybase();
        if (this.config == null) {
            throw new IllegalStateException("Missing 'app.sybase.*' configuration");
        }
    }

    @Bean(name = "sybaseDataSource", destroyMethod = "close")
    public DataSource sybaseDataSource() {
        return HikariDataSourceFactory.build("sybase", config);
    }

    @Bean(name = "sybaseJdbcTemplate")
    public JdbcTemplate sybaseJdbcTemplate(DataSource sybaseDataSource) {
        return new JdbcTemplate(sybaseDataSource);
    }

    /**
     * Used by {@code @Transactional("sybaseTxManager")} — services must pass
     * the qualifier explicitly since this manager is not @Primary.
     */
    @Bean(name = "sybaseTxManager")
    public PlatformTransactionManager sybaseTxManager(DataSource sybaseDataSource) {
        return new DataSourceTransactionManager(sybaseDataSource);
    }
}
