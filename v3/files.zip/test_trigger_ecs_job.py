"""
Unit tests for TriggerEcsJob Lambda handler.

Coverage:

Happy path
  - Successful trigger returns TRIGGERED with task_arn
  - JOB_PARAM env var contains JSON-encoded job_param
  - Nested objects and arrays survive JSON round-trip
  - Unicode characters survive JSON serialization
  - Empty job_param ({}) still serializes and passes

Failure modes (all return TRIGGER_FAILED cleanly)
  - RunTask returns empty tasks list (placement failure)
  - Generic ClientError from RunTask
  - InvalidParameterException — the 8KB overrides overrun
  - ClusterNotFoundException
  - AccessDeniedException

Configuration
  - Runner config overrides for task_definition and container_name
  - Missing cluster still calls RunTask (AWS rejects cleanly)
  - Missing image logs as "N/A"

Payload size logging
  - JOB_PARAM_SIZE log emitted with correct byte count
  - Size log emitted BEFORE RunTask (so size is known even on failure)
  - Byte count matches len(json.dumps(job_param))

Handler integration
  - Handler adds runner_name and runner_type to trigger_result
  - Handler preserves all original event fields
  - Handler calls write_log with correct stage and status
  - write_log called even on failure path
  - Handler handles missing run_id gracefully (defaults to "UNKNOWN")
  - Handler handles completely empty event gracefully
"""

import json
import logging

import pytest
from unittest.mock import MagicMock, patch
from botocore.exceptions import ClientError

from lambdas.trigger_ecs_job.handler import lambda_handler
from lambdas.trigger_ecs_job.ecs_trigger import trigger_ecs_task


# ───────────────────────── Auto-mock write_log ─────────────────────────

@pytest.fixture(autouse=True)
def _mock_write_log():
    """Prevent write_log from hitting real DynamoDB in all tests."""
    with patch("lambdas.trigger_ecs_job.handler.write_log") as mock:
        yield mock


# ───────────────────────── Helpers ─────────────────────────

def _make_event(runner_config_overrides=None, job_param=None, run_id="run-001"):
    """Build a sample merged payload from GetConfig."""
    runner_config = {
        "cluster": "my-ecs-cluster",
        "subnets": ["subnet-aaa111", "subnet-bbb222"],
        "security_groups": ["sg-abc123"],
        "task_definition": "default-task-def",
        "container_name": "default-container",
        "instance_size": "small",
        "image": "",
    }
    if runner_config_overrides:
        runner_config.update(runner_config_overrides)

    if job_param is None:
        job_param = {
            "source": {"type": "API", "name": "RDI"},
            "batch_size": 1000,
            "output": ["s3_path"],
        }

    return {
        "run_id": run_id,
        "job_id": "client",
        "job_type": "sourcing",
        "status": "WAITING",
        "job_config": {
            "job_runner": {
                "type": "ECS_Fargate",
                "name": "S2S3",
                "config": runner_config,
            },
            "job_param": job_param,
            "next_jobs": [],
        },
    }


def _mock_ecs_client_success():
    """Mock ECS client that returns a successful RunTask response."""
    mock_client = MagicMock()
    mock_client.run_task.return_value = {
        "tasks": [
            {
                "taskArn": "arn:aws:ecs:us-east-1:123456789012:task/my-ecs-cluster/abc123def456",
                "lastStatus": "PROVISIONING",
            }
        ],
        "failures": [],
    }
    return mock_client


def _mock_ecs_client_no_tasks():
    """Mock ECS client where RunTask returns no tasks (failure)."""
    mock_client = MagicMock()
    mock_client.run_task.return_value = {
        "tasks": [],
        "failures": [
            {
                "arn": "arn:aws:ecs:us-east-1:123456789012:container-instance/xyz",
                "reason": "RESOURCE:MEMORY",
            }
        ],
    }
    return mock_client


def _mock_ecs_client_with_error(code, message):
    """Mock ECS client that raises a ClientError with the given code/message."""
    mock_client = MagicMock()
    mock_client.run_task.side_effect = ClientError(
        error_response={"Error": {"Code": code, "Message": message}},
        operation_name="RunTask",
    )
    return mock_client


def _get_job_param_env(mock_ecs):
    """Extract the JOB_PARAM env var from the last run_task call."""
    call_kwargs = mock_ecs.run_task.call_args.kwargs
    env_vars = call_kwargs["overrides"]["containerOverrides"][0]["environment"]
    return next(e for e in env_vars if e["name"] == "JOB_PARAM")


# ═══════════════════════════════════════════════════════════════════════
# Happy path — trigger_ecs_task
# ═══════════════════════════════════════════════════════════════════════

class TestHappyPath:

    def test_successful_trigger_returns_task_arn(self):
        """Happy path: RunTask returns a task with an ARN."""
        mock_ecs = _mock_ecs_client_success()
        event = _make_event()
        job_config = event["job_config"]
        job_param = job_config["job_param"]

        result = trigger_ecs_task(mock_ecs, job_config, job_param, "run-001")

        assert result["trigger_status"] == "TRIGGERED"
        assert "abc123def456" in result["task_arn"]
        assert "error" not in result

    def test_job_param_passed_as_json_in_env(self):
        """JOB_PARAM env var contains JSON-encoded job_param."""
        mock_ecs = _mock_ecs_client_success()
        event = _make_event()
        job_config = event["job_config"]
        job_param = job_config["job_param"]

        trigger_ecs_task(mock_ecs, job_config, job_param, "run-001")

        job_param_env = _get_job_param_env(mock_ecs)
        assert job_param_env["name"] == "JOB_PARAM"
        parsed = json.loads(job_param_env["value"])
        assert parsed == job_param

    def test_nested_structures_round_trip(self):
        """Nested objects and arrays survive JSON round-trip."""
        mock_ecs = _mock_ecs_client_success()
        job_param = {
            "source": {"type": "API", "name": "RDI", "config": {"timeout": 30}},
            "filters": [
                {"field": "status", "op": "eq", "value": "active"},
                {"field": "region", "op": "in", "value": ["us", "eu"]},
            ],
            "batch_size": 1000,
            "dry_run": False,
        }
        event = _make_event(job_param=job_param)
        job_config = event["job_config"]

        trigger_ecs_task(mock_ecs, job_config, job_param, "run-001")

        parsed = json.loads(_get_job_param_env(mock_ecs)["value"])
        assert parsed == job_param
        assert parsed["source"]["config"]["timeout"] == 30
        assert parsed["filters"][1]["value"] == ["us", "eu"]
        assert parsed["dry_run"] is False

    def test_unicode_survives_serialization(self):
        """Non-ASCII characters in job_param survive JSON serialization."""
        mock_ecs = _mock_ecs_client_success()
        job_param = {
            "customer_name": "Zürich Café",
            "description": "データ処理",
            "emoji_tag": "🚀",
        }
        event = _make_event(job_param=job_param)
        job_config = event["job_config"]

        trigger_ecs_task(mock_ecs, job_config, job_param, "run-001")

        parsed = json.loads(_get_job_param_env(mock_ecs)["value"])
        assert parsed == job_param

    def test_empty_job_param_still_works(self):
        """Empty dict as job_param should serialize to '{}' and succeed."""
        mock_ecs = _mock_ecs_client_success()
        event = _make_event(job_param={})
        job_config = event["job_config"]

        result = trigger_ecs_task(mock_ecs, job_config, {}, "run-001")

        assert result["trigger_status"] == "TRIGGERED"
        assert _get_job_param_env(mock_ecs)["value"] == "{}"


# ═══════════════════════════════════════════════════════════════════════
# Failure modes
# ═══════════════════════════════════════════════════════════════════════

class TestFailureModes:

    def test_no_tasks_returned_trigger_failed(self):
        """RunTask returns empty tasks list — should mark TRIGGER_FAILED."""
        mock_ecs = _mock_ecs_client_no_tasks()
        event = _make_event()
        job_config = event["job_config"]
        job_param = job_config["job_param"]

        result = trigger_ecs_task(mock_ecs, job_config, job_param, "run-001")

        assert result["trigger_status"] == "TRIGGER_FAILED"
        assert result["task_arn"] == ""
        assert "RESOURCE:MEMORY" in result["error"]

    def test_generic_client_error_trigger_failed(self):
        """Generic ClientError — should mark TRIGGER_FAILED with error message."""
        mock_ecs = _mock_ecs_client_with_error(
            "InternalServerError", "Something went wrong."
        )
        event = _make_event()
        job_config = event["job_config"]
        job_param = job_config["job_param"]

        result = trigger_ecs_task(mock_ecs, job_config, job_param, "run-001")

        assert result["trigger_status"] == "TRIGGER_FAILED"
        assert result["task_arn"] == ""
        assert "InternalServerError" in result["error"]

    def test_invalid_parameter_exception_8kb_overrun(self):
        """The 8KB overrides overrun scenario — InvalidParameterException."""
        mock_ecs = _mock_ecs_client_with_error(
            "InvalidParameterException",
            "Container overrides length must be at most 8192",
        )
        event = _make_event()
        job_config = event["job_config"]
        job_param = job_config["job_param"]

        result = trigger_ecs_task(mock_ecs, job_config, job_param, "run-001")

        assert result["trigger_status"] == "TRIGGER_FAILED"
        assert result["task_arn"] == ""
        assert "InvalidParameterException" in result["error"]
        assert "8192" in result["error"]

    def test_cluster_not_found_exception(self):
        """ClusterNotFoundException — should mark TRIGGER_FAILED."""
        mock_ecs = _mock_ecs_client_with_error(
            "ClusterNotFoundException", "Cluster not found."
        )
        event = _make_event()
        job_config = event["job_config"]
        job_param = job_config["job_param"]

        result = trigger_ecs_task(mock_ecs, job_config, job_param, "run-001")

        assert result["trigger_status"] == "TRIGGER_FAILED"
        assert "ClusterNotFoundException" in result["error"]

    def test_access_denied_exception(self):
        """AccessDeniedException — should mark TRIGGER_FAILED."""
        mock_ecs = _mock_ecs_client_with_error(
            "AccessDeniedException", "User is not authorized."
        )
        event = _make_event()
        job_config = event["job_config"]
        job_param = job_config["job_param"]

        result = trigger_ecs_task(mock_ecs, job_config, job_param, "run-001")

        assert result["trigger_status"] == "TRIGGER_FAILED"
        assert "AccessDeniedException" in result["error"]


# ═══════════════════════════════════════════════════════════════════════
# Configuration
# ═══════════════════════════════════════════════════════════════════════

class TestConfiguration:

    def test_runner_config_overrides_defaults(self):
        """Runner config overrides should flow through to run_task."""
        mock_ecs = _mock_ecs_client_success()
        event = _make_event(runner_config_overrides={
            "task_definition": "custom-task-def",
            "container_name": "custom-container",
        })
        job_config = event["job_config"]
        job_param = job_config["job_param"]

        trigger_ecs_task(mock_ecs, job_config, job_param, "run-001")

        call_kwargs = mock_ecs.run_task.call_args.kwargs
        assert call_kwargs["taskDefinition"] == "custom-task-def"
        overrides = call_kwargs["overrides"]["containerOverrides"][0]
        assert overrides["name"] == "custom-container"

    def test_subnets_and_security_groups_passed_through(self):
        """Network config should be passed to run_task as-is."""
        mock_ecs = _mock_ecs_client_success()
        event = _make_event()
        job_config = event["job_config"]
        job_param = job_config["job_param"]

        trigger_ecs_task(mock_ecs, job_config, job_param, "run-001")

        call_kwargs = mock_ecs.run_task.call_args.kwargs
        net_config = call_kwargs["networkConfiguration"]["awsvpcConfiguration"]
        assert net_config["subnets"] == ["subnet-aaa111", "subnet-bbb222"]
        assert net_config["securityGroups"] == ["sg-abc123"]
        assert net_config["assignPublicIp"] == "DISABLED"

    def test_launch_type_is_fargate(self):
        """Launch type should always be FARGATE."""
        mock_ecs = _mock_ecs_client_success()
        event = _make_event()
        job_config = event["job_config"]
        job_param = job_config["job_param"]

        trigger_ecs_task(mock_ecs, job_config, job_param, "run-001")

        assert mock_ecs.run_task.call_args.kwargs["launchType"] == "FARGATE"

    def test_missing_image_logs_as_na(self, caplog):
        """When image is empty, log should show N/A."""
        mock_ecs = _mock_ecs_client_success()
        event = _make_event(runner_config_overrides={"image": ""})
        job_config = event["job_config"]
        job_param = job_config["job_param"]

        with caplog.at_level(logging.INFO):
            trigger_ecs_task(mock_ecs, job_config, job_param, "run-001")

        assert any("image=N/A" in rec.message for rec in caplog.records)


# ═══════════════════════════════════════════════════════════════════════
# Payload size logging
# ═══════════════════════════════════════════════════════════════════════

class TestPayloadSizeLogging:

    def test_size_log_emitted_with_correct_bytes(self, caplog):
        """JOB_PARAM_SIZE log line should contain the correct byte count."""
        mock_ecs = _mock_ecs_client_success()
        job_param = {"foo": "bar", "nums": [1, 2, 3]}
        expected_bytes = len(json.dumps(job_param))
        event = _make_event(job_param=job_param)
        job_config = event["job_config"]

        with caplog.at_level(logging.INFO):
            trigger_ecs_task(mock_ecs, job_config, job_param, "run-001")

        size_logs = [
            rec for rec in caplog.records if "JOB_PARAM_SIZE" in rec.message
        ]
        assert len(size_logs) == 1
        assert f"job_param_bytes={expected_bytes}" in size_logs[0].message
        assert "run_id=run-001" in size_logs[0].message

    def test_size_logged_before_run_task_call(self, caplog):
        """Size log must be emitted BEFORE run_task so we see size on failure."""
        mock_ecs = _mock_ecs_client_with_error(
            "InvalidParameterException",
            "Container overrides length must be at most 8192",
        )
        event = _make_event()
        job_config = event["job_config"]
        job_param = job_config["job_param"]

        with caplog.at_level(logging.INFO):
            trigger_ecs_task(mock_ecs, job_config, job_param, "run-001")

        messages = [rec.message for rec in caplog.records]
        size_idx = next(
            i for i, m in enumerate(messages) if "JOB_PARAM_SIZE" in m
        )
        error_idx = next(
            i for i, m in enumerate(messages) if "ECS_CLIENT_ERROR" in m
        )
        assert size_idx < error_idx

    def test_size_log_for_empty_payload(self, caplog):
        """Empty {} payload should log 2 bytes ('{}')."""
        mock_ecs = _mock_ecs_client_success()
        event = _make_event(job_param={})
        job_config = event["job_config"]

        with caplog.at_level(logging.INFO):
            trigger_ecs_task(mock_ecs, job_config, {}, "run-001")

        size_logs = [
            rec for rec in caplog.records if "JOB_PARAM_SIZE" in rec.message
        ]
        assert len(size_logs) == 1
        assert "job_param_bytes=2" in size_logs[0].message


# ═══════════════════════════════════════════════════════════════════════
# Handler integration tests
# ═══════════════════════════════════════════════════════════════════════

class TestLambdaHandler:

    def test_handler_success_adds_trigger_result(self, monkeypatch):
        """Handler should add trigger_result with runner metadata on success."""
        mock_ecs = _mock_ecs_client_success()
        monkeypatch.setattr(
            "lambdas.trigger_ecs_job.handler.boto3.client",
            lambda service: mock_ecs,
        )

        event = _make_event()
        result = lambda_handler(event, None)

        assert "trigger_result" in result
        tr = result["trigger_result"]
        assert tr["trigger_status"] == "TRIGGERED"
        assert tr["runner_name"] == "S2S3"
        assert tr["runner_type"] == "ECS"
        assert "abc123def456" in tr["task_arn"]

    def test_handler_failure_adds_trigger_result(self, monkeypatch):
        """Handler should add trigger_result with TRIGGER_FAILED on error."""
        mock_ecs = _mock_ecs_client_no_tasks()
        monkeypatch.setattr(
            "lambdas.trigger_ecs_job.handler.boto3.client",
            lambda service: mock_ecs,
        )

        event = _make_event()
        result = lambda_handler(event, None)

        tr = result["trigger_result"]
        assert tr["trigger_status"] == "TRIGGER_FAILED"
        assert tr["runner_name"] == "S2S3"
        assert tr["runner_type"] == "ECS"

    def test_handler_preserves_original_event_fields(self, monkeypatch):
        """Handler should return the original event fields plus trigger_result."""
        mock_ecs = _mock_ecs_client_success()
        monkeypatch.setattr(
            "lambdas.trigger_ecs_job.handler.boto3.client",
            lambda service: mock_ecs,
        )

        event = _make_event()
        result = lambda_handler(event, None)

        assert result["run_id"] == "run-001"
        assert result["job_id"] == "client"
        assert result["job_type"] == "sourcing"
        assert result["status"] == "WAITING"
        assert result["job_config"]["job_runner"]["type"] == "ECS_Fargate"

    def test_handler_calls_write_log_on_success(
        self, monkeypatch, _mock_write_log
    ):
        """write_log should be called with the correct stage and status."""
        mock_ecs = _mock_ecs_client_success()
        monkeypatch.setattr(
            "lambdas.trigger_ecs_job.handler.boto3.client",
            lambda service: mock_ecs,
        )

        lambda_handler(_make_event(), None)

        _mock_write_log.assert_called_once()
        call_kwargs = _mock_write_log.call_args.kwargs
        assert call_kwargs["run_id"] == "run-001"
        assert call_kwargs["job_id"] == "client"
        assert call_kwargs["stage"] == "TriggerEcsJob"
        assert call_kwargs["status"] == "TRIGGERED"

    def test_handler_calls_write_log_on_failure(
        self, monkeypatch, _mock_write_log
    ):
        """write_log should be called even when the trigger fails."""
        mock_ecs = _mock_ecs_client_no_tasks()
        monkeypatch.setattr(
            "lambdas.trigger_ecs_job.handler.boto3.client",
            lambda service: mock_ecs,
        )

        lambda_handler(_make_event(), None)

        _mock_write_log.assert_called_once()
        assert _mock_write_log.call_args.kwargs["status"] == "TRIGGER_FAILED"

    def test_handler_missing_run_id_defaults_to_unknown(self, monkeypatch):
        """Handler should default run_id to 'UNKNOWN' when missing."""
        mock_ecs = _mock_ecs_client_success()
        monkeypatch.setattr(
            "lambdas.trigger_ecs_job.handler.boto3.client",
            lambda service: mock_ecs,
        )

        event = _make_event()
        del event["run_id"]
        result = lambda_handler(event, None)

        assert result["trigger_result"]["trigger_status"] == "TRIGGERED"
        # run_id wasn't in the event, so the handler used "UNKNOWN"
        # downstream — visible through the write_log call
        # (checked indirectly here; the trigger still succeeds)

    def test_handler_handles_empty_event(self, monkeypatch):
        """Handler should not crash on a minimal / empty-ish event."""
        mock_ecs = _mock_ecs_client_with_error(
            "InvalidParameterException", "taskDefinition cannot be empty"
        )
        monkeypatch.setattr(
            "lambdas.trigger_ecs_job.handler.boto3.client",
            lambda service: mock_ecs,
        )

        # Empty event — every config lookup falls back to a default.
        # The ECS call will fail, but the handler must return cleanly.
        result = lambda_handler({}, None)

        assert "trigger_result" in result
        assert result["trigger_result"]["trigger_status"] == "TRIGGER_FAILED"

    def test_handler_returns_modified_event_not_new_dict(self, monkeypatch):
        """Handler must return the SAME event object, with trigger_result added."""
        mock_ecs = _mock_ecs_client_success()
        monkeypatch.setattr(
            "lambdas.trigger_ecs_job.handler.boto3.client",
            lambda service: mock_ecs,
        )

        event = _make_event()
        result = lambda_handler(event, None)
        assert result is event
