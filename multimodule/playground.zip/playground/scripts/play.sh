#!/usr/bin/env bash
#
# play.sh — build and run feature modules in the playground.
#
# Usage:
#   ./scripts/play.sh list                 list all feature modules
#   ./scripts/play.sh build                build everything (mvn install from root)
#   ./scripts/play.sh build <feature>...   build only the named feature(s) + deps
#   ./scripts/play.sh run <feature> [args] run one feature
#   ./scripts/play.sh help                 show this help
#
# Feature names may be given with or without the "feature-" prefix,
# e.g. both "cli-hello" and "feature-cli-hello" work.
#
# Examples:
#   ./scripts/play.sh build
#   ./scripts/play.sh build rest-config cli-multidb
#   ./scripts/play.sh run cli-hello Ada Bob
#   ./scripts/play.sh run rest-config
#
set -euo pipefail

# Resolve repo root regardless of where the script is called from.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$ROOT_DIR"

# Use the Maven wrapper if present, otherwise fall back to system mvn.
if [[ -x "./mvnw" ]]; then
  MVN="./mvnw"
else
  MVN="mvn"
fi

# Normalise a feature name to its module directory name.
# Accepts "cli-hello" or "feature-cli-hello"; verifies the module exists.
resolve_module() {
  local name="$1"
  [[ "$name" == feature-* ]] || name="feature-$name"
  if [[ ! -d "$ROOT_DIR/$name" ]]; then
    echo "ERROR: no such feature module: $name" >&2
    echo "Run './scripts/play.sh list' to see available features." >&2
    exit 1
  fi
  echo "$name"
}

cmd_list() {
  echo "Feature modules:"
  for d in "$ROOT_DIR"/feature-*/; do
    [[ -d "$d" ]] || continue
    local m
    m="$(basename "$d")"
    if [[ "$m" == "feature-common" ]]; then
      echo "  - $m   (shared library — not runnable)"
    else
      echo "  - $m"
    fi
  done
}

cmd_build() {
  if [[ $# -eq 0 ]]; then
    echo ">> Building ALL modules"
    "$MVN" -q clean install
    return
  fi
  # Build only the requested modules, plus anything they depend on (-am),
  # always including feature-common explicitly so it is installed first.
  local projects="feature-common"
  for f in "$@"; do
    projects="$projects,$(resolve_module "$f")"
  done
  echo ">> Building modules: $projects"
  "$MVN" -q clean install -pl "$projects" -am
}

cmd_run() {
  if [[ $# -lt 1 ]]; then
    echo "ERROR: 'run' needs a feature name." >&2
    echo "Usage: ./scripts/play.sh run <feature> [args...]" >&2
    exit 1
  fi
  local module
  module="$(resolve_module "$1")"
  if [[ "$module" == "feature-common" ]]; then
    echo "ERROR: feature-common is a shared library, not a runnable feature." >&2
    exit 1
  fi
  shift

  echo ">> Running $module"
  if [[ $# -gt 0 ]]; then
    # spring-boot:run takes program args as a comma-separated list.
    local joined
    joined="$(IFS=, ; echo "$*")"
    "$MVN" -q -pl "$module" spring-boot:run -Dspring-boot.run.arguments="$joined"
  else
    "$MVN" -q -pl "$module" spring-boot:run
  fi
}

cmd_help() {
  sed -n '2,/^set -euo/p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//; /^set -euo/d'
}

main() {
  local cmd="${1:-help}"
  shift || true
  case "$cmd" in
    list)  cmd_list ;;
    build) cmd_build "$@" ;;
    run)   cmd_run "$@" ;;
    help|-h|--help) cmd_help ;;
    *)
      echo "Unknown command: $cmd" >&2
      cmd_help
      exit 1
      ;;
  esac
}

main "$@"
