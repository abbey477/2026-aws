# setup.ps1 — load seed data into app-jobConfig, app-jobRun, app-jobLog
$ErrorActionPreference = "Stop"
Set-Location -Path $PSScriptRoot

$Files = @(
    "app-jobConfig_part1_of_1.json",
    "app-jobRun_part1_of_2.json",
    "app-jobRun_part2_of_2.json",
    "app-jobLog_part1_of_4.json",
    "app-jobLog_part2_of_4.json",
    "app-jobLog_part3_of_4.json",
    "app-jobLog_part4_of_4.json"
)

Write-Host "=== Loading seed data ===" -ForegroundColor Cyan
foreach ($f in $Files) {
    Write-Host ">>> $f"
    $fileUri = "file://" + (Join-Path $PSScriptRoot $f)
    aws dynamodb batch-write-item --request-items $fileUri | Out-Null
    if ($LASTEXITCODE -ne 0) {
        Write-Error "Failed on $f"
        exit $LASTEXITCODE
    }
    Write-Host "    OK" -ForegroundColor Green
}

Write-Host ""
Write-Host "Counts:"
foreach ($t in @("app-jobConfig", "app-jobRun", "app-jobLog")) {
    $c = aws dynamodb scan --table-name $t --select COUNT --query Count --output text
    Write-Host "  ${t}: $c"
}
Write-Host "Expected: 15, 50, 100"
