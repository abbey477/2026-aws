#!/usr/bin/env python3
"""
_cleanup.py — delete every item from the three app- tables.
Called by cleanup.sh. Uses the AWS CLI under the hood so it respects the
same credentials/profile as the other scripts.
"""
import json
import subprocess
import sys

TABLES = [
    ("app-jobConfig", "job_id", "job_type"),
    ("app-jobRun",    "run_id", "last_updated_time"),
    ("app-jobLog",    "run_id", "time"),
]


def aws(args, capture=True):
    """Run an aws CLI command; return stdout as str (or raise on nonzero exit)."""
    proc = subprocess.run(
        ["aws"] + args,
        capture_output=capture,
        text=True,
    )
    if proc.returncode != 0:
        print(f"ERROR: aws {' '.join(args[:3])} ... failed", file=sys.stderr)
        print(proc.stderr, file=sys.stderr)
        sys.exit(proc.returncode)
    return proc.stdout


def scan_all_keys(table, pk, sk):
    """Page through Scan, returning a list of {pk: ..., sk: ...} dicts."""
    keys = []
    next_token = None
    while True:
        args = [
            "dynamodb", "scan",
            "--table-name", table,
            "--projection-expression", "#pk, #sk",
            "--expression-attribute-names", json.dumps({"#pk": pk, "#sk": sk}),
            "--output", "json",
        ]
        if next_token:
            args += ["--starting-token", next_token]
        resp = json.loads(aws(args))
        keys.extend(resp.get("Items", []))
        next_token = resp.get("NextToken")
        if not next_token:
            break
    return keys


def delete_in_batches(table, pk, sk, keys):
    """Delete keys 25 at a time via batch-write-item."""
    total = 0
    for i in range(0, len(keys), 25):
        batch = keys[i:i+25]
        payload = {
            table: [
                {"DeleteRequest": {"Key": {pk: k[pk], sk: k[sk]}}}
                for k in batch
            ]
        }
        # Write payload to a temp file — batch-write-item needs --request-items file://...
        tmp = "/tmp/_ddb_del_batch.json"
        with open(tmp, "w") as f:
            json.dump(payload, f)
        aws([
            "dynamodb", "batch-write-item",
            "--request-items", f"file://{tmp}",
        ])
        total += len(batch)
    return total


def count(table):
    out = aws([
        "dynamodb", "scan",
        "--table-name", table,
        "--select", "COUNT",
        "--query", "Count",
        "--output", "text",
    ])
    return int(out.strip())


def main():
    for table, pk, sk in TABLES:
        print(f">>> {table} (keys: {pk}, {sk})")
        keys = scan_all_keys(table, pk, sk)
        if not keys:
            print("    (already empty)")
            continue
        deleted = delete_in_batches(table, pk, sk, keys)
        print(f"    deleted {deleted} items")

    print("")
    print("Counts after cleanup:")
    for table, _, _ in TABLES:
        print(f"  {table}: {count(table)}")


if __name__ == "__main__":
    main()
