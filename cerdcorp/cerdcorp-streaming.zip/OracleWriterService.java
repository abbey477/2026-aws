import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

/**
 * Responsible for ONE thing: writing chunks to Oracle.
 * Knows nothing about Sybase or streaming logic.
 * Accepts a pre-built list of records and batch-inserts them.
 */
@Service
public class OracleWriterService {

    private static final Logger log = LoggerFactory.getLogger(OracleWriterService.class);

    private final JdbcTemplate oracleJdbc;

    public OracleWriterService(@Qualifier("oracleJdbc") JdbcTemplate oracleJdbc) {
        this.oracleJdbc = oracleJdbc;
    }

    // -------------------------------------------------------------------------
    // Public API — called by MigrationService with a full chunk.
    // One network round-trip to Oracle per chunk, not per row.
    // -------------------------------------------------------------------------

    public void writeChunk(List<MyRecord> chunk) {
        String sql = "INSERT INTO target_table (col1, col2, col3) VALUES (?, ?, ?)";

        oracleJdbc.batchUpdate(sql, new ChunkStatementSetter(chunk));

        log.debug("Wrote {} rows to Oracle", chunk.size());
    }

    // -------------------------------------------------------------------------
    // Named inner class replacing the lambda (ps, record) -> { ... }.
    // BatchPreparedStatementSetter tells Spring how to bind each row
    // to the PreparedStatement — one row at a time, via setValues().
    // -------------------------------------------------------------------------

    private static class ChunkStatementSetter implements BatchPreparedStatementSetter {

        private final List<MyRecord> chunk;

        public ChunkStatementSetter(List<MyRecord> chunk) {
            this.chunk = chunk;
        }

        @Override
        public void setValues(PreparedStatement ps, int rowIndex) throws SQLException {
            MyRecord record = chunk.get(rowIndex);
            ps.setLong(1, record.col1());
            ps.setString(2, record.col2());
            ps.setTimestamp(3, record.col3());
        }

        @Override
        public int getBatchSize() {
            return chunk.size(); // tells Spring how many rows are in this batch
        }
    }
}
