terraform {
  required_version = ">= 1.5.0"

  backend "s3" {
    # <<< PLACEHOLDER: replace with your firm's backend values >>>
    bucket         = "REPLACE-with-your-firm-state-bucket"
    key            = "terraform-hello/local/terraform.tfstate"
    region         = "us-east-1"
    dynamodb_table = "REPLACE-with-lock-table-if-used"
    encrypt        = true
  }
}
