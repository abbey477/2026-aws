"""
handler.py
TriggerDbrJob Lambda Handler — entrypoint only.

Orchestrates config extraction, Databricks trigger, and DynamoDB log write.
All business logic lives in databricks_client.py; all logging helpers in log_utils.py.

Input:  Full merged payload from GetConfig (job_run + job_config).
Output: Same payload + trigger_result with dbr_run_id and trigger_status.
"""

import sys
import os

# Ensure src/ is on the path when running inside Lambda
sys.path.insert(0, os.path.dirname(__file__))

from datetime import datetime, timezone

from config import get_runner_name
from databricks_client import trigger_databricks_job
from log_utils import log_debug, log_info, log_warning, log_error

# write_log imported at module level so tests can patch it cleanly
from dynamo_log import write_log  # noqa: F401 — patched in tests


def lambda_handler(event: dict, context) -> dict:
    """
    Lambda entry point — triggers a Databricks job.

    Input:  Full merged payload from GetConfig.
    Output: Same payload + trigger_result with Databricks run details.
    """
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    run_id = event.get("run_id", "UNKNOWN")
    job_config = event.get("job_config", {})
    job_param = job_config.get("job_param", {})

    runner_name = get_runner_name(job_config)

    if not runner_name:
        log_warning(
            "HANDLER_MISSING_RUNNER_NAME",
            {"run_id": run_id, "job_config_keys": list(job_config.keys())},
        )

    log_info(
        "HANDLER_START",
        {
            "timestamp": timestamp,
            "run_id": run_id,
            "runner_name": runner_name,
        },
    )

    log_debug(
        "HANDLER_EVENT_KEYS",
        {"event_keys": list(event.keys()), "job_param_keys": list(job_param.keys())},
    )

    trigger_result = trigger_databricks_job(job_config, job_param)
    trigger_result["runner_name"] = runner_name
    trigger_result["runner_type"] = "DBR"

    event["trigger_result"] = trigger_result

    write_log(
        run_id=run_id,
        job_id=event.get("job_id", ""),
        stage="TriggerDbrJob",
        status=trigger_result.get("trigger_status", "UNKNOWN"),
    )

    log_level = log_info if trigger_result["trigger_status"] == "TRIGGERED" else log_error
    log_level(
        "HANDLER_COMPLETE",
        {
            "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "run_id": run_id,
            "trigger_status": trigger_result.get("trigger_status"),
            "dbr_run_id": trigger_result.get("dbr_run_id", ""),
        },
    )

    return event
