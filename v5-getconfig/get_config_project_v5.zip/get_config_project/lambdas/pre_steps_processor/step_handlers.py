"""
Step handler functions for PreStepsProcessor.

As of v4:
- handle_change_since_append: implemented — queries job_run table via GSI-2
  to find the start_time of the last successful run.
- handle_ddb_config_pull:  still a stub.
- handle_no_pre_steps:     still a stub.
- handle_unknown_pre_step: still a stub.

Each handler returns a dict (possibly empty) that the main handler spreads
into the lambda output under a `pre_steps_results` key — this keeps per-step
results isolated from each other so later handlers can adopt the same pattern
without colliding.
"""

from typing import Any

from .dynamodb_ops import (
    JOB_RUN_TABLE,
    get_dynamodb_resource,
    get_last_successful_run_start_time,
    pull_config_from_table,
)
from .logging_utils import _log


def handle_no_pre_steps() -> dict:
    """
    Called when the input has no pre_steps to process:
    - key missing from job_config
    - pre_steps is None
    - pre_steps is an empty list
    - pre_steps has items but none have a valid pre_step_type

    Returns an empty dict — no result to contribute to output.
    TODO: implement actual no-data logic (discuss with architect).
    """
    _log("HANDLE_NO_PRE_STEPS", {"status": "stub_called"})
    return {}


def handle_change_since_append(step: dict, event: dict) -> dict:
    """
    Called for each pre_step with pre_step_type == 'change_since_append'.

    Looks up the start_time of the most recent successful run for this
    job by querying GSI-2 (jobIdQuery) on the job_run table. Returns a
    placeholder dict for now — the architect will clarify what this
    value should be used for downstream.

    Args:
        step: the pre_step item itself (currently just
              {"pre_step_type": "change_since_append"}).
        event: the full lambda event, used to pull job_id / job_type.

    Returns:
        A dict containing the query result (may contain None if no prior
        successful run). The main handler spreads this into the output.
    """
    job_id = event.get("job_id")
    job_type = event.get("job_type")

    _log("HANDLE_CHANGE_SINCE_APPEND_START", {
        "job_id": job_id,
        "job_type": job_type,
    })

    dynamodb = get_dynamodb_resource()
    table = dynamodb.Table(JOB_RUN_TABLE)

    start_time = get_last_successful_run_start_time(
        table=table,
        job_id=job_id,
        job_type=job_type,
    )

    # Placeholder result shape — the architect will define what
    # downstream consumers expect. For now we just surface the
    # timestamp (or None) under a clearly named key.
    result = {
        "last_successful_start_time": start_time,
        "placeholder": True,  # flag so reviewers know this shape is not final
    }

    _log("HANDLE_CHANGE_SINCE_APPEND_COMPLETE", {
        "job_id": job_id,
        "job_type": job_type,
        "has_start_time": start_time is not None,
    })

    return result


def handle_ddb_config_pull(step: dict, event: dict) -> dict:
    """
    Called for each pre_step with pre_step_type == 'ddb_config_pull'.

    For every table listed in step["tables"], look up the row keyed by
    (job_id, job_type) and include it in the result, keyed by table name.
    Missing rows are represented as `null` so downstream consumers always
    see every requested table.

    The main handler merges this return value DIRECTLY INTO job_param
    (not into pre_steps_results) — so the output shape ends up as:

        job_param: {
            ...existing fields...,
            "<table_name_1>": { ...row... } | None,
            "<table_name_2>": { ...row... } | None,
        }

    Args:
        step: the pre_step item — must contain a `tables` list.
              Shape: {"pre_step_type": "ddb_config_pull",
                      "tables": ["service_config", "table_config"]}
        event: the full lambda event, used to pull job_id / job_type.

    Returns:
        A dict keyed by table name. Empty dict if `tables` is missing,
        not a list, or empty. Missing rows come through as `None`.
    """
    job_id = event.get("job_id")
    job_type = event.get("job_type")
    tables = step.get("tables")

    _log("HANDLE_DDB_CONFIG_PULL_START", {
        "job_id": job_id,
        "job_type": job_type,
        "tables_count": len(tables) if isinstance(tables, list) else 0,
    })

    # No tables to pull — return empty, caller adds nothing to job_param.
    if not isinstance(tables, list) or len(tables) == 0:
        _log("HANDLE_DDB_CONFIG_PULL_NO_TABLES", {
            "reason": "tables missing, not a list, or empty",
        })
        return {}

    dynamodb = get_dynamodb_resource()
    results: dict = {}

    for table_name in tables:
        # Defensive: skip entries that aren't strings so one bad item
        # can't crash the whole pull.
        if not isinstance(table_name, str) or table_name == "":
            _log("HANDLE_DDB_CONFIG_PULL_SKIP_BAD_TABLE_NAME", {
                "table_value": repr(table_name),
            })
            continue

        table = dynamodb.Table(table_name)
        row = pull_config_from_table(
            table=table,
            table_name=table_name,
            job_id=job_id,
            job_type=job_type,
        )
        # Include the table name in the result either way — missing rows
        # come through as None so downstream sees every requested table.
        results[table_name] = row

    _log("HANDLE_DDB_CONFIG_PULL_COMPLETE", {
        "job_id": job_id,
        "job_type": job_type,
        "pulled_count": len(results),
        "result_keys": list(results.keys()),
    })
    return results


def handle_unknown_pre_step(step: Any) -> dict:
    """
    Called for each pre_step with a pre_step_type we don't recognize.
    Logs the unknown type for visibility; doesn't raise.

    TODO: decide whether to handle specific unknown types or treat as error.
    """
    if isinstance(step, dict):
        unknown_type = step.get("pre_step_type", "<missing>")
    else:
        unknown_type = "<not-a-dict>"

    _log("HANDLE_UNKNOWN_PRE_STEP", {
        "status": "stub_called",
        "pre_step_type": unknown_type,
    })
    return {}
