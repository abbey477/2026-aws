# trigger_ecs_job

Lambda function that triggers an ECS Fargate task via the `RunTask` API.

Called by the state machine when `job_config.job_runner.type` is `ECS_Fargate`.
Receives the merged payload from `GetConfig`, launches a Fargate task,
and returns the task ARN plus trigger status.

---

## Project layout

```
trigger_ecs_job/
├── Makefile
├── poetry.toml
├── pyproject.toml
├── src/
│   └── trigger_ecs_job/
│       ├── __init__.py
│       ├── handler.py          # lambda_handler() entry point
│       ├── ecs_trigger.py      # trigger_ecs_task() core RunTask logic
│       ├── logger.py           # shared structured logger
│       └── log_to_dynamo.py    # DynamoDB audit log writer
└── test/
    ├── __init__.py
    ├── conftest.py             # shared fixtures, ECS client mocks, event factory
    ├── test_happy_path.py      # TestHappyPath        — 5 tests
    ├── test_failure_modes.py   # TestFailureModes     — 5 tests
    ├── test_configuration.py   # TestConfiguration    — 5 tests
    ├── test_payload_size.py    # TestPayloadSizeLogging — 3 tests
    └── test_lambda_handler.py  # TestLambdaHandler    — 8 tests
```

---

## Setup

Requires Python 3.12+.

### First, check what's installed

```bash
make check
```

This prints what tooling the Makefile detected (`python3`, `pip`, `poetry`)
and exits cleanly if Python 3 is on your system. If `python3` is missing:

```bash
# Debian / Ubuntu
sudo apt update && sudo apt install -y python3 python3-pip python3-venv

# macOS
brew install python@3.12
```

### Option A — With Poetry (recommended)

If Poetry is already installed:

```bash
make install
```

If Poetry is **not** installed, the Makefile can install it for you:

```bash
make install-poetry
# Add Poetry to PATH (one-time):
export PATH="$HOME/.local/bin:$PATH"
# Make it permanent:
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc

make install    # now uses poetry
```

This creates a local `.venv/` (configured via `poetry.toml`) and installs
all runtime and dev dependencies.

### Option B — With pip only (no Poetry)

```bash
make install-pip
```

This creates a local virtual environment at `./.venv` and installs
`boto3`, `botocore`, and `pytest` into it. No system packages are
touched, so this works on modern Debian/Ubuntu (PEP 668) without any
workarounds. Requires `python3-venv` — install it with
`sudo apt install python3-venv` if `make install-pip` complains.

### Note on `make install`

`make install` automatically picks the right path:
- If Poetry is installed → runs `poetry install`
- If Poetry is not installed → falls back to `make install-pip`

So `make install` always does something sensible.

---

## Running tests

`make test` auto-detects whether Poetry is installed and picks the right
runner. With Poetry it runs `poetry run pytest`; without it, plain `pytest`.

### With Make

```bash
make test           # run the full suite
make lint           # run ruff
make clean          # remove .venv, __pycache__, .pytest_cache
make check          # show detected tooling
```

### Directly

```bash
# With Poetry
poetry run pytest
poetry run pytest test/test_happy_path.py
poetry run pytest -k "empty_event"

# Without Poetry (after `make install-pip`)
pytest
pytest test/test_happy_path.py
pytest -k "empty_event"
```

Pytest configuration lives in `pyproject.toml` under `[tool.pytest.ini_options]`.
The suite runs with live log streaming at INFO level so you can see the
structured log lines (`[TriggerEcsJob] [STEP] key=value, ...`) as tests execute.

---

## Invoking the Lambda

### Input event shape

The handler expects the merged payload produced by `GetConfig`:

```json
{
  "run_id": "run-001",
  "job_id": "client",
  "job_type": "sourcing",
  "status": "WAITING",
  "job_config": {
    "job_runner": {
      "type": "ECS_Fargate",
      "name": "S2S3",
      "config": {
        "cluster": "my-ecs-cluster",
        "subnets": ["subnet-aaa111", "subnet-bbb222"],
        "security_groups": ["sg-abc123"],
        "task_definition": "default-task-def",
        "container_name": "default-container",
        "image": "optional-image-tag"
      }
    },
    "job_param": {
      "source": {"type": "API", "name": "RDI"},
      "batch_size": 1000,
      "output": ["s3_path"]
    },
    "next_jobs": []
  }
}
```

### Output

The same event with a `trigger_result` block appended:

```json
{
  "...": "all original fields preserved",
  "trigger_result": {
    "trigger_status": "TRIGGERED",
    "task_arn": "arn:aws:ecs:us-east-1:123456789012:task/my-ecs-cluster/abc123",
    "runner_name": "S2S3",
    "runner_type": "ECS"
  }
}
```

On failure, `trigger_status` is `TRIGGER_FAILED`, `task_arn` is `""`, and
an `error` field describes what went wrong.

### Invoking locally (for debugging)

```bash
poetry run python -c "
from trigger_ecs_job.handler import lambda_handler
import json

event = json.load(open('event.json'))
result = lambda_handler(event, None)
print(json.dumps(result, indent=2))
"
```

This uses your real AWS credentials and hits DynamoDB + ECS. For dry runs,
prefer the test suite.

### Invoking the deployed Lambda

```bash
aws lambda invoke \
  --function-name trigger_ecs_job \
  --cli-binary-format raw-in-base64-out \
  --payload file://event.json \
  response.json

cat response.json | jq .trigger_result
```

### Invoking from Step Functions

The state machine passes the full merged payload as input. A typical task
state looks like:

```json
{
  "Type": "Task",
  "Resource": "arn:aws:lambda:us-east-1:123456789012:function:trigger_ecs_job",
  "Next": "CheckJobStatus",
  "ResultPath": "$"
}
```

`ResultPath: "$"` replaces the state input with the handler's return value,
so downstream states see the original fields plus `trigger_result`.

---

## Environment variables

| Variable     | Default | Purpose                                            |
|--------------|---------|----------------------------------------------------|
| `LOGS_TABLE` | `logs`  | DynamoDB table that `log_to_dynamo.write_log` writes to |

AWS credentials are resolved from the standard chain (IAM role in Lambda,
`~/.aws/credentials` or env vars locally).

---

## Payload size limit

ECS `RunTask` caps the `overrides` block at 8 KB. `job_param` is
JSON-encoded and passed as the `JOB_PARAM` env var inside that block,
so anything over ~8000 bytes of serialized JSON will fail with
`InvalidParameterException`.

Every invocation logs the payload size before calling `RunTask`:

```
[TriggerEcsJob] [JOB_PARAM_SIZE] run_id=run-001, job_param_bytes=85
```

Watch CloudWatch for this metric to catch payloads approaching the limit
before they start failing.

---

## Trigger statuses

| Status           | Meaning                                                       |
|------------------|---------------------------------------------------------------|
| `TRIGGERED`      | ECS accepted the task; `task_arn` is populated                |
| `TRIGGER_FAILED` | `RunTask` returned no tasks OR raised a `ClientError`         |
| `UNKNOWN`        | Only appears if the trigger function didn't return a status   |

Failures recorded as `TRIGGER_FAILED` include placement failures (no
capacity, bad subnets), `InvalidParameterException` (payload too large),
`ClusterNotFoundException`, `AccessDeniedException`, throttling, and any
other `ClientError` boto3 raises.
