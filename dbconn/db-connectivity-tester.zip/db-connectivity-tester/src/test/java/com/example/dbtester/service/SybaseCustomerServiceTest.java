package com.example.dbtester.service;

import com.example.dbtester.dto.CustomerRequest;
import com.example.dbtester.entity.Customer;
import com.example.dbtester.exception.ResourceNotFoundException;
import com.example.dbtester.repository.sybase.CustomerRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class SybaseCustomerServiceTest {

    @Mock CustomerRepository repository;
    @InjectMocks SybaseCustomerService service;

    private Customer existing;

    @BeforeEach
    void setUp() {
        existing = new Customer(10L, "Ada", "Lovelace", "ada@example.com",
                LocalDateTime.of(2025, 1, 1, 0, 0));
    }

    @Test
    void findAllDelegates() {
        when(repository.findAll()).thenReturn(List.of(existing));

        List<Customer> result = service.findAll();

        assertThat(result).containsExactly(existing);
    }

    @Test
    void findByIdReturnsCustomer() {
        when(repository.findById(10L)).thenReturn(Optional.of(existing));

        assertThat(service.findById(10L)).isEqualTo(existing);
    }

    @Test
    void findByIdThrowsWhenMissing() {
        when(repository.findById(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> service.findById(99L))
                .isInstanceOf(ResourceNotFoundException.class)
                .hasMessageContaining("99");
    }

    @Test
    void createPassesThroughToRepository() {
        Customer saved = new Customer(1L, "New", "Person", "n@p.com", LocalDateTime.now());
        when(repository.insert(any(Customer.class))).thenReturn(saved);

        Customer result = service.create(new CustomerRequest("New", "Person", "n@p.com"));

        assertThat(result).isEqualTo(saved);
    }

    @Test
    void updatePreservesIdAndCreatedAt() {
        when(repository.findById(10L)).thenReturn(Optional.of(existing));
        when(repository.update(eq(10L), any(Customer.class))).thenReturn(1);

        Customer result = service.update(10L, new CustomerRequest("Grace", "Hopper", "g@h.com"));

        assertThat(result.id()).isEqualTo(10L);
        assertThat(result.firstName()).isEqualTo("Grace");
        assertThat(result.createdAt()).isEqualTo(existing.createdAt());
    }

    @Test
    void updateThrowsWhenRowNotUpdated() {
        when(repository.findById(10L)).thenReturn(Optional.of(existing));
        when(repository.update(anyLong(), any(Customer.class))).thenReturn(0);

        assertThatThrownBy(() -> service.update(10L,
                new CustomerRequest("Grace", "Hopper", "g@h.com")))
                .isInstanceOf(ResourceNotFoundException.class);
    }

    @Test
    void deleteThrowsWhenMissing() {
        when(repository.delete(99L)).thenReturn(0);

        assertThatThrownBy(() -> service.delete(99L))
                .isInstanceOf(ResourceNotFoundException.class);
    }

    @Test
    void deleteSucceedsWhenRowAffected() {
        when(repository.delete(10L)).thenReturn(1);

        service.delete(10L);

        verify(repository).delete(10L);
    }
}
