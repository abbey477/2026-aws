# ScheduleNextJob Lambda

Called by the Step Functions state machine after `UpdateJobStatus` marks a job as `SUCCESS`.
Reads the `next_jobs` list from `job_config`, fetches each child's full configuration from DynamoDB, and inserts a new `job_run` record for each — ready to be picked up by the Scheduler.

---

## Project structure

```
schedule_next_job/
├── src/                        # Source code
│   ├── handler.py              # Lambda entry point
│   ├── scheduler.py            # schedule_next_jobs business logic
│   ├── dynamodb_ops.py         # DynamoDB read / write operations
│   ├── logger.py               # Structured INFO / ERROR logger
│   └── config.py               # Env vars and defaults
├── tests/                      # Unit tests (flat, no subfolders)
│   ├── conftest.py             # Shared fixtures and _make_event helper
│   ├── test_handler.py         # Lambda handler tests
│   ├── test_scheduler.py       # Scheduler logic tests
│   ├── test_dynamodb_ops.py    # DynamoDB ops tests
│   └── test_logger.py          # Logger tests
├── pytest.ini                  # Test runner config
└── requirements-dev.txt        # Dev / test dependencies
```

---

## How it works

1. Step Functions invokes `lambda_handler` with the full pipeline payload.
2. The handler reads `job_config.next_jobs` from the event.
3. For each child job, it fetches the child's full config from the `job_config` DynamoDB table.
4. A new `job_run` record is inserted with status `WAITING`, ready for the Scheduler to pick up.
5. The handler returns the original event with a `schedule_result` field added.

---

## Environment variables

| Variable | Default | Description |
|---|---|---|
| `JOB_RUN_TABLE` | `job_run` | DynamoDB table name for job run records |
| `JOB_CONFIG_TABLE` | `job_config` | DynamoDB table name for job config records |

---

## Running the tests

### 1. Install dependencies

```bash
pip install -r requirements-dev.txt
```

### 2. Run all tests

```bash
pytest
```

### 3. Expected output

```
29 passed in ~17s
```

### What the tests cover

| Test file | What it tests |
|---|---|
| `test_handler.py` | Happy path, skip (no next_jobs), multiple jobs, missing config, failure logging |
| `test_scheduler.py` | Job run creation, empty list, defaults, unique run IDs |
| `test_dynamodb_ops.py` | get_item found/not found, put_item, ISO time helpers |
| `test_logger.py` | INFO/ERROR levels, message format, traceback capture |

Tests use **moto** to spin up a real (mocked) DynamoDB locally — no AWS credentials needed.

---

## Source file reference

### `handler.py`
Lambda entry point. Reads the event, calls `schedule_next_jobs`, writes `schedule_result` back onto the event. DynamoDB resource and tables are initialised at module scope for warm-invocation reuse.

### `scheduler.py`
Contains `schedule_next_jobs()` — loops over `next_jobs`, fetches child config, builds and inserts each `job_run` record. Per-child failures are caught and logged without blocking the rest of the batch.

### `dynamodb_ops.py`
All boto3 calls live here: `get_next_job_config()`, `put_job_run()`, and the time helpers `get_current_time_iso()` / `get_next_minute_iso()`. Each operation wraps its call in try/except and logs a structured ERROR with the AWS error code before re-raising.

### `logger.py`
`log_info(step, details)` and `log_error(step, details, exc_info)`. Every log line follows the format:
```
[ScheduleNextJob] [STEP_NAME] key1=val1, key2=val2
```

### `config.py`
Single source of truth for environment variables and default values.
