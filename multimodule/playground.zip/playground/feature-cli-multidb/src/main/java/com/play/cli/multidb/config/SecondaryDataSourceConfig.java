package com.play.cli.multidb.config;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.sql.DataSource;

/**
 * Beans for the "secondary" datasource. Not {@link org.springframework.context.annotation.Primary}
 * — consumers must ask for it by qualifier ({@code secondaryJdbcTemplate}).
 */
@Configuration
public class SecondaryDataSourceConfig {

    private static final String KEY = "secondary";

    private final DataSourceProperties.DbConfig cfg;

    public SecondaryDataSourceConfig(DataSourceProperties props) {
        this.cfg = props.datasources().get(KEY);
    }

    @Bean(name = "secondaryDataSource", destroyMethod = "close")
    public DataSource secondaryDataSource() {
        return DataSourceFactory.build(KEY, cfg);
    }

    @Bean(name = "secondaryJdbcTemplate")
    public JdbcTemplate secondaryJdbcTemplate(
            @Qualifier("secondaryDataSource") DataSource secondaryDataSource) {
        return new JdbcTemplate(secondaryDataSource);
    }
}
