package com.example.myapp.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "app")
public record AppProperties(
        String name,
        String environment,
        Database db
) {
    public record Database(
            String url,
            String username,
            int poolSize
    ) {}
}
