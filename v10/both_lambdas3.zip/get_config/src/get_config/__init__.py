"""GetConfig Lambda package."""
