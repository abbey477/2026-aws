package com.example.dbtester.config;

import com.zaxxer.hikari.HikariDataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;
import java.util.Map;

@Configuration
public class OracleDataSourceConfig {

    private static final String DS_KEY = "oracle";

    private final DataSourceProperties.DbConfig config;

    public OracleDataSourceConfig(DataSourceProperties properties) {
        this.config = properties.datasources().get(DS_KEY);
        if (this.config == null) {
            throw new IllegalStateException("Missing configuration for datasource: " + DS_KEY);
        }
    }

    @Primary
    @Bean(name = "oracleDataSource", destroyMethod = "close")
    public DataSource oracleDataSource() {
        return HikariDataSourceFactory.build(DS_KEY, config);
    }

    @Primary
    @Bean(name = "oracleJdbcTemplate")
    public JdbcTemplate oracleJdbcTemplate(DataSource oracleDataSource) {
        return new JdbcTemplate(oracleDataSource);
    }

    @Primary
    @Bean(name = "oracleTxManager")
    public PlatformTransactionManager oracleTxManager(DataSource oracleDataSource) {
        return new DataSourceTransactionManager(oracleDataSource);
    }
}
