package com.example.batch.core;

/**
 * Runtime parameters passed to a job when it runs.
 *
 * <p>Carries the job name and the business date the run is for.
 * Extend with additional fields as needed (e.g., region, dryRun flag).
 */
public class JobContext {

    private final String jobName;
    private final String runDate;

    public JobContext(String jobName, String runDate) {
        this.jobName = jobName;
        this.runDate = runDate;
    }

    public String getJobName() {
        return jobName;
    }

    public String getRunDate() {
        return runDate;
    }

    @Override
    public String toString() {
        return "JobContext{jobName='" + jobName + "', runDate='" + runDate + "'}";
    }
}
