package com.example.dbtester.controller;

import com.example.dbtester.dto.ConnectionStatus;
import com.example.dbtester.service.DatabaseHealthService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Exposes the database connectivity check as HTTP endpoints.
 *
 * <p>Kept intentionally thin — all logic lives in {@link DatabaseHealthService}.
 * Always returns 200; the "is the DB up?" answer is inside the body, not
 * the HTTP status, so callers can poll without seeing 5xx spikes.
 */
@RestController
@RequestMapping("/api/db/health")
public class HealthController {

    private final DatabaseHealthService healthService;

    public HealthController(DatabaseHealthService healthService) {
        this.healthService = healthService;
    }

    /** GET /api/db/health/all — ping every registered datasource. */
    @GetMapping("/all")
    public List<ConnectionStatus> all() {
        return healthService.checkAll();
    }

    /** GET /api/db/health/{name} — ping a specific one ("oracle" or "sybase"). */
    @GetMapping("/{name}")
    public ConnectionStatus one(@PathVariable String name) {
        return healthService.check(name);
    }
}
