import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Row mappers for {@link ListedInstrument}, extracted from the migration class
 * for readability — ListedInstrument has 60 columns and inlining two copies of
 * the mapping logic would dominate the migration file.
 *
 * <p>Two static methods are provided so the migration class can A/B them
 * on identical data:
 * <ul>
 *   <li>{@link #mapByIndex(ResultSet)} — positional reads, fastest, fragile
 *       to SELECT column reordering.</li>
 *   <li>{@link #mapByName(ResultSet)} — name-based reads, robust to column
 *       reordering, slight per-cell overhead.</li>
 * </ul>
 *
 * <p>Type-handling notes (consistent across all migrations):
 * <ul>
 *   <li>{@code Integer}/{@code Float} fields use the cast pattern
 *       {@code (T) rs.getObject(...)} because jconn4 doesn't support the
 *       two-arg {@code getObject(idx, Class)} overload. Casting null is safe.</li>
 *   <li>{@code Date} fields use {@code rs.getTimestamp(...)} assuming
 *       {@code java.util.Date}. If any field is {@code java.sql.Date},
 *       swap that specific call to {@code rs.getDate}.</li>
 * </ul>
 */
public final class ListedInstrumentRowMapper {

    private ListedInstrumentRowMapper() {
        // utility class
    }

    /** Positional read — column index MUST match SELECT order. */
    public static ListedInstrument mapByIndex(ResultSet rs) throws SQLException {
        ListedInstrument row = new ListedInstrument();
        row.setID_IMNT(              (Integer) rs.getObject(1));
        row.setID_CLASS_EQ(                    rs.getString(2));
        row.setAM_ISSUE_MIN(           (Float) rs.getObject(3));
        row.setDT_IPO_OPN(                     rs.getTimestamp(4));
        row.setDT_IPO_CLSE(                    rs.getTimestamp(5));
        row.setDT_EXPY_LGL(                    rs.getTimestamp(6));
        row.setAM_BID_OFFER_SPRD(      (Float) rs.getObject(7));
        row.setAM_ISSUE(               (Float) rs.getObject(8));
        row.setPR_ISSUE(               (Float) rs.getObject(9));
        row.setAM_IMNT_OUTST(          (Float) rs.getObject(10));
        row.setNM_UNDERWRT(                    rs.getString(11));
        row.setID_REG_BEAR(                    rs.getString(12));
        row.setID_VALID(                       rs.getString(13));
        row.setID_TYP_CLR(           (Integer) rs.getObject(14));
        row.setID_TYP_PR_ISSUE(                rs.getString(15));
        row.setID_TYP_DT_ISSUE(                rs.getString(16));
        row.setID_STG_IMNT(                    rs.getString(17));
        row.setID_BOND_GLOBAL(                 rs.getString(18));
        row.setID_BOND_EURO(                   rs.getString(19));
        row.setID_SEAQ(                        rs.getString(20));
        row.setID_CUPID(                       rs.getString(21));
        row.setID_PROSPECTUS(                  rs.getString(22));
        row.setDT_PROSP_START(                 rs.getTimestamp(23));
        row.setID_PASSPORT(                    rs.getString(24));
        row.setID_PROGRAM(           (Integer) rs.getObject(25));
        row.setDT_ALLOT(                       rs.getTimestamp(26));
        row.setDT_CMDT(                        rs.getTimestamp(27));
        row.setID_SECAM_GOV_TYP(               rs.getString(28));
        row.setID_SECAM_CATCODE(               rs.getString(29));
        row.setID_NCSC(                        rs.getString(30));
        row.setID_CAPITAL_PROTECTED(           rs.getString(31));
        row.setID_CW_REGION(         (Integer) rs.getObject(32));
        row.setID_TERM_PROV(                   rs.getString(33));
        row.setID_PUR_CON_PLEDGE(              rs.getString(34));
        row.setID_TYP_OFF_PAY(                 rs.getString(35));
        row.setID_FUNGIBLE_TRANCHE(            rs.getString(36));
        row.setDT_CREATE(                      rs.getTimestamp(37));
        row.setID_USER_CREATE(                 rs.getString(38));
        row.setDT_CHG_LAST(                    rs.getTimestamp(39));
        row.setID_USER_CHG_LAST(               rs.getString(40));
        row.setDT_NOTICE_FST(                  rs.getTimestamp(41));
        row.setDT_DELIVERY_FST(                rs.getTimestamp(42));
        row.setDT_DELIVERY_LST(                rs.getTimestamp(43));
        row.setID_CLIENT_ROLE(       (Integer) rs.getObject(44));
        row.setAM_DENOMINATION(        (Float) rs.getObject(45));
        row.setID_SUPERSIZED(                  rs.getString(46));
        row.setAM_STRESSED_LTV(        (Float) rs.getObject(47));
        row.setID_SHORT_SELL(                  rs.getString(48));
        row.setID_CNS(                         rs.getString(49));
        row.setAM_CPN_DENOM(           (Float) rs.getObject(50));
        row.setID_ROUNDING(                    rs.getString(51));
        row.setID_TYP_PLCMT(                   rs.getString(52));
        row.setID_REG_SEC(                     rs.getString(53));
        row.setDT_SUB_OPN(                     rs.getTimestamp(54));
        row.setDT_SUB_CLSE(                    rs.getTimestamp(55));
        row.setID_BO_TYPE(           (Integer) rs.getObject(56));
        row.setID_BO_FREQ(           (Integer) rs.getObject(57));
        row.setDT_CHG_GRD(                     rs.getTimestamp(58));
        row.setID_DEL_GRD(                     rs.getString(59));
        row.setID_OWN_GRD(           (Integer) rs.getObject(60));
        return row;
    }

    /** Name-based read — robust to SELECT column reordering. */
    public static ListedInstrument mapByName(ResultSet rs) throws SQLException {
        ListedInstrument row = new ListedInstrument();
        row.setID_IMNT(              (Integer) rs.getObject("ID_IMNT"));
        row.setID_CLASS_EQ(                    rs.getString("ID_CLASS_EQ"));
        row.setAM_ISSUE_MIN(           (Float) rs.getObject("AM_ISSUE_MIN"));
        row.setDT_IPO_OPN(                     rs.getTimestamp("DT_IPO_OPN"));
        row.setDT_IPO_CLSE(                    rs.getTimestamp("DT_IPO_CLSE"));
        row.setDT_EXPY_LGL(                    rs.getTimestamp("DT_EXPY_LGL"));
        row.setAM_BID_OFFER_SPRD(      (Float) rs.getObject("AM_BID_OFFER_SPRD"));
        row.setAM_ISSUE(               (Float) rs.getObject("AM_ISSUE"));
        row.setPR_ISSUE(               (Float) rs.getObject("PR_ISSUE"));
        row.setAM_IMNT_OUTST(          (Float) rs.getObject("AM_IMNT_OUTST"));
        row.setNM_UNDERWRT(                    rs.getString("NM_UNDERWRT"));
        row.setID_REG_BEAR(                    rs.getString("ID_REG_BEAR"));
        row.setID_VALID(                       rs.getString("ID_VALID"));
        row.setID_TYP_CLR(           (Integer) rs.getObject("ID_TYP_CLR"));
        row.setID_TYP_PR_ISSUE(                rs.getString("ID_TYP_PR_ISSUE"));
        row.setID_TYP_DT_ISSUE(                rs.getString("ID_TYP_DT_ISSUE"));
        row.setID_STG_IMNT(                    rs.getString("ID_STG_IMNT"));
        row.setID_BOND_GLOBAL(                 rs.getString("ID_BOND_GLOBAL"));
        row.setID_BOND_EURO(                   rs.getString("ID_BOND_EURO"));
        row.setID_SEAQ(                        rs.getString("ID_SEAQ"));
        row.setID_CUPID(                       rs.getString("ID_CUPID"));
        row.setID_PROSPECTUS(                  rs.getString("ID_PROSPECTUS"));
        row.setDT_PROSP_START(                 rs.getTimestamp("DT_PROSP_START"));
        row.setID_PASSPORT(                    rs.getString("ID_PASSPORT"));
        row.setID_PROGRAM(           (Integer) rs.getObject("ID_PROGRAM"));
        row.setDT_ALLOT(                       rs.getTimestamp("DT_ALLOT"));
        row.setDT_CMDT(                        rs.getTimestamp("DT_CMDT"));
        row.setID_SECAM_GOV_TYP(               rs.getString("ID_SECAM_GOV_TYP"));
        row.setID_SECAM_CATCODE(               rs.getString("ID_SECAM_CATCODE"));
        row.setID_NCSC(                        rs.getString("ID_NCSC"));
        row.setID_CAPITAL_PROTECTED(           rs.getString("ID_CAPITAL_PROTECTED"));
        row.setID_CW_REGION(         (Integer) rs.getObject("ID_CW_REGION"));
        row.setID_TERM_PROV(                   rs.getString("ID_TERM_PROV"));
        row.setID_PUR_CON_PLEDGE(              rs.getString("ID_PUR_CON_PLEDGE"));
        row.setID_TYP_OFF_PAY(                 rs.getString("ID_TYP_OFF_PAY"));
        row.setID_FUNGIBLE_TRANCHE(            rs.getString("ID_FUNGIBLE_TRANCHE"));
        row.setDT_CREATE(                      rs.getTimestamp("DT_CREATE"));
        row.setID_USER_CREATE(                 rs.getString("ID_USER_CREATE"));
        row.setDT_CHG_LAST(                    rs.getTimestamp("DT_CHG_LAST"));
        row.setID_USER_CHG_LAST(               rs.getString("ID_USER_CHG_LAST"));
        row.setDT_NOTICE_FST(                  rs.getTimestamp("DT_NOTICE_FST"));
        row.setDT_DELIVERY_FST(                rs.getTimestamp("DT_DELIVERY_FST"));
        row.setDT_DELIVERY_LST(                rs.getTimestamp("DT_DELIVERY_LST"));
        row.setID_CLIENT_ROLE(       (Integer) rs.getObject("ID_CLIENT_ROLE"));
        row.setAM_DENOMINATION(        (Float) rs.getObject("AM_DENOMINATION"));
        row.setID_SUPERSIZED(                  rs.getString("ID_SUPERSIZED"));
        row.setAM_STRESSED_LTV(        (Float) rs.getObject("AM_STRESSED_LTV"));
        row.setID_SHORT_SELL(                  rs.getString("ID_SHORT_SELL"));
        row.setID_CNS(                         rs.getString("ID_CNS"));
        row.setAM_CPN_DENOM(           (Float) rs.getObject("AM_CPN_DENOM"));
        row.setID_ROUNDING(                    rs.getString("ID_ROUNDING"));
        row.setID_TYP_PLCMT(                   rs.getString("ID_TYP_PLCMT"));
        row.setID_REG_SEC(                     rs.getString("ID_REG_SEC"));
        row.setDT_SUB_OPN(                     rs.getTimestamp("DT_SUB_OPN"));
        row.setDT_SUB_CLSE(                    rs.getTimestamp("DT_SUB_CLSE"));
        row.setID_BO_TYPE(           (Integer) rs.getObject("ID_BO_TYPE"));
        row.setID_BO_FREQ(           (Integer) rs.getObject("ID_BO_FREQ"));
        row.setDT_CHG_GRD(                     rs.getTimestamp("DT_CHG_GRD"));
        row.setID_DEL_GRD(                     rs.getString("ID_DEL_GRD"));
        row.setID_OWN_GRD(           (Integer) rs.getObject("ID_OWN_GRD"));
        return row;
    }
}
