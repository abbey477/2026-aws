"""
test_trigger_failed.py
Tests for the TRIGGER_FAILED status path of the UpdateJobStatus Lambda.
"""

import pytest
from conftest import make_event
from lambdas.update_job_status.handler import lambda_handler


class TestUpdateTriggerFailed:
    """Tests for TRIGGER_FAILED outcome."""

    def test_trigger_failed_sets_waiting(self, dynamodb_setup, monkeypatch):
        """TRIGGER_FAILED marks job_run back to WAITING with next run time."""
        dynamodb, table = dynamodb_setup
        monkeypatch.setattr(
            "lambdas.update_job_status.handler.get_dynamodb_resource",
            lambda: dynamodb,
        )

        event = make_event(trigger_status="TRIGGER_FAILED", job_status="")
        result = lambda_handler(event, None)

        assert result["update_result"]["effective_status"] == "TRIGGER_FAILED"

        item = table.get_item(Key={"run_id": "run-001"})["Item"]
        assert item["status"] == "WAITING"
        assert item["next_scheduled_run_time"] != ""

    def test_trigger_failed_next_run_is_iso_format(self, dynamodb_setup, monkeypatch):
        """next_scheduled_run_time set by TRIGGER_FAILED is valid ISO 8601."""
        from datetime import datetime

        dynamodb, table = dynamodb_setup
        monkeypatch.setattr(
            "lambdas.update_job_status.handler.get_dynamodb_resource",
            lambda: dynamodb,
        )

        event = make_event(trigger_status="TRIGGER_FAILED", job_status="")
        lambda_handler(event, None)

        item = table.get_item(Key={"run_id": "run-001"})["Item"]
        # Should not raise
        datetime.strptime(item["next_scheduled_run_time"], "%Y-%m-%dT%H:%M:%SZ")

    def test_trigger_failed_takes_priority_over_job_status(
        self, dynamodb_setup, monkeypatch
    ):
        """TRIGGER_FAILED overrides any job_status value present."""
        dynamodb, table = dynamodb_setup
        monkeypatch.setattr(
            "lambdas.update_job_status.handler.get_dynamodb_resource",
            lambda: dynamodb,
        )

        # Even with job_status=SUCCESS, TRIGGER_FAILED should win
        event = make_event(trigger_status="TRIGGER_FAILED", job_status="SUCCESS")
        result = lambda_handler(event, None)

        assert result["update_result"]["effective_status"] == "TRIGGER_FAILED"
        item = table.get_item(Key={"run_id": "run-001"})["Item"]
        assert item["status"] == "WAITING"
