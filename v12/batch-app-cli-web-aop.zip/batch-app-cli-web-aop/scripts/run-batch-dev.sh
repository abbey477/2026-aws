#!/bin/bash
# ============================================================
# run-batch-dev.sh — entry point for Autosys (dev environment)
# Usage: run-batch-dev.sh <jobName>
# ============================================================

# Env-specific settings
export ENV="dev"
export APP_HOME="/opt/jobs/dev"
export JAR_NAME="batch-app.jar"             # symlink to current version
export LOG_DIR="/var/log/batch/dev"
export JAVA_OPTS="-Xms256m -Xmx1g -XX:+HeapDumpOnOutOfMemoryError"
export SPRING_PROFILE="dev"

# Source shared logic and run the job
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
source "${SCRIPT_DIR}/common.sh"

run_batch_job "$@"
