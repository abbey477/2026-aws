"""Routing: unknown pre_step_type handling."""
from pre_steps_processor.handler import lambda_handler
from seed_data import make_event


class TestRoutingUnknown:

    def test_unknown_type(self, mocks):
        step = {"pre_step_type": "something_new"}
        lambda_handler(make_event(pre_steps=[step]), None)
        mocks["unknown"].assert_called_once_with(step)

    def test_mixed_known_and_unknown(self, mocks):
        steps = [
            {"pre_step_type": "change_since_append"},
            {"pre_step_type": "mystery_type"},
            {"pre_step_type": "ddb_config_pull", "tables": []},
        ]
        event = make_event(pre_steps=steps)
        lambda_handler(event, None)
        mocks["change_since"].assert_called_once_with(steps[0], event)
        mocks["unknown"].assert_called_once_with(steps[1])
        mocks["ddb_pull"].assert_called_once_with(steps[2], event)

    def test_mixed_valid_and_invalid(self, mocks):
        steps = [
            {"pre_step_type": "change_since_append"}, {},
            {"pre_step_type": ""}, "not-a-dict",
            {"pre_step_type": "ddb_config_pull"},
        ]
        event = make_event(pre_steps=steps)
        lambda_handler(event, None)
        mocks["change_since"].assert_called_once_with(steps[0], event)
        mocks["ddb_pull"].assert_called_once_with(steps[4], event)
