package com.acme.dates;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class DateUtilsTest {

    @Mock
    Clock clock;

    @Test
    void saturdayIsWeekend() {
        when(clock.instant()).thenReturn(Instant.parse("2026-11-14T12:00:00Z")); // Saturday
        when(clock.getZone()).thenReturn(ZoneOffset.UTC);
        assertTrue(new DateUtils(clock).isWeekendToday());
    }

    @Test
    void mondayIsNotWeekend() {
        when(clock.instant()).thenReturn(Instant.parse("2026-11-16T12:00:00Z")); // Monday
        when(clock.getZone()).thenReturn(ZoneOffset.UTC);
        assertFalse(new DateUtils(clock).isWeekendToday());
    }
}
