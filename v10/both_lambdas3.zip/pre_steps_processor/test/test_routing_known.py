"""Routing: known pre_step_types route to correct handlers."""
from pre_steps_processor.handler import lambda_handler
from seed_data import make_event


class TestRoutingKnown:

    def test_change_since_append(self, mocks):
        step = {"pre_step_type": "change_since_append"}
        event = make_event(pre_steps=[step])
        lambda_handler(event, None)
        mocks["change_since"].assert_called_once_with(step, event)
        mocks["ddb_pull"].assert_not_called()

    def test_ddb_config_pull(self, mocks):
        step = {"pre_step_type": "ddb_config_pull", "tables": ["service_config"]}
        event = make_event(pre_steps=[step])
        lambda_handler(event, None)
        mocks["ddb_pull"].assert_called_once_with(step, event)
        mocks["change_since"].assert_not_called()

    def test_both_in_sequence(self, mocks):
        steps = [
            {"pre_step_type": "change_since_append"},
            {"pre_step_type": "ddb_config_pull", "tables": ["a"]},
        ]
        event = make_event(pre_steps=steps)
        lambda_handler(event, None)
        mocks["change_since"].assert_called_once_with(steps[0], event)
        mocks["ddb_pull"].assert_called_once_with(steps[1], event)

    def test_same_type_multiple_times(self, mocks):
        steps = [{"pre_step_type": "change_since_append"}] * 2
        lambda_handler(make_event(pre_steps=steps), None)
        assert mocks["change_since"].call_count == 2
