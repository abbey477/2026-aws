package com.example.batch.core;

import com.example.batch.common.exception.BusinessException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Routes the {@code --job=<name>} CLI argument to the matching BatchJob bean.
 *
 * <p><b>CLI-side exception handling lives here.</b> This is the CLI equivalent of
 * {@code @RestControllerAdvice} — it catches exceptions from {@link BatchJob#execute}
 * and translates them into exit codes the CLI main can pass to {@code System.exit()}.
 *
 * <p>Note: by the time exceptions get HERE, the ServiceErrorAspect has already
 * fired (logged, audited, etc.). The dispatcher's job is purely TRANSPORT SHAPING —
 * mapping the exception type to an exit code Autosys can interpret.
 */
@Component
public class JobDispatcher {

    private static final Logger log = LoggerFactory.getLogger(JobDispatcher.class);

    private final Map<String, BatchJob> jobsByName;

    public JobDispatcher(List<BatchJob> allJobs) {
        this.jobsByName = allJobs.stream()
                .collect(Collectors.toMap(BatchJob::getName, Function.identity()));
        log.info("Registered {} job(s): {}", jobsByName.size(), jobsByName.keySet());
    }

    public JobResult dispatch(JobContext context) {
        BatchJob job = jobsByName.get(context.getJobName());
        if (job == null) {
            return JobResult.failure(
                    "Unknown job '" + context.getJobName() + "'. Available: " + jobsByName.keySet(),
                    2);   // bad-arg style exit code
        }

        try {
            return job.execute(context);

        } catch (BusinessException ex) {
            // Known business failure — translate to its specific exit code.
            // The aspect already logged/audited; we just shape the response.
            log.warn("Job '{}' failed with business error (exitCode={}): {}",
                    context.getJobName(), ex.getExitCode(), ex.getMessage());
            return JobResult.failure(ex.getMessage(), ex.getExitCode());

        } catch (Exception ex) {
            // Unexpected — generic failure exit code.
            log.error("Job '{}' failed unexpectedly", context.getJobName(), ex);
            return JobResult.failure(ex.getMessage(), 1);
        }
    }
}
