# Sybase → Oracle Streaming Migration

Streaming migration code for 8 tables, replacing the previous
"load entire ResultSet into a List" pattern with a streaming read +
buffered batch write. Memory is bounded at ~5000 rows per table
instead of holding 1M+ rows in memory.

## Structure

Every table follows the same three-file pattern:

```
<Entity>Migration.java       — orchestration: SELECT, stream, buffer, flush
<Entity>RowMapper.java       — by-index and by-name row mappers
<Entity>OracleRepository.java — Oracle write side (truncate, batchInsert, count)
```

The 8 entities:

| Sybase table         | Entity                          | Field count |
|----------------------|---------------------------------|-------------|
| EXCH_INST_ALT_ID     | ExchangeInstrumentAlternateId   | 9           |
| GRD_INSTRUMENT_EVENT | GRDInstrumentEvent              | 2           |
| CODE_VALUE           | CodeValue                       | 9           |
| INSTRUMENT           | Instrument                      | 103         |
| INSTRUMENT_LINK      | InstrumentLink                  | 9           |
| IR_INSTRUMENT        | IRInstrument                    | 47          |
| IR_INSTRUMENT_FLAG   | IRInstrumentFlag                | 39          |
| LISTED_INSTRUMENT    | ListedInstrument                | 60          |

This zip includes all 8 migration classes and all 8 row mappers (16 files),
plus one Oracle repository as a reference (ExchangeInstrumentAlternateIdOracleRepository.java).
The other seven repositories follow the same template — adjust table name,
column list, and the typed `List<T>` parameter on `batchInsert`.

## What this changes vs. the previous code

OLD:
```
List<T> rows = sybaseJdbcTemplate.query(sql, new BeanPropertyRowMapper<>(T.class));
oracleJdbcTemplate.batchUpdate(insertSql, rows, 5000, columnMapper::setParameters);
```

NEW (per-table migration class):
```
sybaseJdbcTemplate.query(sql, (RowCallbackHandler) rs -> {
    buffer.add(<Entity>RowMapper.mapByIndex(rs));
    if (buffer.size() >= 5000) flush(buffer);
});
flush(remainder);
```

Net effect: bounded memory, reader/writer overlap (Sybase prefetches the
next chunk while Oracle inserts the current one — no threading needed
because the two pools are independent), and removal of the per-row
reflection cost from `BeanPropertyRowMapper`.

## Two variants per table

Each migration class has both:

- `migrateByIndex()` — reads `ResultSet` columns positionally
  (`rs.getString(2)`). Faster, but the SELECT column order must match
  the mapper.
- `migrateByName()` — reads by name (`rs.getString("ID_TYP_ALT_IMNT")`).
  More readable, robust to SELECT reordering, slight per-cell overhead.

Run both on representative data, take the median of 2-3 runs after JVM
warmup, and pick whichever the team prefers.

## Configuration knobs

In each migration class:

```
private static final int FETCH_SIZE = 2000;   // jconn4 rows per network round-trip
private static final int BATCH_SIZE = 5000;   // rows per Oracle batch flush
```

Start here. If after measuring you want to tune, FETCH_SIZE 1000-10000
is the typical range; larger isn't always better.

## What NOT to change

- Do **not** wrap migration calls in `@Transactional`. Each `batchUpdate`
  commits on its own (Hikari autoCommit defaults to true), which keeps
  Oracle UNDO bounded per batch instead of holding 1M+ inserts in one
  transaction.
- Do **not** modify the existing `ColumnMapper<T>` class as part of this
  refactor. It uses reflection (slower than ideal), but it works and is
  shared across all 8 tables. Replacing it is a separate optimization
  to do *after* measuring the streaming refactor in isolation.

## Logging

Each migration emits:

- INFO at start: variant, fetchSize, batchSize.
- DEBUG per batch: batch number, rows, elapsed ms, rolling total.
- INFO at end: total rows, batch count, elapsed ms, rows/sec throughput.

Monitor the throughput line in production logs to detect regressions
over time.

## Type-handling notes

- `Integer` and `Float` fields use `(T) rs.getObject(idx)` because jconn4
  doesn't support the JDBC 4.1 two-arg `getObject(idx, Class)` overload.
  Casting null is safe.
- `Date` fields use `rs.getTimestamp(...)` assuming `java.util.Date` on
  the model side. If any specific field is `java.sql.Date`, swap that
  call to `rs.getDate(...)`.
- `Float` is used in some financial fields (rates, amounts). This is
  preserved from the existing model. `BigDecimal` would be more correct
  but changing field types is out of scope for this perf refactor.

## Testing recommendation

Don't wire all 8 tables at once. Run one table (recommend INSTRUMENT
since it's the largest), measure the wall-clock improvement vs. the old
implementation, and only roll out the rest once you confirm the gains
hold on real data.
