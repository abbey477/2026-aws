"""
PreStepsProcessor Lambda Handler — v4

Sits between GetConfig and RunnerTypeChoice in the Step Function.
Inspects the `pre_steps` array from the GetConfig output, routes each
step to the appropriate handler, and collects any results each handler
produces into a top-level `pre_steps_results` dict on the output.

Input:  Full GetConfig output payload — see lambdas/get_config/handler.py.
        Relevant path: event["job_config"]["pre_steps"]

Output: Input event spread at top level, plus a `pre_steps_results` dict
        keyed by pre_step_type containing each handler's return value.

Routing:
  - No pre_steps data            → handle_no_pre_steps()
  - change_since_append          → handle_change_since_append(step, event)
  - ddb_config_pull              → handle_ddb_config_pull(step)
  - any other pre_step_type      → handle_unknown_pre_step(step)

v4 change:
  - change_since_append now performs a real DynamoDB query against
    GSI-2 (jobIdQuery) to find the last successful run's start_time.
  - Output shape: spread event + `pre_steps_results` placeholder dict.
"""

from typing import Any

from .logging_utils import _log
from .step_handlers import (
    handle_change_since_append,
    handle_ddb_config_pull,
    handle_no_pre_steps,
    handle_unknown_pre_step,
)


def _has_valid_pre_step_type(step: Any) -> bool:
    """
    True if `step` is a dict with a non-empty string `pre_step_type`.
    Anything else (non-dict, missing key, None, empty string, non-string)
    is considered invalid.
    """
    if not isinstance(step, dict):
        return False
    value = step.get("pre_step_type")
    return isinstance(value, str) and value != ""


def _extract_pre_steps(event: dict) -> list:
    """
    Pull pre_steps out of the event. Returns [] if missing, None, or not a list.
    Downstream logic decides what to do with an empty/invalid result.
    """
    job_config = event.get("job_config") or {}
    pre_steps = job_config.get("pre_steps")
    if not isinstance(pre_steps, list):
        return []
    return pre_steps


def _process_step(step: dict, event: dict) -> dict:
    """
    Route a single step to its handler based on pre_step_type.

    Returns the handler's result dict — caller decides where this goes
    in the final output (most go under pre_steps_results, ddb_config_pull
    goes into job_param). Empty dict means "nothing to add".
    """
    pre_step_type = step["pre_step_type"]  # safe: caller validated

    if pre_step_type == "change_since_append":
        _log("PROCESSING_STEP", {
            "pre_step_type": pre_step_type,
            "action": "route_to_known_handler",
        })
        return handle_change_since_append(step, event)

    if pre_step_type == "ddb_config_pull":
        _log("PROCESSING_STEP", {
            "pre_step_type": pre_step_type,
            "action": "route_to_known_handler",
        })
        return handle_ddb_config_pull(step, event)

    _log("PROCESSING_STEP", {
        "pre_step_type": pre_step_type,
        "action": "route_to_unknown",
    })
    return handle_unknown_pre_step(step)


def lambda_handler(event: dict, context: Any) -> dict:
    """
    Lambda entry point.

    Reads pre_steps from event["job_config"]["pre_steps"] and dispatches each
    step to the appropriate handler.

    Output routing:
      - ddb_config_pull results  → merged into event["job_config"]["job_param"]
                                    (directly, keyed by table name)
      - all other handler results → collected under output["pre_steps_results"]
                                    (keyed by pre_step_type)

    Returns a new dict (doesn't mutate the input event).
    """
    run_id = event.get("run_id", "<missing>")
    _log("HANDLER_START", {"run_id": run_id})

    pre_steps = _extract_pre_steps(event)
    valid_steps = [s for s in pre_steps if _has_valid_pre_step_type(s)]

    _log("VALIDATION", {
        "raw_count": len(pre_steps),
        "valid_count": len(valid_steps),
    })

    # Collected results to merge into the output in two different places.
    pre_steps_results: dict = {}
    ddb_pull_results: dict = {}

    if not valid_steps:
        _log("NO_DATA", {"reason": "no valid pre_steps to process"})
        handle_no_pre_steps()
    else:
        for step in valid_steps:
            result = _process_step(step, event)
            if not result:
                continue

            step_type = step["pre_step_type"]
            if step_type == "ddb_config_pull":
                # Merge pulled tables into job_param (Style A, as confirmed).
                # If multiple ddb_config_pull steps exist, later keys win.
                ddb_pull_results.update(result)
            else:
                pre_steps_results[step_type] = result

    # Build the output — deep-copy-ish approach: we rebuild job_config &
    # job_param so we never mutate the caller's event dict in place.
    job_config = dict(event.get("job_config") or {})
    job_param = dict(job_config.get("job_param") or {})
    if ddb_pull_results:
        job_param.update(ddb_pull_results)
    job_config["job_param"] = job_param

    output = {
        **event,
        "job_config": job_config,
        "pre_steps_results": pre_steps_results,
    }

    _log("HANDLER_COMPLETE", {
        "run_id": run_id,
        "processed_count": len(valid_steps),
        "pre_steps_results_keys": list(pre_steps_results.keys()),
        "ddb_pull_result_keys": list(ddb_pull_results.keys()),
    })

    return output
