package com.example.dbtester.entity;

import java.time.LocalDateTime;

/** Maps to Sybase CUSTOMER. id is null for un-persisted instances. */
public record Customer(
        Long id,
        String firstName,
        String lastName,
        String email,
        LocalDateTime createdAt
) {}
