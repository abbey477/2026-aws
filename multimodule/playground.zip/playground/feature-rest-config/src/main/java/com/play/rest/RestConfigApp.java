package com.play.rest;

import com.play.common.FeatureBanner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

/**
 * Web feature entry point. Starts an embedded Tomcat (spring-boot-starter-web
 * is on the classpath) and serves the endpoints in {@code ConfigController}.
 */
@SpringBootApplication
@ConfigurationPropertiesScan
public class RestConfigApp {

    public static void main(String[] args) {
        System.out.println(FeatureBanner.of("rest-config (web)"));
        SpringApplication.run(RestConfigApp.class, args);
    }
}
