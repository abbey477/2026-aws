package com.example.dbtester.controller;

import com.example.dbtester.dto.BulkResult;
import com.example.dbtester.dto.ProductRequest;
import com.example.dbtester.entity.Product;
import com.example.dbtester.service.OracleProductService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * HTTP endpoints for the Oracle-backed Product resource.
 *
 * <p>Shape mirrors {@link SybaseCustomerController} — the only Oracle-specific
 * bit is that bulk insert returns generated ids (via {@link BulkResult#ids})
 * because Oracle sequence allocation happens before INSERT, unlike Sybase's
 * server-assigned IDENTITY.
 */
@RestController
@RequestMapping("/api/oracle/products")
@Validated
public class OracleProductController {

    private final OracleProductService service;

    public OracleProductController(OracleProductService service) {
        this.service = service;
    }

    // ---- Single-row CRUD ----

    @GetMapping
    public List<Product> findAll() {
        return service.findAll();
    }

    @GetMapping("/{id}")
    public Product findById(@PathVariable Long id) {
        return service.findById(id);
    }

    @PostMapping
    public ResponseEntity<Product> create(@Valid @RequestBody ProductRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.create(request));
    }

    @PutMapping("/{id}")
    public Product update(@PathVariable Long id, @Valid @RequestBody ProductRequest request) {
        return service.update(id, request);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    // ---- Bulk endpoints ----

    /**
     * POST /api/oracle/products/bulk — batch create. Returns the generated
     * ids in input order, so the caller can correlate.
     */
    @PostMapping("/bulk")
    public ResponseEntity<BulkResult> createAll(
            @RequestBody @NotEmpty @Valid List<ProductRequest> requests) {
        List<Long> ids = service.createAll(requests);
        return ResponseEntity.status(HttpStatus.CREATED).body(BulkResult.of(ids));
    }

    /**
     * PUT /api/oracle/products/bulk — batch update.
     * Ids must be populated on every Product in the body.
     */
    @PutMapping("/bulk")
    public BulkResult updateAll(@RequestBody @NotEmpty List<Product> products) {
        return BulkResult.of(service.updateAll(products));
    }

    /** DELETE /api/oracle/products/bulk — body is a JSON array of ids: [1, 2, 3]. */
    @DeleteMapping("/bulk")
    public BulkResult deleteAll(@RequestBody @NotEmpty List<Long> ids) {
        return BulkResult.of(service.deleteAll(ids));
    }
}
