package com.example.dbtester.controller;

import com.example.dbtester.dto.CustomerRequest;
import com.example.dbtester.entity.Customer;
import com.example.dbtester.exception.ResourceNotFoundException;
import com.example.dbtester.service.SybaseCustomerService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDateTime;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(SybaseCustomerController.class)
class SybaseCustomerControllerTest {

    @Autowired MockMvc mvc;
    @Autowired ObjectMapper json;
    @MockBean SybaseCustomerService service;

    private final Customer sample =
            new Customer(1L, "Ada", "Lovelace", "ada@example.com",
                    LocalDateTime.of(2025, 1, 1, 0, 0));

    @Test
    void findAllReturnsList() throws Exception {
        when(service.findAll()).thenReturn(List.of(sample));

        mvc.perform(get("/api/sybase/customers"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].firstName").value("Ada"));
    }

    @Test
    void findByIdReturnsCustomer() throws Exception {
        when(service.findById(1L)).thenReturn(sample);

        mvc.perform(get("/api/sybase/customers/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.email").value("ada@example.com"));
    }

    @Test
    void findByIdReturns404WhenMissing() throws Exception {
        when(service.findById(99L)).thenThrow(new ResourceNotFoundException("Customer not found: 99"));

        mvc.perform(get("/api/sybase/customers/99"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message").value("Customer not found: 99"));
    }

    @Test
    void createReturns201() throws Exception {
        CustomerRequest req = new CustomerRequest("Ada", "Lovelace", "ada@example.com");
        when(service.create(any(CustomerRequest.class))).thenReturn(sample);

        mvc.perform(post("/api/sybase/customers")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json.writeValueAsString(req)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1));
    }

    @Test
    void createReturns400OnInvalidEmail() throws Exception {
        CustomerRequest bad = new CustomerRequest("Ada", "Lovelace", "not-an-email");

        mvc.perform(post("/api/sybase/customers")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json.writeValueAsString(bad)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").exists());
    }

    @Test
    void createReturns400OnBlankFields() throws Exception {
        CustomerRequest bad = new CustomerRequest("", "", "a@b.com");

        mvc.perform(post("/api/sybase/customers")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json.writeValueAsString(bad)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void updateReturnsUpdatedCustomer() throws Exception {
        CustomerRequest req = new CustomerRequest("Grace", "Hopper", "g@h.com");
        Customer updated = new Customer(1L, "Grace", "Hopper", "g@h.com", sample.createdAt());
        when(service.update(eq(1L), any(CustomerRequest.class))).thenReturn(updated);

        mvc.perform(put("/api/sybase/customers/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json.writeValueAsString(req)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.firstName").value("Grace"));
    }

    @Test
    void deleteReturns204() throws Exception {
        mvc.perform(delete("/api/sybase/customers/1"))
                .andExpect(status().isNoContent());

        verify(service).delete(1L);
    }

    @Test
    void deleteReturns404WhenMissing() throws Exception {
        doThrow(new ResourceNotFoundException("Customer not found: 99"))
                .when(service).delete(99L);

        mvc.perform(delete("/api/sybase/customers/99"))
                .andExpect(status().isNotFound());
    }
}
