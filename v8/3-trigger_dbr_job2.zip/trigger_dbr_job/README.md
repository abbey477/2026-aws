# trigger_dbr_job

A small AWS Lambda function that triggers a Databricks job using the Databricks **Jobs Run Now** API.

> **New to Python?** Start with **Option A** below — it uses only tools that come with a standard Python install. You can ignore Options B and C for now.

---

## 📁 Project structure

```
trigger_dbr_job/
├── src/
│   └── trigger_dbr_job/          ← the actual Lambda code
│       ├── handler.py            ← Lambda entrypoint (AWS calls this)
│       ├── databricks_client.py  ← code that calls Databricks
│       ├── config.py             ← reads config values safely
│       ├── log_utils.py          ← DEBUG / INFO / WARNING / ERROR loggers
│       └── log_to_dynamo.py      ← writes status records to DynamoDB
├── test/                          ← unit + integration tests
│   ├── conftest.py               ← shared test fixtures
│   ├── test_databricks_client.py
│   └── test_handler.py
├── pytest.ini                    ← pytest config
├── requirements.txt              ← runtime dependencies
├── requirements-dev.txt          ← dev/test dependencies
├── Makefile                      ← shortcut commands
├── pyproject.toml                ← project metadata
├── poetry.toml                   ← Poetry config (optional)
└── README.md                     ← you are here
```

---

## ✅ Prerequisites

You need **Python 3.12 or newer** installed.

Check your version:

```bash
python3 --version
# Expected: Python 3.12.x or higher
```

If you don't have Python 3.12+, download it from [python.org/downloads](https://www.python.org/downloads/).

---

## 🚀 Option A — Plain `pip + venv` (recommended for beginners)

This is the **simplest** way to get started. It uses only tools that ship with Python.

### Step 1 — Create a virtual environment

A **virtual environment** (or "venv") is a private Python folder just for this project. It keeps the packages this project uses from mixing with other projects.

```bash
python3 -m venv .venv
```

This creates a `.venv/` folder in the project directory.

### Step 2 — Activate the virtual environment

You need to do this **every time** you open a new terminal to work on this project.

**On Mac/Linux:**

```bash
source .venv/bin/activate
```

**On Windows (PowerShell):**

```powershell
.venv\Scripts\Activate.ps1
```

**On Windows (cmd.exe):**

```cmd
.venv\Scripts\activate.bat
```

Once activated, your prompt will show `(.venv)` at the start. That's how you know it's working.

### Step 3 — Install the dependencies

Install both the runtime dependencies (`boto3`) and the test dependencies (`pytest`, `moto`, etc.):

```bash
pip install -r requirements-dev.txt
```

> If you only need to run the code in production (not the tests), you can use `pip install -r requirements.txt` instead.

### Step 4 — Run the tests

```bash
pytest
```

You should see something like:

```
test/test_databricks_client.py::TestTriggerDatabricksJobSuccess::test_returns_triggered_with_run_id PASSED
test/test_handler.py::TestLambdaHandlerSuccess::test_trigger_result_added_on_success PASSED
...
========================= 14 passed in 0.15s =========================
```

### Step 5 — When you're done

Deactivate the virtual environment when you're done working:

```bash
deactivate
```

---

## 🛠️ Option B — Using `make`

If you have `make` installed (most Mac/Linux systems do by default), you can use these shortcuts:

```bash
make install-dev    # Creates .venv and installs everything
make test           # Runs the tests
make test-cov       # Runs tests with a coverage report
make clean          # Removes .venv and cache files
```

Run `make help` to see all available commands.

> `make` wraps the same `pip + venv` commands from Option A — it's just fewer keystrokes.

---

## 🎯 Option C — Using Poetry

Poetry is a more advanced Python tool that manages virtual environments and dependencies together. It's powerful but has a learning curve. Skip this unless you already use Poetry on other projects.

```bash
# Install Poetry once
curl -sSL https://install.python-poetry.org | python3 -

# Install dependencies and create a venv automatically
poetry install

# Run tests inside Poetry's venv
poetry run pytest
```

---

## 🧪 Useful test commands

These all work once you've activated your virtual environment (Step 2 of Option A):

```bash
# Run all tests
pytest

# Run one file
pytest test/test_handler.py

# Run one specific test
pytest test/test_handler.py::TestLambdaHandlerSuccess::test_trigger_result_added_on_success

# Show print statements and log output
pytest -s

# Stop on the first failure
pytest -x

# See which lines of code are covered by tests
pytest --cov=trigger_dbr_job --cov-report=term-missing
```

---

## 📊 Understanding the test output

When a test passes, you'll see structured log lines from the Lambda code mixed with the pytest results. That's intentional — it shows you exactly what the Lambda prints in CloudWatch when it runs:

```
2026-04-23 10:12:45 [INFO]     trigger_dbr_job.log_utils — [TriggerDbrJob] [HANDLER_START] run_id=run-002, runner_name=DBR
2026-04-23 10:12:45 [DEBUG]    trigger_dbr_job.log_utils — [TriggerDbrJob] [DBR_REQUEST_BUILT] host=..., api_url=...
2026-04-23 10:12:45 [INFO]     trigger_dbr_job.log_utils — [TriggerDbrJob] [DBR_TRIGGER_SUCCESS] dbr_run_id=67890
PASSED
```

**Log levels explained:**

- `DEBUG` — verbose internals (what request was built, what keys are in the payload)
- `INFO` — normal flow (handler started, Databricks trigger succeeded, handler complete)
- `WARNING` — unexpected but non-fatal (a config key is missing, Databricks returned an empty run_id)
- `ERROR` — real failures (network error, HTTP 4xx/5xx from Databricks, unexpected exception)

---

## 🐛 Troubleshooting

**`python3: command not found`**
→ Python isn't installed or isn't on your PATH. Install it from [python.org](https://www.python.org/downloads/).

**`ModuleNotFoundError: No module named 'pytest'`**
→ You forgot to activate the venv (Step 2), or haven't installed dev dependencies yet. Run `source .venv/bin/activate` then `pip install -r requirements-dev.txt`.

**`ModuleNotFoundError: No module named 'trigger_dbr_job'`**
→ You're running `pytest` from the wrong folder. Make sure you're in the `trigger_dbr_job/` root directory (where `pytest.ini` lives).

**`ModuleNotFoundError: No module named 'boto3'`**
→ Dev dependencies weren't installed. Run `pip install -r requirements-dev.txt`.

**The `(.venv)` prefix isn't showing in my prompt**
→ You haven't activated the venv. Run `source .venv/bin/activate` (Mac/Linux) or the Windows equivalent.

**I want to start over completely**
→ Run `make clean`, or manually delete `.venv/` and cache folders, then repeat from Step 1.
