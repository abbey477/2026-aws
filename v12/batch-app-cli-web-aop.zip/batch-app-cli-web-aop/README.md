# batch-app (hybrid + AOP)

Hybrid REST + standalone batch app with **AOP-based exception handling** that works in both modes.

## What's new in this version

This adds the AOP layer for cross-cutting error handling.

```
┌──────────────────────────┐    ┌──────────────────────────┐
│  REST mode               │    │  CLI mode                │
│  HTTP POST /api/jobs/... │    │  --job=jobA              │
└────────────┬─────────────┘    └─────────────┬────────────┘
             │                                │
             └──────────────┬─────────────────┘
                            ▼
              ┌─────────────────────────────┐
              │      JobDispatcher          │
              └──────────────┬──────────────┘
                             │
                             ▼
              ┌─────────────────────────────┐
              │       JobA / B / C          │   ← this(BatchJob) pointcut
              │                             │     fires on exceptions here
              └──────────────┬──────────────┘
                             │
                             ▼
              ┌─────────────────────────────┐
              │ SimulatedProcessingService  │   ← @within(BusinessService)
              │ @BusinessService            │     fires on exceptions here
              │                             │
              │ throw BusinessException ❌  │
              └──────────────┬──────────────┘
                             │ exception propagates up
                             ▼
              ┌─────────────────────────────┐
              │ ServiceErrorAspect          │   ← BOTH pointcuts fire
              │ • logs                      │     (one per layer)
              │ • audits                    │
              │ • metrics                   │
              └──────────────┬──────────────┘
                             │ exception continues up
                             ▼
        ┌────────────────────┴────────────────────┐
        ▼                                         ▼
┌──────────────────┐                  ┌──────────────────┐
│ GlobalException  │                  │  JobDispatcher   │
│ Handler          │                  │  catch block     │
│ (REST only)      │                  │  (CLI only)      │
│                  │                  │                  │
│ → HTTP 400 JSON  │                  │ → exit code 3    │
└──────────────────┘                  └──────────────────┘
```

## The two pointcuts

**1. `this(BatchJob)`** — fires at the job boundary (when JobA, JobB, or JobC throws).
- Located in `ServiceErrorAspect.onJobException()`
- No annotation needed on jobs — implementing `BatchJob` is enough.

**2. `@within(BusinessService)`** — fires deeper, on any class marked with `@BusinessService`.
- Located in `ServiceErrorAspect.onServiceException()`
- See `SimulatedProcessingService` for an example of the annotation.

Both are in the same aspect class and fire independently. When `SimulatedProcessingService` throws, BOTH pointcuts trigger (service-layer first, then job-layer as the exception bubbles up).

## Exit codes (CLI mode → Autosys)

| Exit code | Meaning |
|-----------|---------|
| 0 | Success |
| 1 | Unexpected exception (uncategorized) |
| 2 | Bad arguments (unknown job, missing `--job=`) |
| 3 | Business error |
| 4+ | Reserved for specific business exception types |

Set in `BusinessException` per exception type, propagated through `JobResult.getExitCode()` → `System.exit()` → shell wrapper `exit $?` → Autosys.

## Try it

### Build

```bash
mvn clean package
```

### Run the happy path (CLI mode)

```bash
java -cp target/batch-app-1.0.0.jar \
     -Dloader.main=com.example.batch.BatchCliApplication \
     org.springframework.boot.loader.launch.PropertiesLauncher \
     --job=jobA

echo "Exit code: $?"     # → 0
```

### Run the failure path (triggers aspect + exit code mapping)

```bash
java -cp target/batch-app-1.0.0.jar \
     -Dloader.main=com.example.batch.BatchCliApplication \
     org.springframework.boot.loader.launch.PropertiesLauncher \
     --job=jobA --runDate=FAIL

echo "Exit code: $?"     # → 3
```

In the logs you'll see BOTH aspect handlers fire:

```
[Aspect-Service] Exception in SimulatedProcessingService.process(..): Simulated business failure for job jobA
[Aspect-Job] Exception in JobA.execute(..): Simulated business failure for job jobA
```

Service-layer aspect runs first (closer to where the exception was thrown), then the job-layer aspect runs as the exception propagates up.

### Same failure path in REST mode

```bash
# Terminal 1
java -jar target/batch-app-1.0.0.jar

# Terminal 2
curl -X POST "http://localhost:8080/api/jobs/jobA/run?runDate=FAIL"
# → HTTP 400 with JSON body
# Server logs show the SAME two aspect log lines
```

### Run tests

```bash
mvn test
```

Tests cover both the happy path (exit code 0) and the failure path (exit code 3).

## Where the AOP code lives

```
src/main/java/com/example/batch/
├── core/
│   ├── BatchJob.java            ← target of this(BatchJob) pointcut
│   └── BusinessService.java     ← marker annotation for @within pointcut
├── common/
│   ├── aspect/
│   │   └── ServiceErrorAspect.java   ← the aspect with BOTH pointcuts
│   ├── exception/
│   │   └── BusinessException.java    ← carries exit code
│   └── service/
│       └── SimulatedProcessingService.java   ← @BusinessService-annotated
└── web/
    └── GlobalExceptionHandler.java   ← @RestControllerAdvice (REST only)
```

## What the aspect does (and doesn't) do

- ✅ Logs the exception with context.
- ✅ Could write to an audit table, send metrics, alert ops (stubbed in the code).
- ❌ Does NOT swallow the exception — it lets it propagate so the dispatcher (CLI) or @RestControllerAdvice (REST) can handle transport shaping.

## Adding new business exceptions

1. Create a new exception class (or just throw `BusinessException` with a different `exitCode`).
2. Add a catch block in `JobDispatcher.dispatch()` for the new type.
3. Add a `@ExceptionHandler` method in `GlobalExceptionHandler` for the HTTP side.

The aspect doesn't need to change — it catches `Exception`, which covers all subtypes.
