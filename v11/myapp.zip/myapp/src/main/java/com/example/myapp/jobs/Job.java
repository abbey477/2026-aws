package com.example.myapp.jobs;

public interface Job {
    String name();
    void run();
}
