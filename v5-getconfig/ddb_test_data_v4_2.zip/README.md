# DynamoDB Test Data — v4

Seed data for `app-jobConfig` (15 items), `app-jobRun` (50), `app-jobLog` (100).

Pick your platform:

- **`bash/`** — macOS / Linux / WSL / AWS CloudShell
- **`windows/`** — Windows PowerShell

Each folder has the same three commands: `setup`, `cleanup`, `reset`.

## bash

```bash
cd bash
chmod +x *.sh
./setup.sh     # load
./cleanup.sh   # wipe (prompts for 'yes')
./reset.sh     # wipe + load
```

## windows

```powershell
cd windows
.\setup.ps1
.\cleanup.ps1
.\reset.ps1
```

If PowerShell blocks execution, run once per session:
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

## Requirements

- AWS CLI configured (`aws configure`) with read/write on the three tables
- Tables must already exist:
  - `app-jobConfig`: PK `job_id` (S), SK `job_type` (S)
  - `app-jobRun`: PK `run_id` (S), SK `last_updated_time` (S)
  - `app-jobLog`: PK `run_id` (S), SK `time` (S)
- Python 3 (bash version uses it for cleanup; preinstalled on macOS/Linux/CloudShell)

## Notes

- Data is consistent: every `jobRun.job_id` references a real `jobConfig`, every `jobLog.run_id` references a real `jobRun`.
- Run status mix: 25 SUCCESS, 10 FAILED, 8 RUNNING, 7 WAITING.
- GSI key attributes (`next_scheduled_run_time`, `start_time`) are omitted when empty — required by DynamoDB.
