"""
Error handling tests — verifies that on ANY failure:
  1. The error is logged via log.error
  2. write_log is called with status="FAILED"
  3. The original exception is re-raised (so Step Functions Catch routes to HandleError)
"""

import pytest
from unittest.mock import call
from botocore.exceptions import ClientError

from get_config.handler import lambda_handler
from seed_data import make_job_run_item, raise_access_denied


class TestHandlerErrorLogging:
    """Every failure path must: log error → write_log FAILED → re-raise."""

    def test_missing_run_id_writes_failed_log(self, patched_handler, mock_write_log):
        """Missing run_id → FAILED logged before ValueError re-raised."""
        with pytest.raises(ValueError, match="Missing required input"):
            lambda_handler({}, None)

        mock_write_log.assert_called_once_with(
            run_id="<missing>",
            job_id="<unknown>",
            stage="GetConfig",
            status="FAILED",
        )

    def test_run_id_not_found_writes_failed_log(self, patched_handler, mock_write_log):
        """Nonexistent run_id → FAILED logged before ValueError re-raised."""
        with pytest.raises(ValueError, match="No job_run found"):
            lambda_handler({"run_id": "nonexistent"}, None)

        mock_write_log.assert_called_once_with(
            run_id="nonexistent",
            job_id="<unknown>",
            stage="GetConfig",
            status="FAILED",
        )

    def test_missing_job_id_writes_failed_log(self, patched_handler, mock_write_log):
        """job_run row without job_id → FAILED logged."""
        patched_handler.Table("job_run").put_item(Item={
            "run_id": "run-bad",
            "last_updated_time": "2024-01-01T00:00:00Z",
            "job_type": "sourcing",
            "status": "WAITING",
        })

        with pytest.raises(ValueError, match="missing 'job_id' or 'job_type'"):
            lambda_handler({"run_id": "run-bad"}, None)

        mock_write_log.assert_called_once_with(
            run_id="run-bad",
            job_id="<unknown>",
            stage="GetConfig",
            status="FAILED",
        )

    def test_missing_job_config_writes_failed_log(self, patched_handler, mock_write_log):
        """job_run exists but job_config doesn't → FAILED logged with correct job_id."""
        patched_handler.Table("job_run").put_item(Item=make_job_run_item(
            run_id="run-orphan",
            job_type="nonexistent_type",
        ))

        with pytest.raises(ValueError, match="No job_config found"):
            lambda_handler({"run_id": "run-orphan"}, None)

        mock_write_log.assert_called_once_with(
            run_id="run-orphan",
            job_id="client",
            stage="GetConfig",
            status="FAILED",
        )

    def test_dynamodb_client_error_writes_failed_log(
        self, patched_handler, monkeypatch, mock_write_log,
    ):
        """ClientError from DynamoDB → FAILED logged before re-raise."""
        patched_table = patched_handler.Table("job_run")
        monkeypatch.setattr(patched_table, "query", raise_access_denied)

        original_table = patched_handler.Table
        monkeypatch.setattr(
            patched_handler,
            "Table",
            lambda name: patched_table if name == "job_run" else original_table(name),
        )

        with pytest.raises(ClientError):
            lambda_handler({"run_id": "run-001"}, None)

        mock_write_log.assert_called_once_with(
            run_id="run-001",
            job_id="<unknown>",
            stage="GetConfig",
            status="FAILED",
        )

    def test_success_path_still_writes_success_log(self, patched_handler, mock_write_log):
        """Sanity check: successful run still writes SUCCESS (not FAILED)."""
        lambda_handler({"run_id": "run-001"}, None)

        mock_write_log.assert_called_once_with(
            run_id="run-001",
            job_id="client",
            stage="GetConfig",
            status="SUCCESS",
        )
