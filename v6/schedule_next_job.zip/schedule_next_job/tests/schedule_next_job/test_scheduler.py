"""
Tests for the schedule_next_jobs helper function.

Tests:
1. schedule_next_jobs inserts correct DynamoDB items.
2. Empty next_jobs returns empty list.
3. Child config fields populate the new job_run record.
4. Multiple next_jobs creates multiple entries.
5. Missing child config still creates entry with defaults.
"""
import pytest

from scheduler import schedule_next_jobs


class TestScheduleNextJobsHelper:
    """Tests for the schedule_next_jobs helper function."""

    def test_schedule_next_jobs_creates_entries(self, dynamodb_setup):
        """Test that schedule_next_jobs inserts correct DynamoDB items."""
        _, job_run_table, job_config_table = dynamodb_setup

        next_jobs = [{"type": "silver_load", "id": "dbr_client"}]
        job_output = {"s3_path": "s3://bucket/data"}

        created_ids = schedule_next_jobs(
            job_run_table, job_config_table, next_jobs, job_output,
        )

        assert len(created_ids) == 1
        new_item = job_run_table.get_item(Key={"run_id": created_ids[0]})["Item"]
        assert new_item["job_id"] == "dbr_client"
        assert new_item["job_type"] == "silver_load"
        assert new_item["status"] == "WAITING"
        assert new_item["custom_attributes"] == {"s3_path": "s3://bucket/data"}

    def test_schedule_next_jobs_empty(self, dynamodb_setup):
        """Test that empty next_jobs returns empty list."""
        _, job_run_table, job_config_table = dynamodb_setup

        created_ids = schedule_next_jobs(job_run_table, job_config_table, [], {})

        assert created_ids == []

    def test_schedule_next_jobs_child_config_fields(self, dynamodb_setup):
        """Test that child config fields populate the new job_run record."""
        _, job_run_table, job_config_table = dynamodb_setup

        next_jobs = [{"type": "silver_load", "id": "dbr_client"}]
        job_output = {"s3_path": "s3://bucket/out"}

        created_ids = schedule_next_jobs(
            job_run_table, job_config_table, next_jobs, job_output,
        )

        new_item = job_run_table.get_item(Key={"run_id": created_ids[0]})["Item"]
        # trigger_type in the item is always hardcoded to PIPELINE (original behavior).
        assert new_item["trigger_type"] == "PIPELINE"
        assert new_item["mark_for_delete"] is False
        assert new_item["error"] == ""
        assert new_item["delete_at"] == 0

    def test_schedule_multiple_next_jobs(self, dynamodb_setup):
        """Test multiple next_jobs creates multiple entries."""
        _, job_run_table, job_config_table = dynamodb_setup

        next_jobs = [
            {"type": "silver_load", "id": "dbr_client"},
            {"type": "gold_load", "id": "dbr_gold"},
        ]
        job_output = {"s3_path": "s3://bucket/data"}

        created_ids = schedule_next_jobs(
            job_run_table, job_config_table, next_jobs, job_output,
        )

        assert len(created_ids) == 2
        item1 = job_run_table.get_item(Key={"run_id": created_ids[0]})["Item"]
        item2 = job_run_table.get_item(Key={"run_id": created_ids[1]})["Item"]
        job_ids = {item1["job_id"], item2["job_id"]}
        assert job_ids == {"dbr_client", "dbr_gold"}

    def test_schedule_child_config_not_found_uses_defaults(self, dynamodb_setup):
        """Test that a missing child config still creates an entry with defaults."""
        _, job_run_table, job_config_table = dynamodb_setup

        next_jobs = [{"type": "nonexistent_type", "id": "nonexistent_job"}]

        created_ids = schedule_next_jobs(
            job_run_table, job_config_table, next_jobs, {},
        )

        assert len(created_ids) == 1
        new_item = job_run_table.get_item(Key={"run_id": created_ids[0]})["Item"]
        assert new_item["job_id"] == "nonexistent_job"
        assert new_item["job_type"] == "nonexistent_type"
        assert new_item["trigger_type"] == "PIPELINE"
        assert new_item["status"] == "WAITING"

    def test_run_ids_are_unique(self, dynamodb_setup):
        """Test that each created run_id is unique."""
        _, job_run_table, job_config_table = dynamodb_setup

        next_jobs = [
            {"type": "silver_load", "id": "dbr_client"},
            {"type": "gold_load", "id": "dbr_gold"},
        ]

        created_ids = schedule_next_jobs(
            job_run_table, job_config_table, next_jobs, {},
        )

        assert len(set(created_ids)) == len(created_ids)
