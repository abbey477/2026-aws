package com.example.dbtester.config;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import java.util.List;
import java.util.Map;

/**
 * Shared factory that converts a {@link DataSourceProperties.DbConfig} record
 * into a fully-configured {@link HikariDataSource}.
 *
 * <p>Kept package-private and static because this is internal plumbing, not
 * a bean itself — we don't want Spring picking it up by mistake. Each of the
 * {@code OracleDataSourceConfig}/{@code SybaseDataSourceConfig} classes calls
 * into it and exposes the resulting {@code DataSource} as a named bean.
 *
 * <p>Extraction here also means the mapping from "our record" to "Hikari's
 * mutable config object" lives in one place instead of being duplicated per
 * datasource.
 */
final class HikariDataSourceFactory {

    private HikariDataSourceFactory() {}

    /**
     * Build a HikariDataSource from the given config.
     *
     * @param name   Just for documentation/exception messages; Hikari's own
     *               pool name comes from {@code config.hikari().poolName()}.
     * @param config The record-shaped settings, typically from application.properties.
     */
    static HikariDataSource build(String name, DataSourceProperties.DbConfig config) {
        HikariConfig hikari = new HikariConfig();

        // Core connection params — these four are always required.
        hikari.setJdbcUrl(config.url());
        hikari.setUsername(config.username());
        hikari.setPassword(config.password());
        hikari.setDriverClassName(config.driverClassName());

        // Pool sizing & timeouts. All guarded so that unset/zero values
        // fall back to Hikari's built-in defaults rather than breaking
        // things (setting maximumPoolSize=0 would be invalid).
        DataSourceProperties.HikariConfig h = config.hikari();
        if (h != null) {
            if (h.maximumPoolSize() > 0)      hikari.setMaximumPoolSize(h.maximumPoolSize());
            if (h.minimumIdle() >= 0)         hikari.setMinimumIdle(h.minimumIdle());
            if (h.connectionTimeoutMs() > 0)  hikari.setConnectionTimeout(h.connectionTimeoutMs());
            if (h.idleTimeoutMs() > 0)        hikari.setIdleTimeout(h.idleTimeoutMs());
            if (h.maxLifetimeMs() > 0)        hikari.setMaxLifetime(h.maxLifetimeMs());
            if (h.poolName() != null)         hikari.setPoolName(h.poolName());
        }

        // Validation query for the pool's connection-liveness test.
        // Hikari prefers Connection.isValid() (JDBC 4.0) when drivers support
        // it, but older drivers (especially jConnect) may need an explicit query.
        List<String> queries = config.validationQueries();
        if (queries != null && !queries.isEmpty()) {
            hikari.setConnectionTestQuery(queries.get(0));
        }

        // Pass-through driver-specific properties. This is how you plumb
        // things like Oracle's oracle.net.CONNECT_TIMEOUT or Sybase's
        // DYNAMIC_PREPARE through to the underlying driver — the Map
        // entries become JDBC DataSource properties at connection time.
        Map<String, String> props = config.properties();
        if (props != null) {
            props.forEach(hikari::addDataSourceProperty);
        }

        return new HikariDataSource(hikari);
    }
}
