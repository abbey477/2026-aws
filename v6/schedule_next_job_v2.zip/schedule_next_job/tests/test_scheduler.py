"""
Tests for the schedule_next_jobs helper function.
"""
import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import pytest
from scheduler import schedule_next_jobs


class TestScheduleNextJobsHelper:

    def test_schedule_next_jobs_creates_entries(self, dynamodb_setup):
        _, job_run_table, job_config_table = dynamodb_setup
        created_ids = schedule_next_jobs(
            job_run_table, job_config_table,
            [{"type": "silver_load", "id": "dbr_client"}],
            {"s3_path": "s3://bucket/data"},
        )
        assert len(created_ids) == 1
        item = job_run_table.get_item(Key={"run_id": created_ids[0]})["Item"]
        assert item["job_id"] == "dbr_client"
        assert item["job_type"] == "silver_load"
        assert item["status"] == "WAITING"
        assert item["custom_attributes"] == {"s3_path": "s3://bucket/data"}

    def test_schedule_next_jobs_empty(self, dynamodb_setup):
        _, job_run_table, job_config_table = dynamodb_setup
        assert schedule_next_jobs(job_run_table, job_config_table, [], {}) == []

    def test_schedule_next_jobs_child_config_fields(self, dynamodb_setup):
        _, job_run_table, job_config_table = dynamodb_setup
        created_ids = schedule_next_jobs(
            job_run_table, job_config_table,
            [{"type": "silver_load", "id": "dbr_client"}],
            {"s3_path": "s3://bucket/out"},
        )
        item = job_run_table.get_item(Key={"run_id": created_ids[0]})["Item"]
        assert item["trigger_type"] == "PIPELINE"
        assert item["mark_for_delete"] is False
        assert item["error"] == ""
        assert item["delete_at"] == 0

    def test_schedule_multiple_next_jobs(self, dynamodb_setup):
        _, job_run_table, job_config_table = dynamodb_setup
        created_ids = schedule_next_jobs(
            job_run_table, job_config_table,
            [{"type": "silver_load", "id": "dbr_client"}, {"type": "gold_load", "id": "dbr_gold"}],
            {"s3_path": "s3://bucket/data"},
        )
        assert len(created_ids) == 2
        item1 = job_run_table.get_item(Key={"run_id": created_ids[0]})["Item"]
        item2 = job_run_table.get_item(Key={"run_id": created_ids[1]})["Item"]
        assert {item1["job_id"], item2["job_id"]} == {"dbr_client", "dbr_gold"}

    def test_schedule_child_config_not_found_uses_defaults(self, dynamodb_setup):
        _, job_run_table, job_config_table = dynamodb_setup
        created_ids = schedule_next_jobs(
            job_run_table, job_config_table,
            [{"type": "nonexistent_type", "id": "nonexistent_job"}], {},
        )
        assert len(created_ids) == 1
        item = job_run_table.get_item(Key={"run_id": created_ids[0]})["Item"]
        assert item["job_id"] == "nonexistent_job"
        assert item["status"] == "WAITING"

    def test_run_ids_are_unique(self, dynamodb_setup):
        _, job_run_table, job_config_table = dynamodb_setup
        created_ids = schedule_next_jobs(
            job_run_table, job_config_table,
            [{"type": "silver_load", "id": "dbr_client"}, {"type": "gold_load", "id": "dbr_gold"}], {},
        )
        assert len(set(created_ids)) == len(created_ids)
