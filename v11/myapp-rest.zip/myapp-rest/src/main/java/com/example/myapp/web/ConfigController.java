package com.example.myapp.web;

import com.example.myapp.config.AppProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/config")
public class ConfigController {

    private static final Logger log = LoggerFactory.getLogger(ConfigController.class);

    private final AppProperties properties;

    public ConfigController(AppProperties properties) {
        this.properties = properties;
    }

    /**
     * GET /api/config
     * Returns the full bound AppProperties (including the nested Database record).
     */
    @GetMapping
    public AppProperties full() {
        log.info("GET /api/config");
        return properties;
    }

    /**
     * GET /api/config/app
     * Returns the top-level app fields only.
     */
    @GetMapping("/app")
    public Map<String, String> app() {
        log.info("GET /api/config/app");
        return Map.of(
                "name", properties.name(),
                "environment", properties.environment()
        );
    }

    /**
     * GET /api/config/db
     * Returns the nested Database record only.
     */
    @GetMapping("/db")
    public AppProperties.Database db() {
        log.info("GET /api/config/db");
        return properties.db();
    }
}
