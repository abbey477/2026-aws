"""
Shared test helpers, constants, and mock factories for CheckJobStatus tests.
"""

import json
from unittest.mock import MagicMock
from botocore.exceptions import ClientError


# --------------- Constants ---------------

TASK_ARN = "arn:aws:ecs:us-east-1:123456789012:task/my-ecs-cluster/abc123def456"

ECS_RUNNER_CONFIG = {
    "cluster": "my-ecs-cluster",
    "subnets": ["subnet-aaa111"],
    "security_groups": ["sg-abc123"],
    "task_definition": "default-task-def",
    "container_name": "default-container",
}

DBR_RUNNER_CONFIG = {
    "host": "my-databricks-instance.cloud.databricks.com",
    "token": "dapi-mock-token-12345",
    "job_id": "12345",
}


# --------------- Event Builders ---------------


def make_ecs_event(task_arn=TASK_ARN):
    """Build a sample event for an ECS-type job."""
    return {
        "run_id": "run-001",
        "job_id": "client",
        "job_type": "sourcing",
        "status": "WAITING",
        "job_config": {
            "job_runner": {"type": "ECS_Fargate", "name": "S2S3", "config": ECS_RUNNER_CONFIG},
            "job_param": {"batch_size": 1000},
        },
        "trigger_result": {
            "trigger_status": "TRIGGERED",
            "task_arn": task_arn,
            "runner_name": "S2S3",
            "runner_type": "ECS",
        },
    }


def make_dbr_event(dbr_run_id="67890"):
    """Build a sample event for a Databricks-type job."""
    return {
        "run_id": "run-002",
        "job_id": "dbr_client",
        "job_type": "silver_load",
        "status": "WAITING",
        "job_config": {
            "job_runner": {"type": "Databricks", "name": "DBR", "config": DBR_RUNNER_CONFIG},
            "job_param": {"entity_id": "client"},
        },
        "trigger_result": {
            "trigger_status": "TRIGGERED",
            "dbr_run_id": dbr_run_id,
            "runner_name": "DBR",
            "runner_type": "DBR",
        },
    }


# --------------- ECS Mock Factories ---------------


def mock_ecs_describe_stopped_success():
    mock_client = MagicMock()
    mock_client.describe_tasks.return_value = {
        "tasks": [{
            "taskArn": TASK_ARN,
            "lastStatus": "STOPPED",
            "stoppedReason": "Essential container exited",
            "containers": [{"name": "worker", "exitCode": 0}],
        }],
    }
    return mock_client


def mock_ecs_describe_stopped_failed():
    mock_client = MagicMock()
    mock_client.describe_tasks.return_value = {
        "tasks": [{
            "taskArn": TASK_ARN,
            "lastStatus": "STOPPED",
            "stoppedReason": "Essential container exited with error",
            "containers": [{"name": "worker", "exitCode": 1}],
        }],
    }
    return mock_client


def mock_ecs_describe_running():
    mock_client = MagicMock()
    mock_client.describe_tasks.return_value = {
        "tasks": [{
            "taskArn": TASK_ARN,
            "lastStatus": "RUNNING",
            "containers": [{"name": "worker", "lastStatus": "RUNNING"}],
        }],
    }
    return mock_client


def mock_ecs_describe_not_found():
    mock_client = MagicMock()
    mock_client.describe_tasks.return_value = {"tasks": []}
    return mock_client


def mock_ecs_describe_client_error():
    mock_client = MagicMock()
    mock_client.describe_tasks.side_effect = ClientError(
        error_response={
            "Error": {
                "Code": "ClusterNotFoundException",
                "Message": "Cluster not found.",
            }
        },
        operation_name="DescribeTasks",
    )
    return mock_client


# --------------- DBR Mock Helper ---------------


def mock_urlopen_response(body: dict):
    mock_resp = MagicMock()
    mock_resp.read.return_value = json.dumps(body).encode("utf-8")
    mock_resp.__enter__ = lambda s: s
    mock_resp.__exit__ = MagicMock(return_value=False)
    return mock_resp
