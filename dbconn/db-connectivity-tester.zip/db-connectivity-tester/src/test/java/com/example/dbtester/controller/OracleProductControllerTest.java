package com.example.dbtester.controller;

import com.example.dbtester.dto.ProductRequest;
import com.example.dbtester.entity.Product;
import com.example.dbtester.exception.ResourceNotFoundException;
import com.example.dbtester.service.OracleProductService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(OracleProductController.class)
class OracleProductControllerTest {

    @Autowired MockMvc mvc;
    @Autowired ObjectMapper json;
    @MockBean OracleProductService service;

    private final Product sample =
            new Product(1L, "SKU-1", "Widget", new BigDecimal("19.99"), true);

    @Test
    void findAllReturnsList() throws Exception {
        when(service.findAll()).thenReturn(List.of(sample));

        mvc.perform(get("/api/oracle/products"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].sku").value("SKU-1"))
                .andExpect(jsonPath("$[0].inStock").value(true));
    }

    @Test
    void findByIdReturnsProduct() throws Exception {
        when(service.findById(1L)).thenReturn(sample);

        mvc.perform(get("/api/oracle/products/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Widget"));
    }

    @Test
    void findByIdReturns404WhenMissing() throws Exception {
        when(service.findById(99L)).thenThrow(new ResourceNotFoundException("Product not found: 99"));

        mvc.perform(get("/api/oracle/products/99"))
                .andExpect(status().isNotFound());
    }

    @Test
    void createReturns201() throws Exception {
        ProductRequest req = new ProductRequest("SKU-1", "Widget", new BigDecimal("19.99"), true);
        when(service.create(any(ProductRequest.class))).thenReturn(sample);

        mvc.perform(post("/api/oracle/products")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json.writeValueAsString(req)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1));
    }

    @Test
    void createReturns400OnNegativePrice() throws Exception {
        ProductRequest bad = new ProductRequest("SKU-1", "Widget", new BigDecimal("-1.00"), true);

        mvc.perform(post("/api/oracle/products")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json.writeValueAsString(bad)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void createReturns400OnBlankSku() throws Exception {
        ProductRequest bad = new ProductRequest("", "Widget", BigDecimal.ONE, true);

        mvc.perform(post("/api/oracle/products")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json.writeValueAsString(bad)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void updateReturnsProduct() throws Exception {
        ProductRequest req = new ProductRequest("SKU-1", "Widget v2", new BigDecimal("29.99"), false);
        Product updated = new Product(1L, "SKU-1", "Widget v2", new BigDecimal("29.99"), false);
        when(service.update(eq(1L), any(ProductRequest.class))).thenReturn(updated);

        mvc.perform(put("/api/oracle/products/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(json.writeValueAsString(req)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Widget v2"))
                .andExpect(jsonPath("$.inStock").value(false));
    }

    @Test
    void deleteReturns204() throws Exception {
        mvc.perform(delete("/api/oracle/products/1"))
                .andExpect(status().isNoContent());

        verify(service).delete(1L);
    }

    @Test
    void deleteReturns404WhenMissing() throws Exception {
        doThrow(new ResourceNotFoundException("Product not found: 99"))
                .when(service).delete(99L);

        mvc.perform(delete("/api/oracle/products/99"))
                .andExpect(status().isNotFound());
    }
}
