# myapp — Spring Boot CLI MVP

A minimal Spring Boot **non-web** application that:
- Loads `@ConfigurationProperties` into a Java `record` with a nested `record`.
- Prints those properties at startup.
- Dispatches to one of three jobs (`jobA`, `jobB`, `jobC`) based on a CLI argument.
- Supports three profiles (`dev`, `test`, `prod`).
- Writes logs to `output/logs/application-<HOST_IP>.log` (outside `myapp/`,
  survives redeploys).
- Packages a `tar.gz` distribution via the Maven Assembly Plugin.

## Requirements
- Java 21
- Maven 3.9+

## Build
```
mvn clean package
```
Produces:
- `target/myapp-1.0.0.jar`           — Spring Boot fat JAR (no configs inside)
- `target/myapp-1.0.0-dist.tar.gz`   — full distribution

## Configuration

All configuration is externalized — the JAR contains no `application.properties`
and no `logback.xml`. Both ship in the tarball's `config/` directory:

| File                                  | Purpose                              |
|---------------------------------------|--------------------------------------|
| `config/application.properties`       | base (always loaded)                 |
| `config/application-dev.properties`   | dev profile                          |
| `config/application-test.properties`  | test profile                         |
| `config/application-prod.properties`  | prod profile                         |
| `config/logback.xml`                  | logging appenders & patterns         |

### Profile activation
Activate with `--spring.profiles.active=<env>` or env var
`SPRING_PROFILES_ACTIVE=<env>`. The launch scripts pass it for you when you
provide the second argument: `./run-job.sh jobA prod`.

### Log levels
Driven by Spring Boot's `logging.level.*` keys in the properties files. Each
profile sets its own:
- `dev`  : `root=INFO`, `com.example.myapp=DEBUG`
- `test` : `root=INFO`, `com.example.myapp=INFO`
- `prod` : `root=WARN`, `com.example.myapp=INFO`

Edit a profile file on the server, restart, levels change. No XML edits, no
rebuild.

### Spring Boot load order (lowest → highest priority)
1. `config/application.properties`            (base)
2. `config/application-<profile>.properties`  (active profile)
3. CLI args / system properties / env vars

## Run the assembled distribution

### Linux
```
mkdir -p output
tar -xzf target/myapp-1.0.0-dist.tar.gz -C output
cd output/myapp/bin
./run-job.sh jobA dev
./run-job.sh jobB test
./run-job.sh jobC prod
```

### Windows
```
mkdir output
tar -xzf target\myapp-1.0.0-dist.tar.gz -C output
cd output\myapp\bin
run-job.bat jobA dev
```

## Run directly from the JAR (dev only)

The JAR has no baked-in config. Point at the source tree:
```
java \
  -Dapp.host.ip=127.0.0.1 \
  -Dapp.log.dir=./logs \
  -Dlogging.config=file:src/main/resources/logback.xml \
  -jar target/myapp-1.0.0.jar \
  --spring.config.additional-location=file:src/main/resources/ \
  --spring.profiles.active=dev \
  --job=jobA
```

## Layout after extraction
```
output/
├── logs/                              ← persistent, sibling of myapp/
│   └── application-<HOST_IP>.log
└── myapp/                             ← replaced on every deploy
    ├── bin/
    │   ├── run-job.sh
    │   └── run-job.bat
    ├── lib/
    │   └── myapp-1.0.0.jar
    └── config/
        ├── application.properties
        ├── application-dev.properties
        ├── application-test.properties
        ├── application-prod.properties
        └── logback.xml
```

The launch script creates `output/logs/` on first run and writes log files
directly there via `-Dapp.log.dir`. Nothing inside `myapp/` references logs,
so a redeploy that wipes `myapp/` cannot touch them.

## Notes
- The launch scripts detect the host IP and pass `-Dapp.host.ip=...`.
  Logback uses it in the log file name: `application-<IP>.log`.
- The launch scripts pass `-Dlogging.config=file:.../config/logback.xml` so
  Logback uses the externalized config, not whatever's on the classpath.
- The launch scripts pass `--spring.config.additional-location=file:.../config/`
  so Spring Boot reads the externalized properties.
