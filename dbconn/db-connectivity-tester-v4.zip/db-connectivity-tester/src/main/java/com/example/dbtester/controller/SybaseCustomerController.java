package com.example.dbtester.controller;

import com.example.dbtester.dto.BulkResult;
import com.example.dbtester.dto.CustomerRequest;
import com.example.dbtester.entity.Customer;
import com.example.dbtester.service.SybaseCustomerService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/sybase/customers")
@Validated
public class SybaseCustomerController {

    private final SybaseCustomerService service;

    public SybaseCustomerController(SybaseCustomerService service) {
        this.service = service;
    }

    // ---- Single row ----

    @GetMapping
    public List<Customer> findAll() {
        return service.findAll();
    }

    @GetMapping("/{id}")
    public Customer findById(@PathVariable Long id) {
        return service.findById(id);
    }

    @PostMapping
    public ResponseEntity<Customer> create(@Valid @RequestBody CustomerRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.create(request));
    }

    @PutMapping("/{id}")
    public Customer update(@PathVariable Long id, @Valid @RequestBody CustomerRequest request) {
        return service.update(id, request);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }

    // ---- Bulk ----

    @PostMapping("/bulk")
    public ResponseEntity<BulkResult> createAll(
            @RequestBody @NotEmpty @Valid List<CustomerRequest> requests) {
        return ResponseEntity.status(HttpStatus.CREATED).body(BulkResult.of(service.createAll(requests)));
    }

    @PutMapping("/bulk")
    public BulkResult updateAll(@RequestBody @NotEmpty List<Customer> customers) {
        return BulkResult.of(service.updateAll(customers));
    }

    @DeleteMapping("/bulk")
    public BulkResult deleteAll(@RequestBody @NotEmpty List<Long> ids) {
        return BulkResult.of(service.deleteAll(ids));
    }
}
