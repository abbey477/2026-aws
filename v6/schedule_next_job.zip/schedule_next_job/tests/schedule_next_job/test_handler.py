"""
Tests for the ScheduleNextJob Lambda handler.

Tests:
1. Happy path - next_jobs creates new job_run entries using child config.
2. No next_jobs - handler skips gracefully.
3. Child config not found - still creates entry with defaults.
4. Multiple next_jobs - creates multiple entries.
5. Handler failure - write_log called with FAILURE, exception re-raised.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from conftest import _make_event

import pytest


def _load_handler(dynamodb_setup, monkeypatch):
    """
    Import (or reload) handler.py inside the active mock_aws context,
    then monkeypatch the module-scope DynamoDB tables to the moto-backed ones.
    """
    dynamodb, job_run_table, job_config_table = dynamodb_setup

    sys.modules.pop("handler", None)

    import dynamodb_ops
    monkeypatch.setattr(dynamodb_ops, "get_dynamodb_resource", lambda: dynamodb)

    import handler
    monkeypatch.setattr(handler, "_DYNAMODB", dynamodb)
    monkeypatch.setattr(handler, "_JOB_RUN_TABLE", job_run_table)
    monkeypatch.setattr(handler, "_JOB_CONFIG_TABLE", job_config_table)
    return handler, job_run_table, job_config_table


class TestScheduleNextJobLambda:
    """Tests for the ScheduleNextJob Lambda handler."""

    def test_schedule_with_next_jobs(self, dynamodb_setup, monkeypatch):
        """Test happy path: next_jobs creates new job_run entries using child config."""
        handler, job_run_table, _ = _load_handler(dynamodb_setup, monkeypatch)

        event = _make_event(
            next_jobs=[{"type": "silver_load", "id": "dbr_client"}],
            job_output={"s3_path": "s3://bucket/output"},
        )
        result = handler.lambda_handler(event, None)

        assert "schedule_result" in result
        assert result["schedule_result"]["skipped"] is False
        next_ids = result["schedule_result"]["next_job_run_ids"]
        assert len(next_ids) == 1

        new_item = job_run_table.get_item(Key={"run_id": next_ids[0]})["Item"]
        assert new_item["job_id"] == "dbr_client"
        assert new_item["job_type"] == "silver_load"
        assert new_item["trigger_type"] == "PIPELINE"
        assert new_item["status"] == "WAITING"
        assert new_item["custom_attributes"] == {"s3_path": "s3://bucket/output"}
        assert new_item["error"] == ""
        assert new_item["delete_at"] == 0

    def test_schedule_no_next_jobs(self, dynamodb_setup, monkeypatch):
        """Test that handler skips gracefully when no next_jobs."""
        handler, _, _ = _load_handler(dynamodb_setup, monkeypatch)

        event = _make_event(next_jobs=[])
        result = handler.lambda_handler(event, None)

        assert result["schedule_result"]["skipped"] is True
        assert result["schedule_result"]["next_job_run_ids"] == []

    def test_schedule_multiple_next_jobs(self, dynamodb_setup, monkeypatch):
        """Test multiple next_jobs creates multiple entries."""
        handler, job_run_table, _ = _load_handler(dynamodb_setup, monkeypatch)

        event = _make_event(
            next_jobs=[
                {"type": "silver_load", "id": "dbr_client"},
                {"type": "gold_load", "id": "dbr_gold"},
            ],
            job_output={"s3_path": "s3://bucket/data"},
        )
        result = handler.lambda_handler(event, None)

        next_ids = result["schedule_result"]["next_job_run_ids"]
        assert len(next_ids) == 2

        item1 = job_run_table.get_item(Key={"run_id": next_ids[0]})["Item"]
        item2 = job_run_table.get_item(Key={"run_id": next_ids[1]})["Item"]
        job_ids = {item1["job_id"], item2["job_id"]}
        assert job_ids == {"dbr_client", "dbr_gold"}

    def test_schedule_child_config_not_found(self, dynamodb_setup, monkeypatch):
        """Test that missing child config still creates entry with defaults."""
        handler, job_run_table, _ = _load_handler(dynamodb_setup, monkeypatch)

        event = _make_event(
            next_jobs=[{"type": "nonexistent_type", "id": "nonexistent_job"}],
        )
        result = handler.lambda_handler(event, None)

        next_ids = result["schedule_result"]["next_job_run_ids"]
        assert len(next_ids) == 1

        new_item = job_run_table.get_item(Key={"run_id": next_ids[0]})["Item"]
        assert new_item["job_id"] == "nonexistent_job"
        assert new_item["job_type"] == "nonexistent_type"
        assert new_item["trigger_type"] == "PIPELINE"
        assert new_item["status"] == "WAITING"

    def test_handler_failure_calls_write_log_with_failure(
        self, dynamodb_setup, monkeypatch
    ):
        """Test that an unexpected scheduler error writes FAILURE log and re-raises."""
        handler, _, _ = _load_handler(dynamodb_setup, monkeypatch)

        write_log_calls = []
        monkeypatch.setattr(handler, "write_log", lambda **kw: write_log_calls.append(kw))
        monkeypatch.setattr(
            handler,
            "schedule_next_jobs",
            lambda *a, **kw: (_ for _ in ()).throw(RuntimeError("boom")),
        )

        event = _make_event(
            next_jobs=[{"type": "silver_load", "id": "dbr_client"}],
        )

        with pytest.raises(RuntimeError, match="boom"):
            handler.lambda_handler(event, None)

        assert len(write_log_calls) == 1
        assert write_log_calls[0]["status"] == "FAILURE"
        assert write_log_calls[0]["stage"] == "ScheduleNextJob"
