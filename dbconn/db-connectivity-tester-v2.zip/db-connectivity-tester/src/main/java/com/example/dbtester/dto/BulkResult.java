package com.example.dbtester.dto;

import java.util.List;

/**
 * Response shape for bulk endpoints.
 *
 * @param processed Total rows affected across all chunks. For insert, this
 *                  is rows inserted. For update/delete, rows actually
 *                  modified — may be less than the request size if some
 *                  ids didn't exist.
 * @param ids       Generated ids, populated only when the backend can
 *                  surface them. Oracle (sequence-based) returns ids;
 *                  Sybase (IDENTITY + batch) returns an empty list. See
 *                  {@link com.example.dbtester.repository.sybase.CustomerRepository#insertAll}
 *                  for why.
 */
public record BulkResult(
        int processed,
        List<Long> ids
) {
    /** Shorthand for when ids aren't available (Sybase batch insert, updates, deletes). */
    public static BulkResult of(int processed) {
        return new BulkResult(processed, List.of());
    }

    /** Shorthand for when ids are available (Oracle batch insert). */
    public static BulkResult of(List<Long> ids) {
        return new BulkResult(ids.size(), ids);
    }
}
