package com.example.dbtester.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

/**
 * Incoming payload for Customer create/update.
 *
 * <p>DTO (not entity) because:
 * <ul>
 *   <li>The client shouldn't set {@code id} or {@code createdAt} — those
 *       are server-owned.</li>
 *   <li>Validation annotations belong on the input, not the domain record,
 *       keeping the entity free of HTTP concerns.</li>
 * </ul>
 *
 * <p>Bean Validation (Jakarta) rejects blank strings and malformed emails
 * before the controller ever invokes the service — the {@code @Valid}
 * annotation on the controller parameter triggers the check and returns
 * 400 on failure via {@code GlobalExceptionHandler}.
 */
public record CustomerRequest(
        @NotBlank String firstName,
        @NotBlank String lastName,
        @NotBlank @Email String email
) {}
