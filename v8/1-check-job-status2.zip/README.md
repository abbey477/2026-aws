# CheckJobStatus Lambda

Unified status poller that checks the status of a running job regardless of runner type (ECS Fargate or Databricks). Called every 60 seconds by a Step Functions poll loop.

---

## Project structure

```
check-job-status/
├── src/
│   └── check_job_status/
│       ├── __init__.py
│       ├── handler.py              # Lambda entry point (thin router)
│       ├── ecs_status.py           # ECS Fargate status check logic
│       ├── databricks_status.py    # Databricks status check logic
│       └── log_to_dynamo.py        # Shared DynamoDB logger (INFO/WARN/ERROR)
├── test/
│   ├── __init__.py
│   ├── conftest.py                 # Shared pytest fixtures (auto-mock DynamoDB)
│   ├── helpers.py                  # Constants, event builders, mock factories
│   ├── test_ecs_status.py          # 7 tests for ECS status checks
│   ├── test_databricks_status.py   # 10 tests for Databricks status checks
│   └── test_handler.py             # 13 tests for handler routing/validation
├── Makefile
├── poetry.toml
├── pyproject.toml
├── pytest.ini                      # Tells pytest where to find src/ (no PYTHONPATH needed)
├── requirements.txt                # Runtime dependencies
├── requirements-dev.txt            # Runtime + test dependencies
└── README.md
```

---

## Prerequisites

- **Python 3.9 or newer** (3.12 recommended). Check your version:
  ```bash
  python --version
  ```
  If you don't have Python, download it from [python.org](https://www.python.org/downloads/).

---

## Quick start — option 1: Plain pip + venv (recommended for beginners)

No extra tools to install. Just Python and pip (which comes with Python).

### Linux / macOS

1. Open a terminal and go into the project folder:
   ```bash
   cd lambdas/check-job-status
   ```

2. Create a virtual environment (an isolated space for this project's dependencies):
   ```bash
   python3 -m venv .venv
   ```

3. Activate it:
   ```bash
   source .venv/bin/activate
   ```
   Your prompt should now show `(.venv)` at the start.

4. Install the test dependencies:
   ```bash
   pip install -r requirements-dev.txt
   ```

5. Run the tests:
   ```bash
   pytest -v
   ```

6. When you're done, leave the virtual environment:
   ```bash
   deactivate
   ```

### Windows (PowerShell)

1. Open PowerShell and go into the project folder:
   ```powershell
   cd lambdas\check-job-status
   ```

2. Create a virtual environment:
   ```powershell
   python -m venv .venv
   ```

3. Activate it:
   ```powershell
   .venv\Scripts\Activate.ps1
   ```
   If PowerShell blocks the script, run this once and try again:
   ```powershell
   Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
   ```

4. Install the test dependencies:
   ```powershell
   pip install -r requirements-dev.txt
   ```

5. Run the tests:
   ```powershell
   pytest -v
   ```

6. When you're done, leave the virtual environment:
   ```powershell
   deactivate
   ```

---

## Quick start — option 2: Poetry (recommended for ongoing development)

Poetry manages dependencies and virtual environments automatically. Install instructions are further below.

```bash
cd lambdas/check-job-status
poetry install
poetry run pytest -v
```

---

## Quick start — option 3: Make (shortest commands)

If `make` is installed:

```bash
cd lambdas/check-job-status
make install
make test
```

Available targets:
- `make install` — install dependencies
- `make test` — run all tests
- `make test-verbose` — verbose output
- `make test-cov` — show coverage report
- `make clean` — remove cache files

---

## Running specific tests

Once your environment is active (venv or poetry), you can target individual files or tests:

**Run just one test file:**
```bash
pytest test/test_ecs_status.py -v
pytest test/test_databricks_status.py -v
pytest test/test_handler.py -v
```

**Run a single test by name:**
```bash
pytest test/test_ecs_status.py::TestCheckEcsTaskStatus::test_stopped_all_success -v
```

With Poetry, prefix those commands with `poetry run`.

---

## What the tests cover

- **ECS tests** (`test_ecs_status.py` — 7 tests): task stopped with success, task stopped with error, task still running, task not found, AWS ClientError, multiple containers all success, multiple containers mixed exit codes.
- **Databricks tests** (`test_databricks_status.py` — 10 tests): terminated with success, terminated with failed, still running, pending state, terminating state, unexpected lifecycle state, HTTP error, URL error, correct API URL construction, terminated with timeout.
- **Handler tests** (`test_handler.py` — 13 tests): ECS path success/running/failed, missing task_arn, preserves event fields (ECS), DBR path success/running/failed, missing dbr_run_id, preserves event fields (DBR), unsupported/missing/empty runner_type.

**Total: 30 tests**, all mocked so no AWS credentials or network access are needed.

---

## How it works

The `lambda_handler` in `handler.py` receives a Step Functions event, reads `trigger_result.runner_type`, and routes to:

- `ecs_status.check_ecs_task_status()` — calls AWS ECS `describe_tasks` via boto3.
- `databricks_status.check_databricks_job_status()` — calls the Databricks REST API.

Both return a dict with `job_status` (SUCCESS, RUNNING, or FAILED). The handler merges that into `trigger_result` and logs the outcome to DynamoDB via `log_to_dynamo` using the appropriate level:

- `write_log_info()` — normal events (STARTED, RUNNING, SUCCESS)
- `write_log_warn()` — unexpected but non-fatal situations
- `write_log_error()` — failures

---

## Optional: Installing extra tools

### Installing Poetry

**Linux / macOS:**
```bash
curl -sSL https://install.python-poetry.org | python3 -
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
source ~/.bashrc
poetry --version
```

**Windows (PowerShell):**
```powershell
(Invoke-WebRequest -Uri https://install.python-poetry.org -UseBasicParsing).Content | python -
```
Then add `%APPDATA%\Python\Scripts` to your PATH (System → Environment Variables), restart PowerShell, and verify with `poetry --version`.

### Installing make

**Ubuntu/Debian:**
```bash
sudo apt update
sudo apt install make -y
```

**macOS:** already included with Xcode Command Line Tools (`xcode-select --install`).

**Windows:** install via [Chocolatey](https://chocolatey.org/) — open PowerShell as Administrator and run:
```powershell
choco install make -y
```

---

## Troubleshooting

**"command not found: python"** — on Linux/macOS try `python3` instead of `python`.

**"pytest: command not found"** — your virtual environment probably isn't activated. Re-run the activation step (step 3 in the venv instructions).

**"ModuleNotFoundError: No module named 'check_job_status'"** — make sure you ran `pytest` from inside the `check-job-status/` folder. The `pytest.ini` file tells pytest where to find the code.

**PowerShell script execution blocked** — run this once:
```powershell
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
```

---

## Notes

- All tests mock external dependencies (AWS, Databricks API, DynamoDB) — no credentials or network needed.
- `conftest.py` auto-mocks the DynamoDB log writer globally so no test hits a real table.
- `helpers.py` contains reusable event builders and mock factories shared across test files.
