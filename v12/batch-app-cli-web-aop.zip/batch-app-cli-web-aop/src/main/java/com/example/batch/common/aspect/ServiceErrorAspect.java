package com.example.batch.common.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Cross-cutting exception handler for the batch app.
 *
 * <p>This aspect fires whenever a method on an advised bean throws an exception.
 * It runs the SAME way in both REST and CLI mode — that's the whole point.
 *
 * <p>It uses TWO pointcuts for layered coverage:
 *
 * <ol>
 *   <li><b>this(BatchJob)</b> — fires at the job boundary. Any class implementing
 *       BatchJob (JobA, JobB, JobC) is covered automatically.</li>
 *   <li><b>&#64;within(BusinessService)</b> — fires deeper, inside any class
 *       annotated with &#64;BusinessService. Catches service-layer errors
 *       before they bubble up to the job boundary.</li>
 * </ol>
 *
 * <p>The aspect's job is to do the cross-cutting work (logging, auditing, metrics, alerts).
 * It does NOT swallow the exception — it lets it propagate so the dispatcher (in CLI mode)
 * or @RestControllerAdvice (in REST mode) can translate it to the appropriate transport
 * response (exit code or HTTP status).
 */
@Aspect
@Component
public class ServiceErrorAspect {

    private static final Logger log = LoggerFactory.getLogger(ServiceErrorAspect.class);

    // ====================================================================
    // POINTCUT 1: this(BatchJob)
    // Fires when a method is called on any bean implementing BatchJob and
    // that method throws. Catches errors at the JOB BOUNDARY.
    // ====================================================================
    @AfterThrowing(
            pointcut = "this(com.example.batch.core.BatchJob)",
            throwing = "ex"
    )
    public void onJobException(JoinPoint joinPoint, Exception ex) {
        // joinPoint.getSignature() tells us which method threw (e.g., JobA.execute(..))
        log.error("[Aspect-Job] Exception in {}: {}",
                joinPoint.getSignature().toShortString(), ex.getMessage(), ex);

        // Real-world: write to audit table, increment metrics, send alerts, etc.
        // auditService.recordJobFailure(joinPoint, ex);
        // metricsService.increment("job.error");

        // We DO NOT rethrow or swallow — exception continues propagating up.
    }

    // ====================================================================
    // POINTCUT 2: @within(BusinessService)
    // Fires when a method is called on any class marked with @BusinessService
    // and that method throws. Catches errors DEEPER, in service classes.
    // ====================================================================
    @AfterThrowing(
            pointcut = "@within(com.example.batch.core.BusinessService)",
            throwing = "ex"
    )
    public void onServiceException(JoinPoint joinPoint, Exception ex) {
        log.error("[Aspect-Service] Exception in {}: {}",
                joinPoint.getSignature().toShortString(), ex.getMessage(), ex);

        // Real-world: same kind of side-effects you might want at the service layer.
        // auditService.recordServiceFailure(joinPoint, ex);
    }
}
