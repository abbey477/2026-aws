"""ddb_config_pull — query helper + end-to-end."""
import pytest
from botocore.exceptions import ClientError
from pre_steps_processor.dynamodb_ops import pull_config_from_table
from pre_steps_processor.handler import lambda_handler
from seed_data import make_event, raise_access_denied


class TestPullConfigFromTable:

    def test_returns_row(self, config_tables):
        _, tables = config_tables
        tables["service_config"].put_item(Item={
            "job_id": "client", "job_type": "sourcing", "setting": "value_x",
        })
        result = pull_config_from_table(
            table=tables["service_config"], table_name="service_config",
            job_id="client", job_type="sourcing",
        )
        assert result["setting"] == "value_x"

    def test_returns_none(self, config_tables):
        _, tables = config_tables
        result = pull_config_from_table(
            table=tables["service_config"], table_name="service_config",
            job_id="unknown", job_type="sourcing",
        )
        assert result is None

    def test_client_error_propagates(self, monkeypatch, config_tables):
        _, tables = config_tables
        monkeypatch.setattr(tables["service_config"], "get_item", raise_access_denied)
        with pytest.raises(ClientError):
            pull_config_from_table(
                table=tables["service_config"], table_name="service_config",
                job_id="client", job_type="sourcing",
            )


class TestDdbConfigPullEndToEnd:

    def test_pulled_rows_in_return(self, config_tables, monkeypatch):
        dynamodb, tables = config_tables
        tables["service_config"].put_item(Item={
            "job_id": "client", "job_type": "sourcing", "feature_flag": True,
        })
        monkeypatch.setattr("pre_steps_processor.step_handlers.get_dynamodb_resource", lambda: dynamodb)

        event = make_event(pre_steps=[{
            "pre_step_type": "ddb_config_pull", "tables": ["service_config", "table_config"],
        }])
        result = lambda_handler(event, None)

        assert "ddb_config_pull" in result
        assert result["ddb_config_pull"]["service_config"]["feature_flag"] is True
        assert result["ddb_config_pull"]["table_config"] is None
        # job_param should also be present
        assert "job_param" in result

    def test_empty_tables_list(self, config_tables, monkeypatch):
        dynamodb, _ = config_tables
        monkeypatch.setattr("pre_steps_processor.step_handlers.get_dynamodb_resource", lambda: dynamodb)
        result = lambda_handler(make_event(pre_steps=[{
            "pre_step_type": "ddb_config_pull", "tables": [],
        }]), None)
        assert "ddb_config_pull" not in result

    def test_missing_tables_key(self, config_tables, monkeypatch):
        dynamodb, _ = config_tables
        monkeypatch.setattr("pre_steps_processor.step_handlers.get_dynamodb_resource", lambda: dynamodb)
        result = lambda_handler(make_event(pre_steps=[{"pre_step_type": "ddb_config_pull"}]), None)
        assert "ddb_config_pull" not in result
