package com.myapp.resserver.controller;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/**
 * Example protected API endpoints.
 *
 * All requests must carry a valid Bearer JWT issued by the Auth Server.
 * Scope-based access is enforced via @PreAuthorize.
 */
@RestController
@RequestMapping("/api")
public class ApiController {

    /**
     * Public resource info — any authenticated client.
     */
    @GetMapping("/hello")
    public Map<String, String> hello(@AuthenticationPrincipal Jwt jwt) {
        return Map.of(
            "message", "Hello from the Resource Server!",
            "subject", jwt.getSubject(),
            "issuer",  jwt.getIssuer().toString()
        );
    }

    /**
     * Read-protected endpoint — requires scope 'api.read'.
     */
    @GetMapping("/data")
    @PreAuthorize("hasAuthority('SCOPE_api.read')")
    public Map<String, Object> getData(@AuthenticationPrincipal Jwt jwt) {
        return Map.of(
            "data",   "Some protected data",
            "claims", jwt.getClaims()
        );
    }

    /**
     * Write-protected endpoint — requires scope 'api.write'.
     */
    @GetMapping("/admin")
    @PreAuthorize("hasAuthority('SCOPE_api.write')")
    public Map<String, String> adminAction() {
        return Map.of("result", "Admin action executed");
    }
}
