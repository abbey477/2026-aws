import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;

import java.util.ArrayList;
import java.util.List;

/**
 * Streaming migration for IRInstrumentFlag (Sybase -> Oracle).
 *
 * <p>Streams rows from Sybase via {@link RowCallbackHandler}, buffers them, and
 * flushes batches to Oracle through {@link IRInstrumentFlagOracleRepository}.
 * Memory is bounded at ~BATCH_SIZE rows.
 *
 * <p>Row mapping is delegated to {@link IRInstrumentFlagRowMapper}; see that class
 * for type-handling notes.
 *
 * <p>Two variants for A/B comparison: {@link #migrateByIndex()} (positional,
 * fastest) and {@link #migrateByName()} (by name, robust to SELECT reordering).
 */
@Slf4j
public class IRInstrumentFlagMigration {

    private static final int FETCH_SIZE = 2000;
    private static final int BATCH_SIZE = 5000;

    /**
     * SELECT column order MUST match the order used by
     * {@link IRInstrumentFlagRowMapper#mapByIndex} when reading positionally.
     */
    private static final String SELECT_SQL =
            "SELECT ID_IMNT, ID_ACCR, ID_CPN_CUSTOM, ID_AMRT, ID_EMBD_OPTN, " +
            "       ID_EXOTIC, ID_RISKY, ID_ACCR_RCVY, ID_BRADY, ID_GOVT, " +
            "       ID_CPTL, ID_DEFAULT_JPMC, ID_CRV_RCVY, ID_PRICE_PRIMARY, ID_CI_LINKED, " +
            "       ID_GUARANTOR, ID_FIXED, ID_SECURED, ID_PERPETUAL, ID_TYP_REPASTYP, " +
            "       ID_LIQUIDITY, ID_DISTRESS, ID_PIK, ID_TYP_QUOTE, ID_INDEX_LINKED, " +
            "       ID_BO_COMP, ID_RISK_SENS, ID_TYP_CCYTYPE, ID_TRD_MIN, ID_MAKE_WHOLE, " +
            "       ID_TRUST_PRF, ID_SINKABLE, ID_EXTENDIBLE, ID_EXCHANGEABLE, MTG_PAY_DELAY, " +
            "       ID_FVM, DT_CHG_GRD, ID_DEL_GRD, ID_OWN_GRD " +
            "FROM IR_INSTRUMENT_FLAG";

    private static final String TABLE_LABEL = "IR_INSTRUMENT_FLAG";

    private final JdbcTemplate sybaseJdbcTemplate;
    private final IRInstrumentFlagOracleRepository oracleRepo;

    public IRInstrumentFlagMigration(
            @Qualifier("sybaseJdbcTemplate") JdbcTemplate sybaseJdbcTemplate,
            IRInstrumentFlagOracleRepository oracleRepo) {
        this.sybaseJdbcTemplate = sybaseJdbcTemplate;
        this.oracleRepo = oracleRepo;

        // CRITICAL: without this jconn4 uses a tiny default fetch size.
        this.sybaseJdbcTemplate.setFetchSize(FETCH_SIZE);
    }

    /** Variant A — positional read. */
    public void migrateByIndex() {
        run("byIndex", IRInstrumentFlagRowMapper::mapByIndex);
    }

    /** Variant B — by-name read. */
    public void migrateByName() {
        run("byName", IRInstrumentFlagRowMapper::mapByName);
    }

    /**
     * Shared streaming pipeline. The variants only differ in which mapper they pass in,
     * so the orchestration is parameterized to avoid code duplication.
     */
    private void run(String variant, RowMapperFn mapper) {
        log.info("[{}] Starting migration (variant={}, fetchSize={}, batchSize={})",
                TABLE_LABEL, variant, FETCH_SIZE, BATCH_SIZE);
        final long startNanos = System.nanoTime();

        oracleRepo.truncate();

        final List<IRInstrumentFlag> buffer = new ArrayList<>(BATCH_SIZE);
        final MigrationStats stats = new MigrationStats();

        sybaseJdbcTemplate.query(SELECT_SQL, (RowCallbackHandler) rs -> {
            buffer.add(mapper.apply(rs));
            if (buffer.size() >= BATCH_SIZE) {
                flush(stats, buffer);
            }
        });

        if (!buffer.isEmpty()) {
            flush(stats, buffer);
        }

        logCompletion(variant, stats, startNanos);
    }

    private void flush(MigrationStats stats, List<IRInstrumentFlag> buffer) {
        final int rowsInThisBatch = buffer.size();
        final long batchStartNanos = System.nanoTime();

        oracleRepo.batchInsert(buffer);

        final long batchElapsedMs = (System.nanoTime() - batchStartNanos) / 1_000_000;
        stats.batchCount++;
        stats.totalRows += rowsInThisBatch;

        log.debug("[{}] Batch {} complete — rows={}, elapsedMs={}, totalRowsSoFar={}",
                TABLE_LABEL, stats.batchCount, rowsInThisBatch, batchElapsedMs, stats.totalRows);

        buffer.clear();
    }

    private void logCompletion(String variant, MigrationStats stats, long startNanos) {
        final long totalElapsedMs = (System.nanoTime() - startNanos) / 1_000_000;
        final double seconds = Math.max(totalElapsedMs / 1000.0, 0.001);
        final long rowsPerSec = (long) (stats.totalRows / seconds);

        log.info("[{}] Migration complete (variant={}) — totalRows={}, batches={}, elapsedMs={}, throughput={} rows/sec",
                TABLE_LABEL, variant, stats.totalRows, stats.batchCount, totalElapsedMs, rowsPerSec);
    }

    /** Functional interface so we can pass a checked-exception-throwing mapper as a method reference. */
    @FunctionalInterface
    private interface RowMapperFn {
        IRInstrumentFlag apply(java.sql.ResultSet rs) throws java.sql.SQLException;
    }

    private static final class MigrationStats {
        long totalRows = 0;
        int batchCount = 0;
    }
}
