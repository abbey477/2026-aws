package com.example.dbtester.dto;

/**
 * Health-check response for a single datasource.
 *
 * @param datasource Logical name ("oracle" or "sybase")
 * @param status     "UP", "DOWN", or "UNKNOWN"
 * @param latencyMs  How long the validation query took (from getConnection()
 *                   through statement execution). Useful for spotting slow pools.
 * @param message    Human-readable detail — "OK" on success, exception message
 *                   on failure.
 */
public record ConnectionStatus(
        String datasource,
        String status,
        long latencyMs,
        String message
) {}
