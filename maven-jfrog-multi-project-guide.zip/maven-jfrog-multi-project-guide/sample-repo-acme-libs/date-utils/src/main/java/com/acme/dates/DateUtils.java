package com.acme.dates;

import java.time.Clock;
import java.time.DayOfWeek;
import java.time.LocalDate;

public class DateUtils {

    private final Clock clock;

    public DateUtils(Clock clock) {
        this.clock = clock;
    }

    public boolean isWeekendToday() {
        DayOfWeek day = LocalDate.now(clock).getDayOfWeek();
        return day == DayOfWeek.SATURDAY || day == DayOfWeek.SUNDAY;
    }
}
