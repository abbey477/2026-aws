package com.example.dbtester;

import com.example.dbtester.config.AppProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

/**
 * Entry point.
 *
 * DataSourceAutoConfiguration is excluded because we build Oracle and Sybase
 * DataSources manually in config/. AppProperties is registered so @ConfigurationProperties
 * on the record takes effect.
 */
@SpringBootApplication(exclude = { DataSourceAutoConfiguration.class })
@EnableConfigurationProperties(AppProperties.class)
public class DbTesterApplication {

    public static void main(String[] args) {
        SpringApplication.run(DbTesterApplication.class, args);
    }
}
