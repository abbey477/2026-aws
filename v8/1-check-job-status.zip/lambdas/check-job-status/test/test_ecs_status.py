"""
Unit tests for the ecs_status module.

Tests:
    1. Task STOPPED with all containers exit code 0 → SUCCESS.
    2. Task STOPPED with non-zero exit code → FAILED.
    3. Task still RUNNING → RUNNING.
    4. Task not found (empty tasks list) → FAILED.
    5. ClientError from ECS → FAILED.
    6. Multiple containers all success → SUCCESS.
    7. Multiple containers mixed exit codes → FAILED.
"""

from unittest.mock import MagicMock

from check_job_status.ecs_status import check_ecs_task_status
from test.helpers import (
    TASK_ARN,
    ECS_RUNNER_CONFIG,
    mock_ecs_describe_stopped_success,
    mock_ecs_describe_stopped_failed,
    mock_ecs_describe_running,
    mock_ecs_describe_not_found,
    mock_ecs_describe_client_error,
)


class TestCheckEcsTaskStatus:
    """Tests for the check_ecs_task_status helper function."""

    def test_stopped_all_success(self):
        """Task STOPPED with all containers exit code 0 → SUCCESS."""
        mock_client = mock_ecs_describe_stopped_success()
        result = check_ecs_task_status(mock_client, TASK_ARN, ECS_RUNNER_CONFIG)

        assert result["job_status"] == "SUCCESS"
        assert "output" in result
        assert result["output"]["task_arn"] == TASK_ARN

    def test_stopped_with_error(self):
        """Task STOPPED with non-zero exit code → FAILED."""
        mock_client = mock_ecs_describe_stopped_failed()
        result = check_ecs_task_status(mock_client, TASK_ARN, ECS_RUNNER_CONFIG)

        assert result["job_status"] == "FAILED"
        assert "error" in result
        assert "exit_codes" in result
        assert result["exit_codes"]["worker"] == 1

    def test_still_running(self):
        """Task still RUNNING → RUNNING."""
        mock_client = mock_ecs_describe_running()
        result = check_ecs_task_status(mock_client, TASK_ARN, ECS_RUNNER_CONFIG)

        assert result["job_status"] == "RUNNING"

    def test_task_not_found(self):
        """Empty tasks list → FAILED with 'Task not found'."""
        mock_client = mock_ecs_describe_not_found()
        result = check_ecs_task_status(mock_client, TASK_ARN, ECS_RUNNER_CONFIG)

        assert result["job_status"] == "FAILED"
        assert "Task not found" in result["error"]

    def test_client_error(self):
        """ClientError from ECS → FAILED."""
        mock_client = mock_ecs_describe_client_error()
        result = check_ecs_task_status(mock_client, TASK_ARN, ECS_RUNNER_CONFIG)

        assert result["job_status"] == "FAILED"
        assert "ClusterNotFoundException" in result["error"]

    def test_stopped_multiple_containers_all_success(self):
        """Task STOPPED with multiple containers all exit code 0 → SUCCESS."""
        mock_client = MagicMock()
        mock_client.describe_tasks.return_value = {
            "tasks": [{
                "taskArn": TASK_ARN,
                "lastStatus": "STOPPED",
                "stoppedReason": "",
                "containers": [
                    {"name": "worker", "exitCode": 0},
                    {"name": "sidecar", "exitCode": 0},
                ],
            }],
        }
        result = check_ecs_task_status(mock_client, TASK_ARN, ECS_RUNNER_CONFIG)
        assert result["job_status"] == "SUCCESS"

    def test_stopped_mixed_exit_codes(self):
        """Task STOPPED with mixed exit codes → FAILED."""
        mock_client = MagicMock()
        mock_client.describe_tasks.return_value = {
            "tasks": [{
                "taskArn": TASK_ARN,
                "lastStatus": "STOPPED",
                "stoppedReason": "Mixed results",
                "containers": [
                    {"name": "worker", "exitCode": 0},
                    {"name": "sidecar", "exitCode": 137},
                ],
            }],
        }
        result = check_ecs_task_status(mock_client, TASK_ARN, ECS_RUNNER_CONFIG)
        assert result["job_status"] == "FAILED"
        assert result["exit_codes"]["sidecar"] == 137
