"""
ScheduleNextJob Lambda Handler.

Called after UpdateJobStatus marks a job as SUCCESS.
Reads the next_jobs list from job_config, fetches each child's
full configuration from the job_config DynamoDB table, and inserts
a new job_run record for each - ready to be picked up by the Scheduler.

Input:  Full pipeline payload (with update_result from UpdateJobStatus).
Output: Same payload with schedule_result containing created run IDs.
"""
from datetime import datetime, timezone

from schedule_next_job.logger import log_info, log_error
from schedule_next_job.config import JOB_RUN_TABLE, JOB_CONFIG_TABLE
from schedule_next_job.dynamodb_ops import get_dynamodb_resource
from schedule_next_job.scheduler import schedule_next_jobs
from schedule_next_job.log_to_dynamo import write_log

# Initialize DynamoDB resource at module scope so it is reused
# across warm Lambda invocations (cold-start optimisation).
_DYNAMODB = get_dynamodb_resource()
_JOB_RUN_TABLE = _DYNAMODB.Table(JOB_RUN_TABLE)
_JOB_CONFIG_TABLE = _DYNAMODB.Table(JOB_CONFIG_TABLE)


def lambda_handler(event, context):
    """
    Lambda entry point.

    Called by the state machine after UpdateJobStatus marks a job as SUCCESS.
    Reads next_jobs from job_config, fetches each child's config, and
    inserts new job_run records.

    Input:  Full payload with job_config.next_jobs and trigger_result.output.
    Output: Same payload with schedule_result added.
    """
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    run_id = event.get("run_id", "UNKNOWN")
    job_config = event.get("job_config", {})
    trigger_result = event.get("trigger_result", {})
    next_jobs = job_config.get("next_jobs", [])
    job_output = trigger_result.get("output", {})

    log_info("HANDLER_START", {
        "timestamp": timestamp,
        "run_id": run_id,
        "next_jobs_count": len(next_jobs),
        "output_keys": list(job_output.keys()) if job_output else [],
    })

    if not next_jobs:
        log_info("HANDLER_SKIP", {"reason": "No next_jobs to schedule"})
        event["schedule_result"] = {
            "next_job_run_ids": [],
            "skipped": True,
        }
        return event

    try:
        created_run_ids = schedule_next_jobs(
            _JOB_RUN_TABLE, _JOB_CONFIG_TABLE, next_jobs, job_output,
        )
    except Exception as e:
        log_error("HANDLER_FAILED", {
            "run_id": run_id,
            "error": str(e),
        }, exc_info=True)
        write_log(
            run_id=run_id,
            job_id=event.get("job_id", ""),
            stage="ScheduleNextJob",
            status="FAILURE",
        )
        raise

    event["schedule_result"] = {
        "next_job_run_ids": created_run_ids,
        "skipped": False,
    }

    write_log(
        run_id=run_id,
        job_id=event.get("job_id", ""),
        stage="ScheduleNextJob",
        status="SUCCESS",
    )

    log_info("HANDLER_COMPLETE", {
        "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "run_id": run_id,
        "next_jobs_scheduled": len(created_run_ids),
    })

    return event
