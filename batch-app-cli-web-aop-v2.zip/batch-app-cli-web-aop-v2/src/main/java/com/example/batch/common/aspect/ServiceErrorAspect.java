package com.example.batch.common.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Fires when ANY method on a class marked with @BusinessService throws.
 *
 * The aspect only does cross-cutting work (logging here; in real apps add
 * audit table writes, metrics, alerts, etc.). It does NOT decide exit codes
 * — that's the dispatcher's job. The exception keeps propagating up.
 */
@Aspect
@Component
public class ServiceErrorAspect {

    private static final Logger log = LoggerFactory.getLogger(ServiceErrorAspect.class);

    @AfterThrowing(
            pointcut = "@within(com.example.batch.core.BusinessService)",
            throwing = "ex"
    )
    public void onException(JoinPoint jp, Exception ex) {
        log.error("[Aspect] {} threw: {}", jp.getSignature().toShortString(), ex.getMessage());
        // Real-world: audit.record(ex);  metrics.increment("error");  alerts.send(ex);
    }
}
