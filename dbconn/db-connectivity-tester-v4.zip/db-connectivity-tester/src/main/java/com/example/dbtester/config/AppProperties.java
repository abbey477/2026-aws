package com.example.dbtester.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.List;
import java.util.Map;

/**
 * Mirrors application.properties one-to-one.
 *
 * app.oracle.*  -> oracle()
 * app.sybase.*  -> sybase()
 */
@ConfigurationProperties(prefix = "app")
public record AppProperties(
        Oracle oracle,
        Sybase sybase
) {

    public record Oracle(
            String url,
            String username,
            String password,
            String driverClassName,
            OracleHikari hikari,
            Map<String, String> properties,
            List<String> validationQueries
    ) {}

    public record OracleHikari(
            int maximumPoolSize,
            int minimumIdle,
            long connectionTimeoutMs,
            long idleTimeoutMs,
            long maxLifetimeMs,
            String poolName
    ) {}

    public record Sybase(
            String url,
            String username,
            String password,
            String driverClassName,
            SybaseHikari hikari,
            Map<String, String> properties,
            List<String> validationQueries
    ) {}

    public record SybaseHikari(
            int maximumPoolSize,
            int minimumIdle,
            long connectionTimeoutMs,
            long idleTimeoutMs,
            long maxLifetimeMs,
            String poolName
    ) {}
}
