package com.example.dbtester.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;

import java.math.BigDecimal;

/**
 * Incoming payload for Product create/update.
 *
 * <p>{@code price} uses {@code @PositiveOrZero} rather than {@code @Positive}
 * because a legitimate product could be free (price 0.00) — e.g. promotional
 * giveaways.
 *
 * <p>{@code inStock} is a primitive boolean — Jackson defaults it to false
 * if the client omits the field. If you need to distinguish "not sent" from
 * "sent as false", switch to {@code Boolean} and add {@code @NotNull}.
 */
public record ProductRequest(
        @NotBlank String sku,
        @NotBlank String name,
        @NotNull @PositiveOrZero BigDecimal price,
        boolean inStock
) {}
