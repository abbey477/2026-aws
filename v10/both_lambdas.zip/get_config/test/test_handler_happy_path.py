"""Happy-path tests — successful config retrieval end-to-end."""

from get_config.handler import lambda_handler


class TestHandlerHappyPath:

    def test_successful_config_retrieval(self, patched_handler, mock_write_log):
        result = lambda_handler({"run_id": "run-001"}, None)

        # job_run fields spread at top level
        assert result["run_id"] == "run-001"
        assert result["job_id"] == "client"
        assert result["job_type"] == "sourcing"
        assert result["status"] == "WAITING"
        assert result["trigger_type"] == "SCHEDULER"
        assert result["custom_attributes"] == {}
        assert result["last_updated_time"] == "2024-01-01T00:00:00Z"

        # job_config nested
        assert "job_config" in result
        cfg = result["job_config"]
        assert cfg["enabled"] is True
        assert cfg["job_runner"]["name"] == "S2S3"
        assert cfg["job_runner"]["type"] == "ECS_Fargate"

    def test_job_runner_config_fields_preserved(self, patched_handler):
        """All infra fields inside job_runner.config survive the round trip."""
        result = lambda_handler({"run_id": "run-001"}, None)
        runner_cfg = result["job_config"]["job_runner"]["config"]

        assert runner_cfg["cluster"] == "my-ecs-cluster"
        assert runner_cfg["subnets"] == ["subnet-aaa111", "subnet-bbb222"]
        assert runner_cfg["security_groups"] == ["sg-abc123"]
        assert runner_cfg["task_definition"] == "default-task-def"
        assert runner_cfg["container_name"] == "default-container"
        assert runner_cfg["instance_size"] == "small"
        assert runner_cfg["image"] == ""

    def test_next_jobs_and_pre_steps_flow_through(self, patched_handler):
        """next_jobs and pre_steps both pass through verbatim."""
        result = lambda_handler({"run_id": "run-001"}, None)

        next_jobs = result["job_config"]["next_jobs"]
        assert len(next_jobs) == 1
        assert next_jobs[0]["id"] == "dbr_client"

        pre_steps = result["job_config"]["pre_steps"]
        assert len(pre_steps) == 2
        assert pre_steps[0] == {"pre_step_type": "change_since_append"}
        assert pre_steps[1]["pre_step_type"] == "ddb_config_pull"
        assert pre_steps[1]["tables"] == ["service_config", "table_config"]

    def test_write_log_called_on_success(self, patched_handler, mock_write_log):
        """write_log is called exactly once with SUCCESS status."""
        lambda_handler({"run_id": "run-001"}, None)

        mock_write_log.assert_called_once_with(
            run_id="run-001",
            job_id="client",
            stage="GetConfig",
            status="SUCCESS",
        )
