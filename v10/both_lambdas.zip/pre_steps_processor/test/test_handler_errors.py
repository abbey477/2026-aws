"""
Error handling tests for PreStepsProcessor.

Verifies that on ANY failure:
  1. The error is logged via log.error
  2. write_log is called with status="FAILED"
  3. The original exception is re-raised (so Step Functions Catch → HandleError)
"""

import pytest
from botocore.exceptions import ClientError

from pre_steps_processor.handler import lambda_handler
from seed_data import make_event, raise_access_denied


class TestHandlerErrorLogging:

    def test_step_handler_exception_writes_failed_log(self, monkeypatch, mock_write_log):
        """If a step handler raises, we log FAILED and re-raise."""
        # Patch handle_change_since_append to raise (where it's used in handler)
        monkeypatch.setattr(
            "pre_steps_processor.handler.handle_change_since_append",
            lambda step, event: (_ for _ in ()).throw(
                RuntimeError("Something broke")
            ),
        )

        event = make_event(pre_steps=[{"pre_step_type": "change_since_append"}])

        with pytest.raises(RuntimeError, match="Something broke"):
            lambda_handler(event, None)

        mock_write_log.assert_called_once_with(
            run_id="run-001",
            job_id="client",
            stage="PreStepsProcessor",
            status="FAILED",
        )

    def test_success_path_writes_success_log(self, mocks, mock_write_log):
        """Sanity check: successful run writes SUCCESS."""
        lambda_handler(make_event(pre_steps=[]), None)

        mock_write_log.assert_called_once_with(
            run_id="run-001",
            job_id="client",
            stage="PreStepsProcessor",
            status="SUCCESS",
        )

    def test_success_with_steps_writes_success_log(self, mocks, mock_write_log):
        """SUCCESS logged even when steps are processed."""
        lambda_handler(
            make_event(pre_steps=[{"pre_step_type": "change_since_append"}]),
            None,
        )

        mock_write_log.assert_called_once_with(
            run_id="run-001",
            job_id="client",
            stage="PreStepsProcessor",
            status="SUCCESS",
        )
