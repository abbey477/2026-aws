package com.example.batch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Entry point #1 — REST MODE.
 *
 * <p>Starts a normal Spring Boot web app. Embedded Tomcat boots, controllers
 * are exposed at HTTP endpoints. The app stays running until killed.
 *
 * <p>Run with:
 * <pre>java -jar batch-app.jar</pre>
 *
 * <p>Then POST to {@code http://localhost:8080/api/jobs/{jobName}/run}
 * to trigger a job.
 *
 * <p>This is the original way the app worked. Coexists with {@link BatchCliApplication}
 * which is the new standalone mode for Autosys.
 */
@SpringBootApplication
public class BatchWebApplication {

    public static void main(String[] args) {
        SpringApplication.run(BatchWebApplication.class, args);
    }
}
