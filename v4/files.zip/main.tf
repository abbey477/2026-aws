locals {
  name_prefix = "${var.project_name}-${var.env}"
}

# ---------------------------------------------------------------------------
# IAM role for Step Functions
# ---------------------------------------------------------------------------
data "aws_iam_policy_document" "sfn_assume" {
  statement {
    effect  = "Allow"
    actions = ["sts:AssumeRole"]
    principals {
      type        = "Service"
      identifiers = ["states.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "sfn" {
  name               = "${local.name_prefix}-sfn-role"
  assume_role_policy = data.aws_iam_policy_document.sfn_assume.json
}

# No real permissions needed since we only use Pass states.
# When you add Lambdas later, attach a policy with lambda:InvokeFunction here.

# ---------------------------------------------------------------------------
# Step Function state machine
# ---------------------------------------------------------------------------
resource "aws_sfn_state_machine" "hello" {
  name     = "${local.name_prefix}-hello"
  role_arn = aws_iam_role.sfn.arn

  # No variables needed yet - pure static JSON.
  # Once you add Lambdas, switch to:
  # definition = templatefile("${path.module}/step-function/definition.json", {
  #   lambda1_arn = module.lambda1.arn
  #   lambda2_arn = module.lambda2.arn
  # })
  definition = file("${path.module}/step-function/definition.json")
}
