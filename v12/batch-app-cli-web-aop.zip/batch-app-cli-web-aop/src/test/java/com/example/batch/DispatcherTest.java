package com.example.batch;

import com.example.batch.core.JobContext;
import com.example.batch.core.JobDispatcher;
import com.example.batch.core.JobResult;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(
        classes = BatchCliApplication.class,
        properties = {
                "spring.profiles.active=dev",
                "spring.main.web-application-type=none"
        }
)
class DispatcherTest {

    @Autowired
    private JobDispatcher dispatcher;

    @Test
    void jobASucceeds_returnsExitCode0() {
        JobResult result = dispatcher.dispatch(new JobContext("jobA", "2026-05-16"));
        assertThat(result.isSuccess()).isTrue();
        assertThat(result.getExitCode()).isEqualTo(0);
        assertThat(result.getRecordsProcessed()).isGreaterThan(0);
    }

    @Test
    void jobAFails_returnsBusinessExitCode3() {
        // "FAIL" runDate triggers BusinessException in the service.
        // The aspect logs it, the dispatcher maps it to exit code 3.
        JobResult result = dispatcher.dispatch(new JobContext("jobA", "FAIL"));
        assertThat(result.isSuccess()).isFalse();
        assertThat(result.getExitCode()).isEqualTo(3);
        assertThat(result.getMessage()).contains("Simulated business failure");
    }

    @Test
    void unknownJob_returnsExitCode2() {
        JobResult result = dispatcher.dispatch(new JobContext("jobX", "2026-05-16"));
        assertThat(result.isSuccess()).isFalse();
        assertThat(result.getExitCode()).isEqualTo(2);
    }
}
