"""
Step handler functions for PreStepsProcessor.

- handle_change_since_append: queries job_run GSI-2 for the last SUCCESS
  start_time.
- handle_ddb_config_pull: reads each requested table using (job_id, job_type)
  and returns a dict keyed by table name. Missing rows come through as None.
- handle_no_pre_steps: stub — no data to process.
- handle_unknown_pre_step: stub — unrecognised pre_step_type, logs only.

Each handler returns a dict (possibly empty). The main handler.py decides
where to place the returned data in the final output.
"""

from typing import Any

from pre_steps_processor import logging_utils as log
from pre_steps_processor.dynamodb_ops import (
    JOB_RUN_TABLE,
    get_dynamodb_resource,
    get_last_successful_run_start_time,
    pull_config_from_table,
)


def handle_no_pre_steps() -> dict:
    """
    Called when there's nothing to process:
    - job_config has no pre_steps key
    - pre_steps is None / []
    - all items are invalid (no valid pre_step_type)

    TODO: implement actual no-data logic (discuss with architect).
    """
    log.info("HANDLE_NO_PRE_STEPS", {"status": "stub_called"})
    return {}


def handle_change_since_append(step: dict, event: dict) -> dict:
    """
    Find start_time of the last successful run for this (job_id, job_type).

    Result shape is a placeholder — architect will confirm what downstream
    consumers expect.
    """
    job_id = event.get("job_id")
    job_type = event.get("job_type")

    log.info("HANDLE_CHANGE_SINCE_APPEND_START", {
        "job_id": job_id,
        "job_type": job_type,
    })

    dynamodb = get_dynamodb_resource()
    table = dynamodb.Table(JOB_RUN_TABLE)

    start_time = get_last_successful_run_start_time(
        table=table,
        job_id=job_id,
        job_type=job_type,
    )

    result = {
        "last_successful_start_time": start_time,
        "placeholder": True,  # flag — shape not final
    }

    log.info("HANDLE_CHANGE_SINCE_APPEND_COMPLETE", {
        "job_id": job_id,
        "job_type": job_type,
        "has_start_time": start_time is not None,
    })
    return result


def handle_ddb_config_pull(step: dict, event: dict) -> dict:
    """
    For every table in step["tables"], look up (job_id, job_type) and
    return a dict keyed by table name. Missing rows → None.

    The main handler merges this directly into job_param, NOT into
    pre_steps_results.
    """
    job_id = event.get("job_id")
    job_type = event.get("job_type")
    tables = step.get("tables")

    log.info("HANDLE_DDB_CONFIG_PULL_START", {
        "job_id": job_id,
        "job_type": job_type,
        "tables_count": len(tables) if isinstance(tables, list) else 0,
    })

    if not isinstance(tables, list) or len(tables) == 0:
        log.warn("HANDLE_DDB_CONFIG_PULL_NO_TABLES", {
            "reason": "tables missing, not a list, or empty",
        })
        return {}

    dynamodb = get_dynamodb_resource()
    results: dict = {}

    for table_name in tables:
        if not isinstance(table_name, str) or table_name == "":
            log.warn("HANDLE_DDB_CONFIG_PULL_SKIP_BAD_TABLE_NAME", {
                "table_value": repr(table_name),
            })
            continue

        table = dynamodb.Table(table_name)
        row = pull_config_from_table(
            table=table,
            table_name=table_name,
            job_id=job_id,
            job_type=job_type,
        )
        results[table_name] = row  # None if not found

    log.info("HANDLE_DDB_CONFIG_PULL_COMPLETE", {
        "job_id": job_id,
        "job_type": job_type,
        "pulled_count": len(results),
        "result_keys": list(results.keys()),
    })
    return results


def handle_unknown_pre_step(step: Any) -> dict:
    """
    Catch-all for unrecognised pre_step_type values. Logs the type seen;
    doesn't raise.
    """
    if isinstance(step, dict):
        unknown_type = step.get("pre_step_type", "<missing>")
    else:
        unknown_type = "<not-a-dict>"

    log.warn("HANDLE_UNKNOWN_PRE_STEP", {
        "status": "stub_called",
        "pre_step_type": unknown_type,
    })
    return {}
