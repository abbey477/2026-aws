# common/

Shared infrastructure code used by 2+ jobs. Subfolders:

- `repository/` — DAOs/repositories used across jobs (e.g., AuditRepository)
- `service/` — services used across jobs (e.g., NotificationService)
- `model/` — domain objects, enums, DTOs shared across jobs
- `exception/` — custom exception types
- `util/` — pure-function utilities (date, string, CSV helpers)

## Placement rule

Code lives at the lowest level where it's needed.

- If only Job A uses it → inside `jobs/joba/`, NOT here.
- Promote to `common/` only when a second job genuinely needs it.

Keep this folder small. It's not a junk drawer.
