package com.example.dbtester.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.List;
import java.util.Map;

/**
 * Strongly-typed binding of all datasource configuration, rooted at the
 * {@code app} prefix in {@code application.properties}.
 *
 * <p>Shape mirrors the properties file directly:
 * <pre>
 *   app.oracle.url = ...
 *   app.oracle.hikari.maximum-pool-size = 10
 *   app.oracle.properties.oracle.net.CONNECT_TIMEOUT = 10000
 *   app.oracle.validation-queries[0] = SELECT 1 FROM DUAL
 *
 *   app.sybase.url = ...
 *   app.sybase.hikari.maximum-pool-size = 10
 *   app.sybase.properties.DYNAMIC_PREPARE = true
 *   app.sybase.validation-queries[0] = SELECT 1
 * </pre>
 *
 * <p>Read from code as {@code props.oracle().url()} — named fields, IDE
 * autocomplete, no string-keyed lookups.
 */
@ConfigurationProperties(prefix = "app")
public record AppProperties(
        DbProps oracle,
        DbProps sybase
) {

    /**
     * Per-datasource settings. Shared between Oracle and Sybase because the
     * shape is identical; database-specific behavior lives in code (driver
     * class, URL format, validation query) rather than in the record.
     */
    public record DbProps(
            String url,
            String username,
            String password,
            String driverClassName,
            HikariProps hikari,
            /** Pass-through driver properties (e.g. DYNAMIC_PREPARE, oracle.net.CONNECT_TIMEOUT). */
            Map<String, String> properties,
            /** Queries used to test a pooled connection. First entry is used by Hikari. */
            List<String> validationQueries
    ) {}

    /**
     * HikariCP pool settings. All fields optional — unset values fall back
     * to Hikari's built-in defaults.
     */
    public record HikariProps(
            int maximumPoolSize,
            int minimumIdle,
            long connectionTimeoutMs,
            long idleTimeoutMs,
            long maxLifetimeMs,
            String poolName
    ) {}
}
