"""
GetConfig Lambda Handler

Fetches job configuration from DynamoDB.
Step 1: Fetch job_run row (latest or exact-by-last_updated_time for restart).
Step 2: Query job_config using job_id + job_type from the job_run row.

Input:
    Normal run:     { "run_id": "..." }
    Restart a run:  { "run_id": "...", "last_updated_time": "2024-03-15T10:00:00Z" }

Output: Merged payload — all job_run fields at top level, full job_config
        nested under "job_config" key.

AWS Lambda handler entry point: get_config.handler.lambda_handler
"""

import json
from datetime import datetime, timezone

from get_config import logging_utils as log
from get_config.dynamodb_ops import (
    JOB_RUN_TABLE,
    JOB_CONFIG_TABLE,
    get_dynamodb_resource,
    get_job_run,
    get_job_config,
)
from get_config.log_to_dynamo import write_log


def lambda_handler(event, context):
    """
    Lambda entry point.

    Input event:
        { "run_id": "..." }
        or
        { "run_id": "...", "last_updated_time": "2024-03-15T10:00:00Z" }

    Output: merged payload.

    Error handling:
        All exceptions are caught, logged, written to the logs table as
        FAILED, then re-raised so Step Functions' Catch block routes to
        HandleError. This keeps the logs table and CloudWatch in sync.
    """
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    log.info("HANDLER_START", {
        "timestamp": timestamp,
        "input_event": json.dumps(event),
    })

    # Extract run_id and job_id early so they're available in the except
    # block for the FAILED log — even if the error happens mid-flow.
    run_id = event.get("run_id") or "<missing>"
    job_id = "<unknown>"

    try:
        # --- Validate input ---
        if run_id == "<missing>":
            raise ValueError("Missing required input: 'run_id'")

        # Optional — only supplied by Step Function for restart flows.
        # Empty/None means "give me the latest row" (normal case).
        last_updated_time = event.get("last_updated_time")

        log.info("INPUT_VALIDATED", {
            "run_id": run_id,
            "last_updated_time": last_updated_time or "<not provided - will fetch latest>",
        })

        dynamodb = get_dynamodb_resource()

        # --- Step 1: Get job run metadata ---
        log.info("STEP_1", {
            "action": "Fetching job_run row",
            "run_id": run_id,
            "mode": "exact" if last_updated_time else "latest",
        })
        job_run_table = dynamodb.Table(JOB_RUN_TABLE)
        job_run = get_job_run(job_run_table, run_id, last_updated_time)

        # --- Extract keys for config lookup ---
        job_id = job_run.get("job_id") or "<unknown>"
        job_type = job_run.get("job_type")

        if job_id == "<unknown>" or not job_type:
            raise ValueError(
                f"job_run record is missing 'job_id' or 'job_type'. "
                f"Got job_id={job_id}, job_type={job_type}"
            )

        # --- Step 2: Get job configuration ---
        log.info("STEP_2", {
            "action": "Querying job_config table",
            "job_id": job_id,
            "job_type": job_type,
        })
        job_config_table = dynamodb.Table(JOB_CONFIG_TABLE)
        job_config = get_job_config(job_config_table, job_id, job_type)

        # --- Build merged output ---
        output = {**job_run, "job_config": job_config}

        log.info("HANDLER_COMPLETE", {
            "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "run_id": run_id,
            "job_id": job_id,
            "job_type": job_type,
            "runner_name": job_config.get("job_runner", {}).get("name", "N/A"),
            "output_keys": list(output.keys()),
        })

        write_log(run_id=run_id, job_id=job_id, stage="GetConfig", status="SUCCESS")
        return output

    except Exception as e:
        # Log the failure clearly, write a FAILED record to the logs table,
        # then re-raise so Step Functions' Catch block routes to HandleError.
        log.error("HANDLER_FAILED", {
            "run_id": run_id,
            "job_id": job_id,
            "error_type": type(e).__name__,
            "error_message": str(e),
        })
        write_log(run_id=run_id, job_id=job_id, stage="GetConfig", status="FAILED")
        raise
