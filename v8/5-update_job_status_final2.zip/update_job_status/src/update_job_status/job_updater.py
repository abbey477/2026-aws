"""
job_updater.py
DynamoDB update operations for the UpdateJobStatus Lambda.

Each function targets one status transition and returns the updated item
attributes so callers can record them without an extra read.
"""

from .logger import log_step
from .time_utils import (
    get_current_time_iso,
    get_extended_expiry_iso,
    get_next_minute_iso,
)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _run_update(table, run_id: str, update_expression: str,
                attr_names: dict, attr_values: dict) -> dict:
    """
    Execute a DynamoDB update_item call and return the updated attributes.

    Centralising the call here removes repetitive boilerplate from every
    status function and gives one place to add retries / error handling.
    """
    kwargs = {
        "Key": {"run_id": run_id},
        "UpdateExpression": update_expression,
        "ExpressionAttributeValues": attr_values,
        "ReturnValues": "ALL_NEW",
    }
    # Only add ExpressionAttributeNames if there are any (DynamoDB rejects empty dict)
    if attr_names:
        kwargs["ExpressionAttributeNames"] = attr_names

    response = table.update_item(**kwargs)
    return response.get("Attributes", {})


# ---------------------------------------------------------------------------
# Status update functions
# ---------------------------------------------------------------------------

def update_job_run_success(table, run_id: str) -> dict:
    """
    Mark a job run as SUCCESS and update all time attributes.

    Sets: status -> SUCCESS, end_time, last_heartbeat_time.
    """
    now = get_current_time_iso()
    log_step(
        "UPDATE_SUCCESS",
        {"run_id": run_id, "new_status": "SUCCESS", "end_time": now},
    )

    attrs = _run_update(
        table,
        run_id,
        update_expression=(
            "SET #status = :status, "
            "end_time = :end_time, "
            "last_heartbeat_time = :heartbeat"
        ),
        attr_names={"#status": "status"},
        attr_values={
            ":status": "SUCCESS",
            ":end_time": now,
            ":heartbeat": now,
        },
    )

    log_step(
        "UPDATE_SUCCESS_DONE",
        {"run_id": run_id, "status": attrs.get("status", "N/A")},
    )
    return attrs


def update_job_run_trigger_failed(table, run_id: str) -> dict:
    """
    Mark a job run back to WAITING and set next_scheduled_run_time to the
    next minute (ready for re-trigger).
    """
    next_min = get_next_minute_iso()
    log_step(
        "UPDATE_TRIGGER_FAILED",
        {
            "run_id": run_id,
            "new_status": "WAITING",
            "next_scheduled_run_time": next_min,
        },
    )

    attrs = _run_update(
        table,
        run_id,
        update_expression=(
            "SET #status = :status, "
            "next_scheduled_run_time = :next_run"
        ),
        attr_names={"#status": "status"},
        attr_values={
            ":status": "WAITING",
            ":next_run": next_min,
        },
    )

    log_step(
        "UPDATE_TRIGGER_FAILED_DONE",
        {"run_id": run_id, "status": attrs.get("status", "N/A")},
    )
    return attrs


def update_job_run_still_running(table, run_id: str) -> dict:
    """
    Update heartbeat and extend expiry for a still-running job.

    Sets: last_heartbeat_time, expiry_time (+5 minutes).
    """
    now = get_current_time_iso()
    expiry = get_extended_expiry_iso(minutes=5)
    log_step(
        "UPDATE_HEARTBEAT",
        {
            "run_id": run_id,
            "last_heartbeat_time": now,
            "expiry_time": expiry,
        },
    )

    attrs = _run_update(
        table,
        run_id,
        update_expression=(
            "SET last_heartbeat_time = :heartbeat, "
            "expiry_time = :expiry"
        ),
        attr_names={},
        attr_values={
            ":heartbeat": now,
            ":expiry": expiry,
        },
    )

    log_step(
        "UPDATE_HEARTBEAT_DONE",
        {
            "run_id": run_id,
            "last_heartbeat_time": attrs.get("last_heartbeat_time", "N/A"),
            "expiry_time": attrs.get("expiry_time", "N/A"),
        },
    )
    return attrs


def update_job_run_failed(
    table, run_id: str, error_message: str = ""
) -> dict:
    """
    Mark a job run as FAILED and persist the error message.

    Sets: status -> FAILED, end_time, last_heartbeat_time, error.
    """
    now = get_current_time_iso()
    log_step(
        "UPDATE_FAILED",
        {
            "run_id": run_id,
            "new_status": "FAILED",
            "end_time": now,
            "error": error_message or "N/A",
        },
        level="ERROR",
    )

    attrs = _run_update(
        table,
        run_id,
        update_expression=(
            "SET #status = :status, "
            "end_time = :end_time, "
            "last_heartbeat_time = :heartbeat, "
            "#error = :error"
        ),
        attr_names={"#status": "status", "#error": "error"},
        attr_values={
            ":status": "FAILED",
            ":end_time": now,
            ":heartbeat": now,
            ":error": error_message,
        },
    )

    log_step(
        "UPDATE_FAILED_DONE",
        {"run_id": run_id, "status": attrs.get("status", "N/A")},
        level="ERROR",
    )
    return attrs
