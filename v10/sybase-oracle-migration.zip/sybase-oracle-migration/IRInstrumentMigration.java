import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;

import java.util.ArrayList;
import java.util.List;

/**
 * Streaming migration for IRInstrument (Sybase -> Oracle).
 *
 * <p>Streams rows from Sybase via {@link RowCallbackHandler}, buffers them, and
 * flushes batches to Oracle through {@link IRInstrumentOracleRepository}.
 * Memory is bounded at ~BATCH_SIZE rows.
 *
 * <p>Row mapping is delegated to {@link IRInstrumentRowMapper}; see that class
 * for type-handling notes.
 *
 * <p>Two variants for A/B comparison: {@link #migrateByIndex()} (positional,
 * fastest) and {@link #migrateByName()} (by name, robust to SELECT reordering).
 */
@Slf4j
public class IRInstrumentMigration {

    private static final int FETCH_SIZE = 2000;
    private static final int BATCH_SIZE = 5000;

    /**
     * SELECT column order MUST match the order used by
     * {@link IRInstrumentRowMapper#mapByIndex} when reading positionally.
     */
    private static final String SELECT_SQL =
            "SELECT ID_IMNT, ID_CLEAN_DIRTY, AM_FACT_TIME, ID_ACCR_TRD, ID_RULE_TRUNC_ACCR, " +
            "       ID_ACT_PCT, ID_CV_DYBU, ID_FREQ_CPN, RT_CPN, ID_CPN_EOM, " +
            "       ID_EOM_LEAP, DT_CPN_FRT, DT_CPN_LST, AM_VAL_PAR, PR_EXPY, " +
            "       ID_TYP_CPN, DT_START_ACCR, RT_TAX_CPN, ID_RANK_DEBT, CT_EXDIV_MAX, " +
            "       ID_RULE_EXDIV, ID_ODD_LAST, ID_ACCR_MAX, CT_RECORD, ID_RECORD_BUS_DAYS, " +
            "       DT_END_ACCR, ID_ADJ_ACCR, ID_CPN_CREEP, ID_ACCR_CALL, ID_ACCR_PUT, " +
            "       RT_RECOVERY, ID_DEFAULT, DT_DEFAULT, ID_LE_DEF, ID_CALC_TYP, " +
            "       AM_CALLABLE_DAYS, ID_CONT_CALLABLE, AM_SETTLE_DAYS, ID_SERIES, NM_REF_INDEX, " +
            "       ID_TYP_COUPON, NM_GMX_OWNER, ID_VARS_BCHMRK, ID_GEM_CUSTOM_CLASS, DT_CHG_GRD, " +
            "       ID_DEL_GRD, ID_OWN_GRD " +
            "FROM IR_INSTRUMENT";

    private static final String TABLE_LABEL = "IR_INSTRUMENT";

    private final JdbcTemplate sybaseJdbcTemplate;
    private final IRInstrumentOracleRepository oracleRepo;

    public IRInstrumentMigration(
            @Qualifier("sybaseJdbcTemplate") JdbcTemplate sybaseJdbcTemplate,
            IRInstrumentOracleRepository oracleRepo) {
        this.sybaseJdbcTemplate = sybaseJdbcTemplate;
        this.oracleRepo = oracleRepo;

        // CRITICAL: without this jconn4 uses a tiny default fetch size.
        this.sybaseJdbcTemplate.setFetchSize(FETCH_SIZE);
    }

    /** Variant A — positional read. */
    public void migrateByIndex() {
        run("byIndex", IRInstrumentRowMapper::mapByIndex);
    }

    /** Variant B — by-name read. */
    public void migrateByName() {
        run("byName", IRInstrumentRowMapper::mapByName);
    }

    /**
     * Shared streaming pipeline. The variants only differ in which mapper they pass in,
     * so the orchestration is parameterized to avoid code duplication.
     */
    private void run(String variant, RowMapperFn mapper) {
        log.info("[{}] Starting migration (variant={}, fetchSize={}, batchSize={})",
                TABLE_LABEL, variant, FETCH_SIZE, BATCH_SIZE);
        final long startNanos = System.nanoTime();

        oracleRepo.truncate();

        final List<IRInstrument> buffer = new ArrayList<>(BATCH_SIZE);
        final MigrationStats stats = new MigrationStats();

        sybaseJdbcTemplate.query(SELECT_SQL, (RowCallbackHandler) rs -> {
            buffer.add(mapper.apply(rs));
            if (buffer.size() >= BATCH_SIZE) {
                flush(stats, buffer);
            }
        });

        if (!buffer.isEmpty()) {
            flush(stats, buffer);
        }

        logCompletion(variant, stats, startNanos);
    }

    private void flush(MigrationStats stats, List<IRInstrument> buffer) {
        final int rowsInThisBatch = buffer.size();
        final long batchStartNanos = System.nanoTime();

        oracleRepo.batchInsert(buffer);

        final long batchElapsedMs = (System.nanoTime() - batchStartNanos) / 1_000_000;
        stats.batchCount++;
        stats.totalRows += rowsInThisBatch;

        log.debug("[{}] Batch {} complete — rows={}, elapsedMs={}, totalRowsSoFar={}",
                TABLE_LABEL, stats.batchCount, rowsInThisBatch, batchElapsedMs, stats.totalRows);

        buffer.clear();
    }

    private void logCompletion(String variant, MigrationStats stats, long startNanos) {
        final long totalElapsedMs = (System.nanoTime() - startNanos) / 1_000_000;
        final double seconds = Math.max(totalElapsedMs / 1000.0, 0.001);
        final long rowsPerSec = (long) (stats.totalRows / seconds);

        log.info("[{}] Migration complete (variant={}) — totalRows={}, batches={}, elapsedMs={}, throughput={} rows/sec",
                TABLE_LABEL, variant, stats.totalRows, stats.batchCount, totalElapsedMs, rowsPerSec);
    }

    /** Functional interface so we can pass a checked-exception-throwing mapper as a method reference. */
    @FunctionalInterface
    private interface RowMapperFn {
        IRInstrument apply(java.sql.ResultSet rs) throws java.sql.SQLException;
    }

    private static final class MigrationStats {
        long totalRows = 0;
        int batchCount = 0;
    }
}
