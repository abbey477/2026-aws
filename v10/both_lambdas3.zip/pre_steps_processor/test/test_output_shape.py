"""
Output shape contract.

Return includes:
- job_param: copied from input as-is
- step handler results: keyed by pre_step_type
- No input event fields (run_id, job_config etc.) — Step Functions preserves those
"""
from pre_steps_processor.handler import lambda_handler
from seed_data import make_event


class TestOutputShape:

    def test_output_does_not_contain_event_fields(self, mocks):
        """run_id, job_config etc. should NOT be in the return."""
        result = lambda_handler(make_event(pre_steps=[{"pre_step_type": "change_since_append"}]), None)
        assert "run_id" not in result
        assert "job_config" not in result
        assert "job_id" not in result

    def test_job_param_included_in_output(self, mocks):
        """job_param from the input event should be copied into the return."""
        result = lambda_handler(make_event(pre_steps=[]), None)
        assert "job_param" in result
        assert result["job_param"]["source"]["type"] == "API"
        assert result["job_param"]["source"]["name"] == "RDI"
        assert result["job_param"]["batch_size"] == 1000
        assert result["job_param"]["thread_count"] == 10
        assert "data.schemaVersion=1" in result["job_param"]["source"]["url"]

    def test_job_param_unchanged_from_input(self, mocks):
        """job_param should be an exact copy — not modified."""
        event = make_event(pre_steps=[])
        original_job_param = event["job_config"]["job_param"].copy()
        result = lambda_handler(event, None)
        assert result["job_param"] == original_job_param

    def test_empty_results_still_has_job_param(self, mocks):
        """No pre_steps → only job_param in the return."""
        result = lambda_handler(make_event(), None)
        assert "job_param" in result
        assert "change_since_append" not in result
        assert "ddb_config_pull" not in result

    def test_handler_result_keyed_by_pre_step_type(self, mocks):
        mocks["change_since"].return_value = {"last_successful_start_time": "2024-05-15T08:30:00Z"}
        result = lambda_handler(
            make_event(pre_steps=[{"pre_step_type": "change_since_append"}]), None,
        )
        assert "change_since_append" in result
        assert result["change_since_append"]["last_successful_start_time"] == "2024-05-15T08:30:00Z"

    def test_multiple_results_each_keyed_separately(self, mocks):
        mocks["change_since"].return_value = {"a": 1}
        mocks["ddb_pull"].return_value = {"service_config": {"b": 2}}
        result = lambda_handler(
            make_event(pre_steps=[
                {"pre_step_type": "change_since_append"},
                {"pre_step_type": "ddb_config_pull"},
            ]), None,
        )
        assert result["change_since_append"] == {"a": 1}
        assert result["ddb_config_pull"] == {"service_config": {"b": 2}}
        assert "job_param" in result  # still present

    def test_empty_handler_result_not_added(self, mocks):
        mocks["ddb_pull"].return_value = {}
        mocks["change_since"].return_value = {"something": "value"}
        result = lambda_handler(
            make_event(pre_steps=[
                {"pre_step_type": "change_since_append"},
                {"pre_step_type": "ddb_config_pull"},
            ]), None,
        )
        assert "change_since_append" in result
        assert "ddb_config_pull" not in result

    def test_no_job_param_in_input_still_works(self, mocks):
        """If job_param is empty in input, it's not included in the return."""
        event = make_event(pre_steps=[], job_param={})
        result = lambda_handler(event, None)
        # Empty dict is falsy — so job_param won't be in results
        assert "job_param" not in result
