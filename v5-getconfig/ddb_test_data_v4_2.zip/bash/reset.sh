#!/usr/bin/env bash
# reset.sh — cleanup + setup in one go
set -euo pipefail
cd "$(dirname "$0")"

./cleanup.sh
echo ""
echo "=== Cleanup complete, starting setup ==="
echo ""
./setup.sh
