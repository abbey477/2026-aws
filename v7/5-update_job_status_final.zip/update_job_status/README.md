# update_job_status

AWS Lambda that updates the `job_run` DynamoDB table based on the final job outcome
(SUCCESS, TRIGGER_FAILED, RUNNING, FAILED).

---

## Project structure

```
update_job_status/
├── pyproject.toml          ← project config + dependencies (like pom.xml in Maven)
├── poetry.toml             ← Poetry settings (keeps .venv inside the project)
├── Makefile                ← shortcuts: make install / test / build
├── .gitignore
├── README.md
├── src/
│   └── update_job_status/  ← the Python package that gets deployed
│       ├── __init__.py
│       ├── handler.py          Lambda entry point
│       ├── constants.py        JobStatus enum, env config
│       ├── logger.py           structured logging + LOG_LEVEL support
│       ├── time_utils.py       ISO 8601 timestamp helpers
│       ├── dynamo_client.py    boto3 DynamoDB resource factory
│       ├── job_updater.py      DynamoDB update operations
│       └── log_to_dynamo.py    shared audit log writer
└── test/
    ├── __init__.py
    ├── conftest.py             shared pytest fixtures
    ├── test_success.py
    ├── test_trigger_failed.py
    ├── test_running.py
    ├── test_failed.py
    └── test_edge_cases.py
```

---

## First-time setup (new to Python? start here)

### 1. Install Poetry

Poetry is the tool that manages Python dependencies for this project — the same way Maven manages them for Java.

```bash
curl -sSL https://install.python-poetry.org | python3 -
```

Verify it worked:

```bash
poetry --version
```

### 2. Install the project

From inside the `update_job_status/` folder, run:

```bash
poetry install
```

This will:
- Create a virtual environment in `.venv/` (your own isolated Python just for this project)
- Install `boto3` (runtime dependency)
- Install `pytest` and `moto` (test dependencies)

You only need to run this once (and again whenever dependencies change in `pyproject.toml`).

---

## Running tests

```bash
poetry run pytest
```

Or using the Makefile shortcut:

```bash
make test
```

You should see **17 tests** all passing.

---

## Building the Lambda deployment zip

```bash
make build
```

This produces `dist/update_job_status.zip` — upload that to AWS Lambda.

The zip contains:
- Your source code from `src/update_job_status/`
- All runtime dependencies from `pyproject.toml`

---

## Everyday commands

| Command | What it does |
|---|---|
| `poetry install` | Install all dependencies |
| `poetry add <package>` | Add a new runtime dependency |
| `poetry add --group dev <package>` | Add a new dev/test dependency |
| `poetry run pytest` | Run tests |
| `poetry run python` | Start a Python shell with project deps available |
| `poetry shell` | Activate the virtual environment |
| `make test` | Run tests (Makefile shortcut) |
| `make build` | Build Lambda deployment zip |
| `make clean` | Remove build artifacts |

---

## Environment variables

| Variable | Default | Purpose |
|---|---|---|
| `JOB_RUN_TABLE` | `job_run` | DynamoDB table to update |
| `LOGS_TABLE` | `logs` | Audit log table |
| `LOG_LEVEL` | `INFO` | `DEBUG` / `INFO` / `WARNING` / `ERROR` / `CRITICAL` |

---

## How the handler decides what to do

```
trigger_status == "TRIGGER_FAILED"  →  mark WAITING, set next_scheduled_run_time
job_status     == "SUCCESS"         →  mark SUCCESS, record end_time
job_status     == "RUNNING"         →  update heartbeat, extend expiry +5min
job_status     == "FAILED"          →  mark FAILED, save error message
anything else                       →  treat as FAILED with a diagnostic message
```

---

## Troubleshooting

**`poetry: command not found`**
Poetry's install location isn't on your PATH. Either reopen your terminal or add `~/.local/bin` to your PATH.

**Tests fail with `ModuleNotFoundError: No module named 'update_job_status'`**
Run `poetry install` first. This installs your package in editable mode so tests can import it.

**Tests fail with `ModuleNotFoundError: No module named 'moto'`**
Run `poetry install` (without flags) to also install dev dependencies.
