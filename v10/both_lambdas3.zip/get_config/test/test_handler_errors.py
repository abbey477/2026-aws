"""Error handling — verifies FAILED log + re-raise on every error path."""
import pytest
from botocore.exceptions import ClientError
from get_config.handler import lambda_handler
from seed_data import make_job_run_item, raise_access_denied


class TestHandlerErrorLogging:

    def test_missing_run_id_writes_failed(self, patched_handler, mock_write_log):
        with pytest.raises(ValueError):
            lambda_handler({}, None)
        mock_write_log.assert_called_once_with(
            run_id="<missing>", job_id="<unknown>", stage="GetConfig", status="FAILED",
        )

    def test_not_found_writes_failed(self, patched_handler, mock_write_log):
        with pytest.raises(ValueError):
            lambda_handler({"run_id": "nonexistent"}, None)
        mock_write_log.assert_called_once_with(
            run_id="nonexistent", job_id="<unknown>", stage="GetConfig", status="FAILED",
        )

    def test_missing_job_config_writes_failed(self, patched_handler, mock_write_log):
        patched_handler.Table("app-jobRun").put_item(Item=make_job_run_item(
            run_id="run-orphan", job_type="nonexistent_type",
        ))
        with pytest.raises(ValueError):
            lambda_handler({"run_id": "run-orphan"}, None)
        mock_write_log.assert_called_once_with(
            run_id="run-orphan", job_id="client", stage="GetConfig", status="FAILED",
        )

    def test_client_error_writes_failed(self, patched_handler, monkeypatch, mock_write_log):
        patched_table = patched_handler.Table("app-jobRun")
        monkeypatch.setattr(patched_table, "query", raise_access_denied)
        original_table = patched_handler.Table
        monkeypatch.setattr(patched_handler, "Table",
            lambda name: patched_table if name == "app-jobRun" else original_table(name))
        with pytest.raises(ClientError):
            lambda_handler({"run_id": "run-001"}, None)
        mock_write_log.assert_called_once_with(
            run_id="run-001", job_id="<unknown>", stage="GetConfig", status="FAILED",
        )

    def test_success_writes_success(self, patched_handler, mock_write_log):
        lambda_handler({"run_id": "run-001"}, None)
        mock_write_log.assert_called_once_with(
            run_id="run-001", job_id="client", stage="GetConfig", status="SUCCESS",
        )
