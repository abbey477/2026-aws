package com.example.dbtester.entity;

import java.math.BigDecimal;

/**
 * Immutable domain record mapped to the Oracle PRODUCT table.
 *
 * <p>Records are a natural fit for row-mapped JDBC entities: the canonical
 * constructor lines up directly with column values pulled out of a ResultSet,
 * there's no setter ceremony, and equals/hashCode/toString come free.
 *
 * <p>Schema (see {@code oracle-schema.sql}):
 * <pre>
 *   id        NUMBER(19)    PRIMARY KEY,
 *   sku       VARCHAR2(50)  UNIQUE NOT NULL,
 *   name      VARCHAR2(200) NOT NULL,
 *   price     NUMBER(12,2)  NOT NULL,
 *   in_stock  NUMBER(1)     NOT NULL         -- 0 or 1, maps to boolean
 * </pre>
 *
 * <p>Field notes:
 * <ul>
 *   <li>{@code id} is boxed ({@code Long}, not {@code long}) so we can pass
 *       null when a product hasn't been persisted yet.</li>
 *   <li>{@code price} uses {@code BigDecimal} — never use double for money.</li>
 *   <li>{@code inStock} is a plain boolean; the row mapper translates 0/1.</li>
 * </ul>
 */
public record Product(
        Long id,
        String sku,
        String name,
        BigDecimal price,
        boolean inStock
) {}
