# PartiQL Seed Data — Plan B for Console

Same seed data as the CLI bundle, but rendered as PartiQL `INSERT` statements you can paste directly into the DynamoDB console's PartiQL editor.

## Files

| File | Statements | Target table |
|---|---|---|
| `app-jobConfig.partiql.sql` | 15 | `app-jobConfig` |
| `app-jobRun.partiql.sql` | 50 | `app-jobRun` |
| `app-jobLog.partiql.sql` | 100 | `app-jobLog` |

## How to use

1. AWS Console → DynamoDB → **PartiQL editor** (left sidebar)
2. Open one of the `.sql` files in any text editor
3. Copy one `INSERT` statement, paste it into the editor, click **Run**
4. Repeat, or batch a few at a time if the UI accepts multiple

**Load order matters for referential sanity:**
`app-jobConfig` first → `app-jobRun` → `app-jobLog`

(The data will technically insert in any order since DynamoDB doesn't enforce FKs, but loading parents first keeps the test data consistent if you scan mid-load.)

## Quick verify after loading

Run these in the PartiQL editor:

```sql
SELECT COUNT(*) FROM "app-jobConfig";
SELECT COUNT(*) FROM "app-jobRun";
SELECT COUNT(*) FROM "app-jobLog";
```

Expected: 15, 50, 100.

## Notes

- Table names are double-quoted because they contain hyphens.
- Strings use single quotes.
- If the editor complains about any specific statement, it's likely a reserved-word collision on an attribute name — flag it and I'll rework that file.
- PartiQL in the console runs one statement at a time. For the 100 jobLog rows this gets tedious — if the CLI is working at all, prefer it for jobLog.
