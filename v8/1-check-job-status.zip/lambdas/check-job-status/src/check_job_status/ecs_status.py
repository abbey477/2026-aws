"""
ECS Fargate status check.

Checks the status of an ECS Fargate task by calling describe_tasks
and interpreting the container exit codes.

Returns a dict with:
    job_status : "SUCCESS" | "RUNNING" | "FAILED"
    output     : (optional) dict with task_arn on success
    error      : (optional) error message on failure
    exit_codes : (optional) dict of container exit codes on failure
"""

import logging

import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


def _log(step: str, details: dict):
    """Structured info log – every line has a step tag + key-value pairs."""
    detail_str = ", ".join(f"{k}={v}" for k, v in details.items())
    logger.info(f"[EcsStatus] [{step}] {detail_str}")


def get_ecs_client():
    """Return an ECS client. Separated for easy mocking in tests."""
    return boto3.client("ecs")


def check_ecs_task_status(ecs_client, task_arn: str, runner_config: dict) -> dict:
    """
    Check the status of an ECS Fargate task.

    Args:
        ecs_client: boto3 ECS client.
        task_arn: The ARN of the ECS task to check.
        runner_config: Runner config from job_config.job_runner.config
                       (contains cluster, subnets, etc.).

    Returns:
        dict with job_status and optional output details.
    """
    ecs_cluster = runner_config.get("cluster", "")
    _log("ECS_CHECK_START", {"task_arn": task_arn, "cluster": ecs_cluster})

    try:
        response = ecs_client.describe_tasks(
            cluster=ecs_cluster,
            tasks=[task_arn],
        )

        tasks = response.get("tasks", [])
        _log("ECS_DESCRIBE_RESPONSE", {"tasks_returned": len(tasks)})

        if not tasks:
            _log("ECS_TASK_NOT_FOUND", {"task_arn": task_arn, "resolution": "Marking FAILED"})
            return {"job_status": "FAILED", "error": "Task not found"}

        task = tasks[0]
        last_status = task.get("lastStatus", "UNKNOWN")
        _log("ECS_TASK_STATUS", {"lastStatus": last_status, "task_arn": task_arn})

        if last_status == "STOPPED":
            containers = task.get("containers", [])
            stopped_reason = task.get("stoppedReason", "")

            for c in containers:
                _log("ECS_CONTAINER_RESULT", {
                    "name": c.get("name", "N/A"),
                    "exitCode": c.get("exitCode", "N/A"),
                })

            all_success = all(
                c.get("exitCode", -1) == 0 for c in containers
            )

            if all_success:
                output = {}
                for container in containers:
                    if container.get("name") and container.get("exitCode") == 0:
                        output["task_arn"] = task_arn
                _log("ECS_COMPLETED", {"result": "SUCCESS", "stopped_reason": stopped_reason})
                return {"job_status": "SUCCESS", "output": output}
            else:
                exit_codes = {
                    c.get("name"): c.get("exitCode") for c in containers
                }
                _log("ECS_COMPLETED", {
                    "result": "FAILED",
                    "stopped_reason": stopped_reason,
                    "exit_codes": exit_codes,
                })
                return {
                    "job_status": "FAILED",
                    "error": stopped_reason,
                    "exit_codes": exit_codes,
                }
        else:
            _log("ECS_STILL_RUNNING", {"lastStatus": last_status})
            return {"job_status": "RUNNING"}

    except ClientError as e:
        _log("ECS_CLIENT_ERROR", {
            "error_code": e.response["Error"]["Code"],
            "error_message": e.response["Error"]["Message"],
        })
        return {"job_status": "FAILED", "error": str(e)}
