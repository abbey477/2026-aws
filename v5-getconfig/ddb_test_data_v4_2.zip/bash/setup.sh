#!/usr/bin/env bash
# setup.sh — load seed data into app-jobConfig, app-jobRun, app-jobLog
set -euo pipefail
cd "$(dirname "$0")"

FILES=(
  "app-jobConfig_part1_of_1.json"
  "app-jobRun_part1_of_2.json"
  "app-jobRun_part2_of_2.json"
  "app-jobLog_part1_of_4.json"
  "app-jobLog_part2_of_4.json"
  "app-jobLog_part3_of_4.json"
  "app-jobLog_part4_of_4.json"
)

echo "=== Loading seed data ==="
for f in "${FILES[@]}"; do
  echo ">>> $f"
  aws dynamodb batch-write-item --request-items "file://$f" > /dev/null
  echo "    OK"
done

echo ""
echo "Counts:"
for t in app-jobConfig app-jobRun app-jobLog; do
  c=$(aws dynamodb scan --table-name "$t" --select COUNT --query Count --output text)
  echo "  $t: $c"
done
echo "Expected: 15, 50, 100"
