"""Repository-level tests for get_job_run — isolates the DAO from the handler."""

import pytest
from botocore.exceptions import ClientError

from get_config.dynamodb_ops import get_job_run
from seed_data import make_job_run_item, raise_access_denied


class TestGetJobRunLatest:
    """Default (no SK) returns the newest row for a run_id."""

    def test_returns_item_when_found(self, dynamodb_tables):
        table = dynamodb_tables.Table("job_run")
        result = get_job_run(table, "run-001")
        assert result["run_id"] == "run-001"
        assert result["job_id"] == "client"

    def test_returns_newest_when_multiple_rows_exist(self, dynamodb_tables):
        table = dynamodb_tables.Table("job_run")
        table.put_item(Item=make_job_run_item(
            run_id="run-001",
            last_updated_time="2024-06-01T00:00:00Z",
            status="RUNNING",
        ))
        table.put_item(Item=make_job_run_item(
            run_id="run-001",
            last_updated_time="2024-12-01T00:00:00Z",
            status="SUCCESS",
        ))

        result = get_job_run(table, "run-001")
        assert result["last_updated_time"] == "2024-12-01T00:00:00Z"
        assert result["status"] == "SUCCESS"

    def test_raises_when_not_found(self, dynamodb_tables):
        table = dynamodb_tables.Table("job_run")
        with pytest.raises(ValueError, match="No job_run found"):
            get_job_run(table, "does-not-exist")

    def test_raises_on_client_error(self, dynamodb_tables, monkeypatch):
        """Latest-mode uses query(), so we patch that."""
        table = dynamodb_tables.Table("job_run")
        monkeypatch.setattr(table, "query", raise_access_denied)

        with pytest.raises(ClientError):
            get_job_run(table, "run-001")


class TestGetJobRunExact:
    """With SK passed → exact get_item; used for Step Function restarts."""

    def test_exact_fetch_returns_specific_row(self, dynamodb_tables):
        table = dynamodb_tables.Table("job_run")
        table.put_item(Item=make_job_run_item(
            run_id="run-001",
            last_updated_time="2024-06-01T00:00:00Z",
            status="RUNNING",
        ))
        table.put_item(Item=make_job_run_item(
            run_id="run-001",
            last_updated_time="2024-12-01T00:00:00Z",
            status="SUCCESS",
        ))

        result = get_job_run(table, "run-001", "2024-06-01T00:00:00Z")
        assert result["last_updated_time"] == "2024-06-01T00:00:00Z"
        assert result["status"] == "RUNNING"

    def test_exact_fetch_raises_when_row_not_present(self, dynamodb_tables):
        table = dynamodb_tables.Table("job_run")
        with pytest.raises(ValueError, match="No job_run found"):
            get_job_run(table, "run-001", "2099-01-01T00:00:00Z")
